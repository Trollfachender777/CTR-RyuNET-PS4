# Linux implementation and source

`build.py` is the native Linux front-end. `build_linux.py` assembles the approved
PS4 integration and calls the retained native emulation and packaging checks.
The package engine is the same source used by the final Windows builders,
including complete-block PFSC reads. Linux extraction additionally validates
paths using the host filesystem's case rules and rejects traversal/drive paths.

`Approved/` retains the English builder's complete integration source and its
upstream credits/licenses. `SpanishOverrides/` contains the files differing in
the approved Spanish edition; they are applied to a temporary source copy when
Spanish is selected. Native source hashes must match the selected module.

`Payload/` in the main folder contains the two exact approved PS4 SELF modules
and a deterministic homebrew-only integration recipe. No game executable or
asset is supplied. The recipe records our loader/routing code, program-header
metadata, import-routing jumps, and the existing community compatibility/FPS
patches. Every input ELF must match its approved SHA-256, and every integrated
ELF must reproduce the approved final SHA-256 before wrapping or packaging.
An incompatible image stops the process instead of guessing offsets.

The prebuilt modules are byte-identical to the already approved EN/ES modules.
They keep the per-local-user identity setup and all accepted settings. Normal
construction needs no LLVM or create-fself compilation. Developers can inspect
the retained source, original tool references, and source-release manifests.

The native Linux runtimes are official PowerShell, CPython builds distributed
by python-build-standalone, and the pinned Unicorn wheel. Their upstream URLs,
versions, sizes and SHA-256 values are recorded in `Tools/runtimes.json` in the
main folder. The upstream archives and their notices are retained unchanged.

The Linux port is by Trollfachender777 with assistance from AI. Original PC,
RyuNET, PS4 toolchain, library and tool authors retain their credits in
`Approved/docs/CREDITS.md` and the original project notices.

## Validation scope

Tests distinguish Windows host verification from native Linux execution.
`tests/test_package_backend.py` builds an encrypted synthetic PKG, validates
container checks, extracts and compares every test payload, and rejects damaged
packages and unsafe paths. It also checks XTS against the original reference.
`tests/run_native_checks.py` runs the real approved PS4 SELF and loader under
Unicorn using synthetic ELF fixtures containing no game engine or assets.
Six cases which execute or compare original game instruction windows are
explicitly skipped in that game-free suite; they belong to the separately
recorded checks using the developer's own compatible inputs. They are not
reported as Linux passes.
`tests/test_linux_builder.py` covers input rejection, privacy, symlinks, advisory
locking, resource settings and progress. A record of those tests does not claim
a new physical PS4 installation, an end-to-end Linux build with a complete game,
or a race on a new network; those results are tracked separately.
