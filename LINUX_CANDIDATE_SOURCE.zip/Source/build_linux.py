# SPDX-License-Identifier: GPL-2.0-only
"""Assemble the approved PS4 integration on Linux without a Windows compiler."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import struct
import subprocess
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_module(path, name):
    if str(path.parent) not in sys.path:
        sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_payload(payload):
    manifest = json.loads((payload / 'MANIFEST.json').read_text(encoding='utf-8'))
    for name, expected in manifest.items():
        path = payload / name
        if path.is_symlink() or path.parent != payload or not path.is_file() or sha(path.read_bytes()) != expected:
            raise ValueError('Approved integration payload changed: ' + name)
    return json.loads((payload / 'integration.json').read_text(encoding='utf-8'))


def integrate_elf(original, patch):
    if sha(original) != patch['original_elf_sha256']:
        raise ValueError('Unsupported executable image: ' + patch['file'])
    if len(original) != patch['elf_bytes']:
        raise ValueError('Unexpected executable length: ' + patch['file'])
    result = bytearray(original)
    for write in patch['writes']:
        offset = write['offset']
        data = bytes.fromhex(write['hex'])
        if offset < 0 or offset + len(data) > len(result):
            raise ValueError('Integration write is outside the executable.')
        result[offset:offset + len(data)] = data
    if sha(result) != patch['integrated_elf_sha256']:
        raise ValueError('Integration differs from the approved PS4 executable: ' + patch['file'])
    return result


def assemble_images(code, game, payload):
    integration = read_payload(payload)
    port = code / 'work/crash-ryunet-port'
    current = code / 'work/crash-ryunet-vnext'
    (port / 'build').mkdir(exist_ok=True)
    (current / 'build').mkdir(exist_ok=True)
    parser_path = code / 'outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts/prepare.py'
    parser = load_module(parser_path, 'linux_input_elf')
    for patch in integration['patches']:
        original = parser.parse_self((game / patch['file']).read_bytes())[0]
        (port / 'build' / patch['elf_file']).write_bytes(integrate_elf(original, patch))
    profiles = json.loads((payload / 'native-profiles.json').read_text(encoding='utf-8'))
    (current / 'build/native-profiles.json').write_text(json.dumps(profiles, indent=2), encoding='utf-8')
    portable = [dict(profile, elf=str((current / profile['elf']).resolve())) for profile in profiles]
    (port / 'build/native-profiles.json').write_text(json.dumps(portable, indent=2), encoding='utf-8')
    return port, current


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=('package', 'integration'))
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--game', required=True, type=Path)
    parser.add_argument('--payload', required=True, type=Path)
    parser.add_argument('--package-script', required=True, type=Path)
    parser.add_argument('--pwsh', required=True)
    parser.add_argument('--menu-language', choices=('en', 'es'), default='en')
    args = parser.parse_args()
    code, game, payload = args.source.resolve(), args.game.resolve(), args.payload.resolve()
    env = os.environ.copy()
    env['CTR_GAME_DIR'] = str(game)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    def progress(step):
        print('CTR_PROGRESS|code|' + str(step) + '|8', flush=True)
    def run(script, *extra):
        subprocess.run([sys.executable, '-B', str(script), *map(str, extra)], cwd=code, env=env, check=True)
    def ps(script, *extra):
        subprocess.run([args.pwsh, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(script), *map(str, extra)], cwd=code, env=env, check=True)
    port, current = assemble_images(code, game, payload)
    progress(1)
    proof = json.loads((code / 'source-release.json').read_text(encoding='utf-8'))
    # Retained source files must still describe the approved module we package.
    for name, expected in proof['native_sources_exact'].items():
        path = (port / 'src' / name) if name in ('bootstrap.S', 'bootstrap_loader.c') else (current / 'src' / name)
        if sha(path.read_bytes()) != expected:
            raise ValueError('Approved native source changed: ' + name)
    module = payload / ('ctr_online_' + args.menu_language + '.prx')
    if sha(module.read_bytes()) != proof['module_self_sha256']:
        raise ValueError('PS4 module does not match the selected language/source.')
    shutil.copy2(module, current / 'build/ctr_online.prx')
    shutil.copy2(module, port / 'build/ctr_online.prx')
    progress(2)
    run(port / 'wrap_native_self.py')
    run(port / 'test_self_wrapper.py')
    run(port / 'prepare_external_module.py')  # Test plan only; never deployed or packaged.
    run(port / 'test_bootstrap.py')
    progress(3)
    run(current / 'test_native_bridge.py')
    progress(4)
    run(current / 'test_user_isolation.py')
    progress(5)
    if args.task == 'integration':
        print('Approved PS4 integration and native tests completed.', flush=True)
        return
    ps(port / 'test_package_crypto.ps1')
    progress(6)
    run(port / 'stage_package.py')
    progress(7)
    ps(args.package_script, 'pkg_build', port / 'build/native.gp4', port / 'build')
    generated = port / 'build/IV9999-RYUN00001_00-CRASHRYUNET00001.pkg'
    destination = port / 'build/CTR Nitro-Fueled Online - RyuNET.pkg'
    if destination.exists():
        raise ValueError('Refusing to overwrite an installer.')
    generated.rename(destination)
    run(port / 'verify_package_identity.py', destination)
    progress(8)
    print('Linux integration completed: ' + str(destination), flush=True)


if __name__ == '__main__':
    main()
