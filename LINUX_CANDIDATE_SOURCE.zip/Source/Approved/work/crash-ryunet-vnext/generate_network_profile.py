"""Extract explicit networking GOT slots from the two sealed game images."""
from pathlib import Path
import hashlib
import json
import re
import struct
import sys

root = Path(__file__).resolve().parent
portable = root.parents[1] / 'outputs/Crash_Online/CTR-NitroFueled-PC-portable'
sys.path.insert(0, str(portable / 'scripts'))
import prepare

names = dict(re.findall(r'STUB\("([^"]+)",\s*([^)\s]+)\s*\)',
                        (portable / 'out/aerolib.inl').read_text()))
wanted = {'sceNetBind', 'sceNetSendto', 'sceNetRecvfrom', 'sceNetSocketClose',
          'sceNetSend', 'sceNetRecv', 'sceNetGetsockname', 'sceNetGetsockopt',
          'sceNetErrnoLoc', 'sceKernelGetProcessTime',
          'sceNpGetGamePresenceStatus', 'sceNpRegisterGamePresenceCallback',
          'sceNpUnregisterGamePresenceCallback'}
records = []
images = json.loads((root / 'build/native-profiles.json').read_text())
for profile in images:profile['elf']=str((root/profile['elf']).resolve())
for index, profile in enumerate(images):
    raw = Path(profile['elf']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == profile['native_elf_sha256']
    elf, header, segments, _, _ = prepare.parse_elf(raw)
    dynamic = next(s for s in segments if s['type'] == 2)
    tags = dict(prepare.unpack('<QQ', elf, i)
                for i in range(dynamic['offset'], dynamic['offset'] + dynamic['filesz'], 16))
    dyn = next(s for s in segments if s['type'] == 0x61000000)
    blob = prepare.span(elf, dyn['offset'], dyn['filesz'])
    strings = prepare.span(blob, tags[0x61000035], tags[0x61000037])
    symbols = prepare.span(blob, tags[0x61000039], tags[0x6100003f])
    for offset, size in ((0x61000029, 0x6100002d), (0x6100002f, 0x61000031)):
        table = prepare.span(blob, tags[offset], tags[size])
        for i in range(0, len(table), 24):
            target, info, addend = prepare.unpack('<QQq', table, i)
            if info & 0xffffffff not in (1, 6, 7):
                continue
            n, typ, other, section, value, length = prepare.unpack('<IBBHQQ', symbols, (info >> 32) * 24)
            symbol = strings[n:strings.index(0, n)].decode()
            name = names.get(symbol.split('#')[0], '?')
            if section or name not in wanted:
                continue
            stubs = []
            for segment in segments:
                if segment['type'] != 1 or not segment['flags'] & 1:
                    continue
                code = prepare.span(elf, segment['offset'], segment['filesz'])
                for match in re.finditer(b'\xff\x25....', code, re.S):
                    if segment['vaddr'] + match.end() + struct.unpack_from('<i', match.group(), 2)[0] == target:
                        stubs.append(segment['vaddr'] + match.start())
            assert len(stubs) == 1, (index, name, stubs)
            records.append({'module': index, 'name': name, 'nid': prepare.nid(name),
                            'got': target, 'unresolved': stubs[0] + 6})

report = {'images': [{'module': i, 'sha256': p['native_elf_sha256']} for i, p in enumerate(images)],
          'imports': records}
(root / 'build/network-profile.json').write_text(json.dumps(report, indent=2))
hooks = {'sceNetBind', 'sceNetSendto', 'sceNetRecvfrom', 'sceNetSocketClose'}
assert hooks <= {item['name'] for item in records}
lines = ['// Generated from the sealed RYUN00001 images; fixed import addresses.',
         'static NetImport net_imports[] = {']
for item in records:
    if item['name'] in hooks:
        lines.append('{%d,"%s",0x%x,0x%x},' % (item['module'], item['name'], item['got'], item['unresolved']))
lines += ['};', 'static NetSymbol net_symbols[] = {']
for name in sorted(hooks | {'sceNetGetsockopt', 'sceNetErrnoLoc', 'sceKernelGetProcessTime'}):
    lines.append('{"%s","%s"},' % (name, prepare.nid(name)))
lines += ['};']
(root / 'src/network_profile.h').write_text('\n'.join(lines) + '\n')
print(json.dumps(report, indent=2))
