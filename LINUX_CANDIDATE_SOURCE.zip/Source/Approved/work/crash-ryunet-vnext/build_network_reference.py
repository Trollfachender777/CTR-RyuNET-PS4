"""Build the untouched upstream v0.5.3 bookkeeping for interoperability tests."""
from pathlib import Path
import hashlib,os
import json
import shutil
import subprocess

root=Path(__file__).resolve().parent
source=root/'reference/network-v053'
build=root/'build/upstream-network-v053'
build.mkdir(exist_ok=True)
proof=json.loads((source/'provenance.json').read_text())
assert proof['commit']=='d5be87dc0b9be6d947bc27654c0ee596e0eb93d3'
for filename in ('src_runtime_net_tunnel.c','src_runtime_net_tunnel.h'):
    item=next(row for row in proof['files'] if row.get('file')==filename)
    assert hashlib.sha256((source/filename).read_bytes()).hexdigest()==item['sha256']
shutil.copy2(source/'src_runtime_net_tunnel.h',build/'runtime_net_tunnel.h')
# Freestanding declarations only; upstream source and packet logic stay exact.
(build/'string.h').write_text('#include <stddef.h>\nvoid *memcpy(void*,const void*,size_t);\nvoid *memset(void*,int,size_t);\nint memcmp(const void*,const void*,size_t);\n')
shim=build/'memcmp.c'
shim.write_text('#include <stddef.h>\nint memcmp(const void*a,const void*b,size_t n){const unsigned char*x=a,*y=b;for(size_t i=0;i<n;i++)if(x[i]!=y[i])return x[i]-y[i];return 0;}\n')
llvm=Path(os.environ.get('CTR_LLVM_BIN',root.parent/'ps4-online/llvm/bin'))
objects=[]
for index,path in enumerate((source/'src_runtime_net_tunnel.c',root/'src/mini.c',shim)):
    obj=build/f'part{index}.obj'
    subprocess.run([str(llvm/'clang.exe'),'--target=x86_64-pc-windows-msvc','-ffreestanding','-fno-builtin','-fno-stack-protector','-mno-stack-arg-probe','-O1','-I'+str(build),'-I'+str(root/'src'),'-c',str(path),'-o',str(obj)],check=True)
    objects.append(str(obj))
functions=('tun_reset','tun_candidate','tun_on_send','tun_on_direct','tun_on_tunnelled','tun_keepalive_due','tun_wrap','tun_unwrap')
subprocess.run([str(llvm/'lld.exe'),'-flavor','link','/dll','/noentry','/machine:x64','/out:'+str(build/'upstream.dll'),*[f'/export:{name}' for name in functions],*objects],check=True)
print('Unmodified OCTR v0.5.3 tunnel bookkeeping compiled for differential testing.')
