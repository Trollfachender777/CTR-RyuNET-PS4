"""Execute the C settings, JSON and menu on the host, with dialog ABI mocks."""
from pathlib import Path
import ctypes as C,json,unittest
import test_core as core
lib=core.lib
ROOT=Path(__file__).resolve().parent
class Settings(C.Structure):
    _fields_=[('fps',C.c_int32),('blur',C.c_int32),('pro',C.c_int32),('performance',C.c_int32),('light_effects',C.c_int32),('low_quality',C.c_int32),('no_shadows',C.c_int32),('count',C.c_uint32),('friends',(C.c_char*17)*32)]
lib.ctr_settings_defaults.argtypes=[C.POINTER(Settings)]
lib.ctr_settings_parse.argtypes=[C.POINTER(Settings),C.c_char_p,C.c_size_t]
lib.ctr_settings_format.argtypes=[C.POINTER(Settings),C.c_void_p,C.c_size_t]
lib.ctr_settings_add.argtypes=[C.POINTER(Settings),C.c_char_p,C.c_char_p]
lib.ctr_settings_remove.argtypes=[C.POINTER(Settings),C.c_char_p]
lib.ctr_settings_publish.argtypes=[C.POINTER(Settings)]
lib.ctr_settings_snapshot.argtypes=[C.POINTER(Settings)]
lib.ctr_settings_resolution.argtypes=[C.POINTER(Settings)]
lib.ctr_settings_set_resolution.argtypes=[C.POINTER(Settings),C.c_int32]
lib.ctr_settings_reset_graphics.argtypes=[C.POINTER(Settings)]
lib.ctr_friends_json.argtypes=[C.c_char_p,C.c_void_p,C.c_size_t]
lib.ctr_menu_init.argtypes=[C.c_void_p]
lib.ctr_menu_poll.argtypes=[C.c_int32,C.c_uint32]
lib.ctr_menu_ime_owned.argtypes=[]
lib.ctr_menu_active.argtypes=[]
lib.ctr_menu_request_setup.argtypes=[]
lib.ctr_sessions_init.argtypes=[C.c_int32,C.c_void_p,C.c_void_p]
lib.ctr_session_queue.argtypes=[C.c_char_p]
lib.ctr_profile_publish.argtypes=[C.c_char_p]
lib.ctr_profile_snapshot.argtypes=[C.c_void_p]
lib.ctr_player_name.restype=C.c_char_p
def defaults():
    s=Settings();lib.ctr_settings_defaults(C.byref(s));return s
def snapshot():
    s=Settings();assert lib.ctr_settings_snapshot(C.byref(s))==0;return s
class DialogBase(C.Structure):_fields_=[('size',C.c_uint64),('reserved',C.c_ubyte*36),('magic',C.c_uint32)]
class Buttons(C.Structure):_fields_=[('first',C.c_char_p),('second',C.c_char_p),('reserved',C.c_ubyte*32)]
class Message(C.Structure):_fields_=[('type',C.c_int32),('padding',C.c_int32),('text',C.c_char_p),('buttons',C.POINTER(Buttons)),('reserved',C.c_ubyte*24)]
class Dialog(C.Structure):_fields_=[('base',DialogBase),('size',C.c_uint64),('mode',C.c_int32),('padding',C.c_int32),('message',C.POINTER(Message)),('progress',C.c_void_p),('system',C.c_void_p),('user',C.c_int32),('reserved',C.c_ubyte*40),('padding2',C.c_int32)]
class Result(C.Structure):_fields_=[('mode',C.c_int32),('result',C.c_int32),('button',C.c_int32),('reserved',C.c_ubyte*32)]
class Ime(C.Structure):_fields_=[('user',C.c_int32),('type',C.c_int32),('languages',C.c_uint64),('label',C.c_int32),('method',C.c_int32),('filter',C.c_void_p),('option',C.c_uint32),('max_length',C.c_uint32),('buffer',C.POINTER(C.c_uint16)),('x',C.c_float),('y',C.c_float),('horizontal',C.c_int32),('vertical',C.c_int32),('placeholder',C.c_void_p),('title',C.POINTER(C.c_uint16)),('reserved',C.c_ubyte*16)]
class MenuApi(C.Structure):_fields_=[(n,C.c_void_p) for n in ('msg_init','msg_open','msg_status','msg_update','msg_result','msg_term','ime_init','ime_status','ime_result','ime_term','ime_abort','save','save_name','trace')]+[('user',C.c_int32),('pro',C.c_int32)]
class Menu:
    def __init__(self,pro=False,save_failure=False,existing=False,initialized=False,ime_result_failure=False,ime_term_failure=False):
        self.callbacks=[];self.status=2 if existing else (1 if initialized else 0);self.ime_state=0;self.shown=[];self.errors=[];self.chosen=1;self.cancel=False;self.save_failure=save_failure;self.saved=[];self.terminated=0
        self.aborted=0;self.ime_terminated=0;self.traces=[]
        self.saved_names=[]
        def fn(result,args,function):
            cb=C.CFUNCTYPE(result,*args)(function);self.callbacks.append(cb);return C.cast(cb,C.c_void_p).value
        def initialize():self.status=1;return 0
        def opened(pointer):
            p=pointer.contents
            if p.size!=136 or p.base.size!=48 or p.base.magic!=((C.addressof(p.base)+0xc0d1a109)&0xffffffff) or p.user!=42:self.errors.append('dialog ABI')
            m=p.message.contents
            self.shown.append((m.text.decode(),m.buttons.contents.first.decode() if m.buttons else '',m.buttons.contents.second.decode() if m.buttons else ''))
            self.status=2;return 0
        def result(pointer):pointer.contents.mode=1;pointer.contents.result=int(self.cancel);pointer.contents.button=self.chosen;return 0
        def terminate():self.status=0;self.terminated+=1;return 0
        def ime_init(pointer,_):
            self.ime=pointer.contents
            if self.ime.max_length!=16 or self.ime.user!=42:self.errors.append('IME ABI')
            if not lib.ctr_menu_ime_owned():self.errors.append('IME ownership missing at init')
            self.ime_state=1;return 0
        def ime_result(pointer):
            if not lib.ctr_menu_ime_owned():self.errors.append('IME ownership missing at result')
            C.cast(pointer,C.POINTER(C.c_int32))[0]=int(self.cancel);return -1 if ime_result_failure else 0
        def ime_term():
            if not lib.ctr_menu_ime_owned():self.errors.append('IME ownership missing at term')
            self.ime_terminated+=1;self.ime_state=0;return -1 if ime_term_failure else 0
        def ime_abort():self.aborted+=1;self.ime_state=2;return 0
        def save(pointer):self.saved.append(bytes(pointer.contents));return -1 if self.save_failure else 0
        def save_name(name):self.saved_names.append(name);return -1 if self.save_failure else 0
        values=[fn(C.c_int32,[],initialize),fn(C.c_int32,[C.POINTER(Dialog)],opened),fn(C.c_int32,[],lambda:self.status),fn(C.c_int32,[],lambda:self.status),fn(C.c_int32,[C.POINTER(Result)],result),fn(C.c_int32,[],terminate),fn(C.c_int32,[C.POINTER(Ime),C.c_void_p],ime_init),fn(C.c_int32,[],lambda:self.ime_state),fn(C.c_int32,[C.c_void_p],ime_result),fn(C.c_int32,[],ime_term),fn(C.c_int32,[],ime_abort),fn(C.c_int32,[C.POINTER(Settings)],save),fn(C.c_int32,[C.c_char_p],save_name),fn(None,[C.c_int32,C.c_int32],lambda a,b:self.traces.append((a,b)))]
        self.api=MenuApi(*values,42,int(pro));assert lib.ctr_menu_init(C.byref(self.api))==0
    def poll(self,buttons=0,handle=1):return lib.ctr_menu_poll(handle,buttons)
    def open(self):self.poll(0);return self.poll(6)
    def choose(self,button=1,cancel=False):self.chosen=button;self.cancel=cancel;self.status=3;return self.poll(0)
    def type(self,name,cancel=False):
        self.cancel=cancel
        for i,c in enumerate(name):self.ime.buffer[i]=ord(c)
        self.ime.buffer[len(name)]=0;self.ime_state=2;return self.poll(0)
class Tests(unittest.TestCase):
    def setUp(self):
        self.api=core.Api();assert lib.ctr_core_init(C.byref(self.api),b'DemoPlayerPS4001')==0
        self.s=defaults();assert lib.ctr_settings_publish(C.byref(self.s))==0
    def test_roundtrip_and_corrupt_config_keeps_previous(self):
        self.s.fps=30;self.s.blur=0;self.s.pro=1
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'PcFriend',b'DemoPlayerPS4001'),0)
        out=C.create_string_buffer(1024);n=lib.ctr_settings_format(C.byref(self.s),out,1024)
        parsed=defaults();self.assertEqual(lib.ctr_settings_parse(C.byref(parsed),out,n),0);self.assertEqual(bytes(parsed),bytes(self.s))
        for bad in (b'version=2\nfps=30\n',b'version=1\nfps=240\n',b'version=1\nfriends=bad/name\n',b'version=1\nfriends=Bad\x00Name\n',b'version=1\nfriends=Friend,friend\n',b'version=1\npro_1080=2\n'):
            before=bytes(parsed);self.assertLess(lib.ctr_settings_parse(C.byref(parsed),bad,len(bad)),0);self.assertEqual(bytes(parsed),before)
    def test_first_run_is_explicit_and_defers_to_existing_game_dialogs(self):
        lib.ctr_profile_reset();m=Menu(existing=True);lib.ctr_menu_request_setup()
        for _ in range(240):self.assertEqual(m.poll(),0)
        self.assertFalse(m.shown);m.status=0
        for _ in range(120):m.poll()
        self.assertIn('Bienvenido a RyuNET',m.shown[-1][0]);self.assertEqual(m.shown[-1][1],'Elegir apodo')
        m.choose(2);m.poll();self.assertFalse(lib.ctr_menu_active());self.assertFalse(m.saved_names)
        for _ in range(240):m.poll()
        self.assertEqual(len(m.shown),1);self.assertFalse(m.errors)
    def test_first_run_saves_own_name_without_rebinding_active_session_or_graphics(self):
        lib.ctr_profile_reset();m=Menu();lib.ctr_menu_request_setup()
        for _ in range(120):m.poll()
        m.choose(1);self.assertEqual(m.ime_state,1);m.type('MiPropioApodo')
        self.assertEqual(m.saved_names,[b'MiPropioApodo']);self.assertIn('vuelve a abrirlo',m.shown[-1][0])
        self.assertEqual(lib.ctr_player_name(),b'DemoPlayerPS4001');self.assertEqual(bytes(snapshot()),bytes(self.s));self.assertFalse(m.errors)
    def test_names_dedup_self_limits_and_remove(self):
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'DemoPlayerPS4001',b'DemoPlayerPS4001'),-2)
        for bad in (b'',b'"inject',b'x'*17,b'bad,name',b'bad name'):self.assertLess(lib.ctr_settings_add(C.byref(self.s),bad,None),0)
        for i in range(32):self.assertEqual(lib.ctr_settings_add(C.byref(self.s),f'Friend{i}'.encode(),None),0)
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'FRIEND1',None),-3)
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'Overflow',None),-4)
        self.assertEqual(lib.ctr_settings_remove(C.byref(self.s),b'fRIEND1'),0);self.assertEqual(self.s.count,31)
        self.assertEqual(bytes(self.s.friends[1]).split(b'\0')[0],b'Friend2')
    def test_max_friends_json_full_webapi_and_bounds(self):
        for i in range(32):lib.ctr_settings_add(C.byref(self.s),f'Friend{i:010}'.encode(),None)
        lib.ctr_settings_publish(C.byref(self.s))
        for path,key in ((b'/v1/friendList','friendList'),(b'/v1/profiles','profiles'),(b'/friendOnlineIdLists','friendOnlineIdLists')):
            out=C.create_string_buffer(32768);n=lib.ctr_friends_json(path,out,len(out));self.assertGreater(n,0);doc=json.loads(out.value)
            if key=='friendOnlineIdLists':self.assertEqual(len(doc[key][0]['friendOnlineIdList']),32)
            else:
                self.assertEqual(len(doc[key]),33 if key=='profiles' else 32)
                friend=doc[key][-1];self.assertEqual(int(friend['accountId']),core.expected_pid('Friend0000000031'))
            tiny=(C.c_ubyte*48)(*([0xa5]*48));self.assertLess(lib.ctr_friends_json(path,C.byref(tiny,16),16),0);self.assertEqual(bytes(tiny[:16]),b'\xa5'*16);self.assertEqual(bytes(tiny[-16:]),b'\xa5'*16)
        create=core.function('sceNpWebApiCreateRequest',C.c_int32,C.c_int32,C.c_char_p,C.c_char_p,C.c_int32,C.c_void_p,C.POINTER(C.c_int64))
        send=core.function('sceNpWebApiSendRequest',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        read=core.function('sceNpWebApiReadData',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        delete=core.function('sceNpWebApiDeleteRequest',C.c_int32,C.c_int64)
        handle=C.c_int64();self.assertEqual(create(1,b'userProfile',b'/v1/friendList',0,None,C.byref(handle)),0);self.assertEqual(send(handle.value,None,0),0)
        chunks=[]
        for _ in range(2000):
            out=C.create_string_buffer(29);n=read(handle.value,out,len(out))
            if not n:break
            chunks.append(out.raw[:n])
        self.assertEqual(json.loads(b''.join(chunks))['size'],32);delete(handle.value)
        out=C.create_string_buffer(1024);self.assertEqual(lib.ctr_friends_json(b'/friends/sessions',out,len(out)),0)
    def test_menu_combo_edge_cancel_and_other_system_dialog(self):
        m=Menu();self.assertEqual(m.open(),1);m.poll(6);m.poll(6);self.assertEqual(len(m.shown),1)
        self.assertIn('RyuNET',m.shown[0][0]);self.assertFalse(m.errors)
        m.choose(cancel=True);self.assertEqual(snapshot().fps,60)
        m=Menu(existing=True);self.assertEqual(m.open(),0);self.assertEqual(m.terminated,0);self.assertEqual(m.shown,[])
    def test_menu_reuses_idle_dialog_and_restores_initialized_state(self):
        m=Menu(initialized=True);self.assertEqual(m.open(),1);self.assertEqual(len(m.shown),1)
        m.choose(cancel=True);self.assertEqual(m.status,1);self.assertFalse(m.errors)
    def test_menu_fps_and_write_failure(self):
        for fail in (False,True):
            lib.ctr_settings_publish(C.byref(defaults()));m=Menu(save_failure=fail);m.open();m.choose(1);m.choose(1);m.choose(1);m.choose(1)
            self.assertEqual(snapshot().fps,60 if fail else 30);self.assertEqual(len(m.saved),1);self.assertFalse(m.errors)
            self.assertIn('anterior' if fail else 'guardado',m.shown[-1][0])
    def test_menu_unlimited_is_separate_and_persists_with_contacts_and_graphics(self):
        self.s.low_quality=1;self.s.no_shadows=1;self.s.performance=1
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'PcFriend',None),0)
        lib.ctr_settings_publish(C.byref(self.s))
        m=Menu();m.open();m.choose(1);m.choose(1)
        self.assertEqual(m.shown[-1][1:],('30 / 60 FPS','Sin limite'))
        m.choose(2);s=snapshot();self.assertEqual(s.fps,0)
        self.assertEqual((s.low_quality,s.no_shadows,s.performance,s.count),(1,1,1,1))
        out=C.create_string_buffer(1024);n=lib.ctr_settings_format(C.byref(s),out,1024)
        self.assertIn(b'fps=0\n',out.value);parsed=defaults()
        self.assertEqual(lib.ctr_settings_parse(C.byref(parsed),out,n),0);self.assertEqual(bytes(parsed),bytes(s))
        m=Menu();m.open();m.choose(1);m.choose(1);self.assertIn('sin limite',m.shown[-1][0])
        m.choose(1);self.assertEqual(m.shown[-1][1:],('30 FPS','60 FPS'))
        m.choose(2);self.assertEqual(snapshot().fps,60)
        self.assertEqual(bytes(snapshot().friends),bytes(s.friends))
    def test_all_fps_values_roundtrip_and_reject_unknown_values_without_erasing_settings(self):
        for fps in (0,30,60):
            self.s.fps=fps;out=C.create_string_buffer(1024)
            n=lib.ctr_settings_format(C.byref(self.s),out,1024);self.assertGreater(n,0)
            parsed=defaults();self.assertEqual(lib.ctr_settings_parse(C.byref(parsed),out,n),0)
            self.assertEqual(parsed.fps,fps)
        for fps in (-1,1,59,120):
            self.s.fps=fps;self.assertLess(lib.ctr_settings_publish(C.byref(self.s)),0)
            raw=f'version=1\nfps={fps}\n'.encode();before=bytes(parsed)
            self.assertLess(lib.ctr_settings_parse(C.byref(parsed),raw,len(raw)),0);self.assertEqual(bytes(parsed),before)
    def test_keyboard_add_remove_cancel_and_invalid_unicode(self):
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(1);m.type('PcFriend')
        self.assertEqual(snapshot().count,1);self.assertFalse(m.errors)
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(1);m.type('Otro',cancel=True);self.assertEqual(snapshot().count,1)
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(1);m.type('n\u00f1');self.assertEqual(snapshot().count,1)
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(2);m.choose(2);m.type('pcfriend');self.assertEqual(snapshot().count,0)
        self.assertEqual(lib.ctr_menu_ime_owned(),0)
    def test_keyboard_disappearance_or_failure_releases_game_input(self):
        for status in (0,-1,3):
            m=Menu();m.open();m.choose(2);m.choose(1);m.choose(1)
            self.assertEqual(lib.ctr_menu_ime_owned(),1)
            m.ime_state=status;self.assertEqual(m.poll(),1)
            self.assertEqual(m.poll(),0);self.assertEqual(lib.ctr_menu_ime_owned(),0)
            self.assertEqual(snapshot().count,0);self.assertFalse(m.errors)
        for kwargs in ({'ime_result_failure':True},{'ime_term_failure':True}):
            m=Menu(**kwargs);m.open();m.choose(2);m.choose(1);m.choose(1);m.type('PcFriend')
            self.assertEqual(m.poll(),0);self.assertEqual(lib.ctr_menu_ime_owned(),0)
            self.assertEqual(snapshot().count,0);self.assertFalse(m.errors)
    def test_keyboard_emergency_combo_aborts_only_owned_dialog(self):
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(1)
        for _ in range(21):self.assertEqual(m.poll(),1)
        self.assertEqual(m.poll(6),1);self.assertEqual(m.aborted,1);self.assertEqual(m.ime_terminated,1)
        self.assertEqual(lib.ctr_menu_ime_owned(),0);self.assertEqual(m.poll(6),0)
        self.assertEqual(snapshot().count,0);self.assertFalse(m.errors)
    def test_friend_management_keeps_contacts_and_releases_input_without_queuing_join(self):
        now=[1000000];clock=C.CFUNCTYPE(C.c_uint64)(lambda:now[0])
        lib.ctr_sessions_init(42,C.cast(clock,C.c_void_p),None);lib.ctr_sessions_ready(1)
        m=Menu();m.open();m.choose(2);m.choose(1)
        self.assertEqual(m.shown[-1][1:],('Anadir amigo','Ver / eliminar'))
        m.choose(2);self.assertEqual(m.shown[-1][1:],('Ver lista','Eliminar amigo'))
        m.choose(1);self.assertIn('Todavia',m.shown[-1][0]);m.choose()
        self.assertEqual(m.poll(),0);self.assertEqual(lib.ctr_session_due(),0)
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'PcFriend',None),0)
        self.assertEqual(lib.ctr_settings_add(C.byref(self.s),b'OtherFriend',None),0)
        lib.ctr_settings_publish(C.byref(self.s))
        before=bytes(snapshot())
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(2);m.choose(1)
        self.assertIn('PcFriend',m.shown[-1][0]);self.assertIn('OtherFriend',m.shown[-1][0])
        m.choose(1);self.assertEqual(lib.ctr_menu_active(),0);self.assertEqual(m.status,0)
        self.assertEqual(m.poll(),0);self.assertEqual(lib.ctr_session_due(),0)
        now[0]+=250000;self.assertEqual(lib.ctr_session_due(),0)
        self.assertEqual(bytes(snapshot()),before);self.assertEqual(m.saved,[])
        self.assertFalse(m.errors)
    def test_unified_resolution_selector_is_available_on_base_and_pro_and_does_not_save_while_browsing(self):
        for pro in (False,True):
            before=bytes(snapshot());m=Menu(pro=pro);m.open();m.choose(1);m.choose(2);m.choose(1)
            self.assertIn('Elegida: Nativa',m.shown[-1][0]);self.assertEqual(m.shown[-1][1:],('Aplicar','Siguiente'))
            m.choose(2);self.assertIn('Elegida: 720p',m.shown[-1][0])
            m.choose(2);self.assertIn('Elegida: 480p',m.shown[-1][0])
            m.choose(2);self.assertIn('Elegida: Nativa',m.shown[-1][0])
            self.assertEqual(m.saved,[]);self.assertEqual(bytes(snapshot()),before)
            m.choose(cancel=True);self.assertEqual(bytes(snapshot()),before);self.assertFalse(m.errors)
    def test_light_effects_migrate_roundtrip_and_reject_invalid_value_without_erasing_contacts(self):
        old=b'version=1\nfps=60\nmotion_blur=0\npro_1080=0\nperformance=1\nfriends=First,Middle,Last\n'
        self.assertEqual(lib.ctr_settings_parse(C.byref(self.s),old,len(old)),0)
        self.assertEqual((self.s.performance,self.s.light_effects,self.s.count),(1,0,3));self.s.light_effects=1
        out=C.create_string_buffer(1024);n=lib.ctr_settings_format(C.byref(self.s),out,1024)
        parsed=defaults();self.assertEqual(lib.ctr_settings_parse(C.byref(parsed),out,n),0);self.assertEqual(bytes(parsed),bytes(self.s))
        for value in (b'2',b'-1',b'true'):
            bad=old+b'light_effects='+value+b'\n';before=bytes(parsed)
            self.assertLess(lib.ctr_settings_parse(C.byref(parsed),bad,len(bad)),0);self.assertEqual(bytes(parsed),before)
        self.s.light_effects=2;self.assertLess(lib.ctr_settings_publish(C.byref(self.s)),0)
    def test_resolution_menu_keeps_fps_manual_effects_shadows_and_contacts(self):
        for performance in (0,1):
            s=defaults();s.fps=30;s.blur=1;s.pro=1;s.performance=performance
            for name in (b'First',b'Middle',b'Last'):self.assertEqual(lib.ctr_settings_add(C.byref(s),name,None),0)
            lib.ctr_settings_publish(C.byref(s));contacts=bytes(s.friends)
            m=Menu(pro=True);m.open();m.choose(1);m.choose(2);m.choose(1)
            for _ in range(2-performance):m.choose(2)
            self.assertIn('Elegida: 480p',m.shown[-1][0]);m.choose(1)
            current=snapshot();self.assertEqual((current.fps,current.blur,current.pro,current.performance,current.low_quality,current.no_shadows),(30,1,0,0,1,0))
            self.assertEqual(bytes(current.friends),contacts);self.assertFalse(m.errors)
    def test_resolution_and_shadows_cancel_or_save_failure_preserve_previous_configuration(self):
        for kwargs,cancel in (({},True),({'save_failure':True},False)):
            for choice in (1,2):
                before=bytes(snapshot());m=Menu(**kwargs);m.open();m.choose(1);m.choose(2)
                if choice==1:m.choose(1);m.choose(2)
                else:m.choose(2);m.choose(1);m.choose(2)
                m.choose(1,cancel=cancel)
                self.assertEqual(bytes(snapshot()),before);self.assertFalse(m.errors)
    def test_quality_and_shadow_keys_migrate_roundtrip_and_reject_invalid_values(self):
        old=b'version=1\nfps=30\nmotion_blur=1\npro_1080=1\nperformance=1\nlight_effects=1\nfriends=First,Last\n'
        self.assertEqual(lib.ctr_settings_parse(C.byref(self.s),old,len(old)),0)
        self.assertEqual((self.s.low_quality,self.s.no_shadows,self.s.count),(0,0,2))
        for key in ('low_quality','no_shadows'):
            for value in (0,1):
                setattr(self.s,key,value)
                out=C.create_string_buffer(1024);n=lib.ctr_settings_format(C.byref(self.s),out,1024)
                parsed=defaults();self.assertEqual(lib.ctr_settings_parse(C.byref(parsed),out,n),0);self.assertEqual(bytes(parsed),bytes(self.s))
            for value in (b'2',b'-1',b'true'):
                bad=old+key.encode()+b'='+value+b'\n';before=bytes(parsed)
                self.assertLess(lib.ctr_settings_parse(C.byref(parsed),bad,len(bad)),0);self.assertEqual(bytes(parsed),before)
            setattr(self.s,key,2);self.assertLess(lib.ctr_settings_publish(C.byref(self.s)),0);setattr(self.s,key,0)
    def test_shadow_menu_is_independent_and_resolution_can_replace_legacy_combination(self):
        self.s.low_quality=1;self.s.fps=30;self.s.blur=1
        lib.ctr_settings_add(C.byref(self.s),b'PcFriend',None);lib.ctr_settings_publish(C.byref(self.s))
        m=Menu();m.open();m.choose(1);m.choose(2);m.choose(2);m.choose(1);m.choose(2)
        self.assertIn('Sombras dinamicas',m.shown[-1][0]);m.choose(1)
        self.assertEqual((snapshot().no_shadows,snapshot().low_quality,snapshot().fps,snapshot().blur,snapshot().count),(1,1,30,1,1))
        m=Menu();m.open();m.choose(1);m.choose(2);m.choose(2);m.choose(1);m.choose(2);m.choose(2)
        self.assertEqual(snapshot().no_shadows,0)
        m=Menu();m.open();m.choose(1);m.choose(2);m.choose(1);m.choose(2);m.choose(2);m.choose(1)
        self.assertEqual((snapshot().performance,snapshot().low_quality,snapshot().fps,snapshot().blur),(1,0,30,1))
    def test_performance_mode_migrates_old_config_and_roundtrips_without_losing_contacts(self):
        old=b'version=1\nfps=30\nmotion_blur=1\npro_1080=1\nfriends=First,Middle,Last\n'
        self.assertEqual(lib.ctr_settings_parse(C.byref(self.s),old,len(old)),0);self.assertEqual(self.s.performance,0)
        self.s.performance=1
        out=C.create_string_buffer(1024);n=lib.ctr_settings_format(C.byref(self.s),out,1024)
        parsed=defaults();self.assertEqual(lib.ctr_settings_parse(C.byref(parsed),out,n),0);self.assertEqual(bytes(parsed),bytes(self.s))
        for bad in (old+b'performance=2\n',old+b'performance=-1\n',old+b'performance=bogus\n'):
            before=bytes(parsed);self.assertLess(lib.ctr_settings_parse(C.byref(parsed),bad,len(bad)),0);self.assertEqual(bytes(parsed),before)
        self.s.performance=2;self.assertLess(lib.ctr_settings_publish(C.byref(self.s)),0)
    def test_nativa_selection_clears_both_old_modes_and_pro_override(self):
        self.s.fps=30;self.s.blur=1;self.s.pro=1
        self.s.performance=1;self.s.low_quality=1
        for name in (b'First',b'Middle',b'Last'):self.assertEqual(lib.ctr_settings_add(C.byref(self.s),name,None),0)
        lib.ctr_settings_publish(C.byref(self.s));contacts=bytes(self.s.friends)
        m=Menu(pro=True);m.open();m.choose(1);m.choose(2);m.choose(1);m.choose(2)
        self.assertIn('Elegida: Nativa',m.shown[-1][0]);m.choose(1)
        s=snapshot();self.assertEqual((s.performance,s.low_quality,s.fps,s.blur,s.pro,s.count),(0,0,30,1,0,3));self.assertEqual(bytes(s.friends),contacts)
        self.assertIn('vuelve a abrirlo',m.shown[-1][0]);self.assertFalse(m.errors)
    def test_resolution_cancel_and_failed_save_leave_settings_unchanged(self):
        for kwargs,cancel in (({},True),({'save_failure':True},False)):
            before=bytes(snapshot());m=Menu(**kwargs);m.open();m.choose(1);m.choose(2);m.choose(1);m.choose(1,cancel=cancel)
            self.assertEqual(bytes(snapshot()),before);self.assertFalse(m.errors)
    def test_graphics_helpers_preserve_all_other_bytes_and_reject_invalid_inputs(self):
        for fps in (0,30,60):
            s=defaults();s.fps=fps;s.blur=0;s.pro=1;s.performance=1;s.low_quality=1;s.light_effects=1;s.no_shadows=1
            for name in (b'First',b'Middle',b'Last'):lib.ctr_settings_add(C.byref(s),name,None)
            self.assertEqual(lib.ctr_settings_resolution(C.byref(s)),2)
            for mode in range(3):
                before=Settings.from_buffer_copy(s);expected=Settings.from_buffer_copy(s)
                expected.pro=0;expected.performance=int(mode==1);expected.low_quality=int(mode==2)
                self.assertEqual(lib.ctr_settings_set_resolution(C.byref(s),mode),0)
                self.assertEqual(bytes(s),bytes(expected));self.assertEqual(lib.ctr_settings_resolution(C.byref(s)),mode)
                for invalid in (-1,3,720):
                    raw=bytes(s);self.assertLess(lib.ctr_settings_set_resolution(C.byref(s),invalid),0);self.assertEqual(bytes(s),raw)
        self.assertEqual(lib.ctr_settings_resolution(None),-1)
        self.assertEqual(lib.ctr_settings_set_resolution(None,0),-1)
        self.assertEqual(lib.ctr_settings_reset_graphics(None),-1)
    def test_restore_graphics_only_resets_graphics_and_keeps_fps_contacts_and_profile(self):
        lib.ctr_profile_publish(b'AliasPrivado_123');identity=lib.ctr_player_name()
        for fps in (0,30,60):
            s=defaults();s.fps=fps;s.blur=0;s.pro=s.performance=s.low_quality=s.light_effects=s.no_shadows=1
            for name in (b'First',b'Middle',b'Last'):lib.ctr_settings_add(C.byref(s),name,None)
            lib.ctr_settings_publish(C.byref(s));contacts=bytes(s.friends)
            m=Menu();m.open();m.choose(1);m.choose(2);m.choose(2);m.choose(2)
            self.assertEqual(m.saved,[]);self.assertIn('Conserva el limite de FPS',m.shown[-1][0]);m.choose(1)
            after=snapshot();self.assertEqual((after.fps,after.blur,after.pro,after.performance,after.low_quality,after.light_effects,after.no_shadows),(fps,1,0,0,0,0,0))
            self.assertEqual(after.count,3);self.assertEqual(bytes(after.friends),contacts)
            profile=C.create_string_buffer(17);lib.ctr_profile_snapshot(profile);self.assertEqual(profile.value,b'AliasPrivado_123')
            self.assertEqual(lib.ctr_player_name(),identity);self.assertEqual(m.saved_names,[]);self.assertFalse(m.errors)
    def test_restore_graphics_cancel_and_write_failure_keep_original_bytes(self):
        self.s.fps=0;self.s.low_quality=1;self.s.no_shadows=1;self.s.blur=0
        lib.ctr_settings_add(C.byref(self.s),b'PcFriend',None);lib.ctr_settings_publish(C.byref(self.s))
        for kwargs,cancel in (({},True),({'save_failure':True},False)):
            before=bytes(snapshot());m=Menu(**kwargs);m.open();m.choose(1);m.choose(2);m.choose(2);m.choose(2)
            m.choose(1,cancel=cancel);self.assertEqual(bytes(snapshot()),before)
            self.assertEqual(m.saved_names,[]);self.assertFalse(m.errors)
        m=Menu();m.open();m.choose(1);m.choose(2);m.choose(2);m.choose(2);m.choose(2)
        self.assertEqual(m.saved,[]);self.assertEqual(bytes(snapshot()),before)
    def test_legacy_pro_override_is_labelled_until_user_chooses_a_resolution(self):
        self.s.pro=1;lib.ctr_settings_publish(C.byref(self.s))
        m=Menu(pro=True);m.open();m.choose(1);m.choose(2);m.choose(1)
        self.assertIn('Guardada: 1080p Pro (heredado)',m.shown[-1][0]);self.assertEqual(snapshot().pro,1)
        m.choose(1);self.assertEqual(snapshot().pro,0)
    def test_nickname_menu_saves_for_restart_without_changing_live_identity(self):
        self.assertEqual(lib.ctr_profile_publish(b'DemoPlayerPS4001'),0)
        m=Menu();m.open();m.choose(2);m.choose(2)
        self.assertIn('En uso: DemoPlayerPS4001',m.shown[-1][0]);m.choose(1)
        self.assertEqual(''.join(chr(m.ime.buffer[i]) for i in range(16)),'DemoPlayerPS4001')
        m.type('AliasPrivado_123')
        self.assertEqual(m.saved_names,[b'AliasPrivado_123']);self.assertEqual(lib.ctr_player_name(),b'DemoPlayerPS4001')
        out=C.create_string_buffer(17);self.assertEqual(lib.ctr_profile_snapshot(out),0);self.assertEqual(out.value,b'AliasPrivado_123')
        self.assertIn('vuelve a abrirlo',m.shown[-1][0]);self.assertEqual(snapshot().fps,60);self.assertFalse(m.errors)
    def test_nickname_cancel_invalid_friend_collision_and_save_failure_keep_previous(self):
        lib.ctr_profile_publish(b'DemoPlayerPS4001')
        lib.ctr_settings_add(C.byref(self.s),b'PcFriend',None);lib.ctr_settings_publish(C.byref(self.s))
        for name,kwargs,cancel in (('Nuevo',{},True),('ab',{},False),('Player',{},False),('n\u00f1',{},False),('PcFriend',{},False),('Nuevo',{'save_failure':True},False)):
            m=Menu(**kwargs);m.open();m.choose(2);m.choose(2);m.choose(1);m.type(name,cancel=cancel)
            out=C.create_string_buffer(17);self.assertEqual(lib.ctr_profile_snapshot(out),0);self.assertEqual(out.value,b'DemoPlayerPS4001')
            self.assertEqual(lib.ctr_player_name(),b'DemoPlayerPS4001');self.assertEqual(snapshot().count,1);self.assertFalse(m.errors)
    def test_renamed_self_contact_does_not_erase_fps_or_other_friends(self):
        text=b'version=1\nfps=30\nmotion_blur=0\npro_1080=1\nfriends=PcFriend,demoplayerps4001,Other\n'
        self.assertEqual(lib.ctr_settings_parse(C.byref(self.s),text,len(text)),0)
        self.assertEqual((self.s.fps,self.s.blur,self.s.pro,self.s.count),(30,0,1,2))
        self.assertEqual(bytes(self.s.friends[1]).split(b'\0')[0],b'Other')
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/settings-menu-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'actual C settings, JSON, dialog state machine and native dialog ABI with mocked OS dialogs'},indent=2))
    raise SystemExit(not result.wasSuccessful())
