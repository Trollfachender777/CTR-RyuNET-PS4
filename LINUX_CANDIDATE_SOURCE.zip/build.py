#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-only
"""Local builder: each user supplies their own game files."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,queue,re,shutil,struct,subprocess,sys,threading,time,xml.etree.ElementTree as ET
from progress import Progress
from console_session import configure_session, child_environment
from process_memory import ProcessMemoryGuard
ROOT=Path(__file__).resolve().parent
NAME='CTR Nitro-Fueled Online - RyuNET'
TITLE='RYUN00001';PREFIX='IV9999-'+TITLE+'_00-'
PROGRESS=None
class Error(Exception):pass
def sfo(raw):
    if len(raw)<20:raise Error('Incomplete SFO metadata.')
    magic,_,keys,values,count=struct.unpack_from('<5I',raw)
    if magic!=0x46535000 or count>512 or 20+count*16>len(raw):raise Error('Invalid SFO metadata.')
    result={}
    for i in range(count):
        ko,fmt,n,cap,vo=struct.unpack_from('<HHIII',raw,20+i*16)
        start=keys+ko;end=raw.find(b'\0',start)
        if start>=len(raw) or end<start or values+vo+n>len(raw) or n>cap:raise Error('SFO fields point outside the file.')
        key=raw[start:end].decode('ascii');data=raw[values+vo:values+vo+n]
        if key in result:raise Error('Duplicate SFO field.')
        result[key]=(fmt,data,cap)
    return result
def value(meta,key):return meta.get(key,(0,b'',0))[1].rstrip(b'\0').decode('utf-8',errors='replace')
def pkg_meta(path):
    size=path.stat().st_size
    with path.open('rb') as f:
        head=f.read(0x1100)
        if len(head)<0x1100 or head[:4]!=b'\x7fCNT':raise Error('Not a valid PKG file: '+path.name)
        count=struct.unpack_from('>I',head,0x10)[0];offset=struct.unpack_from('>I',head,0x18)[0]
        if not 0<count<=512 or offset+count*32>size:raise Error('Invalid PKG table.')
        f.seek(offset);table=f.read(count*32)
        for i in range(count):
            kind,_,flags,_,pos,n=struct.unpack_from('>6I',table,i*32)
            if kind!=0x1000:continue
            if flags&0x80000000 or n>65536 or pos+n>size:raise Error('An extracted copy with readable metadata is required.')
            f.seek(pos);return sfo(f.read(n))
    raise Error('The PKG does not contain param.sfo.')
def layout(folder,game=True):
    candidates=[(folder,folder/'sce_sys'),(folder/'Image0',folder/'Sc0'),(folder/'Image0',folder/'Image0/sce_sys')]
    for data,system in candidates:
        if (system/'param.sfo').is_file() and (not game or (data/'eboot.bin').is_file()):return data,system
    return None
def source(folder,game=True,optional=False):
    packages=sorted(p for p in folder.iterdir() if p.is_file() and p.suffix.lower()=='.pkg')
    trees=[]
    if layout(folder,game):trees.append(folder)
    else:
        for child in sorted(folder.iterdir()):
            if child.is_dir() and not child.is_symlink() and layout(child,game):trees.append(child)
    if not packages and not trees and optional:return None
    if len(packages)+len(trees)!=1:raise Error('Place exactly one PKG or one extracted folder in '+str(folder))
    path=(packages+trees)[0]
    if path.is_symlink():raise Error('Use your own files without links to other folders.')
    meta=pkg_meta(path) if path.is_file() else sfo((layout(path,game)[1]/'param.sfo').read_bytes())
    return {'path':path,'pkg':path.is_file(),'meta':meta}
def inspect_input(entrada):
    for name in ('Game','Update','DLC'):
        if not (entrada/name).is_dir():raise Error('Missing folder Input/'+name)
    game=source(entrada/'Game');patch=source(entrada/'Update',optional=True)
    cusa=value(game['meta'],'TITLE_ID')
    if cusa!='CUSA13795':raise Error('This integration supports CUSA13795; do not mix editions.')
    if patch and (value(patch['meta'],'TITLE_ID')!=cusa or value(patch['meta'],'CATEGORY')!='gp'):
        raise Error('The update does not belong to the same game.')
    effective=patch or game
    if value(effective['meta'],'APP_VER')!='01.21':raise Error('This integration requires the compatible 1.21 update; folder names do not change.')
    dlc=[];seen=set()
    for p in sorted((entrada/'DLC').iterdir()):
        if p.is_symlink():raise Error('Links are not allowed in the DLC folder.')
        if p.is_file() and p.suffix.lower()=='.pkg':item={'path':p,'pkg':True,'meta':pkg_meta(p)}
        elif p.is_dir() and layout(p,False):item={'path':p,'pkg':False,'meta':sfo((layout(p,False)[1]/'param.sfo').read_bytes())}
        else:continue
        cid=value(item['meta'],'CONTENT_ID')
        if value(item['meta'],'CATEGORY')!='ac' or not re.fullmatch(r'[A-Z]{2}[0-9]{4}-'+cusa+r'_00-[A-Z0-9_]{16}',cid):
            raise Error('DLC from another edition or with incompatible metadata: '+p.name)
        label=cid[-16:]
        if label in seen:raise Error('Duplicate DLC: '+p.name)
        seen.add(label);item['label']=label;dlc.append(item)
    return game,patch,dlc
def public_plan(items):
    game,patch,dlc=items
    def item(x):return {'file':x['path'].name,'cusa':value(x['meta'],'TITLE_ID'),'version':value(x['meta'],'APP_VER'),'type':'PKG' if x['pkg'] else 'extracted folder'} if x else None
    return {'game':item(game),'update':item(patch),'dlc':[{'file':x['path'].name,'id':x['label']} for x in dlc],
            'output':NAME+'.pkg','includes_user_data':False}
def run(args,cwd=None,env=None,log=None,stage=None):
    if PROGRESS is None:
        with subprocess.Popen([str(x) for x in args],cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) as child:
            guard=ProcessMemoryGuard(child.pid).start()
            try:stdout,stderr=child.communicate()
            finally:guard.close(Path(log).with_suffix('.memory.json') if log else None)
            process=subprocess.CompletedProcess(args,child.returncode,stdout,stderr)
        if log:Path(log).write_text(process.stdout+process.stderr,encoding='utf-8')
        if process.returncode:raise Error('Failed '+str(args[0])+'. See '+str(log or 'the build log')+'.')
        return process.stdout
    child_env=(env or os.environ).copy()
    child_env.update(CTR_BUILD_PROGRESS='1',PYTHONUNBUFFERED='1',PYTHONIOENCODING='utf-8')
    if stage and stage not in ('build','dlc'):PROGRESS.stage(stage)
    lines=queue.Queue();captured=[];reader_errors=[]
    record=Path(log).open('w',encoding='utf-8') if log else None
    guard=None
    try:
        with subprocess.Popen([str(x) for x in args],cwd=cwd,env=child_env,stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1) as process:
            guard=ProcessMemoryGuard(process.pid).start()
            def read_output():
                try:
                    for line in process.stdout:
                        # Keep the diagnostic log live even if console output waits.
                        if record and not reader_errors:
                            try:record.write(line);record.flush()
                            except OSError as error:reader_errors.append(error)
                        lines.put(line)
                finally:lines.put(None)
            reader=threading.Thread(target=read_output,daemon=True);reader.start()
            while True:
                try:line=lines.get(timeout=.5)
                except queue.Empty:PROGRESS.draw();continue
                if line is None:break
                captured.append(line)
                PROGRESS.consume(line,stage);PROGRESS.draw()
            reader.join();code=process.wait();process.stdout.close()
        if reader_errors:raise Error('Could not write the build log: '+str(reader_errors[0]))
        if code:raise Error('Failed '+str(args[0])+'. See '+str(log or 'the build log')+'.')
        return ''.join(captured)
    finally:
        if guard:guard.close(Path(log).with_suffix('.memory.json') if log else None)
        if record:record.close()
def read_language():
    config=ROOT/'.builder-language.json'
    if not config.is_file():return 'en'
    language=json.loads(config.read_text(encoding='utf-8')).get('menu_language')
    if language not in ('en','es'):raise Error('Invalid menu language. Use 0_SETUP.sh en or es.')
    return language

def verify_core():
    manifest=ROOT/'CORE_MANIFEST.json'
    if not manifest.is_file():raise Error('CORE_MANIFEST.json is missing. Extract the complete builder again.')
    for row in json.loads(manifest.read_text(encoding='utf-8')):
        path=ROOT/row['path']
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT) or not path.is_file() or path.stat().st_size!=row['bytes'] or hashlib.file_digest(path.open('rb'),'sha256').hexdigest()!=row['sha256']:
            raise Error('A builder file is missing or changed: '+row['path'])

def tools():
    bundled=ROOT/'Tools/PowerShell/pwsh'
    configured=os.environ.get('CTR_PWSH_BIN')
    pwsh=str(Path(configured).resolve()) if configured else str(bundled)
    if not Path(pwsh).is_file():raise Error('Native PowerShell is missing. Run ./0_SETUP.sh first.')
    env=child_environment(os.environ.copy())
    tool=ROOT/'pkg_tools.ps1'
    if not tool.is_file():raise Error('The builder is missing pkg_tools.ps1.')
    return env,[pwsh,'-NoLogo','-NoProfile','-NonInteractive','-File',tool],pwsh

def link_tree(folder,destination,prefix=Path()):
    if folder.is_symlink():raise Error('Linked folders are not allowed inside the input.')
    for source_path in sorted(folder.rglob('*')):
        if source_path.is_symlink() or not source_path.resolve().is_relative_to(folder.resolve()):raise Error('Links pointing outside the game folder are not allowed.')
        if not source_path.is_file():continue
        relative=prefix/source_path.relative_to(folder)
        if any(part.lower() in ('data','goldhen','savedata','home','users','backups') for part in relative.parts):raise Error('The input contains user data that does not belong to the game.')
        if source_path.suffix.lower() in ('.key','.pem','.pfx','.log','.ini'):raise Error('The input contains settings or keys; remove them before building the package.')
        target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():target.unlink() # Only the new workspace link, never the input.
        try:os.link(source_path,target)
        except OSError:shutil.copy2(source_path,target)
def materialize(item,dest,command,env,stage=None):
    if not item['pkg']:return item['path']
    dest.mkdir();run(command+['pkg_extract',item['path'],dest],env=env,log=dest.parent/(dest.name+'.log'),stage=stage)
    return dest
def write_sfo(path,entries):
    keys=bytearray();data=bytearray();table=bytearray()
    for key,(fmt,raw,cap) in sorted(entries.items()):
        while len(data)%4:data.append(0)
        table+=struct.pack('<HHIII',len(keys),fmt,len(raw),cap,len(data));keys+=key.encode()+b'\0';data+=raw.ljust(cap,b'\0')
    start=20+len(table);value_start=(start+len(keys)+3)&-4
    path.write_bytes(struct.pack('<5I',0x46535000,0x101,start,value_start,len(entries))+table+keys+bytes(value_start-start-len(keys))+data)
def build_dlc(item,source_folder,work,out,command,env):
    found=layout(source_folder,False)
    if found is None:raise Error('Extracted DLC metadata was not found.')
    data,system=found;stage=work/'package-root';stage.mkdir()
    if data!=source_folder:link_tree(data,stage)
    else:
        for p in source_folder.iterdir():
            if p.name=='sce_sys':continue
            if p.is_dir():link_tree(p,stage,prefix=Path(p.name))
            elif p.is_file():os.link(p,stage/p.name)
    generated={'digests','entry_keys','entry_names','general_digests','image_key','license.dat','license.info','metas','psreserved.dat','_Fugazi_','playgo-chunk.dat','playgo-chunk.sha','playgo-manifest.xml'}
    (stage/'sce_sys').mkdir(exist_ok=True)
    for p in system.iterdir():
        if p.is_file() and p.name not in generated and p.name!='param.sfo':shutil.copy2(p,stage/'sce_sys'/p.name)
    meta=dict(item['meta']);content=PREFIX+item['label']
    for key,value_,cap in (('TITLE_ID',TITLE,16),('CONTENT_ID',content,48)):
        meta[key]=(0x204,value_.encode()+b'\0',max(cap,meta.get(key,(0,b'',0))[2]))
    for key in ('PUBTOOLINFO','PUBTOOLVER','PUBTOOLMINVER'):meta.pop(key,None)
    write_sfo(stage/'sce_sys/param.sfo',meta)
    files=sorted(p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file())
    project=ET.Element('psproject',fmt='gp4',version='1000');volume=ET.SubElement(project,'volume')
    # Keep a real PFS, including for entitlement-only add-ons with no payload.
    # This matches the example DLC's layout and permits all PFS digest checks.
    ET.SubElement(volume,'volume_type').text='pkg_ps4_ac_data'
    ET.SubElement(volume,'volume_id').text='PS4VOLUME';ET.SubElement(volume,'volume_ts').text=time.strftime('%Y-%m-%d %H:%M:%S',time.gmtime())
    ET.SubElement(volume,'package',content_id=content,passcode='0'*32,entitlement_key='0'*32)
    group=ET.SubElement(project,'files',img_no='0')
    for f in files:ET.SubElement(group,'file',targ_path=f,orig_path='package-root/'+f)
    rootdir=ET.SubElement(project,'rootdir');directories={'':rootdir}
    for f in files:
        parent=''
        for part in f.split('/')[:-1]:
            child=parent+'/'+part if parent else part
            if child not in directories:directories[child]=ET.SubElement(directories[parent],'dir',targ_name=part)
            parent=child
    ET.indent(project);gp4=work/'addon.gp4';ET.ElementTree(project).write(gp4,encoding='utf-8',xml_declaration=True)
    temporary=work/'pkg';temporary.mkdir()
    run(command+['pkg_build',gp4,temporary],env=env,log=work/'build.log',stage='dlc')
    packages=list(temporary.glob('*.pkg'))
    if len(packages)!=1:raise Error('The generated DLC installer could not be identified.')
    if value(pkg_meta(packages[0]),'CONTENT_ID')!=content:raise Error('The DLC does not match the generated application.')
    run(command+['pkg_validate',packages[0]],env=env,log=work/'validation.log',stage='dlc')
    out.mkdir(exist_ok=True);shutil.copy2(packages[0],out/(item['label']+'.pkg'))
def main():
    global PROGRESS
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('check','prepare','build','tools'))
    parser.add_argument('--input',type=Path,default=ROOT/'Input')
    parser.add_argument('--menu-language',choices=('en','es'),default=read_language())
    args=parser.parse_args()
    if not sys.platform.startswith('linux') and os.environ.get('CTR_TEST_HOST')!='1':raise Error('This edition runs on Linux. Use the Windows builder on Windows.')
    verify_core()
    if args.action in ('prepare','build'):configure_session()
    if args.action=='tools':
        env,_,pwsh=tools()
        import unicorn
        cpu=unicorn.Uc(unicorn.UC_ARCH_X86,unicorn.UC_MODE_64);cpu.mem_map(0x1000,0x1000);cpu.mem_write(0x1000,b'\x48\xc7\xc0\x2a\x00\x00\x00');cpu.emu_start(0x1000,0x1007)
        assert cpu.reg_read(unicorn.x86_const.UC_X86_REG_RAX)==42,'Test engine failed'
        ps=run([pwsh,'-NoProfile','-NonInteractive','-Command','$PSVersionTable.PSVersion.ToString()'],env=env).strip()
        print(json.dumps({'tools_ready':True,'python':sys.version.split()[0],'unicorn':unicorn.__version__,'menu_language':args.menu_language,'approved_ps4_modules':True,'powershell':ps,'global_installation_required':False},ensure_ascii=False,indent=2));return
    items=inspect_input(args.input.resolve())
    print(json.dumps(public_plan(items),ensure_ascii=False,indent=2))
    if args.action=='check':return
    env,command,pwsh=tools()
    # Native emulation is required by the public source build; check its Python dependency early.
    if args.action=='build':
        try:import unicorn
        except ImportError:raise Error('Unicorn is missing; install Source/requirements-test.txt before building.')
    size=sum(x['path'].stat().st_size if x['pkg'] else sum(p.stat().st_size for p in x['path'].rglob('*') if p.is_file()) for x in (items[0],items[1],*items[2]) if x)
    if shutil.disk_usage(ROOT).free<size*2+10*1024**3:raise Error('Not enough free space to extract and build while preserving your original files.')
    area=ROOT/'Work'/time.strftime('%Y%m%d-%H%M%S');area.mkdir(parents=True,exist_ok=False)
    game,patch,dlcs=items;merged=area/'prepared-game';merged.mkdir()
    if args.action=='build':
        PROGRESS=Progress(patch=patch is not None,dlc=bool(dlcs));PROGRESS.draw(force=True)
    for index,item in enumerate((game,patch)):
        if item is None:continue
        stage='base' if index==0 else 'update'
        if PROGRESS:PROGRESS.stage(stage)
        folder=materialize(item,area/('base' if index==0 else 'update'),command,env,stage=stage)
        found=layout(folder)
        if found is None:raise Error('The extracted files do not contain readable game executables and metadata.')
        data,system=found;link_tree(data,merged)
        if system!=data/'sce_sys':link_tree(system,merged,Path('sce_sys'))
        if PROGRESS:PROGRESS.stage(stage,1)
    if PROGRESS:PROGRESS.stage('prepare');PROGRESS.draw()
    # Original executables must match the documented native integration exactly.
    prepare_script=ROOT/'Source/Approved/outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts/prepare.py'
    sys.path.insert(0,str(prepare_script.parent))
    spec=importlib.util.spec_from_file_location('ctr_prepare',prepare_script)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    proof=json.loads((ROOT/'Source/Approved/source-release.json').read_text(encoding='utf-8'))
    for name,expected in proof['original_elf_sha256'].items():
        blob=(merged/name).read_bytes();elf=module.parse_self(blob)[0]
        if hashlib.sha256(elf).hexdigest()!=expected:raise Error('The executables are incompatible with this integration. Your original files have not been changed.')
    (area/'plan.json').write_text(json.dumps(public_plan(items),ensure_ascii=False,indent=2),encoding='utf-8')
    if args.action=='prepare':print('Files prepared in '+str(merged));return
    code=area/'Source';shutil.copytree(ROOT/'Source/Approved',code)
    if args.menu_language=='es':shutil.copytree(ROOT/'Source/SpanishOverrides',code,dirs_exist_ok=True)
    print('Build log: '+str(area/'build.log'),flush=True)
    if PROGRESS:PROGRESS.stage('code');PROGRESS.draw(force=True)
    else:print('Integrating the approved PS4 module and running native tests.',flush=True)
    run([sys.executable,'-B',ROOT/'Source/build_linux.py','package','--source',code,'--game',merged,'--payload',ROOT/'Payload','--package-script',ROOT/'pkg_tools.ps1','--pwsh',pwsh,'--menu-language',args.menu_language],env=env,log=area/'build.log',stage='build')
    main_pkg=code/'work/crash-ryunet-port/build'/ (NAME+'.pkg')
    if not main_pkg.is_file():raise Error('The build did not produce the expected installer.')
    output=ROOT/'Output'/area.name;output.mkdir(parents=True)
    # Publish only the finished, validated file. Inputs and generated logs stay private.
    run(command+['pkg_validate',main_pkg],env=env,log=area/'game-validation.log',stage='validate')
    shutil.move(str(main_pkg),str(output/main_pkg.name))
    for i,item in enumerate(dlcs):
        if PROGRESS:PROGRESS.stage('dlc',i/len(dlcs));PROGRESS.draw()
        work=area/('dlc-'+str(i));work.mkdir()
        folder=materialize(item,work/'extracted',command,env,stage='dlc')
        build_dlc(item,folder,work,output/'DLC',command,env)
        if PROGRESS:PROGRESS.stage('dlc',(i+1)/len(dlcs))
    (output/'INSTALL.txt').write_text('Install '+NAME+'.pkg first, then any generated DLC PKGs. On first launch, choose your own nickname and restart the game. Do not share profiles or keys.\n',encoding='utf-8')
    if PROGRESS:PROGRESS.complete()
    print('Finished: '+str(output))
if __name__=='__main__':
    try:main()
    except (Error,OSError,ValueError,struct.error) as error:
        if PROGRESS:PROGRESS.fail()
        print('ERROR: '+str(error),file=sys.stderr);raise SystemExit(1)
