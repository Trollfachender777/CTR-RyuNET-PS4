# SPDX-License-Identifier: GPL-2.0-only
"""Observe the owned child's RSS on Linux; never impose an unsafe .NET VM cap."""
import json
import os
from pathlib import Path
import threading


class ProcessMemoryGuard:
    def __init__(self, pid, limit=None):
        self.pid = int(pid)
        self.stop = threading.Event()
        self.thread = None
        self.report = {'enabled': False, 'peak_observed_rss': 0,
                       'checks': 0, 'hard_memory_cap': False,
                       'scope': 'Owned subprocess RSS; Linux manages resident pages.'}

    def start(self):
        status = Path('/proc') / str(self.pid) / 'status'
        if os.name != 'posix' or not status.is_file():
            return self
        self.report['enabled'] = True
        def watch():
            while not self.stop.wait(.5):
                try:
                    values = dict(line.split(':', 1) for line in status.read_text().splitlines() if ':' in line)
                    rss = int(values.get('VmRSS', '0 kB').split()[0]) * 1024
                    self.report['peak_observed_rss'] = max(self.report['peak_observed_rss'], rss)
                    self.report['checks'] += 1
                except (OSError, ValueError):
                    break
        self.thread = threading.Thread(target=watch, daemon=True)
        self.thread.start()
        return self

    def close(self, report_path=None):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=2)
        if report_path:
            Path(report_path).write_text(json.dumps(self.report, indent=2), encoding='utf-8')
