// SPDX-License-Identifier: LGPL-3.0-only
// Thin local adapter around the included LGPL-3.0 LibOrbisPkg sources.
using System;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using LibOrbisPkg.PKG;
using LibOrbisPkg.PFS;
using LibOrbisPkg.GP4;
using LibOrbisPkg.Util;

public static class ConstructorPkgBridge
{
    private static string Destination(string root, string relative)
    {
        relative = relative.Replace('\\', '/');
        if (relative.Split('/').Any(part => part == ".." || part == "." || part.Length == 0) ||
            (relative.Length >= 2 && Char.IsLetter(relative[0]) && relative[1] == ':') || Path.IsPathRooted(relative)) throw new Exception("Rooted package path");
        var prefix = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var result = Path.GetFullPath(Path.Combine(prefix, relative.Replace('/', Path.DirectorySeparatorChar)));
        var comparison = Path.DirectorySeparatorChar == '\\' ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
        if (!result.StartsWith(prefix, comparison)) throw new Exception("Package path escapes the extraction directory");
        Directory.CreateDirectory(Path.GetDirectoryName(result));
        return result;
    }

    public static void Extract(string input, string output)
    {
        ExtractCore(input, output, null);
    }

    // Small read-only integration probe: avoids extracting all game assets.
    public static void Probe(string input, string output)
    {
        ExtractCore(input, output, new[] { "eboot.bin", "sce_module/libSceNpToolkit2.prx", "version.xml" });
    }

    private static void ExtractCore(string input, string output, string[] selected)
    {
        Directory.CreateDirectory(output);
        if (Directory.EnumerateFileSystemEntries(output).Any()) throw new Exception("Extraction output must be empty");
        int entries = 0, files = 0;
        using (var map = MemoryMappedFile.CreateFromFile(input, FileMode.Open, null, 0, MemoryMappedFileAccess.Read))
        {
            Pkg pkg;
            using (var stream = map.CreateViewStream(0, 0, MemoryMappedFileAccess.Read)) pkg = new PkgReader(stream).ReadPkg();
            foreach (var meta in pkg.Metas.Metas)
            {
                if (Gp4Creator.GeneratedEntries.Contains(meta.id) || !EntryNames.IdToName.ContainsKey(meta.id)) continue;
                var length = meta.Encrypted ? ((long)meta.DataSize + 15) & ~15L : meta.DataSize;
                if (length > 64L * 1024 * 1024) throw new Exception("Unexpectedly large system entry");
                var data = new byte[checked((int)length)];
                using (var stream = map.CreateViewStream(meta.DataOffset, length, MemoryMappedFileAccess.Read))
                {
                    int read = 0;
                    while (read < data.Length)
                    {
                        int n = stream.Read(data, read, data.Length - read);
                        if (n == 0) throw new EndOfStreamException();
                        read += n;
                    }
                }
                if (meta.Encrypted) data = Entry.Decrypt(data, pkg, meta);
                using (var file = File.Create(Destination(output, "sce_sys/" + EntryNames.IdToName[meta.id])))
                    file.Write(data, 0, checked((int)meta.DataSize));
                entries++;
            }
            if (pkg.Header.pfs_image_size > 0)
            {
                using (var view = map.CreateViewAccessor((long)pkg.Header.pfs_image_offset, (long)pkg.Header.pfs_image_size, MemoryMappedFileAccess.Read))
                {
                    var debugPasscode = new string('0', 32);
                    var imageKey = pkg.CheckPasscode(debugPasscode)
                        ? LibOrbisPkg.Util.Crypto.ComputeKeys(pkg.Header.content_id, debugPasscode, 1)
                        : pkg.GetEkpfs();
                    var outer = new PfsReader(view, pkg.Header.pfs_flags, imageKey);
                    var inner = new PfsReader(new PFSCReader(outer.GetFile("pfs_image.dat").GetView()));
                    var payloads = inner.GetAllFiles().Where(f => selected == null || selected.Contains(f.FullName.Substring(7))).ToArray();
                    var progress = new BuildProgress.Counter("extract", payloads.Sum(f => f.size));
                    foreach (var file in payloads)
                    {
                        if (!file.FullName.StartsWith("/uroot/", StringComparison.Ordinal)) throw new Exception("Unexpected PFS root");
                        if (selected != null && !selected.Contains(file.FullName.Substring(7))) continue;
                        long previous = 0;
                        file.Save(Destination(output, file.FullName.Substring(7)), false, position => {
                            progress.Advance(position - previous); previous = position;
                        });
                        files++;
                    }
                    progress.Complete();
                }
            }
        }
        Console.WriteLine("Extracted system entries: " + entries + "; game files: " + files);
    }

    public static void Build(string projectFile, string output)
    {
        Gp4Project project;
        using (var stream = File.OpenRead(projectFile)) project = Gp4Project.ReadFrom(stream);
        var root = Path.GetDirectoryName(Path.GetFullPath(projectFile));
        foreach (var problem in Gp4Validator.ValidateProject(project, root))
            if (problem.Type.ToString() == "Fatal") throw new Exception(problem.Message);
        Directory.CreateDirectory(output);
        var target = Path.Combine(output, project.volume.Package.ContentId + ".pkg");
        if (File.Exists(target)) throw new Exception("Refusing to overwrite an installer");
        new PkgBuilder(PkgProperties.FromGp4(project, root)).Write(target);
        Console.WriteLine("Built local package");
    }

    public static void Validate(string input)
    {
        int good = 0, unavailable = 0;
        using (var stream = File.OpenRead(input))
        {
            var pkg = new PkgReader(stream).ReadPkg();
            var validations = new PkgValidator(pkg).Validations(stream);
            var progress = new BuildProgress.Counter("validate", validations.Count);
            foreach (var check in validations)
            {
                var result = check.Validate();
                if (result == PkgValidator.ValidationResult.Fail) throw new Exception("Invalid package check: " + check.Name);
                if (result == PkgValidator.ValidationResult.NoKey) unavailable++;
                else good++;
                progress.Advance(1);
            }
            progress.Complete();
        }
        Console.WriteLine("Validated checks: " + good + "; checks requiring unavailable platform keys: " + unavailable);
    }
}
