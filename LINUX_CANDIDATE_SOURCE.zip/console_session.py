# SPDX-License-Identifier: GPL-2.0-only
"""Process-local Linux resource controls and a shared advisory build lock."""
import atexit
import os
from pathlib import Path
import tempfile

_lock = None


def configure_session():
    global _lock
    if os.name != 'posix':
        return  # The host verification harness does not claim a Linux test.
    import fcntl
    # All EN/ES copies for this user share the same lock, even on other drives.
    directory = Path(os.environ.get('XDG_RUNTIME_DIR', tempfile.gettempdir()))
    path = directory / ('ctr-ryunet-builder-' + str(os.getuid()) + '.lock')
    flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
    descriptor = os.open(path, flags, 0o600)
    try:
        if os.fstat(descriptor).st_uid != os.getuid():
            raise OSError('The builder lock belongs to another user.')
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (OSError, BlockingIOError):
        os.close(descriptor)
        raise OSError('Another builder is running. Wait for it to finish.')
    _lock = descriptor
    def release():
        global _lock
        if _lock is not None:
            os.close(_lock)
            _lock = None
    atexit.register(release)
    # This only lowers this process's priority. Children inherit it.
    try:
        os.nice(5)
    except OSError:
        pass


def child_environment(env):
    env['DOTNET_PROCESSOR_COUNT'] = str(max(1, min(4, os.cpu_count() or 1)))
    env['DOTNET_GCConserveMemory'] = '5'
    env['POWERSHELL_TELEMETRY_OPTOUT'] = '1'
    env['POWERSHELL_UPDATECHECK'] = 'Off'
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return env
