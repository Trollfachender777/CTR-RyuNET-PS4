# SPDX-License-Identifier: GPL-2.0-only
"""Local console progress; estimates are never inferred from allocated PKG size."""
import shutil
import sys
import time


def duration(seconds):
    if seconds is None:
        return 'calculating...'
    seconds = max(0, int(seconds + .5))
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return (f'{hours}h {minutes:02}m' if hours else f'{minutes}m {seconds:02}s')


class Progress:
    def __init__(self, patch=True, dlc=False, stream=None, clock=time.monotonic):
        self.stream = stream or sys.stdout
        self.clock = clock
        self.started = clock()
        self.last_advance = self.started
        self.rate_started = self.started
        self.rate_fraction = 0.0
        self.phase_deadline = None
        self.steps = [('base', 'Extracting game', 9)]
        if patch:
            self.steps += [('update', 'Extracting update', 7)]
        self.steps += [('prepare', 'Preparing files', 1), ('code', 'Integrating and testing', 13),
                       ('pkg_data', 'Writing content', 25), ('pkg_sign', 'Signing content', 5),
                       ('pkg_encrypt', 'Encrypting content', 33), ('pkg_playgo', 'Calculating PlayGo', 3),
                       ('pkg_digest', 'PKG integrity', 2), ('validate', 'Validating installer', 1)]
        if dlc:
            self.steps += [('dlc', 'Preparing DLC', 1)]
        self.total_weight = sum(row[2] for row in self.steps)
        self.index = 0
        self.fraction = 0.0
        self.high_water = 0.0
        self.finished = False
        self.failed = False
        self.last_draw = -float('inf')
        self.width = 0
        self.tty = bool(getattr(self.stream, 'isatty', lambda: False)())

    def stage(self, name, fraction=0.0):
        index = next((i for i, row in enumerate(self.steps) if row[0] == name), None)
        if index is None or index < self.index or self.finished or self.failed:
            return
        if index > self.index:
            self.index, self.fraction = index, 0.0
            self.rate_started = self.clock()
            self.rate_fraction = 0.0
            self.phase_deadline = None
        self.fraction = max(self.fraction, min(1.0, max(0.0, fraction)))
        completed = sum(row[2] for row in self.steps[:self.index])
        previous = self.high_water
        self.high_water = max(self.high_water, (completed + self.steps[self.index][2] * self.fraction) / self.total_weight)
        if self.high_water > previous:
            now = self.clock()
            if now - self.last_advance > 20:
                self.rate_started, self.rate_fraction = now, self.fraction
                self.phase_deadline = None
            elapsed = now - self.rate_started
            advanced = self.fraction - self.rate_fraction
            if elapsed >= 2 and advanced > .001 and self.fraction < 1:
                self.phase_deadline = now + elapsed * (1-self.fraction) / advanced
            elif self.fraction >= 1:
                self.phase_deadline = None
            self.last_advance = now

    def consume(self, line, context):
        parts = line.strip().split('|')
        if len(parts) != 4 or parts[0] != 'CTR_PROGRESS':
            return
        try:
            done, total = int(parts[2]), int(parts[3])
        except ValueError:
            return
        if total <= 0 or done < 0:
            return
        fraction = min(done / total, 1.0)
        if context in ('base', 'update', 'validate'):
            self.stage(context, fraction)
        elif context == 'build':
            self.stage(parts[1], fraction)
        # DLC consists of several subprocesses. The caller advances that whole
        # stage only after each add-on is completely built AND validated.

    def remaining(self):
        if self.finished:
            return 0.0
        now = self.clock()
        if self.failed or self.phase_deadline is None or now-self.last_advance > 20 or self.phase_deadline <= now:
            return None
        # Estimate this stage from its live counters, then count down between
        # updates. Do not let startup or suspended time distort later phases.
        return self.phase_deadline-now

    def render(self):
        percent = 100 if self.finished else min(99, int(self.high_water * 100))
        filled = percent * 12 // 100
        bar = '#' * filled + '.' * (12 - filled)
        label = 'Completed' if self.finished else ('Stopped due to error' if self.failed else self.steps[self.index][1])
        phase = '' if self.finished or self.failed else f' {int(self.fraction * 100)}%'
        if not self.finished and not self.failed and self.steps[self.index][0] == 'code':
            phase = f' step {int(self.fraction*8)}/8'
        left = 'not completed' if self.failed else duration(self.remaining())
        elapsed = duration(max(0.0, self.clock() - self.started))
        pulse = '' if self.finished or self.failed else ' |/-'[int(self.clock()*2)%4] + ' '
        return f'{pulse}[{bar}] {percent:3}% approx. | {label}{phase} | Elapsed: {elapsed} | Stage left (~): {left}'

    def draw(self, force=False):
        now = self.clock()
        interval = .5 if self.tty else 10
        if not force and now - self.last_draw < interval:
            return
        text = self.render()
        if self.tty:
            width = max(30, shutil.get_terminal_size((110, 25)).columns - 1)
            text = text[:width]
            self.stream.write('\r' + text + ' ' * max(0, min(self.width, width) - len(text)))
            self.width = len(text)
        else:
            self.stream.write(text + '\n')
        self.stream.flush()
        self.last_draw = now

    def complete(self):
        self.finished = True
        self.draw(force=True)
        if self.tty:
            self.stream.write('\n')
            self.stream.flush()

    def fail(self):
        self.failed = True
        self.draw(force=True)
        if self.tty:
            self.stream.write('\n')
            self.stream.flush()
