#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
if [ "$(uname -s)" != Linux ] || [ "$(uname -m)" != x86_64 ]; then
    printf '%s\n' 'This archive requires Linux x86_64. Use the Windows edition on Windows.' >&2
    exit 1
fi
if [ ! -x "$root/Tools/Python/bin/python3" ]; then
    command -v flock >/dev/null 2>&1 || { printf '%s\n' 'The Linux flock utility is required (util-linux).' >&2; exit 1; }
    (
        flock 9
        [ ! -x "$root/Tools/Python/bin/python3" ] || exit 0
        printf '%s  %s\n' '6d7521138fd33afddc1ccd08abb007d9a2829e38117c2576f9efdc0ec73ce772' "$root/Tools/Archives/python-linux-x64.tar.gz" | sha256sum -c -
        temporary=$(mktemp -d "$root/Tools/.python.XXXXXX")
        tar -xzf "$root/Tools/Archives/python-linux-x64.tar.gz" -C "$temporary"
        [ -x "$temporary/python/bin/python3" ] || { printf '%s\n' 'Incomplete Python archive.' >&2; exit 1; }
        mv "$temporary/python" "$root/Tools/Python"
        rmdir "$temporary"
    ) 9>"$root/Tools/.bootstrap.lock"
fi
exec "$root/Tools/Python/bin/python3" -B "$root/setup_runtime.py" "$@"
