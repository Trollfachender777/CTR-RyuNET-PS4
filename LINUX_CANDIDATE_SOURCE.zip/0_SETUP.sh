#!/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
if [ "$#" -eq 1 ]; then
    case "$1" in en|es) exec "$root/launcher.sh" tools --save-language "$1" ;; esac
fi
exec "$root/launcher.sh" tools "$@"
