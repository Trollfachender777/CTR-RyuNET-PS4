# CTR RyuNET builder for Linux

This edition runs on a **Linux x86_64 computer** and creates the same PS4
application, **CTR Nitro-Fueled Online - RyuNET.pkg**. The game runs on PS4.

It includes native Linux Python, PowerShell/.NET and the test engine. It does
not require Wine, a Windows installation, LLVM, a separate .NET SDK, or sudo.
The bundled runtime archives are unpacked inside this folder on first use.
After downloading and extracting the complete builder, no network is used
to process your game files.

## 1. Extract the complete archive

Extract `CTR_RyuNET_Builder_Linux.tar.gz` into a writable folder on a Linux
filesystem, preferably under your home directory. Keep all its contents
together. Open a terminal in the extracted folder.

**What it does:** preserves the executable permissions on the `.sh` launchers
and keeps tools, source, and integrity manifests in the expected places.
The initial target is x86_64 Linux with glibc. ARM and Alpine/musl are not
included in this archive. Standard `tar`, `sha256sum`, `flock`, and the system
libraries required by [portable PowerShell](https://learn.microsoft.com/powershell/scripting/install/alternate-install-methods)
must be available. Setup does not install system packages.

## 2. Prepare the tools and choose the PS4 menu language

Run one of these commands:

```sh
./0_SETUP.sh en
```

```sh
./0_SETUP.sh es
```

**What it does:** verifies and unpacks the bundled native tools, checks that
they run, and saves English (`en`) or Spanish (`es`) for the custom PS4 menu.
You can rerun it to change the language for the next PKG you build. Folder
and launcher names are the same for both choices. The original game's own
language is independent of this selection.

## 3. Add your inputs

- Put one **CUSA13795 base-game PKG** in `Input/Game`.
- Put the matching **1.21 update PKG** in `Input/Update`.
- Put compatible optional DLC PKGs in `Input/DLC`, or leave it empty.

A single complete game PKG already updated to 1.21, or a complete extracted
game folder already at 1.21, can go in `Input/Game` with `Input/Update` empty.
An update-only PKG cannot replace the full game. Use one game input at a time.

**What it does:** gives the builder the game data supplied by you. Metadata
and executable hashes must match the approved integration. Renaming another
CUSA does not make it compatible. Input originals are preserved.

Allow space for extracted data, the installer, and your originals. With the
development inputs, the conservative check requires about 55 GB free; the
exact amount depends on what you provide.

## 4. Check the files

```sh
./1_CHECK_FILES.sh
```

**What it does:** checks placement, CUSA, version, and DLC metadata before
the build. Executable compatibility is also checked during preparation.

## 5. Build the PS4 installer

```sh
./3_BUILD_PKG.sh
```

Leave the terminal open until **Finished** and the output folder appear.

**What it does:** extracts your inputs, verifies the approved PS4 module and
homebrew integration payload, reproduces the approved integrated executable
hashes, tests the native integration, stages the application, builds and checks
the encrypted PKG, and prepares any DLC separately. The approved PS4 modules
are reused without recompiling them on each build. Full source is included.

Progress includes the current stage, elapsed time, and an approximate stage
estimate. `calculating...` means there is no reliable estimate yet. A large
partially written file does not mean the installer has finished.

The builder lowers its own scheduling priority, uses a .NET processor-count
setting of at most four, and allows one active build per Linux user. It asks
.NET to conserve memory and records its own child's RSS; it does not impose
a hard RAM cap or use the Windows working-set trimming mechanism.
Logs stay under `Work/<build>/`, including `build.log`.

`./2_PREPARE_FILES.sh` is optional. It extracts and checks inputs without
creating a PKG. Running 3 afterward prepares the inputs again, so normal use
is **1, then 3**.

## 6. Install on PS4

Open the latest completed folder under `Output`. Install
`CTR Nitro-Fueled Online - RyuNET.pkg` first, then any PKGs in its `DLC` folder.
Read `INSTALL.txt` in that output folder. Use your existing GoldHEN package
installation method and an installation medium supporting files over 4 GB.
Back up saves before replacing an existing installation.

On first launch, choose your own RyuNET nickname, close the game normally,
and reopen it. Each local PS4 user has a separate identity generated on the
console. Personal names, keys, and contacts are not included in the builder.

Approved settings remain: 30/60 FPS and Unlimited; Native/720p/480p internal
resolution; motion blur and dynamic shadows; graphics reset; nickname and
contacts. Join games through CTR's original Friends menu. Invitations and
the removed duplicate L3+R3 Join option are not added by this Linux edition.
The network baseline remains OCTR 0.5.3. A 60 FPS cap does not promise a
permanent 60 FPS on every track or system.

See the [project guides and credits](https://github.com/Trollfachender777/CTR-RyuNET-PS4).
The Linux implementation and its checks are described in `Source/LINUX.md`.

Share the original archive. After use, `Input`, `Work`, and `Output` contain
your own material and must not be redistributed with it.
