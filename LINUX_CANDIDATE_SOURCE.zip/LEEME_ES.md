# Constructor de RyuNET para Linux

Esta edición se ejecuta en una computadora **Linux x86_64 con glibc** y genera
el instalador para PS4. Incluye las herramientas nativas dentro del archivo;
no requiere Wine ni instalar programas en Windows.

1. Extrae el archivo completo en una carpeta con permiso de escritura,
   preferiblemente dentro de tu carpeta personal. Abre una terminal allí.
2. Ejecuta `./0_SETUP.sh es` para preparar las herramientas y elegir el menú
   de PS4 en español. Usa `./0_SETUP.sh en` si lo quieres en inglés. La selección
   se aplica al siguiente PKG que construyas; las carpetas conservan sus nombres
   en inglés.
3. Coloca el juego base **CUSA13795** en `Input/Game`, su actualización **1.21**
   en `Input/Update` y los DLC compatibles opcionales en `Input/DLC`.
   Si el juego completo ya está actualizado a 1.21, deja vacía `Input/Update`.
4. Ejecuta `./1_CHECK_FILES.sh` para comprobar los archivos.
5. Ejecuta `./3_BUILD_PKG.sh` y espera a que muestre **Finished**.
6. Abre la última carpeta terminada de `Output`. Instala primero
   `CTR Nitro-Fueled Online - RyuNET.pkg` y después sus DLC separados, si los
   añadiste. Lee también `INSTALL.txt`.

El paso 2 de los lanzadores, `./2_PREPARE_FILES.sh`, es opcional: prepara y
comprueba los archivos, pero no genera un PKG. El 3 ya incluye esa preparación.

Se conservan las funciones aprobadas de PS4 y la identidad individual por
usuario. No se incluyen juego, actualizaciones, DLC, partidas, contactos ni
claves personales. Los módulos de PS4 aprobados se verifican y reutilizan,
evitando compilarlos de nuevo en cada construcción.

El constructor muestra progreso y registros en `Work/<construcción>/build.log`.
La estimación es aproximada. Reduce su propia prioridad y limita el número
de procesadores expuestos a .NET; no establece un límite rígido de RAM.
ARM y Alpine/musl no forman parte de este archivo. No instala dependencias
del sistema automáticamente ni requiere sudo para preparar sus herramientas.

Consulta `START_HERE.md` para el detalle de cada paso y los requisitos.
Conserva el archivo original para compartirlo: después de usar el constructor,
`Input`, `Work` y `Output` contienen tus propios archivos.
