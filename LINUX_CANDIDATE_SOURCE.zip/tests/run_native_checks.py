# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import argparse
import json
import os
import subprocess
import sys
import time
from make_native_fixture import create

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--language', choices=('en', 'es'), default='en')
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    code = create(ROOT / ('Work/native-' + args.language + '-' + str(time.time_ns())), args.language)
    port, current = code / 'work/crash-ryunet-port', code / 'work/crash-ryunet-vnext'
    environment = os.environ.copy()
    environment.update(PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    def run(script, *extra):
        subprocess.run([sys.executable, '-B', str(script), *extra], cwd=code, env=environment, check=True)
    run(port / 'prepare_external_module.py')
    run(port / 'test_bootstrap.py')
    run(ROOT / 'tests/selected_native_suite.py', str(current), *(['--smoke'] if args.smoke else []))
    if not args.smoke:
        run(current / 'test_user_isolation.py')
    results = {'successful': True, 'platform': sys.platform, 'language': args.language,
               'real_game_or_assets_used': False, 'smoke_only': args.smoke}
    for label, path in [('bootstrap', port / 'build/bootstrap-test-result.json'),
                        ('native', current / 'build/native-bridge-test-result.json'),
                        ('users', current / 'build/user-isolation-test-result.json')]:
        if path.is_file():
            data = json.loads(path.read_text(encoding='utf-8'))
            assert data['successful'], label
            results[label] = data
    output = ROOT / 'Work/test-results'
    output.mkdir(parents=True, exist_ok=True)
    (output / ('native-' + args.language + '.json')).write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps(results, indent=2), flush=True)


if __name__ == '__main__':
    main()
