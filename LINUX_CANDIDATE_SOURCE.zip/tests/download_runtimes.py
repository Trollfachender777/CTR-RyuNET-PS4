# SPDX-License-Identifier: GPL-2.0-only
"""CI/release preparation only. Normal use ships these verified archives."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def download(item):
    name, metadata = item
    target = ROOT / 'Tools/Archives' / metadata['file']
    target.parent.mkdir(exist_ok=True)
    if target.is_file():
        with target.open('rb') as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() == metadata['sha256']:
                return name + ': cached'
    partial = target.with_suffix(target.suffix + '.partial')
    with urllib.request.urlopen(metadata['url'], timeout=90) as response, partial.open('wb') as stream:
        while data := response.read(1024 * 1024):
            stream.write(data)
    with partial.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == metadata['sha256'], name
    assert partial.stat().st_size == metadata['bytes']
    partial.replace(target)
    return name + ': SHA-256 verified'


if __name__ == '__main__':
    manifest = json.loads((ROOT / 'Tools/runtimes.json').read_text(encoding='utf-8'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        for result in executor.map(download, [(key, manifest[key]) for key in ('python', 'powershell', 'unicorn')]):
            print(result, flush=True)
