# SPDX-License-Identifier: GPL-2.0-only
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import build as builder
from console_session import child_environment
from progress import Progress


def backend():
    spec = importlib.util.spec_from_file_location('linux_backend_test', ROOT / 'Source/build_linux.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Tests(unittest.TestCase):
    def test_uppercase_pkg_extension_is_recognized_on_linux(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            sfo_path = directory / 'metadata'
            builder.write_sfo(sfo_path, {'TITLE_ID': (0x204, b'CUSA13795\0', 16)})
            metadata = sfo_path.read_bytes()
            package = bytearray(0x1140 + len(metadata))
            package[:4] = b'\x7fCNT'
            struct.pack_into('>I', package, 0x10, 1)
            struct.pack_into('>I', package, 0x18, 0x1100)
            struct.pack_into('>6I', package, 0x1100, 0x1000, 0, 0, 0, 0x1140, len(metadata))
            package[0x1140:] = metadata
            path = directory / 'My input.PKG'
            path.write_bytes(package)
            self.assertEqual(builder.source(directory)['path'], path)

    def test_game_identity_and_edition_rejected_before_build(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            for name in ('Game/sce_sys', 'Update', 'DLC'):
                (directory / name).mkdir(parents=True)
            (directory / 'Game/eboot.bin').write_bytes(b'An original synthetic test, not a game.')
            for title, version in (('CUSA00000', '01.21'), ('CUSA13795', '01.00')):
                entries = {key: (0x204, value.encode() + b'\0', 48) for key, value in
                           {'TITLE_ID': title, 'APP_VER': version, 'CATEGORY': 'gd'}.items()}
                builder.write_sfo(directory / 'Game/sce_sys/param.sfo', entries)
                with self.assertRaises(builder.Error):
                    builder.inspect_input(directory)

    def test_fresh_user_data_cannot_enter_the_prepared_game(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source, output = directory / 'source', directory / 'output'
            source.mkdir()
            output.mkdir()
            (source / 'identity.key').write_bytes(b'synthetic-private-data')
            with self.assertRaises(builder.Error):
                builder.link_tree(source, output)
            self.assertFalse((output / 'identity.key').exists())

    @unittest.skipUnless(os.name == 'posix', 'Requires real Linux symlinks')
    def test_input_symlinks_cannot_copy_an_external_file(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source, output = directory / 'source', directory / 'output'
            source.mkdir()
            output.mkdir()
            secret = directory / 'outside.dat'
            secret.write_bytes(b'Keep outside the build.')
            (source / 'linked.dat').symlink_to(secret)
            with self.assertRaises(builder.Error):
                builder.link_tree(source, output)
            self.assertFalse((output / 'linked.dat').exists())

    def test_unknown_or_changed_executable_never_accepts_integration(self):
        engine = backend()
        patch = json.loads((ROOT / 'Payload/integration.json').read_text())['patches'][0]
        with self.assertRaisesRegex(ValueError, 'Unsupported executable'):
            engine.integrate_elf(b'not an approved executable', patch)

    def test_prebuilt_ps4_modules_are_the_approved_self_containers(self):
        expected = {'en': 'a633a3d24b8c52d9f92ba0a8ca7768544fa4869739935c87001a2e986a5623b0',
                    'es': '0c32379ed4766b2a89aef0cc790ba37896c89a9eca83cf83beb81003d73afaf6'}
        for language, digest in expected.items():
            data = (ROOT / ('Payload/ctr_online_' + language + '.prx')).read_bytes()
            self.assertEqual(data[:4], b'O\x15=\x1d')
            self.assertEqual(hashlib.sha256(data).hexdigest(), digest)
        backend().read_payload(ROOT / 'Payload')

    def test_resource_controls_apply_to_children_without_a_hard_ram_cap(self):
        env = child_environment({})
        self.assertGreaterEqual(int(env['DOTNET_PROCESSOR_COUNT']), 1)
        self.assertLessEqual(int(env['DOTNET_PROCESSOR_COUNT']), 4)
        self.assertEqual(env['DOTNET_GCConserveMemory'], '5')
        self.assertNotIn('DOTNET_GCHeapHardLimit', env)

    @unittest.skipUnless(os.name == 'posix', 'Requires a Linux advisory lock')
    def test_two_builders_are_blocked_and_the_lock_recovers_after_exit(self):
        script = "import console_session,sys;console_session.configure_session();print('ready',flush=True);sys.stdin.read()"
        holder = subprocess.Popen([sys.executable, '-B', '-c', script], cwd=ROOT,
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            self.assertEqual(holder.stdout.readline().strip(), 'ready')
            blocked = subprocess.run([sys.executable, '-B', '-c', 'import console_session;console_session.configure_session()'],
                                     cwd=ROOT, capture_output=True, text=True, timeout=10)
            self.assertNotEqual(blocked.returncode, 0)
            self.assertIn('Another builder is running', blocked.stderr)
        finally:
            holder.communicate('', timeout=10)
        recovered = subprocess.run([sys.executable, '-B', '-c', 'import console_session;console_session.configure_session()'],
                                   cwd=ROOT, capture_output=True, text=True, timeout=10)
        self.assertEqual(recovered.returncode, 0, recovered.stderr)

    def test_progress_reports_steps_and_never_claims_early_completion(self):
        now = [0.0]
        progress = Progress(clock=lambda: now[0], stream=io.StringIO())
        progress.stage('code', .5)
        self.assertIn('step 4/8', progress.render())
        self.assertNotIn('100%', progress.render())
        now[0] = 30
        self.assertIsNone(progress.remaining())
        progress.complete()
        self.assertIn('100%', progress.render())


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    output = ROOT / 'Work/test-results'
    output.mkdir(parents=True, exist_ok=True)
    (output / 'frontend.json').write_text(json.dumps({'successful': result.wasSuccessful(),
        'groups': result.testsRun, 'skipped': len(result.skipped), 'platform': sys.platform}, indent=2))
    raise SystemExit(not result.wasSuccessful())
