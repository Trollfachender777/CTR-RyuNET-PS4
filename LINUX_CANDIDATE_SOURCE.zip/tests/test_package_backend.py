# SPDX-License-Identifier: GPL-2.0-only
"""Exercise the actual encrypted package engine using original synthetic data."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import random
import shutil
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
import zlib

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import build as builder
from console_session import child_environment


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def own_png():
    def chunk(kind, data):
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))
    pixels = (b'\0' + b'\x20\x60\xa0' * 512) * 512
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 512, 512, 8, 2, 0, 0, 0)) +
            chunk(b'IDAT', zlib.compress(pixels)) + chunk(b'IEND', b''))


def make_fixture(area, mib):
    source = area / 'fixture'
    (source / 'sce_sys').mkdir(parents=True)
    (source / 'assets/Nested folder').mkdir(parents=True)
    (source / 'eboot.bin').write_bytes(b'RyuNET original synthetic package fixture. Not a game executable.\n' * 64)
    (source / 'assets/Nested folder/MixedCase.dat').write_bytes(bytes(range(256)) * 17)
    (source / 'assets/Nested folder/Empty.dat').touch()
    (source / 'sce_sys/icon0.png').write_bytes(own_png())
    nptitle = bytearray(160)
    nptitle[:4] = b'NPTD'
    struct.pack_into('>I', nptitle, 4, 128)
    nptitle[16:28] = b'RYUN00001_00'
    (source / 'sce_sys/nptitle.dat').write_bytes(nptitle)
    strings = {'TITLE_ID': 'RYUN00001', 'CONTENT_ID': 'IV9999-RYUN00001_00-CRASHRYUNET00001',
               'APP_VER': '01.21', 'VERSION': '01.00', 'CATEGORY': 'gd', 'TITLE': 'RyuNET synthetic test'}
    entries = {key: (0x204, value.encode() + b'\0', 128 if key == 'TITLE' else 48) for key, value in strings.items()}
    for key, value in {'SYSTEM_VER': 0x03500000, 'APP_TYPE': 1, 'ATTRIBUTE': 0}.items():
        entries[key] = (0x404, struct.pack('<I', value), 4)
    builder.write_sfo(source / 'sce_sys/param.sfo', entries)
    random_source = random.Random(1598237)
    with (source / 'payload.dat').open('wb') as stream:
        for _ in range(mib):
            stream.write(random_source.randbytes(1024 * 1024))
    project = ET.Element('psproject', fmt='gp4', version='1000')
    volume = ET.SubElement(project, 'volume')
    ET.SubElement(volume, 'volume_type').text = 'pkg_ps4_app'
    ET.SubElement(volume, 'volume_id').text = 'PS4VOLUME'
    ET.SubElement(volume, 'volume_ts').text = '2026-01-01 00:00:00'
    ET.SubElement(volume, 'package', content_id=strings['CONTENT_ID'], passcode='0' * 32,
                  storage_type='digital25', app_type='full')
    files = ET.SubElement(project, 'files', img_no='0')
    rootdir = ET.SubElement(project, 'rootdir')
    directories = {'': rootdir}
    for path in sorted(source.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(source).as_posix()
        ET.SubElement(files, 'file', targ_path=relative, orig_path='fixture/' + relative)
        parent = ''
        for part in relative.split('/')[:-1]:
            child = parent + '/' + part if parent else part
            if child not in directories:
                directories[child] = ET.SubElement(directories[parent], 'dir', targ_name=part)
            parent = child
    ET.ElementTree(project).write(area / 'fixture.gp4', encoding='utf-8', xml_declaration=True)
    return source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mib', type=int, default=32)
    args = parser.parse_args()
    area = ROOT / 'Work/package-test'
    area.mkdir(parents=True, exist_ok=False)
    source = make_fixture(area, args.mib)
    env, command, pwsh = builder.tools()
    env = child_environment(env)
    env['CTR_BUILD_PROGRESS'] = '1'
    def run(name, arguments, fails=False):
        result = subprocess.run(list(map(str, arguments)), env=env, cwd=area,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8')
        (area / (name + '.log')).write_text(result.stdout, encoding='utf-8')
        if fails:
            assert result.returncode != 0, name + ' was incorrectly accepted'
        else:
            assert result.returncode == 0, name + '\n' + result.stdout[-6000:]
        return result.stdout
    run('build', command + ['pkg_build', area / 'fixture.gp4', area / 'package'])
    package = next((area / 'package').glob('*.pkg'))
    validation = run('validate', command + ['pkg_validate', package])
    assert 'Validated checks: 29;' in validation, validation
    run('extract', command + ['pkg_extract', package, area / 'readback'])
    checked = 0
    for path in source.rglob('*'):
        if path.is_file() and path.name != 'param.sfo':
            assert digest(path) == digest(area / 'readback' / path.relative_to(source)), str(path)
            checked += 1
    run('refuse-nonempty-output', command + ['pkg_extract', package, area / 'readback'], fails=True)
    damaged = area / 'damaged.pkg'
    shutil.copy2(package, damaged)
    with damaged.open('r+b') as stream:
        stream.seek(0x10000)
        value = stream.read(1)
        stream.seek(0x10000)
        stream.write(bytes([value[0] ^ 1]))
    run('reject-damaged', command + ['pkg_validate', damaged], fails=True)
    audit_script = area / 'path-tests.ps1'
    audit_script.write_text(r'''$ErrorActionPreference='Stop'
[Reflection.Assembly]::LoadFrom($args[0]) | Out-Null
$method=[ConstructorPkgBridge].GetMethod('Destination',[Reflection.BindingFlags]'NonPublic,Static')
$root=Join-Path $PSScriptRoot 'safe-root'
$bad=@('../escape','..\escape','/absolute','C:\absolute','a/../../escape','./escape')
foreach($path in $bad) {
  $rejected=$false
  try { $method.Invoke($null,@($root,$path)) | Out-Null } catch { $rejected=$true }
  if(-not $rejected) { throw ('Unsafe package path accepted: '+$path) }
}
Write-Output 'Rejected unsafe path variants: 6'
''', encoding='utf-8')
    run('path-checks', [pwsh, '-NoLogo', '-NoProfile', '-NonInteractive', '-File', audit_script,
                        ROOT / 'Work/tools/LibOrbisPkg.Builder.dll'])
    run('crypto-reference', [pwsh, '-NoLogo', '-NoProfile', '-NonInteractive', '-File',
                             ROOT / 'Source/Approved/work/crash-ryunet-port/test_package_crypto.ps1'])
    result = {'successful': True, 'platform': sys.platform, 'synthetic_mib': args.mib,
              'container_checks': 29, 'payload_files_verified': checked,
              'damaged_pkg_rejected': True, 'nonempty_extract_output_rejected': True,
              'unsafe_path_variants_rejected': 6, 'package_sha256': digest(package),
              'game_data_used': False, 'crypto_reference_matches': 42}
    output = ROOT / 'Work/test-results'
    output.mkdir(parents=True, exist_ok=True)
    (output / 'package.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
