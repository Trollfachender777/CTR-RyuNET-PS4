# SPDX-License-Identifier: GPL-2.0-only
"""Test the real PS4 module without distributing any game executable or asset.

The synthetic ELF files contain zero-filled engine areas, standard ELF/program
headers, and only our generated homebrew integration writes. The emulator runs
our module and bootstrap; it never runs a game engine.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]


def create(destination, language='en'):
    destination = Path(destination).resolve()
    shutil.copytree(ROOT / 'Source/Approved', destination)
    if language == 'es':
        shutil.copytree(ROOT / 'Source/SpanishOverrides', destination, dirs_exist_ok=True)
    port = destination / 'work/crash-ryunet-port'
    current = destination / 'work/crash-ryunet-vnext'
    port_build = port / 'build'
    port_build.mkdir(exist_ok=True)
    data = json.loads((ROOT / 'Payload/integration.json').read_text(encoding='utf-8'))
    profiles = json.loads((ROOT / 'Payload/native-profiles.json').read_text(encoding='utf-8'))
    for patch, profile in zip(data['patches'], profiles):
        target = port_build / patch['elf_file']
        with target.open('wb') as stream:
            stream.truncate(patch['elf_bytes'])
            stream.write(bytes.fromhex(patch['elf_header']))
            for write in patch['writes']:
                stream.seek(write['offset'])
                stream.write(bytes.fromhex(write['hex']))
        with target.open('rb') as stream:
            profile['native_elf_sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert profile['native_elf_sha256'] != patch['integrated_elf_sha256'], 'Fixture must not be an actual game ELF.'
    (current / 'build/native-profiles.json').write_text(json.dumps(profiles, indent=2), encoding='utf-8')
    portable = [dict(p, elf=str((current / p['elf']).resolve())) for p in profiles]
    (port_build / 'native-profiles.json').write_text(json.dumps(portable, indent=2), encoding='utf-8')
    shutil.copy2(ROOT / ('Payload/ctr_online_' + language + '.prx'), current / 'build/ctr_online.prx')
    return destination


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path)
    parser.add_argument('--language', choices=('en', 'es'), default='en')
    args = parser.parse_args()
    create(args.destination, args.language)
    print('Created synthetic, game-free native test fixtures: ' + str(args.destination))
