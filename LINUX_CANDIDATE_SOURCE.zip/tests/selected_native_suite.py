# SPDX-License-Identifier: GPL-2.0-only
"""Run game-free native cases; report original-instruction cases as skipped."""
from pathlib import Path
import argparse
import json
import sys
import unittest

ORIGINAL_INSTRUCTION_CASES = (
    'test_native_performance_patches_base_and_pro_without_changing_online_or_hardware_mode',
    'test_native_quality_scales_real_setup_and_preserves_all_effects_and_selected_fps',
    'test_native_shadow_controls_use_consistent_shader_flags_and_normal_camera_disable_path',
    'test_native_toolkit_friend_query_with_profile_photo_fields_keeps_friend_schema',
    'test_original_game_friend_status_comparison_is_unchanged_and_not_forced_online',
    'test_scene_scale_consumer_and_original_target_dimension_math_on_base_and_pro',
)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('current', type=Path)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    sys.path.insert(0, str(args.current))
    import test_native_bridge as native
    for name in ORIGINAL_INSTRUCTION_CASES:
        method = getattr(native.Tests, name)
        setattr(native.Tests, name, unittest.skip('Needs original game instructions; synthetic CI distributes no game code.')(method))
    suite = (unittest.defaultTestLoader.loadTestsFromName('Tests.test_success_uses_only_owned_port_slots', native)
             if args.smoke else unittest.defaultTestLoader.loadTestsFromTestCase(native.Tests))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'successful': result.wasSuccessful(), 'groups': result.testsRun,
              'executed_groups': result.testsRun - len(result.skipped), 'skipped_groups': len(result.skipped),
              'real_game_data_used': False, 'scope': 'Actual approved PS4 SELF on synthetic ELF/ABI fixtures.'}
    (args.current / 'build/native-bridge-test-result.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    raise SystemExit(not result.wasSuccessful())
