# SPDX-License-Identifier: GPL-2.0-only
"""Unpack the hash-pinned native runtimes locally; no network or sudo."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent


def verify_archive(item):
    path = ROOT / 'Tools/Archives' / item['file']
    if not path.is_file() or path.is_symlink() or path.stat().st_size != item['bytes']:
        raise RuntimeError('Runtime archive missing: ' + item['file'])
    with path.open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    if actual != item['sha256']:
        raise RuntimeError('Runtime archive checksum mismatch: ' + item['file'])
    return path


def ensure_runtime():
    if sys.platform != 'linux' or platform.machine().lower() not in ('x86_64', 'amd64'):
        raise RuntimeError('This archive is for Linux x86_64 with glibc. ARM and Alpine are not included.')
    import fcntl
    lock_path = ROOT / 'Tools/.setup.lock'
    with lock_path.open('a+b') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        manifest = json.loads((ROOT / 'Tools/runtimes.json').read_text(encoding='utf-8'))
        marker = ROOT / 'Tools/.runtime-ready.json'
        expected = {key: value['sha256'] for key, value in manifest.items() if isinstance(value, dict)}
        if marker.is_file() and json.loads(marker.read_text(encoding='utf-8')) == expected:
            if (ROOT / 'Tools/PowerShell/pwsh').is_file():
                try:
                    import unicorn
                    return
                except ImportError:
                    pass
        for key in ('powershell', 'unicorn'):
            verify_archive(manifest[key])
        print('Preparing the bundled Linux tools. No system installation is required.', flush=True)
        shell_root = ROOT / 'Tools/PowerShell'
        with tempfile.TemporaryDirectory(prefix='.powershell-', dir=ROOT / 'Tools') as folder:
            temporary = Path(folder)
            with tarfile.open(ROOT / 'Tools/Archives' / manifest['powershell']['file']) as archive:
                archive.extractall(temporary, filter='data')
            (temporary / 'pwsh').chmod(0o755)
            if shell_root.exists():
                # Only replace this builder-owned runtime, after successful extraction.
                if shell_root.is_symlink() or shell_root.parent != ROOT / 'Tools':
                    raise RuntimeError('Unsafe runtime folder.')
                shutil.rmtree(shell_root)
            temporary.rename(shell_root)
        import sysconfig
        packages = Path(sysconfig.get_path('purelib'))
        if not packages.resolve().is_relative_to((ROOT / 'Tools/Python').resolve()):
            raise RuntimeError('The setup must use the bundled Python interpreter.')
        with zipfile.ZipFile(ROOT / 'Tools/Archives' / manifest['unicorn']['file']) as wheel:
            for member in wheel.infolist():
                parts = PurePosixPath(member.filename)
                if parts.is_absolute() or '..' in parts.parts:
                    raise RuntimeError('Unsafe wheel entry.')
                if not parts.parts or not (parts.parts[0] == 'unicorn' or parts.parts[0].startswith('unicorn-')):
                    raise RuntimeError('Unexpected wheel entry.')
                wheel.extract(member, packages)
        import unicorn
        marker.write_text(json.dumps(expected, indent=2), encoding='utf-8')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('tools', 'check', 'prepare', 'build'))
    parser.add_argument('--save-language', choices=('en', 'es'))
    args, extra = parser.parse_known_args()
    ensure_runtime()
    if args.save_language:
        (ROOT / '.builder-language.json').write_text(json.dumps({'menu_language': args.save_language}), encoding='utf-8')
    from console_session import child_environment
    env = child_environment(os.environ.copy())
    result = subprocess.run([sys.executable, '-B', str(ROOT / 'build.py'), args.action, *extra], env=env, cwd=ROOT)
    return result.returncode


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, tarfile.TarError, zipfile.BadZipFile) as error:
        print('ERROR: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
