# SPDX-License-Identifier: LGPL-3.0-only
param(
    [Parameter(Mandatory)][ValidateSet('pkg_extract','pkg_probe','pkg_build','pkg_validate')][string]$Action,
    [Parameter(Mandatory)][string]$InputPath,
    [string]$OutputPath
)
$ErrorActionPreference = 'Stop'
$constructorRoot = $PSScriptRoot
$vendorRoot = Join-Path $constructorRoot 'Source/Approved/work/crash-ryunet-port/pkg-tool-source/LibOrbisPkg-master/LibOrbisPkg'
$cacheRoot = [IO.Path]::GetFullPath((Join-Path $constructorRoot 'Work/tools'))
New-Item -ItemType Directory -Path $cacheRoot -Force | Out-Null
$assemblyPath = Join-Path $cacheRoot 'LibOrbisPkg.Builder.dll'
$stampPath = Join-Path $cacheRoot 'sources.sha256.txt'
$sourcePaths = @((Get-ChildItem -LiteralPath $vendorRoot -Recurse -Filter '*.cs' | Sort-Object FullName | Select-Object -ExpandProperty FullName))
$sourcePaths += Join-Path $constructorRoot 'pkg_bridge.cs'
$fingerprints = @($sourcePaths | ForEach-Object { (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash }) -join ''
$stamp = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($fingerprints)))
if ((-not (Test-Path -LiteralPath $assemblyPath)) -or (-not (Test-Path -LiteralPath $stampPath)) -or ((Get-Content -LiteralPath $stampPath -Raw).Trim() -ne $stamp)) {
    if (Test-Path -LiteralPath $assemblyPath) { Remove-Item -LiteralPath $assemblyPath }
    Add-Type -Path $sourcePaths -OutputAssembly $assemblyPath -CompilerOptions '/define:CORE','/unsafe','/optimize' -IgnoreWarnings -WarningAction SilentlyContinue
    [IO.File]::WriteAllText($stampPath, $stamp)
}
[Reflection.Assembly]::LoadFrom($assemblyPath) | Out-Null
switch ($Action) {
    'pkg_extract' { [ConstructorPkgBridge]::Extract([IO.Path]::GetFullPath($InputPath), [IO.Path]::GetFullPath($OutputPath)) }
    'pkg_probe' { [ConstructorPkgBridge]::Probe([IO.Path]::GetFullPath($InputPath), [IO.Path]::GetFullPath($OutputPath)) }
    'pkg_build' { [ConstructorPkgBridge]::Build([IO.Path]::GetFullPath($InputPath), [IO.Path]::GetFullPath($OutputPath)) }
    'pkg_validate' { [ConstructorPkgBridge]::Validate([IO.Path]::GetFullPath($InputPath)) }
}
