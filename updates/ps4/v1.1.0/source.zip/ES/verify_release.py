"""Verify the source manifest; optionally reject generated binary/private files."""
from pathlib import Path
import argparse,hashlib,json
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-only',action='store_true',help='Reject any file absent from the source manifest')
args=parser.parse_args()
manifest=ROOT/'MANIFIESTO_SHA256.json'
entries=json.loads(manifest.read_text())
errors=[];expected={manifest.name}
for row in entries:
    path=ROOT/row['path'];expected.add(row['path'])
    if not path.resolve().is_relative_to(ROOT):raise ValueError('Unsafe manifest path')
    if not path.is_file():errors.append('Missing: '+row['path']);continue
    if path.stat().st_size!=row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
        errors.append('Modified: '+row['path'])
if args.source_only:
    extra={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}-expected
    errors.extend('Not in source manifest: '+p for p in sorted(extra))
print(json.dumps({'verified':not errors,'manifest_files':len(entries),'source_only':args.source_only,'errors':errors},indent=2))
raise SystemExit(bool(errors))
