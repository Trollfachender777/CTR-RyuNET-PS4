"""Stage this user's owned CTR assets with the native RyuNET integration.

Unmodified assets use hard links. Modified files are independent copies.
GP4 schema/generated-entry exclusions follow maxton/LibOrbisPkg (LGPL-3.0).
Nothing in the existing game installation, save or GoldHEN config is modified.
"""
from pathlib import Path
import os,struct,json,hashlib,shutil,xml.etree.ElementTree as ET
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent;CHAT=ROOT.parent.parent;BUILD=ROOT/'build'
SOURCE=Path(os.environ['CTR_GAME_DIR']).resolve()
STAGE=BUILD/'package-root'
TITLE='RYUN00001';CONTENT='IV9999-RYUN00001_00-CRASHRYUNET00001'
assert len(TITLE)==9 and len(CONTENT)==36

def rebase_nptitle(raw,original_title,new_title):
    assert len(raw)==160 and raw[:4]==b'NPTD'
    assert struct.unpack_from('>I',raw,4)[0]==128
    old=(original_title+'_00').encode('ascii')
    new=(new_title+'_00').encode('ascii')
    assert len(old)==len(new)==12 and raw[16:28]==old
    result=raw[:16]+new+raw[28:]
    assert result[:16]==raw[:16] and result[28:]==raw[28:]
    return result

def read_sfo(path):
    raw=path.read_bytes();magic,version,keys,values,count=struct.unpack_from('<5I',raw)
    assert magic==0x46535000
    result={}
    for i in range(count):
        keyoff,fmt,length,capacity,valueoff=struct.unpack_from('<HHIII',raw,20+i*16)
        pos=keys+keyoff;key=raw[pos:raw.index(0,pos)].decode()
        value=raw[values+valueoff:values+valueoff+length]
        result[key]=(fmt,value,capacity)
    return result
def write_sfo(path,entries):
    names=bytearray();values=bytearray();table=bytearray()
    for key,(fmt,value,capacity) in sorted(entries.items()):
        assert len(value)<=capacity
        while len(values)%4:values.append(0)
        table+=struct.pack('<HHIII',len(names),fmt,len(value),capacity,len(values))
        names+=key.encode()+b'\0';values+=value.ljust(capacity,b'\0')
    start=20+len(table);data_start=(start+len(names)+3)&-4
    path.write_bytes(struct.pack('<5I',0x46535000,0x101,start,data_start,len(entries))+table+names+bytes(data_start-start-len(names))+values)

if __name__=='__main__':
    for filename in ('bootstrap-test-result.json','self-wrapper-test.json'):
        assert json.loads((BUILD/filename).read_text())['successful'],filename
    STAGE.mkdir(exist_ok=True)
    # Generated container entries must not be copied back as duplicate entries.
    skip={'sce_sys/'+n for n in ('digests','entry_keys','image_key','general_digests','metas','entry_names','license.dat','license.info','psreserved.dat','playgo-chunk.dat','playgo-chunk.sha','playgo-manifest.xml','origin-deltainfo.dat','_Fugazi_')}
    nptitle_original=(SOURCE/'sce_sys/nptitle.dat').read_bytes()
    (BUILD/'nptitle.native.dat').write_bytes(rebase_nptitle(nptitle_original,'CUSA13795',TITLE))
    (BUILD/'ryunet-updater.txt').write_text('RYUNET-PS4-UPDATER-ABI1:es\n',encoding='ascii')
    replacement={'sce_module/ryunet-updater.txt':BUILD/'ryunet-updater.txt','eboot.bin':BUILD/'eboot.native.bin','sce_module/libSceNpToolkit2.prx':BUILD/'libSceNpToolkit2.native.prx','sce_module/ctr_online.prx':BUILD/'ctr_online.prx','sce_sys/nptitle.dat':BUILD/'nptitle.native.dat'}
    copied=[];linked=[];files=[]
    for source in sorted(SOURCE.rglob('*')):
        if not source.is_file():continue
        relative=source.relative_to(SOURCE).as_posix()
        assert source.resolve().is_relative_to(SOURCE) and not source.is_symlink(),'Unsafe input link'
        assert not any(x.lower() in ('data','goldhen','home','users','savedata','backups') for x in source.relative_to(SOURCE).parts),'User data is not game content'
        assert source.suffix.lower() not in ('.key','.pem','.pfx','.log','.ini'),'Private configuration must not enter a PKG'
        if relative in skip:continue
        target=STAGE/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if relative=='sce_sys/param.sfo':continue
        if relative in replacement:continue
        if not target.exists():os.link(source,target)
        assert os.path.samefile(source,target),relative
        linked.append(relative);files.append(relative)
    for relative,source in replacement.items():
        target=STAGE/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            if relative!='sce_sys/nptitle.dat':
                assert not os.path.samefile(target,SOURCE/relative) if (SOURCE/relative).exists() else True
            # Unlink only the known staging entry, breaking its former hardlink.
            assert target.resolve().is_relative_to(STAGE.resolve())
            target.unlink()
        shutil.copy2(source,target);copied.append(relative);files.append(relative)
    entries=read_sfo(SOURCE/'sce_sys/param.sfo')
    for key,value in {'TITLE_ID':TITLE,'CONTENT_ID':CONTENT,'TITLE':'CTR Nitro-Fueled Online - RyuNET','CATEGORY':'gd','APP_VER':'01.21','VERSION':'01.00'}.items():
        fmt,_,size=entries[key];entries[key]=(fmt,value.encode()+b'\0',size)
    for key in entries:
        if key.startswith('TITLE_') and key[6:].isdigit():
            fmt,_,size=entries[key]
            entries[key]=(fmt,b'CTR Nitro-Fueled Online - RyuNET\0',size)
    for key in ('PUBTOOLINFO','PUBTOOLVER','PUBTOOLMINVER'):entries.pop(key,None)
    target=STAGE/'sce_sys/param.sfo'
    if target.exists():assert not os.path.samefile(target,SOURCE/'sce_sys/param.sfo')
    write_sfo(target,entries);copied.append('sce_sys/param.sfo');files.append('sce_sys/param.sfo')
    assert read_sfo(target)['TITLE_ID'][1]==TITLE.encode()+b'\0'
    assert read_sfo(SOURCE/'sce_sys/param.sfo')['TITLE_ID'][1]==b'CUSA13795\0'
    assert (STAGE/'sce_sys/nptitle.dat').read_bytes()[16:28]==(TITLE+'_00').encode()
    assert (SOURCE/'sce_sys/nptitle.dat').read_bytes()==nptitle_original
    assert len(set(files))==len(files)
    actual={p.relative_to(STAGE).as_posix() for p in STAGE.rglob('*') if p.is_file()}
    assert actual==set(files),'Unexpected files in stage'
    project=ET.Element('psproject',fmt='gp4',version='1000');volume=ET.SubElement(project,'volume')
    ET.SubElement(volume,'volume_type').text='pkg_ps4_app';ET.SubElement(volume,'volume_id').text='PS4VOLUME'
    ET.SubElement(volume,'volume_ts').text=datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    ET.SubElement(volume,'package',content_id=CONTENT,passcode='0'*32,storage_type='digital50',app_type='full')
    chunks=ET.SubElement(volume,'chunk_info',chunk_count='1',scenario_count='1')
    ET.SubElement(ET.SubElement(chunks,'chunks'),'chunk',id='0',layer_no='0',label='Full game')
    ET.SubElement(ET.SubElement(chunks,'scenarios',default_id='0'),'scenario',id='0',type='sp',initial_chunk_count='1',label='Full game').text='0'
    items=ET.SubElement(project,'files',img_no='0')
    dirs=ET.SubElement(project,'rootdir');dir_nodes={'':dirs}
    for relative in sorted(files):
        ET.SubElement(items,'file',targ_path=relative,orig_path='package-root/'+relative)
        parent=''
        for part in relative.split('/')[:-1]:
            child=parent+'/'+part if parent else part
            if child not in dir_nodes:dir_nodes[child]=ET.SubElement(dir_nodes[parent],'dir',targ_name=part)
            parent=child
    ET.indent(project);ET.ElementTree(project).write(BUILD/'native.gp4',encoding='utf-8',xml_declaration=True)
    report={'title_id':TITLE,'content_id':CONTENT,'files':len(files),'hardlinked_assets':len(linked),'independent_modified_files':copied,'bytes':sum((STAGE/f).stat().st_size for f in files),'excluded_generated_entries':sorted(skip),'modified_sha256':{f:hashlib.file_digest((STAGE/f).open('rb'),'sha256').hexdigest() for f in copied},'console_validation':'PENDING','original_installation_modified':False}
    (BUILD/'staging-report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
