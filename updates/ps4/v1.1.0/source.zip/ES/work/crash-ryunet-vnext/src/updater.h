// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "updates.h"
#define CTR_UPDATER_CHANNEL "https://raw.githubusercontent.com/Trollfachender777/CTR-RyuNET-PS4/main/updates/ps4/stable.json"
#define CTR_UPDATER_FILES "https://raw.githubusercontent.com/Trollfachender777/CTR-RyuNET-PS4/main/updates/ps4/"
#define CTR_UPDATER_LANGUAGE "es"
#define CTR_UPDATER_TARGET "/data/ryunet/" CTR_UPDATER_LANGUAGE "/ctr_online.prx"
#define CTR_UPDATER_MAX (1024*1024)
enum {CTR_UPDATER_IDLE,CTR_UPDATER_CHECKING,CTR_UPDATER_CURRENT,CTR_UPDATER_AVAILABLE,
      CTR_UPDATER_NETWORK,CTR_UPDATER_RATE_LIMIT,CTR_UPDATER_INVALID,CTR_UPDATER_UNAVAILABLE,
      CTR_UPDATER_NO_RELEASE,CTR_UPDATER_DOWNLOADING,CTR_UPDATER_READY,CTR_UPDATER_FAILED,CTR_UPDATER_NEEDS_SETUP};
typedef struct {CtrRelease release;uint32_t size;uint8_t digest[32];} CtrUpdatePackage;
typedef struct {int32_t state,error;uint32_t percent;char version[81];} CtrUpdaterResult;
typedef struct {
    int (*spawn)(void *(*entry)(void*),void *arg);
    int (*fetch)(const char*,char*,size_t,size_t*,int32_t*);
    uint64_t (*time_us)(void);
    int (*stage)(const uint8_t*,size_t,const uint8_t[32]);
} CtrUpdaterApi;
CTR_EXPORT int ctr_update_manifest_parse(const char*,size_t,CtrUpdatePackage*);
CTR_EXPORT int ctr_updater_url_allowed(const char*);
CTR_EXPORT int ctr_update_self_valid(const uint8_t*,size_t);
CTR_EXPORT int ctr_updater_init(const CtrUpdaterApi*);
CTR_EXPORT int ctr_updater_snapshot(CtrUpdaterResult*);
CTR_EXPORT int ctr_updater_check(void);
CTR_EXPORT int ctr_updater_install(void);
void ctr_updater_progress(size_t,size_t);

CTR_EXPORT uint32_t ctr_updater_version(void);

CTR_EXPORT void ctr_updater_tick(void);
CTR_EXPORT int ctr_updater_auto_prompt(void);
