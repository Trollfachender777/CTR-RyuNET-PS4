# CTR Nitro-Fueled Online - RyuNET — fuentes del constructor

Este código genera una aplicación local a partir de los archivos que aporte
cada usuario. No incluye juego, actualización, DLC, partidas ni identidades.
El primer inicio no importa el perfil global de desarrollo; cada usuario local
elige su apodo y genera su clave en la consola. No se usa el nombre de PSN.

Consulta ../EMPEZAR_AQUI.md y docs/PRIMER_INICIO_POR_USUARIO_ES.md.
Se conserva el cliente de PC sin cambios. La integración admite los ejecutables
compatibles CUSA13795 con actualización 1.21 documentados en source-release.json.
Una edición o imagen distinta se rechaza antes de modificar ejecutables.

Las fuentes nativas son exactas respecto al módulo probado en emulación.
Los cambios del constructor afectan rutas, nombres de salida y exclusión de
datos privados. Créditos y licencias están en docs/CREDITOS.md y licenses/.
La instalación real de la nueva revisión y la comprobación de los DLC generados
en una PS4 se registran por separado; no se afirma compatibilidad universal.
El HTTP 403 posterior observado antes no se considera resuelto aquí.
