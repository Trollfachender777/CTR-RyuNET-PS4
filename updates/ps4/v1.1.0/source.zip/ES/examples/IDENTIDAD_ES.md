No se copian perfiles. El primer inicio crea una identidad nueva por usuario local. Elige tu apodo dentro del juego y reinícialo. No añadas claves, perfiles, contactos ni partidas al constructor.
