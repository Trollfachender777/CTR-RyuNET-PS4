# Identidad individual por usuario local

El primer inicio pide un apodo propio de 3 a 16 letras, números, guion o
guion bajo. La consola genera 32 bytes mediante libSceRandom y guarda la
clave privada, su respaldo y el perfil bajo /data/ryunet/users/<usuario-local>/.
El identificador local selecciona la carpeta; no se incorpora al constructor
ni se utiliza como identidad online. El nombre de PSN no se usa como apodo.

Hay que cerrar normalmente y volver a abrir el juego después de elegir el
apodo. El siguiente arranque conserva la identidad. El perfil global de las
revisiones anteriores queda intacto, pero no se importa al espacio nuevo.
Tampoco se comparten contactos ni ajustes entre usuarios locales.

La autenticación sigue el contrato de OCTR 0.5.3: HMAC-SHA256 con el host y
cabecera X-RyuNET-Key, únicamente para http://octr.ryu7w7.xyz:8080.
No se reutiliza la clave del cliente PC ni se modifican sus archivos.
La clave y la cabecera no se escriben en los registros.

Un apodo puede pertenecer ya a otra identidad: elige uno nuevo propio.
No se omiten las reglas del servidor. Perder ambas copias de una clave
configurada deja el perfil offline; no se genera otra silenciosamente para
apropiarse del mismo nombre. Los archivos privados nuevos usan permisos0600.
El FTP puede listarlos sin poder leerlos: eso no indica que estén ausentes.

Para un respaldo privado, conserva los archivos del usuario propietario con
una herramienta que tenga acceso a ellos. No relajes sus permisos ni incluyas
perfiles, claves, partidas o contactos en un ZIP o PKG para otras personas.

En esta revisión se comprobó en la consola de desarrollo: asistente, guardado,
reinicio, carga del perfil, cabecera de posesión aceptada y entrada a Online
confirmada por el usuario. Hubo dos respuestas200 y una403 adicional; su URL
y motivo no quedaron registrados y no se consideran resueltos. No equivale
a una instalación del PKG completo en otra consola ni a una carrera entre redes.
