# CTR Nitro-Fueled Online - RyuNET

Guía rápida de los ajustes conservados en esta edición.

## Abrir los ajustes

Abre **CTR Nitro-Fueled Online - RyuNET** y presiona **L3 + R3** a la vez: pulsa ambos sticks hacia dentro. **Círculo** cierra el diálogo y vuelve al juego.

Los cambios gráficos se guardan, pero se aplican al **cerrar la aplicación normalmente y volver a abrirla**. Los cambios de límite de FPS se aplican al regresar al juego.

## Elegir Nativa, 720p o 480p

Entra en **FPS y gráficos → Gráficos → Resolución interna**.

1. Mira la resolución **Guardada** y la opción **Elegida**.
2. Pulsa **Siguiente** para recorrer **Nativa → 720p → 480p**.
3. Pulsa **Aplicar** para guardar la opción elegida. Recorrer las opciones no cambia nada hasta que la aplicas; Círculo cancela.
4. Cierra el juego normalmente y vuelve a abrirlo.

| Opción | Qué cambia |
| --- | --- |
| **Nativa** | Recupera la resolución original del juego para la consola. |
| **720p** | Usa el perfil de 720p existente, con el desenfoque de movimiento desactivado mientras este perfil esté seleccionado. |
| **480p** | Reduce más la resolución de la escena 3D y conserva la preferencia manual de desenfoque. La imagen se ve menos nítida. |

Elegir resolución **conserva el límite de FPS, las sombras, el apodo y los amigos**. Las opciones antiguas de rendimiento y calidad quedan representadas por este único selector.

La TV puede seguir indicando **1080p**: esa es la señal HDMI. La escena 3D puede renderizarse a menor resolución y ampliarse a la salida. Las imágenes de carga y otros elementos 2D pueden mantener su resolución.

## Sombras y desenfoque

Abre **FPS y gráficos → Gráficos → Más opciones → Efectos y sombras**.

- **Desenfoque:** guarda tu preferencia de movimiento. El perfil de 720p lo mantiene apagado; la preferencia manual se recupera al elegir Nativa o 480p.
- **Sombras dinámicas:** permite quitar o restaurar los controles de sombras incorporados en esta edición. Algunas sombras del escenario pueden permanecer visibles.

Ambos cambios gráficos requieren cerrar y volver a abrir el juego.

## Restaurar solo los gráficos

Entra en **FPS y gráficos → Gráficos → Más opciones → Restaurar gráficos** y confirma **Restaurar**.

Esto selecciona **Nativa**, activa el **desenfoque** y restaura las **sombras dinámicas**. Conserva **FPS, partida, apodo y amigos**. Después, cierra y vuelve a abrir el juego. **Cancelar** deja tus ajustes anteriores.

## Límite de FPS

En **FPS y gráficos → Límite de FPS**, elige **30 / 60 FPS** para seleccionar un límite, o **Sin límite** para retirar el limitador de esta edición.

El objetivo es **hasta 60 FPS** con el límite de 60. En las pruebas se observaron oscilaciones de GoldHEN entre 58 y 60; no se anuncia un bloqueo permanente a 60 en todas las pistas.

## Apodo y amigos

- **Online → Mi apodo:** cambia únicamente el apodo usado por RyuNET. Reabre el juego para usar el nuevo; tus amigos deben añadir ese apodo nuevo.
- **Online → Amigos → Añadir amigo:** escribe el apodo de RyuNET del otro jugador, de 1 a 16 caracteres, sin espacios. No es su identificador de PSN.
- **Online → Amigos → Ver / eliminar:** consulta o elimina contactos de tu lista local. Eliminar un contacto no te elimina automáticamente de la lista del otro jugador.

Para unirte a una partida, usa **Online → Amigos del menú original de CTR** y elige al contacto con una sala disponible. La opción duplicada de unirse desde L3+R3 se retiró; los ajustes y la gestión de contactos se conservan.

Se comprobó una carrera privada compartida con PC y la entrada desde la lista del cliente PC a salas privadas y públicas de PS4. Si el PC conserva información de un apodo anterior, cerrar y reabrir normalmente ese cliente renovó la consulta en las pruebas. No hace falta modificar sus archivos.

## Referencia de compatibilidad

La instalación utilizada corresponde a **CUSA13795, actualización 1.21**, en la aplicación separada **RYUN00001**. Se probó una PS4 base; el responsable de la prueba indicó firmware **13.52** y GoldHEN **v2.4b18.12**. El cliente PC usado para comprobar la conexión fue **OCTR v0.5.3**.

Estos datos describen la instalación de prueba; no acreditan todas las ediciones, modelos o firmwares. El estado específico de los controles nuevos figura en [Validación](VALIDACION.md). Los autores y referencias están en [Créditos](CREDITOS.md).
