# Menú de amigos — revisión 22

Se retira únicamente «Unirse a amigo» del menú L3+R3, a petición del usuario.

L3+R3 → Online → Amigos ofrece:

- Añadir amigo.
- Ver / eliminar → Ver lista o Eliminar amigo.

La entrada a partidas se conserva en Online → Amigos del menú original de
CTR. El módulo de sesiones, las respuestas de amigos, el túnel de red y sus
comprobaciones coinciden exactamente con la revisión 21. No se cambian FPS,
gráficos, apodo, formato de configuración ni archivos de PC.

El cambio de comportamiento solo está en menu.c. native_bridge.c cambia
únicamente el marcador de revisión. Los números de estados restantes se
conservan. Las pruebas existentes del menú se adaptan al acceso directo a
Ver / eliminar y comprueban que consultar contactos no solicita una unión.

La instalación sustituye solo el módulo externo después de cerrar el juego
normalmente, con respaldo exacto previo y lectura de verificación por FTP.
Los informes de compilación, pruebas, staging e instalación determinan el
estado efectivo; esta nota no acredita una prueba física en la consola.

Las invitaciones se mantienen fuera del alcance por decisión del usuario.
