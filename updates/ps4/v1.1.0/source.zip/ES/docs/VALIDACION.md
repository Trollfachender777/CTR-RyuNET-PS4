# Estado de validación

- 147 grupos locales:106 de lógica,38 de ABI nativa y3 de aislamiento entre usuarios.
- Recompilación portable idéntica byte a byte al módulo instalado en PS4.
- Asistente, nuevo perfil persistente y acceso a Online confirmados en la consola de desarrollo.
- Extracción de los ejecutables de las copias locales de juego y actualización contrastada con sus hashes compatibles.
- DLC de ejemplo extraído, vinculado a la nueva aplicación y empaquetado con validación de contenedor.
- Prueba de ida y vuelta de un PFS cifrado con archivos anidados; un PKG alterado es rechazado.
- 42 casos criptográficos comparados con la implementación original; título del staging verificado.

El reconocimiento del DLC en PS4, una instalación usando únicamente el PKG
completo en otra consola y una carrera entre redes con esta identidad siguen
pendientes. Hay una respuesta403 adicional sin causa identificada. Las pruebas
locales no acreditan compatibilidad universal ni60FPS permanentes.
