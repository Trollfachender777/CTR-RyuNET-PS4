# Compatibilidad de red con OCTR 0.5.3 — PS4 r19

Esta candidata adapta el túnel UDP de OCTR 0.5.3 a la aplicación nativa de PS4.
La revisión 19 está instalada en la consola utilizada y su módulo se verificó
por FTP. Su objetivo es permitir conexiones entre jugadores que no tienen una ruta directa
por el tipo de NAT de sus redes. No está comprobada todavía en una carrera entre
dos casas y no se presenta como una corrección confirmada del estado de los amigos.

Referencia exacta: [OCTR 0.5.3, d5be87d](https://github.com/Ryu7w7/OCTR-NitroFueled-PC/tree/d5be87dc0b9be6d947bc27654c0ee596e0eb93d3).
Se adaptan `runtime_net_tunnel.c`, su cabecera y el transporte de `runtime_net.c`.
Las notas oficiales indican que ambos extremos necesitan soporte del túnel.

## Qué cambia

- La PS4 conserva los envíos directos del juego y añade paquetes compatibles con
  el túnel del servidor mientras la ruta directa no esté confirmada en ambos sentidos.
- Solo se interviene el socket IPv4 de tipo datagrama que el juego enlaza al puerto
  3074. Las conexiones de autenticación y los demás sockets mantienen su recorrido.
- Al recibir un paquete reenviado por el servidor, se retira su cabecera y se
  entrega al juego el paquete con la dirección del jugador de origen.
- Las direcciones de red local siguen usando la conexión directa. Se conservan las
  consultas NAT originales. No se abren puertos del router ni se cambian sus ajustes.
- Los controles de gráficos, FPS, apodo, contactos, partida y el cliente de PC
  conservan su código o configuración. No se genera un PKG nuevo en esta fase.

Los sockets y la memoria se gestionan sin tareas residentes nuevas ni esperas de
sondeo. La lectura del socket no retiene el bloqueo de la tabla de pares, de forma
que otro hilo del juego puede seguir enviando por el túnel. Los diagnósticos no
registran direcciones IP.

## Prueba pendiente

1. Comprobar que arranca la aplicación y llega a Online.
2. Con un amigo en otra red que use PC 0.5.3, intentar entrar en una sala privada
   primero desde PS4 y después en sentido contrario. Para PS4 ↔ PS4, ambas consolas
   necesitan esta adaptación; una instalación anterior carece del túnel.
3. Completar una carrera y repetir con más de dos jugadores antes de afirmar que
   funciona en grupos o en distintos países. El país por sí solo no determina la
   conectividad: importan las redes y la disponibilidad del servidor.
4. Comprobar por separado el estado mostrado en Amigos. El túnel no es un servicio
   de presencia y no se ha inventado una API remota para anunciar amigos conectados.

El registro distingue instalación de los cuatro adaptadores, resolución del
servidor, socket del juego y paquetes del túnel enviados/recibidos. Ver paquetes
no acredita por sí solo una carrera completa. Las pruebas locales incluyen el
formato original y comparación de decisiones con el código sin modificar de
OCTR 0.5.3, además de ejecución del módulo SELF con las llamadas nativas simuladas.

## Recuperación

La revisión 18 queda respaldada. La reversión usa el sello `network-v053` y exige
cerrar el juego normalmente antes de sustituir el módulo. Conserva los archivos
de ajustes y perfil. No se debe reemplazar el módulo con el juego abierto.
