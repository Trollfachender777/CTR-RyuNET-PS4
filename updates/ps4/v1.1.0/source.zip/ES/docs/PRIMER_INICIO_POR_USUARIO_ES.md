# Primer inicio por usuario

La revisión nueva no importa el antiguo perfil global de desarrollo.
Cada usuario local de la PS4 tiene una carpeta propia bajo
`/data/ryunet/users/<usuario-local>/`. Esa carpeta se decide en ejecución;
ningún identificador de esta consola está incorporado al código o al PKG.

Si el usuario no está configurado, empieza offline y aparece el asistente.
El jugador elige un apodo propio y la consola genera una clave aleatoria.
Después debe cerrar y volver a abrir el juego. En las siguientes ejecuciones
se conserva ese perfil; la clave no se vuelve a generar en cada arranque.

No se usa el nombre de PSN como apodo. El identificador local solo selecciona
su carpeta; no se envía como identidad online. El servicio sigue identificando
al jugador por su apodo RyuNET y la prueba de posesión de su clave privada.
Dos usuarios de la misma consola tampoco comparten contactos ni ajustes.

El antiguo `/data/ryunet/profile.ini` y sus ajustes permanecen intactos como
respaldo de la revisión anterior. No se incluyen perfiles, claves, partidas,
logs ni contactos en el constructor que se comparte.

Se rechazan perfiles antiguos sin clave dentro del nuevo espacio de usuario.
Perder las dos copias de una clave configurada deja el perfil offline; no se
reemplaza silenciosamente con otra clave para el mismo apodo.

Las pruebas nativas verifican el asistente, el aislamiento entre dos usuarios,
la omisión del perfil global y la persistencia. La prueba real de primer inicio,
reinicio y entrada a Online pasó en la consola de desarrollo. Permanece una
respuesta403 adicional sin causa identificada; no se afirma haberla corregido.
Una instalación usando solo el nuevo PKG en otra consola sigue sin verificarse.
