# Créditos y referencias

**CTR Online RyuNet Unofficial PS4** es una adaptación comunitaria no oficial. Los nombres siguientes reconocen el trabajo original y las herramientas utilizadas; no implican participación o aprobación de sus autores en esta edición de PS4.

## Código y referencias de la adaptación

- **Ryu7w7 y colaboradores — [OCTR-NitroFueled-PC](https://github.com/Ryu7w7/OCTR-NitroFueled-PC):** referencia principal para la compatibilidad con RyuNET, identidad, sesiones y amigos.
- **GetLostIn — [CTR-NitroFueled-PC](https://github.com/GetLostIn/CTR-NitroFueled-PC):** proyecto de Windows del que deriva OCTR.
- **T3CHNOLOG1C — SacredFire**, junto con los colaboradores de **bbport** y **shadPS4:** antecedentes del proyecto PC reconocidos por el [README de OCTR](https://github.com/Ryu7w7/OCTR-NitroFueled-PC#readme).
- **Adaptación y validación en PS4:** trabajo realizado para esta edición comunitaria, incluyendo el menú L3+R3, los controles gráficos y de FPS, el apodo y la integración de amigos con el juego de PS4.

Las referencias de código conservadas para este trabajo incluyen OCTR `05ddf38f906a364b8c2cd1cc3d56243e7389ba19` y, para sesiones y escalado, `64ea69db82784a3361211933e5e8643141acf3ee`. No se atribuye a esta edición la creación del servidor RyuNET ni del port original de PC.

## Herramientas de desarrollo

- **[OpenOrbis PS4 Toolchain](https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain)** y **[create-fself](https://github.com/OpenOrbis/create-fself):** compilación y preparación del módulo instalable.
- **[GoldHEN Plugins SDK](https://github.com/GoldHEN/GoldHEN_Plugins_SDK):** código de arranque del módulo. El SDK conserva el aviso MIT de GoldHEN de 2022.
- **LLVM/Clang:** compilación y análisis del código nativo.
- **Unicorn:** ejecución de pruebas de instrucciones y del ABI de PS4 en un entorno simulado.

## Licencias conservadas

Los archivos propios del módulo llevan el identificador `GPL-2.0-only`. La distribución PC consultada declara `GPL-2.0-or-later`; se conserva el texto de GPL versión 2 como referencia. Las herramientas OpenOrbis y create-fself consultadas incluyen GPL versión 3, y el código de arranque del SDK GoldHEN incluye MIT. Las herramientas de desarrollo no se atribuyen al autor de esta adaptación.

Copias de los avisos consultados:

- [GNU GPL versión 2](../licenses/GPL-2.0.txt).
- [Licencia de OpenOrbis](../licenses/OpenOrbis-LICENSE.txt).
- [Licencia de create-fself](../licenses/create-fself-LICENSE.txt).
- [Licencia del SDK GoldHEN](../licenses/GoldHEN-SDK-MIT.txt).

El juego original **Crash Team Racing: Nitro-Fueled**, sus activos y sus marcas corresponden a sus respectivos titulares. Beenox, Activision, Sony y los autores de los proyectos citados no se presentan como autores o patrocinadores de esta adaptación.

Esta carpeta contiene documentación y avisos. No constituye una publicación del código fuente ni un nuevo instalador del juego.
