"""Update an existing external-module installation with exact baseline checks."""
from pathlib import Path
import argparse,hashlib,io,json,sys
from datetime import datetime,timezone
from ftplib import FTP

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/crash-ryunet-vnext'))
from ps4_transport import require_self,matches_readback,stored_size
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--host',required=True,help='IP of your own PS4')
parser.add_argument('--port',type=int,default=2121)
parser.add_argument('--module',type=Path,required=True)
parser.add_argument('--baseline',type=Path,required=True,help='Original installable SELF matching the currently installed module')
parser.add_argument('--game-closed',action='store_true')
parser.add_argument('--install',action='store_true',help='Without this flag only validates local SELF files; no network access')
args=parser.parse_args()
new=require_self(args.module.read_bytes());old=require_self(args.baseline.read_bytes())
sha=lambda data:hashlib.sha256(data).hexdigest()
if not args.install:
    print(json.dumps({'local_self_valid':True,'module_sha256':sha(new),'baseline_sha256':sha(old),'network_used':False}))
    raise SystemExit(0)
if not args.game_closed:parser.error('Close RyuNET normally and supply --game-closed before installing')
ftp=FTP(timeout=10)
def read(path,limit=1024*1024):
    output=io.BytesIO()
    def block(data):
        if output.tell()+len(data)>limit:raise ValueError('Unexpected file size')
        output.write(data)
    ftp.retrbinary('RETR '+path,block)
    return output.getvalue()
def upload(path,data):
    ftp.storbinary('STOR '+path,io.BytesIO(data))
    assert stored_size(ftp,path)==len(data) and matches_readback(data,read(path))
temporary='/data/ryunet/ctr_online.prx.source-update'
installed=False
try:
    ftp.connect(args.host,args.port);ftp.login()
    assert not any(x.rsplit('/',1)[-1].startswith('RYUN00001_') for x in ftp.nlst('/mnt/sandbox')),'Game is still in use'
    target='/data/ryunet/ctr_online.prx'
    assert stored_size(ftp,target)==len(old) and matches_readback(old,read(target)),'Baseline does not match installed module'
    settings=read('/data/ryunet/settings.ini',4096);profile=read('/data/ryunet/profile.ini',128)
    folder=ROOT/'private-backups'/datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')
    folder.mkdir(parents=True,exist_ok=False)
    (folder/'ctr_online.prx').write_bytes(old)
    (folder/'settings.ini').write_bytes(settings);(folder/'profile.ini').write_bytes(profile)
    upload(temporary,new)
    try:
        ftp.rename(temporary,target)
        assert stored_size(ftp,target)==len(new) and matches_readback(new,read(target))
        assert read('/data/ryunet/settings.ini',4096)==settings
        assert read('/data/ryunet/profile.ini',128)==profile
        installed=True
    except Exception:
        upload(temporary,old);ftp.rename(temporary,target)
        raise
finally:ftp.close()
print(json.dumps({'installed':installed,'module_sha256':sha(new),'settings_and_profile_preserved':True,'backup':str(folder)}))
