# CTR Nitro-Fueled Online - RyuNET - builder source

This source builds a local application from files supplied by each user.
It contains no game, update, DLC, saves or identities. First launch does not
import the old global development profile. Each local user chooses a nickname
and generates a key on the console. The PSN name is not used as a nickname.

See ../START_HERE.md and docs/FIRST_RUN_PER_USER_EN.md.
The official PC client is unchanged. The integration supports the compatible
CUSA13795 update 1.21 executables documented in source-release.json.
Another edition or incompatible image is rejected before executables are modified.

The English edition translates the builder and custom PS4 menu text. The menu
state machine, graphics/FPS controls, networking, identities, friends, file
formats and package title are retained. Credits and licenses are in
docs/CREDITS.md and licenses/. Physical installation, English console-menu
verification and generated DLC recognition are recorded separately. Universal
compatibility is not claimed. The previously observed additional HTTP 403 is
not treated as resolved by a language translation.
