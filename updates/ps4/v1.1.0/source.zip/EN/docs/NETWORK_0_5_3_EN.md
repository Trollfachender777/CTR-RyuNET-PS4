# OCTR 0.5.3 network compatibility - PS4 r19

This candidate adapts OCTR 0.5.3's UDP tunnel to the native PS4 application.
Revision 19 was installed on the test console and its module verified over FTP.
It targets connections without a direct route due to NAT. A race between two
homes was not verified at that stage, and it was not presented as a confirmed
friend-presence fix.

Exact reference: [OCTR 0.5.3, d5be87d](https://github.com/Ryu7w7/OCTR-NitroFueled-PC/tree/d5be87dc0b9be6d947bc27654c0ee596e0eb93d3).
The adaptation uses runtime_net_tunnel.c, its header and runtime_net.c transport.
The upstream notes require tunnel support at both ends.

## Changes

- PS4 retains direct game sends and adds server-tunnel-compatible packets until
  the direct route is confirmed in both directions.
- Only the IPv4 datagram socket bound by the game to port 3074 is intercepted.
  Authentication and other sockets retain their paths.
- Forwarded packets have the server header removed and reach the game with
  the originating player's address.
- Local addresses use direct connections. Original NAT queries are retained.
  Router ports are not opened and router settings are unchanged.
- Graphics, FPS, nickname, contacts, saves and PC-client code/configuration
  are preserved. A new PKG was not generated during that phase.

Socket and memory handling add no resident tasks or polling waits. Socket reads
do not hold the peer-table lock, allowing another game thread to send through
the tunnel. Diagnostics do not log IP addresses.

## Separate testing

1. Check application startup and Online access.
2. With a PC 0.5.3 friend on another network, try a private room from PS4 and
   then in the opposite direction. Both PS4s need this adaptation for PS4-to-PS4;
   older installations lack the tunnel.
3. Complete a race and repeat with more than two players before claiming
   multi-player/cross-country compatibility. Networks and server availability,
   rather than the country alone, determine connectivity.
4. Check Friends presence separately. The tunnel is not a presence service,
   and no remote presence API was invented.

Logs distinguish the four installed adapters, server resolution, game socket
and tunnel sends/receives. Seeing packets alone is not proof of a complete race.
Local tests compare original formats/decisions with unmodified OCTR 0.5.3 and
execute the native SELF with simulated native calls.

## Recovery

Revision 18 remains backed up. Rollback uses the network-v053 marker and requires
closing the game normally before replacing the module. Settings and profile
files are preserved. Do not replace a module while the game is open.
