# Individual identity per local user

First launch asks for your own nickname: 3-16 letters, numbers, hyphens or
underscores. The console generates 32 bytes through libSceRandom and stores
the private key, its backup and the profile under /data/ryunet/users/<local-user>/.
The local user ID selects that folder. It is not embedded in the builder or
used as the online identity. The PSN name is not used as the nickname.

Close the game normally and reopen it after choosing a nickname. The next
launch retains the identity. The old global profile remains intact but is
not imported into the new space. Local users do not share contacts or settings.

Authentication follows the OCTR 0.5.3 contract: HMAC-SHA256 with the host and
X-RyuNET-Key header, only for http://octr.ryu7w7.xyz:8080. The PC client's key
is not reused and its files are unchanged. Keys and this header are not logged.

A nickname may already belong to another identity; choose a new name of your
own. Server rules are retained. Losing both copies of a configured key leaves
the profile offline. Another key is not silently generated to take over the
same name. New private files use permissions 0600. FTP may list them without
allowing reads; this does not mean the files are missing.

For a private backup, preserve the owning user's files with a tool that can
access them. Do not relax permissions or include profiles, keys, saves or
contacts in a ZIP or PKG for other people.

The original revision was checked on the test console: setup, saving, restart,
profile loading, accepted proof-of-ownership header and user-confirmed Online
access. Two HTTP 200 responses and one additional 403 were observed. The 403
URL/cause was not recorded and is not claimed resolved. These checks do not
establish installation on another console or a race across separate networks.
