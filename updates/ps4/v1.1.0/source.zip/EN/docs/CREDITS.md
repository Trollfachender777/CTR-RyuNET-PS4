# Credits and references

**CTR Online RyuNet Unofficial PS4** is an unofficial community adaptation.
The following names credit original work and tools; they do not imply their
authors participated in or endorsed this PS4 edition.

## Adaptation source and references

- **Ryu7w7 and contributors - [OCTR-NitroFueled-PC](https://github.com/Ryu7w7/OCTR-NitroFueled-PC):** primary reference for RyuNET, identity, sessions and friends compatibility.
- **GetLostIn - [CTR-NitroFueled-PC](https://github.com/GetLostIn/CTR-NitroFueled-PC):** Windows project from which OCTR derives.
- **T3CHNOLOG1C - SacredFire**, with the **bbport** and **shadPS4** contributors: PC-project foundations acknowledged by the [OCTR README](https://github.com/Ryu7w7/OCTR-NitroFueled-PC#readme).
- **PS4 adaptation and validation:** work for this community edition, including L3+R3 settings, graphics/FPS controls, nickname and friend integration with the PS4 game.

Preserved source references include OCTR `05ddf38f906a364b8c2cd1cc3d56243e7389ba19`
and, for sessions and scaling, `64ea69db82784a3361211933e5e8643141acf3ee`.
This edition does not claim authorship of the RyuNET server or original PC port.

## Development tools

- **[OpenOrbis PS4 Toolchain](https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain)** and **[create-fself](https://github.com/OpenOrbis/create-fself):** compilation and preparation of the installable module.
- **[GoldHEN Plugins SDK](https://github.com/GoldHEN/GoldHEN_Plugins_SDK):** module startup code. The SDK retains GoldHEN's 2022 MIT notice.
- **LLVM/Clang:** native compilation and analysis.
- **Unicorn:** instruction and PS4-ABI testing in a simulated environment.

## Preserved licenses

The module's own files carry `GPL-2.0-only`. The referenced PC distribution
declares `GPL-2.0-or-later`; the GPL version 2 text is retained as a reference.
The referenced OpenOrbis and create-fself tools include GPL version 3, and the
GoldHEN SDK startup code includes MIT. Tool authorship is not attributed to
the author of this adaptation.

- [GNU GPL version 2](../licenses/GPL-2.0.txt).
- [OpenOrbis license](../licenses/OpenOrbis-LICENSE.txt).
- [create-fself license](../licenses/create-fself-LICENSE.txt).
- [GoldHEN SDK license](../licenses/GoldHEN-SDK-MIT.txt).

The original **Crash Team Racing: Nitro-Fueled** game, assets and trademarks
belong to their respective rights holders. Beenox, Activision, Sony and the
referenced project authors are not presented as authors or sponsors of this
adaptation. This documentation folder is not itself a source publication or
a new game installer.
