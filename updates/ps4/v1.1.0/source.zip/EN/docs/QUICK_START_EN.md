# CTR Nitro-Fueled Online - RyuNET

Quick reference for the settings retained in this edition.

## Open settings

Open **CTR Nitro-Fueled Online - RyuNET** and press **L3 + R3** together by
clicking both sticks. **Circle** closes the dialog and returns to the game.

Graphics settings are saved but take effect after you **close the application
normally and reopen it**. FPS-limit changes apply when you return to the game.

## Choose Native, 720p or 480p

Open **FPS and graphics -> Graphics -> Internal resolution**.

1. Check the **Saved** resolution and the **Selected** option.
2. Press **Next** to cycle through **Native -> 720p -> 480p**.
3. Press **Apply** to save the selected option. Cycling does not apply it;
   Circle cancels.
4. Close the game normally and reopen it.

| Option | Effect |
| --- | --- |
| Native | Restores the game's original resolution for the console. |
| 720p | Uses the existing 720p profile, with motion blur disabled while selected. |
| 480p | Further reduces 3D-scene resolution and preserves the manual blur preference. The image is less sharp. |

Choosing a resolution preserves the FPS limit, shadows, nickname and friends.
The old performance and quality choices are represented by this single selector.

The TV may still report **1080p**, which is the HDMI signal. The 3D scene can
render at a lower resolution and be upscaled. Loading images and other 2D
elements can retain their original resolution.

## Shadows and motion blur

Open **FPS and graphics -> Graphics -> More options -> Effects and shadows**.

- **Motion blur:** saves your preference. The 720p profile keeps it disabled;
  the manual preference returns when Native or 480p is selected.
- **Dynamic shadows:** removes or restores the shadow controls included in
  this edition. Some scenery shadows can remain visible.

Both graphics changes require closing and reopening the game.

## Restore graphics only

Open **FPS and graphics -> Graphics -> More options -> Restore graphics**
and confirm **Restore**. This selects **Native**, enables **motion blur** and
restores **dynamic shadows**. FPS, saves, nickname and friends are preserved.
Close and reopen the game. **Cancel** keeps your previous settings.

## FPS limit

Under **FPS and graphics -> FPS limit**, choose **30 / 60 FPS** to select a
cap, or **Unlimited** to remove this edition's limiter. The 60-FPS option
targets up to 60 FPS. GoldHEN fluctuated between 58 and 60 during testing;
a permanent 60-FPS lock on every track is not advertised.

## Nickname and friends

- **Online -> My nickname:** changes only the nickname used by RyuNET. Reopen
  the game to use it. Friends must add the new nickname.
- **Online -> Friends -> Add friend:** enter the other player's RyuNET
  nickname, 1-16 characters with no spaces. This is not their PSN ID.
- **Online -> Friends -> View / remove:** view or remove local contacts.
  Removing someone does not automatically remove you from their list.

To join a game, use **Online -> Friends in the original CTR menu** and choose
a contact with an available room. The duplicate L3+R3 Join option was removed;
settings and contact management are retained.

A shared private race with PC and joining PS4 private/public rooms through the
PC client's normal friend list were tested. If the PC keeps information about
an older nickname, closing and reopening that client refreshed its query in
testing. Its files do not need modification.

## Compatibility reference

The test installation uses **CUSA13795, update 1.21**, as the separate app
**RYUN00001**. One base PS4 was tested. The tester reported firmware **13.52**
and GoldHEN **v2.4b18.12**. The PC connection reference was **OCTR v0.5.3**.
These describe the test setup, not all editions, models or firmware versions.
See [Validation](VALIDATION.md) and [Credits](CREDITS.md).
