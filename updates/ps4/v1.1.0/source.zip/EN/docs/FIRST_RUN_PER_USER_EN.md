# First launch per user

The new revision does not import the old global development profile. Each
local PS4 user has a folder under `/data/ryunet/users/<local-user>/`. It is
selected at runtime; no ID from the test console is embedded in source or PKG.

An unconfigured user starts offline and sees setup. The player chooses a
nickname and the console generates a random key. Close and reopen the game.
Later launches retain the profile; the key is not regenerated each time.

The PSN name is not used as the nickname. The local user ID only selects the
folder and is not sent as the online identity. The service identifies the
player by their RyuNET nickname and proof of ownership of the private key.
Two users of the same console do not share contacts or settings.

The old `/data/ryunet/profile.ini` and settings remain intact as an earlier
revision's backup. Profiles, keys, saves, logs and contacts are not included
in the shared builder.

Old profiles without a key are rejected in the new per-user space. Losing
both copies of a configured key leaves the profile offline; another key is
not silently substituted for the same nickname.

Native tests cover setup, isolation between two users, skipping the global
profile and persistence. Actual first launch, restart and Online access passed
on the test console for the approved revision. An additional HTTP 403 had no
identified cause and is not claimed fixed. A complete-PKG-only installation
on another console remains unverified.
