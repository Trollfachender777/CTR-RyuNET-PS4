# Validation status

- The approved revision has 147 local groups: 106 logic, 38 native ABI and 3 user-isolation groups.
- The original portable build reproduced the approved PS4 module byte for byte.
- Setup, a persistent new profile and Online access were confirmed on the test console.
- Game/update executable extraction was checked against the compatible hashes.
- The example DLC was extracted, linked to the new app and packaged with container validation.
- An encrypted PFS with nested files passed a round trip; a modified PKG was rejected.
- 42 cryptographic cases were compared with the original implementation; staging title identity was checked.

The English edition translates labels and paths while preserving the approved
logic. Its build and test results are recorded separately. A physical-console
test of the English menu is not claimed by the original Spanish result.
DLC recognition on PS4, a complete-PKG-only installation on another console
and a race across separate networks with this identity remain separate checks.
An additional HTTP 403 previously lacked an identified cause. Local testing
does not establish universal compatibility or permanent 60 FPS.
