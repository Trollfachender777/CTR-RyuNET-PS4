# Friends menu - revision 22

Only "Join friend" was removed from L3+R3 at the user's request.

L3+R3 -> Online -> Friends offers:

- Add friend.
- View / remove -> View list or Remove friend.

Joining remains available in Online -> Friends in the original CTR menu.
The session module, friend responses, network tunnel and their checks match
revision 21. FPS, graphics, nickname, settings format and PC files are unchanged.

The behavior change is confined to menu.c; native_bridge.c changes only the
revision marker. Other state numbers are preserved. Existing menu tests use
the direct View / remove route and check that listing contacts does not request
a join. The English edition changes displayed text, not these routes.

Installation replaces only the external module after closing the game normally,
with an exact backup and FTP readback verification. Build, test, staging and
installation reports establish actual status; this historical note is not
proof of a physical console test. Invitations remain excluded by user choice.
