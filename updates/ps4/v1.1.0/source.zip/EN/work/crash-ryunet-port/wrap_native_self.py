"""Package the existing Orbis ELFs without rehashing their original imports.

Format follows OpenOrbis/create-fself pkg/fself (GPL-3.0), based on flatz.
Only unencrypted homebrew SELF containers are produced; no keys or decryption.
"""
from pathlib import Path
import struct,hashlib,sys,json
ROOT=Path(__file__).resolve().parent;CHAT=ROOT.parent.parent
sys.path.insert(0,str(CHAT/'outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts'))
import prepare
def align(x,a=16):return (x+a-1)&-a
SELF_SEGMENTS=(1,0x61000000,0x61000010,0x6fffff00)
def wrap(source,target,paid):
    raw=Path(source).read_bytes();elf,eh,ph,_,_=prepare.parse_elf(raw)
    # The owned eboot has a real PT_SCE_COMMENT entry. It must survive wrapping,
    # even though it is not mapped as executable code. PT_SCE_VERSION is a
    # version descriptor rather than a segment backed by a SELF data entry.
    selected=[(i,p) for i,p in enumerate(ph) if p['type'] in SELF_SEGMENTS]
    count=len(selected)*2
    header_size=align(32+count*32+64+len(ph)*56)+64+48
    meta_size=count*80+80+256
    position=header_size+meta_size
    entries=[];payloads=[]
    for index,p in selected:
        meta=bytes(align(p['filesz'],0x4000)//0x4000*32)
        ordinal=len(entries)
        entries.append((4|(1<<16)|((ordinal+1)<<20),position,len(meta),len(meta)));payloads.append((position,meta));position=align(position+len(meta))
        data=prepare.span(elf,p['offset'],p['filesz'])
        entries.append((4|0x800|0x2000|(index<<20),position,len(data),len(data)));payloads.append((position,data));position=align(position+len(data))
    result=bytearray(position)
    struct.pack_into('<IBBBBIHHQHHI',result,0,0x1d3d154f,0,1,1,0x12,0x101,header_size,meta_size,position,count,0x22,0)
    for i,item in enumerate(entries):struct.pack_into('<QQQQ',result,32+i*32,*item)
    offset=32+count*32
    result[offset:offset+64]=elf[:64]
    for i,p in enumerate(ph):struct.pack_into('<IIQQQQQQ',result,offset+64+i*56,*[p[k] for k in ('type','flags','offset','vaddr','paddr','filesz','memsz','align')])
    ext=align(offset+64+len(ph)*56)
    struct.pack_into('<QQQQ32s',result,ext,paid,1,0,0,hashlib.sha256(elf).digest())
    struct.pack_into('<H',result,ext+64,3)
    struct.pack_into('<I',result,header_size+count*80+48,0x10000)
    for offset,data in payloads:result[offset:offset+len(data)]=data
    decoded,dh,dph,_,_=prepare.parse_self(result)
    assert len(dph)==len(ph)
    for p in ph:
        if p['type'] in SELF_SEGMENTS:assert prepare.span(decoded,p['offset'],p['filesz'])==prepare.span(elf,p['offset'],p['filesz'])
    Path(target).write_bytes(result)
    return {'file':str(target),'bytes':len(result),'sha256':hashlib.sha256(result).hexdigest(),'self_payload_segments_verified':len(selected),'dynamic_metadata_preserved':True,'sce_comment_preserved':any(p['type']==0x6fffff00 for _,p in selected),'console_execution_verified':False}
if __name__=='__main__':
    reports=[]
    for source,target,paid in (('eboot.native.elf','eboot.native.bin',0x3100000000000001),('np_toolkit.native.elf','libSceNpToolkit2.native.prx',0x3800000000000011)):
        reports.append(wrap(ROOT/'build'/source,ROOT/'build'/target,paid))
    (ROOT/'build/self-verification.json').write_text(json.dumps(reports,indent=2))
    print(json.dumps(reports,indent=2))
