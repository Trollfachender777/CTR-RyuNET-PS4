// SPDX-License-Identifier: LGPL-3.0-only
// Optional local telemetry. No package bytes, filenames or identities are sent.
using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace LibOrbisPkg.Util
{
  public static class BuildProgress
  {
    public static readonly bool Enabled = Environment.GetEnvironmentVariable("CTR_BUILD_PROGRESS") == "1";
    public sealed class Counter
    {
      readonly string phase;
      readonly long total;
      readonly object gate = new object();
      readonly Stopwatch watch = Stopwatch.StartNew();
      long completed, last;
      public Counter(string phase, long total)
      {
        this.phase = phase; this.total = Math.Max(1, total);
        if (Enabled) Emit(0);
      }
      void Emit(long value)
      {
        Console.WriteLine("CTR_PROGRESS|" + phase + "|" + value + "|" + total);
        Console.Out.Flush();
      }
      public void Advance(long amount)
      {
        if (!Enabled) return;
        Interlocked.Add(ref completed, amount);
        long now = watch.ElapsedMilliseconds;
        if (now - Interlocked.Read(ref last) < 500) return;
        lock (gate)
        {
          now = watch.ElapsedMilliseconds;
          if (now - last < 500) return;
          last = now;
          Emit(Math.Min(total - 1, Interlocked.Read(ref completed)));
        }
      }
      public void Complete()
      {
        if (!Enabled) return;
        lock (gate) Emit(total);
      }
    }

    // Forward every operation; leave the original stream open. Count only bytes
    // whose Write completed, never allocated length, seeks or SetLength calls.
    public sealed class WriteStream : Stream
    {
      readonly Stream inner;
      readonly Counter counter;
      public WriteStream(Stream inner, Counter counter) { this.inner=inner; this.counter=counter; }
      public override bool CanRead => inner.CanRead;
      public override bool CanSeek => inner.CanSeek;
      public override bool CanWrite => inner.CanWrite;
      public override long Length => inner.Length;
      public override long Position { get => inner.Position; set => inner.Position=value; }
      public override void Flush() => inner.Flush();
      public override int Read(byte[] buffer,int offset,int count) => inner.Read(buffer,offset,count);
      public override long Seek(long offset,SeekOrigin origin) => inner.Seek(offset,origin);
      public override void SetLength(long value) => inner.SetLength(value);
      public override void Write(byte[] buffer,int offset,int count) { inner.Write(buffer,offset,count); counter.Advance(count); }
      public override void WriteByte(byte value) { inner.WriteByte(value); counter.Advance(1); }
    }
  }
}
