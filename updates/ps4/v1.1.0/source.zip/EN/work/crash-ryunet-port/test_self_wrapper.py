"""Regression: every originally represented SELF segment must survive wrapping."""
from pathlib import Path
import struct, tempfile, json, hashlib, sys, os
sys.path.insert(0,str(Path(__file__).resolve().parent))
from wrap_native_self import wrap, prepare, ROOT, CHAT

source=Path(os.environ['CTR_GAME_DIR'])
results=[]
with tempfile.TemporaryDirectory(dir=ROOT/'build') as temp:
    for name,paid in [('eboot.bin',0x3100000000000001),('sce_module/libSceNpToolkit2.prx',0x3800000000000011)]:
        original=(source/name).read_bytes()
        elf,eh,ph,_,_=prepare.parse_self(original)
        indices=[(struct.unpack_from('<Q',original,32+i*32)[0]>>20)&0xfff for i in range(struct.unpack_from('<H',original,24)[0]) if struct.unpack_from('<Q',original,32+i*32)[0]&0x800]
        target=Path(temp)/'roundtrip.self';plain=Path(temp)/'source.elf';plain.write_bytes(elf)
        wrap(plain,target,paid)
        new=target.read_bytes();decoded,neweh,newph,_,_=prepare.parse_self(new)
        newindices=[(struct.unpack_from('<Q',new,32+i*32)[0]>>20)&0xfff for i in range(struct.unpack_from('<H',new,24)[0]) if struct.unpack_from('<Q',new,32+i*32)[0]&0x800]
        assert indices==newindices,(name,indices,newindices)
        assert eh==neweh and ph==newph
        for i in indices:
            p=ph[i];assert elf[p['offset']:p['offset']+p['filesz']]==decoded[p['offset']:p['offset']+p['filesz']]
        results.append({'file':name,'original_payload_indices':indices,'wrapped_payload_indices':newindices,'all_original_payload_bytes_preserved':True})
report={'successful':True,'scope':'Original SELF payload coverage, not console acceptance','results':results}
(ROOT/'build/self-wrapper-test.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
