"""Build two native, reversible ELF integration images from the owned dump.

Uses existing segment padding and extends the existing zero-filled data BSS.
Original import slots, dynamic metadata, entry points, TLS and engine code stay
at their existing RVAs. Imported PLT entries select a zero-initialized port slot,
falling through to the real system import until native initialization succeeds.
"""
from pathlib import Path
import sys,json,struct,subprocess,hashlib,re,os
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from compact_routes import assembly as compact_assembly
CHAT=ROOT.parent.parent
TOOLS=CHAT/'work/ps4-online'
PORT=CHAT/'outputs/Crash_Online/CTR-NitroFueled-PC-portable'
sys.path.insert(0,str(PORT/'scripts'))
import prepare
SRC=ROOT/'src';BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
GAME=Path(os.environ['CTR_GAME_DIR']).resolve()
LLVM=Path(os.environ.get('CTR_LLVM_BIN',TOOLS/'llvm/bin'))
EXPECTED=json.loads((CHAT/'source-release.json').read_text())['original_elf_sha256']
def align(n,a=0x4000):return (n+a-1)&-a
def run(args):
    p=subprocess.run([str(x) for x in args],capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
names=dict(re.findall(r'STUB\("([^"]+)",\s*([^)\s]+)\s*\)',(PORT/'out/aerolib.inl').read_text()))
profiles=[]
for index,file in enumerate(('eboot.bin','sce_module/libSceNpToolkit2.prx')):
    elf,eh,ph,_,_=prepare.parse_self((GAME/file).read_bytes())
    original=bytes(elf)
    assert hashlib.sha256(original).hexdigest()==EXPECTED[file],"Unsupported executable image; use the documented CUSA13795 1.21 build"
    loads=[p for p in ph if p['type'] in (1,0x61000010)]
    original_ranges=[(p['offset'],p['filesz']) for p in loads]
    original_phnum=len(ph)
    dp=next(p for p in ph if p['type']==2)
    tags=dict(prepare.unpack('<QQ',elf,pos) for pos in range(dp['offset'],dp['offset']+dp['filesz'],16))
    dd=next(p for p in ph if p['type']==0x61000000)
    blob=prepare.span(elf,dd['offset'],dd['filesz'])
    strings=prepare.span(blob,tags[0x61000035],tags[0x61000037]);symbols=prepare.span(blob,tags[0x61000039],tags[0x6100003f])
    records=[]
    for ot,st in ((0x61000029,0x6100002d),(0x6100002f,0x61000031)):
        table=prepare.span(blob,tags[ot],tags[st])
        for pos in range(0,len(table),24):
            target,info,addend=prepare.unpack('<QQq',table,pos)
            if info&0xffffffff not in (1,6,7):continue
            name,typ,other,section,value,size=prepare.unpack('<IBBHQQ',symbols,(info>>32)*24)
            if section:continue
            text=strings[name:strings.index(0,name)].decode('ascii');symbol=names.get(text.split('#')[0],'?')
            if not(symbol.startswith('sceNp') or symbol in ('sceHttpCreateConnectionWithURL','sceHttpCreateRequestWithURL','sceHttpCreateRequestWithURL2','sceHttpGetStatusCode','sceNetResolverStartNtoa','sceNetCtlInit','sceSysmoduleLoadModule','sceUserServiceGetInitialUser')):continue
            if any(symbol.startswith(prefix) for prefix in ('sceNpTrophy','sceNpCommerce','sceNpProfileDialog','sceNpSns')):continue
            stubs=[]
            for seg in loads:
                if not(seg['flags']&1):continue
                data=prepare.span(elf,seg['offset'],seg['filesz']);start=0
                while True:
                    offset=data.find(b'\xff\x25',start)
                    if offset<0:break
                    if offset+6<=len(data) and seg['vaddr']+offset+6+struct.unpack_from('<i',data,offset+2)[0]==target:
                        stubs.append((seg['vaddr']+offset,seg['offset']+offset))
                    start=offset+2
            if stubs:records.append({'name':symbol,'got':target,'stubs':stubs})
    assert len({r['name'] for r in records})==len(records)
    data_segment=max((p for p in loads if p['flags']&2),key=lambda p:p['vaddr'])
    old_memsz=data_segment['memsz']
    cache_rva=align(data_segment['vaddr']+old_memsz,16)
    cache_size=align(len(records)*8,16)
    data_segment['memsz']=cache_rva+cache_size-data_segment['vaddr']
    text_segment=next(p for p in loads if p['flags']==5)
    code_rva=align(text_segment['vaddr']+text_segment['filesz'],16)
    code_offset=text_segment['offset']+code_rva-text_segment['vaddr']
    marker=b'CTR-RYUNET-PS4\0\0\0'+struct.pack('<IIQQ',2,index,cache_rva,len(records))
    marker=marker.ljust(64,b'\0');assert len(marker)==64
    asm=['.text','.globl image_start','image_start:', '.byte '+','.join(str(x) for x in marker)]
    for i,r in enumerate(records):r['cache']=cache_rva+i*8
    table_rva=None;readonly_additions=[]
    if index==1:
        ro=next(p for p in ph if p['type']==0x61000010)
        table_rva=align(ro['vaddr']+ro['filesz'],16)
        table_offset=ro['offset']+table_rva-ro['vaddr']
        table=b''.join(struct.pack('<ii',r['cache']-table_rva,r['got']-table_rva) for r in records)
        table_end=table_offset+len(table)
        assert table_end<=min(p['offset'] for p in ph if p['offset']>ro['offset'])
        assert table_rva+len(table)<=min(p['vaddr'] for p in loads if p['vaddr']>ro['vaddr'])
        assert not any(elf[table_offset:table_end])
        elf[table_offset:table_end]=table
        ro['filesz']=table_end-ro['offset'];ro['memsz']=ro['filesz']
        readonly_additions.append({'rva':table_rva,'offset':table_offset,'size':len(table)})
        asm+=compact_assembly(len(records))
    else:
        for i,r in enumerate(records):
            asm += [f'.globl proxy_{i}',f'proxy_{i}:',f'mov cache_{i}(%rip),%rax','test %rax,%rax',f'jz fallback_{i}','jmp *%rax',f'fallback_{i}:',f'jmp *original_{i}(%rip)']
    (BUILD/f'image{index}.S').write_text('\n'.join(asm)+'\n')
    obj=BUILD/f'image{index}.o'
    run([LLVM/'clang.exe','--target=x86_64-pc-freebsd12-elf','-c',BUILD/f'image{index}.S','-o',obj])
    objects=[obj]
    if index==0:
        bootobj=BUILD/'bootstrap.o'
        run([LLVM/'clang.exe','--target=x86_64-pc-freebsd12-elf','-c',SRC/'bootstrap.S','-o',bootobj]);objects.append(bootobj)
        for part in ('bootstrap_loader.c','native_syscall.S'):
            extra=BUILD/(part.replace('.','-')+'.o')
            run([LLVM/'clang.exe','--target=x86_64-pc-freebsd12-elf','-ffreestanding','-fno-builtin','-fno-stack-protector','-fPIC','-Oz','-c',SRC/part,'-o',extra]);objects.append(extra)
    defs=[]
    if table_rva is not None:defs += [f'--defsym=route_table=0x{table_rva:x}']
    for i,r in enumerate(records):defs += [f'--defsym=cache_{i}=0x{r["cache"]:x}',f'--defsym=original_{i}=0x{r["got"]:x}']
    if index==0:
        net=next(r for r in records if r['name']=='sceNetCtlInit');defs += [f'--defsym=ctr_original_netctl=0x{net["got"]:x}']
    linked=BUILD/f'image{index}-code.elf'
    script=BUILD/f'image{index}-link.x'
    script.write_text('SECTIONS { . = 0x%x; .text : { *(.text .text.*) *(.rodata .rodata.*) } /DISCARD/ : { *(.eh_frame .comment .note*) } }'%code_rva)
    run([LLVM/'ld.lld.exe','-m','elf_x86_64','--image-base=0','--script',script,'-e','image_start',*defs,*objects,'-o',linked])
    linked_data=linked.read_bytes();lh=struct.unpack_from('<16sHHIQQQIHHHHHH',linked_data)
    # Read normal ELF symbol/section tables for resolved proxy addresses.
    sections=[struct.unpack_from('<IIQQQQIIQQ',linked_data,lh[6]+i*lh[11]) for i in range(lh[12])]
    symsec=next(s for s in sections if s[1]==2);symstrings=sections[symsec[6]];strdata=linked_data[symstrings[4]:symstrings[4]+symstrings[5]]
    labels={}
    for pos in range(symsec[4],symsec[4]+symsec[5],24):
        n,info,other,section,value,size=struct.unpack_from('<IBBHQQ',linked_data,pos)
        labels[strdata[n:strdata.index(0,n)].decode()]=value
    text=next(s for s in sections if s[1]==1 and s[3]==code_rva)
    code=linked_data[text[4]:text[4]+text[5]];assert code[:64]==marker
    touched=[]
    for i,r in enumerate(records):
        destination=labels['ctr_bootstrap'] if index==0 and r['name']=='sceNetCtlInit' else labels[f'proxy_{i}']
        r['proxy']=labels[f'proxy_{i}']
        for rva,offset in r['stubs']:
            old=bytes(elf[offset:offset+5]);new=b'\xe9'+struct.pack('<i',destination-rva-5)
            elf[offset:offset+5]=new;touched.append({'offset':offset,'old':old.hex(),'new':new.hex(),'name':r['name']})
    code_end=code_offset+len(code)
    assert code_end<=min(p['offset'] for p in ph if p['offset']>=code_offset)
    assert code_rva+len(code)<=min(p['vaddr'] for p in loads if p['vaddr']>text_segment['vaddr'])
    assert not any(elf[code_offset:code_end])
    elf[code_offset:code_end]=code
    text_segment['filesz']=code_end-text_segment['offset'];text_segment['memsz']=text_segment['filesz']
    assert len(ph)==original_phnum
    assert eh[5]+len(ph)*56<min(p['offset'] for p in loads)
    struct.pack_into('<H',elf,56,len(ph))
    for i,p in enumerate(ph):struct.pack_into('<IIQQQQQQ',elf,eh[5]+i*56,*[p[k] for k in ('type','flags','offset','vaddr','paddr','filesz','memsz','align')])
    offline=[]
    if index==0:
        import xml.etree.ElementTree as ET
        line=ET.parse(PORT/'patches/CrashTeamRacingOnline.xml').getroot().find('.//Line')
        for name,rva,value in (('Demonware community key',int(line.attrib['Address'],16)-0x400000,bytes.fromhex(line.attrib['Value'])),('60 FPS',0x017a9d90-0x400000,bytes.fromhex('41899688040000'))):
            segment=next(p for p in loads if p['vaddr']<=rva and rva+len(value)<=p['vaddr']+p['filesz'])
            offset=segment['offset']+rva-segment['vaddr'];before=bytes(elf[offset:offset+len(value)])
            elf[offset:offset+len(value)]=value;offline.append({'name':name,'rva':rva,'offset':offset,'before':before.hex(),'after':value.hex()})
    target=BUILD/('eboot.native.elf' if index==0 else 'np_toolkit.native.elf');target.write_bytes(elf)
    # Every original loaded byte outside declared PLT/key/FPS edits must match.
    allowed=set()
    for item in touched:allowed.update(range(item['offset'],item['offset']+5))
    for item in offline:allowed.update(range(item['offset'],item['offset']+len(bytes.fromhex(item['after']))))
    for offset,size in original_ranges:
        a,b=offset,offset+size
        assert all(x==y or a+i in allowed for i,(x,y) in enumerate(zip(original[a:b],elf[a:b]))),file
    assert blob==prepare.span(elf,dd['offset'],dd['filesz'])
    profiles.append({'file':file,'elf':str(target),'original_elf_sha256':hashlib.sha256(original).hexdigest(),'native_elf_sha256':hashlib.sha256(elf).hexdigest(),'marker_rva':code_rva,'marker':marker.hex(),'cache_rva':cache_rva,'cache_size':cache_size,'records':records,'bootstrap':labels.get('ctr_bootstrap'),'code_size':len(code),'code_offset':code_offset,'readonly_additions':readonly_additions,'changes':touched,'offline_patches':offline,'original_data_memsz':old_memsz,'new_data_memsz':data_segment['memsz'],'program_header_count_preserved':True,'mapped_segments':len(loads)})

(BUILD/'native-profiles.json').write_text(json.dumps(profiles,indent=2))
c=['// Generated native port profiles; only the integrated images match these markers.','static PortProfile profiles[] = {']
for p in profiles:c += ['{0x%x,0x%x,%d,{%s},0,0},'%(p['marker_rva'],p['cache_rva'],len(p['records']),','.join('0x'+p['marker'][i:i+2] for i in range(0,128,2)))]
c+=['};','static PortImport imports[] = {']
for index,p in enumerate(profiles):
    for r in p['records']:c += ['{%d,0x%x,0x%x,0x%x,"%s"},'%(index,r['got'],r['cache'],r['stubs'][0][0],r['name'])]
c+=['};'];(SRC/'native_profiles.h').write_text('\n'.join(c)+'\n')
print(json.dumps([{'file':p['file'],'hook_candidates':len(p['records']),'added_code':p['code_size'],'extra_zero_filled_data':p['new_data_memsz']-p['original_data_memsz'],'bootstrap':hex(p['bootstrap']) if p['bootstrap'] else None} for p in profiles],indent=2))
