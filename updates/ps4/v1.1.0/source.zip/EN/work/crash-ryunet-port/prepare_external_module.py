"""Redirect only this experiment's existing bootstrap string to an updateable PRX.

Uses the already-installed game_patch engine, never registers a network plugin.
No instruction, original game import, original-title patch or save is changed.
"""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent;BUILD=ROOT/'build'
old=b'/app0/sce_module/ctr_online.prx\0'
new=b'/data/ryunet/ctr_online.prx\0'
profiles=json.loads((BUILD/'native-profiles.json').read_text())
p=profiles[0];elf=Path(p['elf']).read_bytes()
assert hashlib.sha256(elf).hexdigest()==p['native_elf_sha256']
assert elf.count(old)==1 and len(new)<=len(old)
offset=elf.index(old)
assert p['code_offset']<=offset and offset+len(old)<=p['code_offset']+p['code_size']
rva=p['marker_rva']+offset-p['code_offset']
value=new.ljust(len(old),b'\0')

def patch_hash(title,name,version,path,app):
    data=(title+name+version+path+app).encode('utf-8')[:255]
    result=5381
    for c in data:result=((result*33)^c)&((1<<64)-1)
    return result
assert patch_hash('Crash Team Racing Nitro-Fueled','60 FPS Unlock','01.21','/data/GoldHEN/patches/xml/CUSA13795.xml','eboot.bin')==0xb4aba1ebd19f3b6b

title='Crash Online - RyuNET';name='RyuNET external module'
xml_remote='/data/GoldHEN/patches/xml/RYUN00001.xml'
root=ET.Element('Patch');ET.SubElement(ET.SubElement(root,'TitleID'),'ID').text='RYUN00001'
metadata=ET.SubElement(root,'Metadata',Title=title,Name=name,Author='Local port',AppVer='01.21',AppElf='eboot.bin',PatchVer='1.0')
ET.SubElement(ET.SubElement(metadata,'PatchList'),'Line',Type='bytes',Address=f'0x{rva+0x400000:08x}',Value=value.hex())
ET.indent(root)
folder=BUILD/'network-diagnostics';folder.mkdir(exist_ok=True)
ET.ElementTree(root).write(folder/'RYUN00001.xml',encoding='utf-8',xml_declaration=True)
plan={'title_id':'RYUN00001','version':'01.21','rva':rva,'file_offset':offset,'original':old.hex(),'replacement':value.hex(),'new_module_path':new.rstrip(b'\0').decode(),'xml_remote':xml_remote,'settings_remote':f'/data/GoldHEN/patches/settings/0x{patch_hash(title,name,"01.21",xml_remote,"eboot.bin"):016x}.txt','xml_local':str(folder/'RYUN00001.xml'),'changes_only_existing_bootstrap_string':True,'uses_existing_game_patch_plugin':True,'new_plugin_registered':False,'original_title_modified':False,'tests':'SEE source-release.json; verify after building'}
(BUILD/'external-module-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
print(json.dumps(plan,indent=2))
