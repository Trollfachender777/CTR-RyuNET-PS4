$ErrorActionPreference = 'Stop'
$portRoot = $PSScriptRoot
$referenceCode = [IO.File]::ReadAllText((Join-Path $portRoot 'build/XtsBlockTransform.original.cs.txt')).Replace('namespace LibOrbisPkg.Util', 'namespace RyuToolV1')
Add-Type -TypeDefinition $referenceCode -IgnoreWarnings
$code = [IO.File]::ReadAllText((Join-Path $portRoot 'pkg-tool-source/LibOrbisPkg-master/LibOrbisPkg/Util/XtsBlockTransform.cs')).Replace('namespace LibOrbisPkg.Util', 'namespace RyuToolV2')
Add-Type -TypeDefinition $code -IgnoreWarnings
$random = [Random]::new(20261016)
$key = [byte[]]::new(16); $tweakKey = [byte[]]::new(16)
$random.NextBytes($key); $random.NextBytes($tweakKey)
$reference = [RyuToolV1.XtsBlockTransform]::new($key, $tweakKey)
$optimized = [RyuToolV2.XtsBlockTransform]::new($key, $tweakKey)
$cases = 0
foreach ($length in @(16, 32, 512, 4096, 16384, 512, 4096)) {
    foreach ($sector in @([ulong]0, [ulong]1, [ulong]15, [ulong]16, [ulong]4294967295, [ulong]::MaxValue)) {
        $plain = [byte[]]::new($length); $random.NextBytes($plain)
        $a = [byte[]]$plain.Clone(); $b = [byte[]]$plain.Clone()
        $reference.EncryptSector($a, $sector); $optimized.EncryptSector($b, $sector)
        if ([Convert]::ToBase64String($a) -ne [Convert]::ToBase64String($b)) { throw "XTS mismatch: $length/$sector" }
        $optimized.DecryptSector($b, $sector)
        $reference.DecryptSector($a, $sector)
        if ([Convert]::ToBase64String($plain) -ne [Convert]::ToBase64String($b)) { throw 'XTS roundtrip mismatch' }
        if ([Convert]::ToBase64String($a) -ne [Convert]::ToBase64String($b)) { throw 'XTS reference decryption mismatch' }
        $cases++
    }
}
$buffer = [byte[]]::new(4096); $random.NextBytes($buffer)
$watch = [Diagnostics.Stopwatch]::StartNew()
for ($i=0; $i -lt 512; $i++) { $reference.EncryptSector($buffer, [ulong]$i) }
$referenceMs = $watch.Elapsed.TotalMilliseconds; $watch.Restart()
for ($i=0; $i -lt 512; $i++) { $optimized.EncryptSector($buffer, [ulong]$i) }
$optimizedMs = $watch.Elapsed.TotalMilliseconds; $optimized.Dispose()
$result = @{ successful=$true; exact_reference_matches=$cases; benchmark_bytes=2097152; reference_ms=[Math]::Round($referenceMs,2); optimized_ms=[Math]::Round($optimizedMs,2); speed_ratio=[Math]::Round($referenceMs/$optimizedMs,2); scope='Byte-for-byte encryption compatibility with unmodified LibOrbisPkg and decrypt roundtrips, with cached transforms and varied sector sizes' }
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $portRoot 'build/package-crypto-test.json') -Encoding utf8
$result | ConvertTo-Json
