"""Run the actual x86-64 integration code under Unicorn, with PS4 ABI mocks."""
from pathlib import Path
import sys,json,struct,unittest
ROOT=Path(__file__).resolve().parent
TOOLS=ROOT.parent/'ps4-online'
sys.path.insert(0,str(TOOLS/'test-libs'))
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE,UC_HOOK_INSN
from unicorn.x86_const import *
profiles=json.loads((ROOT/'build/native-profiles.json').read_text())
STUB=0x7000000000
STACK=0x6000000000

class Machine:
    def __init__(self,profile,base):
        self.uc=Uc(UC_ARCH_X86,UC_MODE_64);self.pages=set();self.profile=profile;self.base=base
        data=Path(profile['elf']).read_bytes();off=profile['code_offset'];size=profile['code_size']
        self.map(base+profile['marker_rva'],size);self.uc.mem_write(base+profile['marker_rva'],data[off:off+size])
        for region in profile.get('readonly_additions',[]):
            self.map(base+region['rva'],region['size']);self.uc.mem_write(base+region['rva'],data[region['offset']:region['offset']+region['size']])
        self.map(STACK,0x11000);self.map(STUB,0x1000);self.uc.mem_write(STUB,b'\xc3'*0x1000)
        for r in profile['records']:
            self.map(base+r['got'],8);self.map(base+r['cache'],8)
        self.uc.reg_write(UC_X86_REG_RSP,STACK+0xfff8);self.uc.mem_write(STACK+0xfff8,struct.pack('<Q',STUB+0x300))
        self.callee={UC_X86_REG_RBX:0x112233445566,UC_X86_REG_RBP:0x223344556677,UC_X86_REG_R12:0x334455667788,UC_X86_REG_R13:0x445566778899,UC_X86_REG_R14:0x5566778899aa,UC_X86_REG_R15:0x66778899aabb}
        for register,value in self.callee.items():self.uc.reg_write(register,value)
    def map(self,address,size):
        for page in range(address&-4096,(address+size+4095)&-4096,4096):
            if page not in self.pages:self.uc.mem_map(page,4096);self.pages.add(page)
    def text(self,address):
        value=bytearray()
        for i in range(256):
            x=self.uc.mem_read(address+i,1)[0]
            if not x:return value.decode()
            value.append(x)
        raise AssertionError('Unterminated string')
    def run(self,start):
        self.uc.emu_start(start,STUB+0x300,count=100000)
        assert self.uc.reg_read(UC_X86_REG_RIP)==STUB+0x300,'Did not return within the instruction bound'
        for register,value in self.callee.items():assert self.uc.reg_read(register)==value,'Callee-saved register changed'
        assert self.uc.reg_read(UC_X86_REG_RSP)==STACK+0x10000
        return self.uc.reg_read(UC_X86_REG_RAX)&0xffffffff

class Tests(unittest.TestCase):
    def test_every_proxy_preserves_arguments_and_falls_back(self):
        regs=(UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8,UC_X86_REG_R9)
        values=(11,22,33,44,55,66)
        for base in (0x400000,0x980000000):
            for profile in profiles:
                for record in profile['records']:
                    for enabled in (False,True):
                        machine=Machine(profile,base);u=machine.uc
                        u.mem_write(base+record['got'],struct.pack('<Q',STUB))
                        if enabled:u.mem_write(base+record['cache'],struct.pack('<Q',STUB+0x100))
                        for reg,value in zip(regs,values):u.reg_write(reg,value)
                        u.mem_write(STACK+0x10000,struct.pack('<QQ',77,88))
                        reached=[]
                        def target(uc,address,size,user):
                            if address in (STUB,STUB+0x100):
                                self.assertEqual(tuple(uc.reg_read(r) for r in regs),values)
                                self.assertEqual(uc.reg_read(UC_X86_REG_RSP)%16,8)
                                self.assertEqual(struct.unpack('<QQ',uc.mem_read(uc.reg_read(UC_X86_REG_RSP)+8,16)),(77,88))
                                reached.append(address);uc.reg_write(UC_X86_REG_RAX,0x4321)
                        u.hook_add(UC_HOOK_CODE,target)
                        self.assertEqual(machine.run(base+record['proxy']),0x4321)
                        self.assertEqual(reached,[STUB+0x100 if enabled else STUB])
    def test_bootstrap_failure_paths_and_success_preserve_original_status(self):
        profile=profiles[0];net=next(r for r in profile['records'] if r['name']=='sceNetCtlInit')
        scenarios=('success','external_path','external_update','external_older','external_missing_version','log_success','list_error','kernel_symbol_missing','load_error','entry_missing','entry_error','original_error')
        for base in (0x400000,0x980000000):
            for scenario in scenarios:
                m=Machine(profile,base);u=m.uc;events=[];logs=[]
                if scenario=='external_path':
                    plan=json.loads((ROOT/'build/external-module-plan.json').read_text())
                    old=bytes.fromhex(plan['original']);new=bytes.fromhex(plan['replacement'])
                    self.assertEqual(bytes(u.mem_read(base+plan['rva'],len(old))),old)
                    u.mem_write(base+plan['rva'],new)
                original_result=0x80412108 if scenario=='original_error' else 0
                u.mem_write(base+net['got'],struct.pack('<Q',STUB))
                def syscall(uc,user):
                    number=uc.reg_read(UC_X86_REG_RDI);a=uc.reg_read(UC_X86_REG_RSI);b=uc.reg_read(UC_X86_REG_RDX);c=uc.reg_read(UC_X86_REG_R10)
                    fail=False;value=0
                    if number==5:
                        self.assertIn(m.text(a),('/data/GoldHEN/ctr_native_port.log','/temp0/ctr_native_port.log'))
                        fail=scenario!='log_success';value=3
                    elif number==4:
                        self.assertEqual(a,3);self.assertEqual(c,40)
                        logs.append(bytes(uc.mem_read(b,c)).decode());value=c
                    elif number==6:self.assertEqual(a,3)
                    elif number==592:
                        self.assertEqual(b,256)
                        fail=scenario=='list_error'
                        if not fail:uc.mem_write(a,struct.pack('<ii',0,0x2001));uc.mem_write(c,struct.pack('<Q',2))
                        events.append('list')
                    elif number==591:
                        name=m.text(b)
                        if name=='sceKernelLoadStartModule':
                            fail=a!=0x2001 or scenario=='kernel_symbol_missing'
                            if not fail:uc.mem_write(c,struct.pack('<Q',STUB+0x100))
                        elif name=='ctr_updater_version':
                            self.assertEqual(a,0x2400);fail=scenario=='external_missing_version'
                            if not fail:uc.mem_write(c,struct.pack('<Q',STUB+0x280))
                        elif name=='sceKernelStopUnloadModule':
                            uc.mem_write(c,struct.pack('<Q',STUB+0x290))
                        elif name=='ctr_initialize':
                            self.assertEqual(a,0x2400);fail=scenario=='entry_missing'
                            if not fail:uc.mem_write(c,struct.pack('<Q',STUB+0x200))
                        else:self.fail('Unexpected symbol '+name)
                        events.append(name)
                    else:self.fail('Unexpected syscall '+str(number))
                    flags=uc.reg_read(UC_X86_REG_EFLAGS)
                    uc.reg_write(UC_X86_REG_EFLAGS,(flags|1) if fail else (flags&~1));uc.reg_write(UC_X86_REG_RAX,3 if fail else value)
                    uc.reg_write(UC_X86_REG_RCX,0xdeadbeef);uc.reg_write(UC_X86_REG_R11,flags)
                def code(uc,address,size,user):
                    if address==STUB:
                        events.append('original');uc.reg_write(UC_X86_REG_RAX,original_result)
                    elif address==STUB+0x100:
                        path=m.text(uc.reg_read(UC_X86_REG_RDI));first=events.count('load')==0
                        expected='/data/ryunet/en/ctr_online.prx' if first else '/data/ryunet/ctr_online.prx' if scenario=='external_path' else '/app0/sce_module/ctr_online.prx'
                        self.assertEqual(path,expected)
                        for r in (UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8):self.assertEqual(uc.reg_read(r),0)
                        uc.mem_write(uc.reg_read(UC_X86_REG_R9),struct.pack('<i',0))
                        self.assertEqual(uc.reg_read(UC_X86_REG_RSP)%16,8)
                        events.append('load');uc.reg_write(UC_X86_REG_RAX,0x80020002 if scenario=='load_error' or first and scenario not in ('external_update','external_older','external_missing_version') else 0x2400)
                    elif address==STUB+0x280:uc.reg_write(UC_X86_REG_RAX,1000999 if scenario=='external_older' else 1001000)
                    elif address==STUB+0x290:
                        self.assertEqual(uc.reg_read(UC_X86_REG_RDI),0x2400);events.append('unload');uc.reg_write(UC_X86_REG_RAX,0)
                    elif address==STUB+0x200:
                        events.append('initialize');self.assertEqual(uc.reg_read(UC_X86_REG_RSP)%16,8)
                        uc.reg_write(UC_X86_REG_RAX,0xffffffff if scenario=='entry_error' else 0)
                u.hook_add(UC_HOOK_INSN,syscall,None,1,0,UC_X86_INS_SYSCALL);u.hook_add(UC_HOOK_CODE,code)
                self.assertEqual(m.run(base+profile['bootstrap']),original_result)
                self.assertEqual(events[0],'original')
                self.assertEqual('initialize' in events,scenario in ('success','external_path','external_update','external_older','external_missing_version','log_success','entry_error'))
                if scenario=='original_error':self.assertEqual(events,['original'])
                if scenario in ('external_older','external_missing_version'):self.assertIn('unload',events);self.assertEqual(events.count('load'),2)
                if scenario=='log_success':self.assertEqual(logs,['CTR loader stage=00000032 code=00000000\n','CTR loader stage=00000038 code=80020002\n','CTR loader stage=00000035 code=00002400\n','CTR loader stage=00000037 code=00000000\n'])

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/bootstrap-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'test_groups':result.testsRun,'proxy_cases':sum(len(p['records']) for p in profiles)*4,'bootstrap_cases':24,'scope':'actual compiled x86-64 routing and loader code under emulated CPU; native platform API behavior mocked'},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
