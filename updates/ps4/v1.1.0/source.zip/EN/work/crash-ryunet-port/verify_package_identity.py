"""Check semantic title consistency in actual PKG entries, beyond package hashes."""
from pathlib import Path
import struct,json,sys

def verify(path):
    with Path(path).open('rb') as stream:
        header=stream.read(0x1100)
        assert header[:4]==b'\x7fCNT'
        count=struct.unpack_from('>I',header,0x10)[0]
        offset=struct.unpack_from('>I',header,0x18)[0]
        assert 0<count<256
        content=header[0x40:0x70].split(b'\0',1)[0].decode('ascii')
        expected=content.split('-')[1]
        stream.seek(offset);entries=stream.read(count*32)
        metadata={}
        for index in range(count):
            kind,_,flags,_,position,length=struct.unpack_from('>6I',entries,index*32)
            if kind not in (0x402,0x1000):continue
            assert not(flags&0x80000000),'Semantic audit requires decoded homebrew metadata'
            assert length<=65536
            stream.seek(position);metadata[kind]=stream.read(length)
        raw=metadata[0x402]
        assert len(raw)==160 and raw[:4]==b'NPTD'
        actual=raw[16:28].rstrip(b'\0').decode('ascii')
        if actual!=expected:raise ValueError(f'NP title mismatch: package={expected}, nptitle.dat={actual}')
        sfo=metadata[0x1000]
        magic,_,keys,values,fields=struct.unpack_from('<5I',sfo)
        assert magic==0x46535000
        params={}
        for index in range(fields):
            keyoff,fmt,length,_,valueoff=struct.unpack_from('<HHIII',sfo,20+index*16)
            pos=keys+keyoff;key=sfo[pos:sfo.index(0,pos)].decode()
            if fmt==0x204:params[key]=sfo[values+valueoff:values+valueoff+length].rstrip(b'\0').decode('utf-8')
        assert params['TITLE_ID']==expected[:9]
        assert params['CONTENT_ID']==content
        return {'package':str(path),'title_id':params['TITLE_ID'],'np_title_id':actual,'content_id':content,'app_title':params['TITLE'],'matched':True}

if __name__=='__main__':
    result=verify(sys.argv[1]);print(json.dumps(result,indent=2))
