param([switch]$CompileOnly)
$ErrorActionPreference = 'Stop'
$portRoot = $PSScriptRoot
$chatRoot = [IO.Path]::GetFullPath((Join-Path $portRoot '../..'))
$vendorSource = Join-Path $portRoot 'pkg-tool-source/LibOrbisPkg-master/LibOrbisPkg'
$assemblyDir = Join-Path $portRoot 'build/pkg-tool'
New-Item -ItemType Directory -Path $assemblyDir -Force | Out-Null
$assemblyFile = Join-Path $assemblyDir 'LibOrbisPkg.NativeV2.dll'
$cryptoProof = Get-Content -LiteralPath (Join-Path $portRoot 'build/package-crypto-test.json') -Raw | ConvertFrom-Json
if (-not $cryptoProof.successful) { throw 'Crypto compatibility tests did not pass' }
if (-not (Test-Path -LiteralPath $assemblyFile)) {
    $sourceFiles = Get-ChildItem -LiteralPath $vendorSource -Recurse -Filter '*.cs' | Select-Object -ExpandProperty FullName
    Add-Type -Path $sourceFiles -OutputAssembly $assemblyFile -CompilerOptions '/define:CORE','/unsafe','/optimize' -IgnoreWarnings
}
if ($CompileOnly) { Write-Output "Compiled $assemblyFile"; exit 0 }
[Reflection.Assembly]::LoadFrom($assemblyFile) | Out-Null
$PID | Set-Content -LiteralPath (Join-Path $portRoot 'build/package-builder.pid')
$projectFile = Join-Path $portRoot 'build/native.gp4'
$projectStream = [IO.File]::OpenRead($projectFile)
try { $project = [LibOrbisPkg.GP4.Gp4Project]::ReadFrom($projectStream) }
finally { $projectStream.Dispose() }
$projectDir = [IO.Path]::GetDirectoryName($projectFile)
$problems = [LibOrbisPkg.GP4.Gp4Validator]::ValidateProject($project, $projectDir)
foreach ($problem in $problems) {
    Write-Output ($problem.Type.ToString() + ': ' + $problem.Message)
    if ($problem.Type.ToString() -eq 'Fatal') { throw $problem.Message }
}
$properties = [LibOrbisPkg.PKG.PkgProperties]::FromGp4($project, $projectDir)
$builder = [LibOrbisPkg.PKG.PkgBuilder]::new($properties)
# The integration is documented in source-release.json; verify your local build before installing.
$outputFile = Join-Path $portRoot 'build/CTR Nitro-Fueled Online - RyuNET.pkg'
if (Test-Path -LiteralPath $outputFile) { throw "Refusing to overwrite $outputFile" }
try { $result = $builder.Write($outputFile) }
catch {
    [IO.File]::WriteAllText((Join-Path $portRoot 'build/package-failure-detail.txt'), $_.Exception.ToString())
    throw
}
Write-Output ('Completed package: ' + $outputFile)
Write-Output ('Bytes: ' + $result.Header.package_size)
