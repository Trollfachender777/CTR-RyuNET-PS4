"""Integer-only tail-call routing small enough for the toolkit's existing text gap."""
def assembly(count):
    assert 0<count<=256
    out=[]
    # Four-byte entries: push imm8 (index), short jump to a nearby shared stub.
    # The stub removes that index before invoking either target, preserving the
    # caller's stack arguments, return address, six argument registers and ABI.
    for first in range(0,count,20):
        last=min(first+20,count);group=first//20
        for i in range(first,last):
            out += [f'.globl proxy_{i}',f'proxy_{i}:',f'.byte 0x6a,{i},0xeb',f'.byte dispatch_{group}-(.+1)']
        out += [f'dispatch_{group}:','pop %r11','movzbl %r11b,%r11d',
                'lea route_table(%rip),%r10','movslq (%r10,%r11,8),%rax',
                'add %r10,%rax','mov (%rax),%rax','test %rax,%rax',
                f'jnz selected_{group}','movslq 4(%r10,%r11,8),%rax',
                'add %r10,%rax','jmp *(%rax)',f'selected_{group}:','jmp *%rax']
    return out
