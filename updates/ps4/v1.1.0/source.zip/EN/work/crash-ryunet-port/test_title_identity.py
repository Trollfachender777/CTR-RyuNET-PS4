"""Title-ID regression using synthetic metadata, without any game PKG."""
from pathlib import Path
import json,struct,tempfile,unittest
from verify_package_identity import verify
ROOT=Path(__file__).resolve().parent
CONTENT='IV9999-RYUN00001_00-CRASHRYUNET00001'
def fixture(path,np_title):
    params={'TITLE_ID':'RYUN00001','CONTENT_ID':CONTENT,'TITLE':'Example homebrew'}
    names=bytearray();values=bytearray();table=bytearray()
    for key,value in params.items():
        raw=value.encode()+b'\0'
        table+=struct.pack('<HHIII',len(names),0x204,len(raw),len(raw),len(values))
        names+=key.encode()+b'\0';values+=raw
    keys=20+len(table);value_start=keys+len(names)
    sfo=struct.pack('<5I',0x46535000,0x101,keys,value_start,len(params))+table+names+values
    np=bytearray(160);np[:4]=b'NPTD';np[16:28]=np_title.encode().ljust(12,b'\0')
    raw=bytearray(0x1200+len(sfo));raw[:4]=b'\x7fCNT'
    struct.pack_into('>I',raw,0x10,2);struct.pack_into('>I',raw,0x18,0x1100)
    raw[0x40:0x40+len(CONTENT)]=CONTENT.encode()
    for index,(kind,pos,data) in enumerate(((0x402,0x1140,np),(0x1000,0x1200,sfo))):
        struct.pack_into('>6I',raw,0x1100+index*32,kind,0,0,0,pos,len(data));raw[pos:pos+len(data)]=data
    path.write_bytes(raw)
class Tests(unittest.TestCase):
    def test_rejects_mismatched_np_title(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'synthetic.pkg';fixture(path,'CUSA13795_00')
            with self.assertRaisesRegex(ValueError,'NP title mismatch'):verify(path)
    def test_accepts_consistent_package_metadata(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'synthetic.pkg';fixture(path,'RYUN00001_00')
            proof=verify(path);self.assertTrue(proof['matched']);self.assertEqual(proof['np_title_id'],'RYUN00001_00')
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build').mkdir(exist_ok=True)
    (ROOT/'build/title-identity-test.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'synthetic_metadata_only':True},indent=2))
    raise SystemExit(not result.wasSuccessful())
