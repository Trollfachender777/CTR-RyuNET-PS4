// SPDX-License-Identifier: GPL-2.0-or-later
// CTR-NitroFueled-PC launcher (Windows). Sets up the game folder (the 1.21 update merged over
// the base game with hard links), edits the settings the game reads (bbport.ini, the same keys
// as the in-game menu) and starts run.py with the bundled Python, showing its output.
// Dear ImGui on Win32 + Direct3D 11, linked statically: one .exe next to run.py and bin\.
//
// Files: launcher.ini (this launcher: game folders, language, display...) and bbport.ini (the
// game's settings) in the port folder; run.py writes last_run.log there.

#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <windowsx.h>
#include <d3d11.h>
#include <dwmapi.h>
#include <wincodec.h>
#include <shellapi.h>
#include <shobjidl.h>
#include <shlobj.h>
#include <winhttp.h>
#include <bcrypt.h>
#include <tlhelp32.h>

#include <algorithm>
#include <cctype>
#include <cstring>
#include <ctime>
#include <cmath>
#include <cwctype>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <deque>
#include <filesystem>
#include <fstream>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"

#include "discord_link.h"
#include "nat_check.h"
#include "port_update.h"
#include "discord_presence.h"
#include "launcher_locales.h"

namespace fs = std::filesystem;

namespace {

// The Americas build (CUSA13795) and the European one (CUSA14876, SacredFire EU): the port runs both.
constexpr const char* kTitleIds[] = {"CUSA13795", "CUSA14876"};
bool IsCtrTitle(const std::string& title) {
    for (const char* id : kTitleIds)
        if (title == id) return true;
    return false;
}
constexpr const char* kUpdateVersion = "01.21";
constexpr const char* kRepoUrl = "https://github.com/GetLostIn/CTR-NitroFueled-PC";
// The 1.21 update alone is about 8.5 GB; base game + update is much larger.
constexpr std::uintmax_t kCompleteGameMinBytes = 10ull << 30;

struct LauncherArtwork {
    ID3D11ShaderResourceView* texture = nullptr;
    UINT width = 0;
    UINT height = 0;
};
LauncherArtwork g_hero_art;
LauncherArtwork g_logo_art;
LauncherArtwork g_menu_background;
ImFont* g_ctr_font = nullptr;
RECT g_titlebar_drag{};
float g_ui_scale = 1.0f;
extern ID3D11Device* g_device;

// ---------------------------------------------------------------------------------------------
// Text helpers

std::wstring Widen(const std::string& s) {
    if (s.empty()) return {};
    const int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), int(s.size()), nullptr, 0);
    std::wstring w(size_t(n), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), int(s.size()), w.data(), n);
    return w;
}

std::string Narrow(const std::wstring& w) {
    if (w.empty()) return {};
    const int n = WideCharToMultiByte(CP_UTF8, 0, w.data(), int(w.size()), nullptr, 0, nullptr, nullptr);
    std::string s(size_t(n), '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), int(w.size()), s.data(), n, nullptr, nullptr);
    return s;
}

std::string PathText(const fs::path& p) { return Narrow(p.wstring()); }
fs::path TextPath(const std::string& s) { return fs::path(Widen(s)); }

std::string Trim(std::string s) {
    while (!s.empty() && (s.back() == '\r' || s.back() == '\n' || s.back() == ' ' || s.back() == '\t')) s.pop_back();
    size_t i = 0;
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t')) ++i;
    return s.substr(i);
}

std::string ReadText(const fs::path& p) {
    std::ifstream f(p, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

bool WriteTextAtomic(const fs::path& p, const std::string& text) {
    fs::path temp = p;
    temp += L".tmp";
    {
        std::ofstream f(temp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f << text;
        if (!f) return false;
    }
    return MoveFileExW(temp.c_str(), p.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
}

std::string FormatBytes(std::uintmax_t bytes) {
    char buf[64];
    std::snprintf(buf, sizeof buf, "%.1f GB", double(bytes) / double(1ull << 30));
    return buf;
}

const ImVec4 kGreen{0.45f, 0.85f, 0.45f, 1.0f};
const ImVec4 kRed{1.0f, 0.45f, 0.40f, 1.0f};
const ImVec4 kYellow{1.0f, 0.80f, 0.35f, 1.0f};
const ImVec4 kGrey{0.65f, 0.65f, 0.68f, 1.0f};

// ---------------------------------------------------------------------------------------------
// Language: Spanish or English, chosen in the launcher (default: Windows' language).

bool g_spanish = false;
std::string g_language = "auto";
std::string g_active_locale = "en";

std::string DetectWindowsLocale() {
    wchar_t name[LOCALE_NAME_MAX_LENGTH]{};
    if (!GetUserDefaultLocaleName(name, LOCALE_NAME_MAX_LENGTH)) return "en";
    std::wstring locale(name);
    std::transform(locale.begin(), locale.end(), locale.begin(), [](wchar_t c) { return wchar_t(towlower(c)); });
    if (locale.rfind(L"pt", 0) == 0) return "pt_BR";
    if (locale.rfind(L"es", 0) == 0) return "es";
    if (locale.rfind(L"fr", 0) == 0) return "fr";
    if (locale.rfind(L"de", 0) == 0) return "de";
    if (locale.rfind(L"it", 0) == 0) return "it";
    if (locale.rfind(L"ja", 0) == 0) return "ja";
    if (locale.rfind(L"zh", 0) == 0) return "zh_CN";
    if (locale.rfind(L"ru", 0) == 0) return "ru";
    return "en";
}

void ApplyLauncherLanguage() {
    g_active_locale = g_language == "auto" ? DetectWindowsLocale() : g_language;
    g_spanish = g_active_locale == "es";
}

const char* T(const char* es, const char* en) {
    if (g_active_locale == "es") return es;
    if (g_active_locale == "en") return en;
    const auto& all = GeneratedLocales();
    const auto language = all.find(g_active_locale);
    if (language != all.end()) {
        const auto value = language->second.find(en);
        if (value != language->second.end()) return value->second.c_str();
    }
    return en;
}

// ---------------------------------------------------------------------------------------------
// key=value files, edited in place: comments, order and unknown keys are kept.

struct Ini {
    std::vector<std::string> lines;
    std::map<std::string, std::string> values;

    void Load(const fs::path& path) {
        lines.clear();
        values.clear();
        std::stringstream ss(ReadText(path));
        std::string line;
        while (std::getline(ss, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            lines.push_back(line);
            const auto t = Trim(line);
            if (t.empty() || t[0] == '#' || t[0] == ';') continue;
            const auto eq = t.find('=');
            if (eq == std::string::npos) continue;
            values[Trim(t.substr(0, eq))] = Trim(t.substr(eq + 1));
        }
    }
    std::string Get(const std::string& key, const std::string& fallback = "") const {
        const auto it = values.find(key);
        return it == values.end() ? fallback : it->second;
    }
    bool Flag(const std::string& key, bool fallback) const {
        const auto v = Get(key);
        return v.empty() ? fallback : v != "0";
    }
    int Int(const std::string& key, int fallback) const {
        const auto v = Get(key);
        if (v.empty()) return fallback;
        char* end = nullptr;
        const long n = std::strtol(v.c_str(), &end, 10);
        return end && *end == '\0' ? int(n) : fallback;
    }
    void Set(const std::string& key, const std::string& value) {
        values[key] = value;
        erased.erase(key);
    }
    // Removes the key: its line is dropped on Save.
    void Erase(const std::string& key) {
        values.erase(key);
        erased.insert(key);
    }
    std::set<std::string> erased;
    bool Save(const fs::path& path, const char* header) {
        std::vector<std::string> out;
        std::map<std::string, bool> written;
        for (const auto& line : lines) {
            const auto t = Trim(line);
            const auto eq = t.find('=');
            if (!t.empty() && t[0] != '#' && t[0] != ';' && eq != std::string::npos) {
                const auto key = Trim(t.substr(0, eq));
                if (erased.count(key)) continue;
                const auto it = values.find(key);
                if (it != values.end()) {
                    if (!written[key]) out.push_back(key + "=" + it->second);
                    written[key] = true;
                    continue;
                }
            }
            out.push_back(line);
        }
        if (lines.empty() && header) out.push_back(header);
        for (const auto& [key, value] : values) {
            if (!written[key]) out.push_back(key + "=" + value);
        }
        std::string text;
        for (const auto& line : out) text += line + "\n";
        if (!WriteTextAtomic(path, text)) return false;
        lines = out;
        erased.clear();
        return true;
    }
};

// ---------------------------------------------------------------------------------------------
// param.sfo: the game's title, version and category (gd = game, gp = patch).

std::map<std::string, std::string> ParseSfo(const std::string& data) {
    std::map<std::string, std::string> out;
    auto u32 = [&](size_t at) -> uint32_t {
        if (at + 4 > data.size()) return 0;
        return uint32_t(uint8_t(data[at])) | uint32_t(uint8_t(data[at + 1])) << 8 |
               uint32_t(uint8_t(data[at + 2])) << 16 | uint32_t(uint8_t(data[at + 3])) << 24;
    };
    auto u16 = [&](size_t at) -> uint32_t {
        if (at + 2 > data.size()) return 0;
        return uint32_t(uint8_t(data[at])) | uint32_t(uint8_t(data[at + 1])) << 8;
    };
    if (data.size() < 20 || data.compare(0, 4, std::string("\0PSF", 4)) != 0) return out;
    const uint32_t keys = u32(8), values = u32(12), count = u32(16);
    for (uint32_t i = 0; i < count && 20 + i * 16 + 16 <= data.size(); ++i) {
        const size_t entry = 20 + size_t(i) * 16;
        const uint32_t key_off = u16(entry), fmt = u16(entry + 2), len = u32(entry + 4), off = u32(entry + 12);
        const size_t key_at = size_t(keys) + key_off;
        if (key_at >= data.size()) continue;
        const size_t key_end = data.find('\0', key_at);
        if (key_end == std::string::npos) continue;
        const std::string key = data.substr(key_at, key_end - key_at);
        const size_t value_at = size_t(values) + off;
        if (value_at + len > data.size()) continue;
        if (fmt == 0x0404) {
            out[key] = std::to_string(u32(value_at));
        } else {
            std::string v = data.substr(value_at, len);
            while (!v.empty() && v.back() == '\0') v.pop_back();
            out[key] = v;
        }
    }
    return out;
}

std::map<std::string, std::string> ReadSfo(const fs::path& file) { return ParseSfo(ReadText(file)); }

enum class Kind { Empty, Missing, NotGame, OtherTitle, OtherVersion, Base, Update, Complete };

struct FolderInfo {
    Kind kind = Kind::Empty;
    std::string title, version, category;
    std::uintmax_t bytes = 0;
    bool split = false;  // Image0 + Sc0 (PS4 PKG Tool): needs preparing before it runs
};

std::uintmax_t FolderBytes(const fs::path& dir) {
    std::uintmax_t total = 0;
    std::error_code ec;
    for (fs::recursive_directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end;
         !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        if (it->is_regular_file(e2)) total += it->file_size(e2);
    }
    return total;
}

// Where a dump keeps its files. Most tools give the PS4 layout (eboot.bin and sce_sys\param.sfo
// side by side); PS4 PKG Tool splits it into Image0\ (eboot.bin, sce_module, the data) and Sc0\
// (what goes in sce_sys). Such a folder is "split": preparing the game flattens it.
struct Layout {
    fs::path files, sys;  // the folder that becomes the game root, the one that becomes sce_sys
    bool split = false;
    explicit operator bool() const { return !files.empty(); }
};

Layout FindLayout(const fs::path& dir) {
    std::error_code ec;
    const auto has = [&](const fs::path& p) { return fs::is_regular_file(p, ec); };
    const bool flat = has(dir / L"eboot.bin") && has(dir / L"sce_sys" / L"param.sfo");
    const fs::path image = dir / L"Image0";
    // A folder fixed by hand keeps Image0 next to a copied eboot.bin: it is flat only once
    // sce_module is in the root too.
    if (flat && (!has(image / L"eboot.bin") || fs::is_directory(dir / L"sce_module", ec))) return {dir, dir / L"sce_sys", false};
    if (!has(image / L"eboot.bin")) return {};
    for (const fs::path& sys : {image / L"sce_sys", dir / L"Sc0", dir / L"sce_sys"}) {
        if (has(sys / L"param.sfo")) return {image, sys, true};
    }
    return {};
}

// A folder picked one level too high (the folder that holds CUSA13795) stands for its only game.
fs::path GameRoot(const fs::path& dir) {
    std::error_code ec;
    if (dir.empty() || FindLayout(dir)) return dir;
    // Image0 itself, picked from a PS4 PKG Tool dump, stands for the dump.
    if (_wcsicmp(dir.filename().c_str(), L"Image0") == 0 && FindLayout(dir.parent_path())) return dir.parent_path();
    fs::path found;
    for (fs::directory_iterator it(dir, ec), end; !ec && it != end; it.increment(ec)) {
        if (it->is_directory(ec) && FindLayout(it->path())) {
            if (!found.empty()) return dir;  // more than one: the player chooses
            found = it->path();
        }
    }
    return found.empty() ? dir : found;
}

/// The files of a dump as (source, path in the PS4 layout).
std::vector<std::pair<fs::path, fs::path>> LayoutFiles(const fs::path& dir, std::error_code& ec) {
    std::vector<std::pair<fs::path, fs::path>> files;
    const Layout layout = FindLayout(dir);
    if (!layout) return files;
    auto add = [&](const fs::path& from, const fs::path& prefix) {
        for (fs::recursive_directory_iterator it(from, ec), end; !ec && it != end; it.increment(ec)) {
            std::error_code e2;
            if (it->is_regular_file(e2)) files.emplace_back(it->path(), prefix / fs::relative(it->path(), from, e2));
        }
    };
    add(layout.files, {});
    if (!ec && layout.split && layout.sys != layout.files / L"sce_sys") add(layout.sys, L"sce_sys");
    return files;
}

FolderInfo Analyze(const fs::path& dir) {
    FolderInfo info;
    if (dir.empty()) return info;
    std::error_code ec;
    if (!fs::is_directory(dir, ec)) {
        info.kind = Kind::Missing;
        return info;
    }
    const Layout layout = FindLayout(dir);
    if (!layout) {
        info.kind = Kind::NotGame;
        return info;
    }
    info.split = layout.split;
    const auto sfo = ReadSfo(layout.sys / L"param.sfo");
    auto get = [&](const char* k) {
        const auto it = sfo.find(k);
        return it == sfo.end() ? std::string() : it->second;
    };
    info.title = get("TITLE_ID");
    info.version = get("APP_VER");
    info.category = get("CATEGORY");
    if (!IsCtrTitle(info.title)) {
        info.kind = Kind::OtherTitle;
    } else if (info.category == "gd") {
        info.kind = Kind::Base;
    } else if (info.version != kUpdateVersion) {
        info.kind = Kind::OtherVersion;
    } else {
        info.bytes = FolderBytes(layout.split ? layout.files : dir);
        info.kind = info.bytes >= kCompleteGameMinBytes ? Kind::Complete : Kind::Update;
    }
    return info;
}

// ---------------------------------------------------------------------------------------------
// Processes

fs::path ExeDir() {
    wchar_t buf[MAX_PATH * 4];
    const DWORD n = GetModuleFileNameW(nullptr, buf, DWORD(std::size(buf)));
    return fs::path(std::wstring(buf, n)).parent_path();
}

/// The port folder: the launcher's own (portable package), or the source tree above out\.
fs::path FindRoot() {
    fs::path dir = ExeDir();
    for (int i = 0; i < 3 && !dir.empty(); ++i) {
        std::error_code ec;
        if (fs::is_regular_file(dir / L"run.py", ec)) return dir;
        dir = dir.parent_path();
    }
    return ExeDir();
}

std::wstring Quote(const std::wstring& s) { return L"\"" + s + L"\""; }

struct Python {
    std::wstring exe;
    std::wstring args;  // before the script, e.g. L"-3 "
    std::string description;
};

std::optional<Python> FindPython(const fs::path& root) {
    std::error_code ec;
    const fs::path bundled = root / L"python" / L"python.exe";
    if (fs::is_regular_file(bundled, ec)) return Python{bundled.wstring(), L"", "python\\ (bundled)"};
    wchar_t found[MAX_PATH * 4];
    if (SearchPathW(nullptr, L"py.exe", nullptr, DWORD(std::size(found)), found, nullptr)) {
        return Python{found, L"-3 ", Narrow(found)};
    }
    if (SearchPathW(nullptr, L"python.exe", nullptr, DWORD(std::size(found)), found, nullptr)) {
        // Windows' "App execution alias" opens the Microsoft Store instead of running Python.
        if (std::wstring(found).find(L"WindowsApps") == std::wstring::npos) return Python{found, L"", Narrow(found)};
    }
    const fs::path msys = L"C:\\msys64\\clang64\\bin\\python.exe";
    if (fs::is_regular_file(msys, ec)) return Python{msys.wstring(), L"", PathText(msys)};
    return std::nullopt;
}

struct Captured {
    bool started = false;
    DWORD code = 1;
    std::string output;
};

/// Runs a console program without a window and returns its output (stdout + stderr).
Captured RunCaptured(const std::wstring& exe, const std::wstring& command_line, const fs::path& cwd,
                     DWORD timeout_ms) {
    Captured result;
    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE read = nullptr, write = nullptr;
    if (!CreatePipe(&read, &write, &sa, 0)) return result;
    SetHandleInformation(read, HANDLE_FLAG_INHERIT, 0);
    HANDLE nul = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, nullptr);
    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = nul;
    si.hStdOutput = write;
    si.hStdError = write;
    PROCESS_INFORMATION pi{};
    std::wstring cmd = command_line;
    const BOOL ok = CreateProcessW(exe.c_str(), cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr,
                                   cwd.empty() ? nullptr : cwd.c_str(), &si, &pi);
    CloseHandle(write);
    if (nul != INVALID_HANDLE_VALUE) CloseHandle(nul);
    if (!ok) {
        CloseHandle(read);
        return result;
    }
    result.started = true;
    std::thread reader([&] {
        char buf[4096];
        DWORD n = 0;
        while (ReadFile(read, buf, sizeof buf, &n, nullptr) && n) result.output.append(buf, n);
    });
    if (WaitForSingleObject(pi.hProcess, timeout_ms) == WAIT_TIMEOUT) TerminateProcess(pi.hProcess, 1);
    reader.join();
    GetExitCodeProcess(pi.hProcess, &result.code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    CloseHandle(read);
    return result;
}

void OpenInShell(const fs::path& target) {
    ShellExecuteW(nullptr, L"open", target.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

std::vector<fs::path> PickFiles(HWND owner, const wchar_t* title, const wchar_t* filter_name, const wchar_t* filter) {
    std::vector<fs::path> result;
    IFileOpenDialog* dialog = nullptr;
    if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&dialog)))) {
        return result;
    }
    DWORD options = 0;
    dialog->GetOptions(&options);
    dialog->SetOptions(options | FOS_ALLOWMULTISELECT | FOS_FORCEFILESYSTEM | FOS_FILEMUSTEXIST);
    dialog->SetTitle(title);
    const COMDLG_FILTERSPEC spec[] = {{filter_name, filter}};
    dialog->SetFileTypes(1, spec);
    if (SUCCEEDED(dialog->Show(owner))) {
        IShellItemArray* items = nullptr;
        if (SUCCEEDED(dialog->GetResults(&items))) {
            DWORD count = 0;
            items->GetCount(&count);
            for (DWORD i = 0; i < count; ++i) {
                IShellItem* item = nullptr;
                if (FAILED(items->GetItemAt(i, &item))) continue;
                PWSTR path = nullptr;
                if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path))) {
                    result.emplace_back(path);
                    CoTaskMemFree(path);
                }
                item->Release();
            }
            items->Release();
        }
    }
    dialog->Release();
    return result;
}

std::optional<fs::path> PickFolder(HWND owner, const wchar_t* title, const fs::path& start) {
    IFileOpenDialog* dialog = nullptr;
    if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&dialog)))) {
        return std::nullopt;
    }
    DWORD options = 0;
    dialog->GetOptions(&options);
    dialog->SetOptions(options | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST);
    dialog->SetTitle(title);
    std::error_code ec;
    if (!start.empty() && fs::is_directory(start, ec)) {
        IShellItem* folder = nullptr;
        if (SUCCEEDED(SHCreateItemFromParsingName(start.c_str(), nullptr, IID_PPV_ARGS(&folder)))) {
            dialog->SetFolder(folder);
            folder->Release();
        }
    }
    std::optional<fs::path> result;
    if (SUCCEEDED(dialog->Show(owner))) {
        IShellItem* item = nullptr;
        if (SUCCEEDED(dialog->GetResult(&item))) {
            PWSTR path = nullptr;
            if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path))) {
                result = fs::path(path);
                CoTaskMemFree(path);
            }
            item->Release();
        }
    }
    dialog->Release();
    return result;
}

// ---------------------------------------------------------------------------------------------
// The launcher

struct Choice {
    const char* es;
    const char* en;
    const char* value;
};

// PS4 system language codes (BB_LANGUAGE) of the languages CUSA13795 (the Americas build) has:
// English (1, US), Latin American Spanish (20), French (2) and Brazilian Portuguese (17). Other
// codes (Spain's Spanish 3, German, Italian...) are not in this build and fall back to English.
constexpr Choice kGameLanguages[] = {
    {"Inglés", "English", "1"},
    {"Español latinoamericano", "Spanish (Latin America)", "20"},
    {"Francés", "French", "2"},
    {"Portugués (Brasil)", "Portuguese (Brazil)", "17"},
};
// The European build (CUSA14876) has English, Spain's Spanish (3), French, German (4), Italian (5)
// and Arabic (21): the .lng texts in its archives.
constexpr Choice kGameLanguagesEU[] = {
    {"Inglés", "English", "1"},
    {"Español (España)", "Spanish (Spain)", "3"},
    {"Francés", "French", "2"},
    {"Alemán", "German", "4"},
    {"Italiano", "Italian", "5"},
    {"Árabe", "Arabic", "21"},
};
constexpr Choice kPresentModes[] = {
    {"Mailbox (recomendado)", "Mailbox (recommended)", "Mailbox"},
    {"FIFO (VSync)", "FIFO (VSync)", "Fifo"},
    {"FIFO relajado", "FIFO Relaxed", "FifoRelaxed"},
    {"Inmediato (sin VSync)", "Immediate (no VSync)", "Immediate"},
};
constexpr int kFpsLimits[] = {0, 30, 60, 72, 90, 120, 144, 240};

struct SaveParam {  // OrbisSaveDataParam
    char title[128], subtitle[128], detail[1024];
    uint32_t user_param;
    int32_t pad;
    int64_t mtime;
    uint8_t reserved[32];
};
static_assert(sizeof(SaveParam) == 1328, "OrbisSaveDataParam layout");

struct SaveSlot {
    std::string dir, title, subtitle, detail, modified;
    std::uintmax_t bytes = 0;
};

struct Backup {
    fs::path path;
    std::string name, modified;
    std::uintmax_t bytes = 0;
};

struct PatchInfo {
    std::string key, name, author, note, version;
    std::string title;  // the edition its file is for (CUSA13795, CUSA14876), "" for any game
    bool default_on = false;
    const char* ini_key = nullptr;
};

struct DlcInfo {
    fs::path path;
    std::string file, title, label, problem;
    bool ok = false;
};

enum class Job { None, Merge, Check, Play };

struct App {
    HWND hwnd = nullptr;
    int active_page = 0;
    fs::path root, bin;
    std::string version;
    std::optional<Python> python;

    Ini launcher;  // launcher.ini
    Ini game;      // bbport.ini
    char online_server_buf[128] = "octr.ryu7w7.xyz";
    char online_name_buf[32] = "";
    char online_friends_buf[512] = "";

    // Game folders.
    fs::path game_dir, base_dir, update_dir;
    FolderInfo game_info, base_info, update_info;
    std::atomic<bool> game_checked{false};
    bool game_ok = false;
    std::string check_message;

    // Background work (one at a time).
    std::atomic<Job> job{Job::None};
    std::thread worker;
    std::mutex mutex;  // guards the strings below and log
    std::string job_error;
    std::atomic<size_t> merge_done{0}, merge_total{0};
    std::atomic<bool> job_finished{false};

    // The running game.
    HANDLE process = nullptr, job_object = nullptr;
    std::deque<std::string> log;
    std::string last_status;
    std::atomic<bool> game_running{false};
    DWORD exit_code = 0;
    bool show_exit = false, stopped = false;

    // Monitors and controllers (bb-gpu-capabilities).
    std::vector<std::pair<std::string, std::string>> displays;  // value (number), label
    std::vector<std::pair<std::string, std::string>> gamepads;  // GUID, name
    std::thread probe;
    std::atomic<bool> probe_done{false};

    bool want_close = false;
    bool confirm_clear_cache = false;
    bool ask_nick = false;  // PLAY pressed online without a usable nickname
    // A Discord invite for another server, waiting for the player to confirm the switch.
    bool ask_join_server = false;
    std::string join_server, join_nick;
    bool pending_play = false;  // an accepted invite starts the game once it is ready
    std::string notice;

    // Patches tab.
    std::vector<PatchInfo> patches;
    std::vector<std::string> patch_enabled, patch_disabled;
    // Saves tab.
    std::vector<SaveSlot> saves;
    std::vector<Backup> backups;
    bool saves_dirty = true;
    fs::path pending_path;
    int pending_action = 0, confirm_action = 0;  // 1 restore, 2 delete a backup, 3 remove a DLC
    // DLC tab.
    std::vector<DlcInfo> dlc;
    bool dlc_dirty = true;
};

App g_app;

/// The title ID of the chosen game (the merged folder, else the update or the base game): the
/// saves, the shader cache and the merged folder's name follow it. CUSA13795 when none is known.
std::wstring GameTitle() {
    for (const FolderInfo* info : {&g_app.game_info, &g_app.update_info, &g_app.base_info})
        if (IsCtrTitle(info->title)) return Widen(info->title);
    return L"CUSA13795";
}

std::string EffectiveRenderRes();

fs::path LauncherIni() { return g_app.root / L"launcher.ini"; }
fs::path GameIni() { return g_app.root / L"bbport.ini"; }

void SaveLauncher() {
    App& a = g_app;
    a.launcher.Set("game_dir", PathText(a.game_dir));
    a.launcher.Set("base_dir", PathText(a.base_dir));
    a.launcher.Set("update_dir", PathText(a.update_dir));
    a.launcher.Set("ui_language", g_language);
    if (!a.launcher.Save(LauncherIni(), "# CTR-NitroFueled-PC launcher")) {
        a.notice = T("No se pudo guardar launcher.ini.", "Could not save launcher.ini.");
    }
}

void SaveGameIni() {
    if (!g_app.game.Save(GameIni(), "# bbport settings (in-game menu: Insert / L3+R3)")) {
        g_app.notice = T("No se pudo guardar bbport.ini.", "Could not save bbport.ini.");
    }
}

void SyncOnlineBuffers() {
    App& a = g_app;
    std::string srv = a.game.Get("online_server", "octr.ryu7w7.xyz");
    if (srv.empty()) {
        srv = "octr.ryu7w7.xyz";
        a.game.Set("online_server", srv);
    }
    std::string nick = a.game.Get("online_name", a.game.Get("user_name"));
    std::string friends = a.game.Get("online_friends", "");
    std::strncpy(a.online_server_buf, srv.c_str(), sizeof(a.online_server_buf) - 1);
    a.online_server_buf[sizeof(a.online_server_buf) - 1] = '\0';
    std::strncpy(a.online_name_buf, nick.c_str(), sizeof(a.online_name_buf) - 1);
    a.online_name_buf[sizeof(a.online_name_buf) - 1] = '\0';
    std::strncpy(a.online_friends_buf, friends.c_str(), sizeof(a.online_friends_buf) - 1);
    a.online_friends_buf[sizeof(a.online_friends_buf) - 1] = '\0';
}

std::string CurrentNick() { return Trim(g_app.game.Get("online_name", g_app.game.Get("user_name"))); }

/// The server derives the player's ID from the nickname, so everyone left on the old default
/// (RyuPC) was ONE player online: one wallet, and matchmaking evicting each other. These names
/// are refused; run.py refuses them too.
bool ReservedNick(const std::string& nick) {
    static const char* const kReserved[] = {"ryupc", "ryunet", "player", "jugador", "guest"};
    std::string lower = nick;
    for (char& c : lower) c = char(std::tolower(static_cast<unsigned char>(c)));
    for (const char* r : kReserved)
        if (lower == r) return true;
    return false;
}

bool NickChar(unsigned c) { return c < 128 && (std::isalnum(int(c)) || c == '_' || c == '-'); }

/// Why this nickname cannot be used online, or nullptr when it can.
const char* NickProblem(const std::string& nick) {
    if (nick.empty()) return T("Falta tu apodo.", "Your nickname is missing.");
    if (nick.size() < 3 || nick.size() > 16)
        return T("El apodo debe tener de 3 a 16 caracteres.", "The nickname must be 3 to 16 characters.");
    for (const char c : nick)
        if (!NickChar(static_cast<unsigned char>(c)))
            return T("Solo letras, números, _ y -.", "Only letters, digits, _ and -.");
    if (ReservedNick(nick))
        return T("Ese es un apodo por defecto que usa mucha gente: elige uno propio.",
                 "That is a default nickname many people share: choose your own.");
    return nullptr;
}

int NickFilter(ImGuiInputTextCallbackData* data) { return NickChar(data->EventChar) ? 0 : 1; }

/// Nickname field (letters, digits, _ and - only, 16 at most); true when it was edited.
bool NickInput(const char* label) {
    App& a = g_app;
    constexpr size_t kMaxNick = 16;
    static_assert(sizeof(a.online_name_buf) > kMaxNick);
    if (!ImGui::InputText(label, a.online_name_buf, kMaxNick + 1, ImGuiInputTextFlags_CallbackCharFilter, NickFilter))
        return false;
    a.game.Set("online_name", a.online_name_buf);
    a.game.Set("user_name", a.online_name_buf);
    return true;
}

/// This installation's secret, shared with run.py (ryunet_online.key next to it): the server
/// lets the first key to use a nickname keep it. Created here when missing, so the nickname
/// check below already speaks for this installation.
/// A second copy of the key outside the game folder (%APPDATA%\CTR-NitroFueled-PC), so that
/// deleting, moving or re-downloading the folder on the same PC keeps the nicknames.
fs::path BackupKeyPath() {
    const wchar_t* appdata = _wgetenv(L"APPDATA");
    return appdata && *appdata ? fs::path(appdata) / L"CTR-NitroFueled-PC" / L"ryunet_online.key" : fs::path();
}

std::string ReadKeyFile(const fs::path& path) {
    std::string key;
    if (path.empty()) return key;
    std::ifstream(path, std::ios::binary) >> key;
    for (char& c : key) c = char(std::tolower(static_cast<unsigned char>(c)));
    if (key.size() != 64 || key.find_first_not_of("0123456789abcdef") != std::string::npos) key.clear();
    return key;
}

bool WriteKeyFile(const fs::path& path, const std::string& key) {
    if (path.empty()) return false;
    std::error_code ec;
    fs::create_directories(path.parent_path(), ec);
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    out << key << "\n";
    return bool(out);
}

std::string OnlineKey() {
    static std::mutex mutex;  // the server checks ask from background threads
    static std::string cached;
    std::scoped_lock lock{mutex};
    if (!cached.empty()) return cached;
    const fs::path path = g_app.root / L"ryunet_online.key";
    const fs::path backup = BackupKeyPath();
    std::string key = ReadKeyFile(path);
    if (key.empty()) key = ReadKeyFile(backup);  // a new folder on a PC that played before
    if (key.empty()) {
        unsigned char raw[32];
        if (BCryptGenRandom(nullptr, raw, sizeof raw, BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0) return {};
        static const char kHex[] = "0123456789abcdef";
        for (const unsigned char b : raw) {
            key += kHex[b >> 4];
            key += kHex[b & 15];
        }
    }
    if (ReadKeyFile(path) != key && !WriteKeyFile(path, key)) return {};
    if (ReadKeyFile(backup).empty()) WriteKeyFile(backup, key);  // never overwrites another folder's
    cached = key;
    return cached;
}

/// Server availability of a nickname: "free", "yours", "taken", "reserved", "invalid", or
/// "" while unknown or when the server could not be asked (it checks again at login).
struct NickCheck {
    struct Result {
        std::string status;
        ULONGLONG at = 0;  // GetTickCount64: an unreachable server is asked again later
        bool linked = false;          // the nickname is linked to a Discord account
        bool link_available = false;  // the server can link Discord accounts
        std::string discord;          // the linked account's name (only for our own nickname)
    };
    std::mutex mutex;
    std::map<std::string, Result> results;  // "server|nick" -> answer
    std::string in_flight;
};
NickCheck g_nick_check;

std::string Lower(std::string s) {
    for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

/// The server setting's host and HTTP port, split exactly as run.py does ("host" or "host:port").
void SplitServer(const std::string& server, std::string& host, INTERNET_PORT& port) {
    host = server;
    port = 8080;  // run.py's online_http_port default
    const auto colon = server.find(':');
    if (colon == std::string::npos || server.front() == '[') return;
    const std::string digits = server.substr(colon + 1);
    if (digits.empty() || digits.find_first_not_of("0123456789") != std::string::npos) return;
    host = server.substr(0, colon);
    port = INTERNET_PORT(std::atoi(digits.c_str()));
}

/// What one server sees of the installation's key: HMAC-SHA256(key, host), as run.py sends it.
/// Every server gets a different value, so none can reuse it on another to take a nickname.
std::string ServerKey(const std::string& host) {
    const std::string key = OnlineKey();
    if (key.size() != 64) return {};
    unsigned char raw[32];
    for (int i = 0; i < 32; ++i) raw[i] = static_cast<unsigned char>(std::stoi(key.substr(i * 2, 2), nullptr, 16));
    const std::string msg = Lower(Trim(host));
    unsigned char mac[32];
    bool ok = false;
    BCRYPT_ALG_HANDLE alg = nullptr;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, BCRYPT_ALG_HANDLE_HMAC_FLAG) == 0) {
        BCRYPT_HASH_HANDLE hash = nullptr;
        if (BCryptCreateHash(alg, &hash, nullptr, 0, raw, sizeof raw, 0) == 0) {
            ok = BCryptHashData(hash, reinterpret_cast<PUCHAR>(const_cast<char*>(msg.data())), ULONG(msg.size()), 0) == 0 &&
                 BCryptFinishHash(hash, mac, sizeof mac, 0) == 0;
            BCryptDestroyHash(hash);
        }
        BCryptCloseAlgorithmProvider(alg, 0);
    }
    if (!ok) return {};
    static const char kHex[] = "0123456789abcdef";
    std::string out;
    for (const unsigned char b : mac) {
        out += kHex[b >> 4];
        out += kHex[b & 15];
    }
    return out;
}

/// A request to the RyuNET server's HTTP port, with this installation's key for that server.
/// The body, or "" when the server could not be reached. Called from background threads.
std::string HttpRequest(const std::string& server, const wchar_t* method, const std::wstring& path,
                        const std::string& form = {}, int timeout_ms = 3000) {
    std::string host;
    INTERNET_PORT port = 0;
    SplitServer(server, host, port);
    const std::string key = ServerKey(host);
    std::string body;
    HINTERNET session = WinHttpOpen(L"CTR-NitroFueled-PC launcher", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                                    WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!session) return body;
    WinHttpSetTimeouts(session, timeout_ms, timeout_ms, timeout_ms, timeout_ms);
    HINTERNET conn = WinHttpConnect(session, Widen(host).c_str(), port, 0);
    HINTERNET req = conn ? WinHttpOpenRequest(conn, method, path.c_str(), nullptr, WINHTTP_NO_REFERER,
                                              WINHTTP_DEFAULT_ACCEPT_TYPES, 0)
                         : nullptr;
    std::wstring headers;
    if (!key.empty()) headers += L"X-RyuNET-Key: " + Widen(key) + L"\r\n";
    if (!form.empty()) headers += L"Content-Type: application/x-www-form-urlencoded\r\n";
    if (req && WinHttpSendRequest(req, headers.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headers.c_str(),
                                  headers.empty() ? 0 : DWORD(-1),
                                  form.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char*>(form.data()),
                                  DWORD(form.size()), DWORD(form.size()), 0) &&
        WinHttpReceiveResponse(req, nullptr)) {
        DWORD avail = 0;
        while (WinHttpQueryDataAvailable(req, &avail) && avail && body.size() < 4096) {
            std::string chunk(avail, '\0');
            DWORD got = 0;
            if (!WinHttpReadData(req, chunk.data(), avail, &got) || !got) break;
            body.append(chunk.data(), got);
        }
    }
    if (req) WinHttpCloseHandle(req);
    if (conn) WinHttpCloseHandle(conn);
    WinHttpCloseHandle(session);
    return body;
}

std::string HttpGet(const std::string& server, const std::wstring& path) { return HttpRequest(server, L"GET", path); }

/// A string field of a small flat JSON answer ("" when missing).
std::string JsonField(const std::string& body, const char* key) {
    const std::string field = std::string("\"") + key + "\":\"";
    const auto at = body.find(field);
    if (at == std::string::npos) return {};
    const auto end = body.find('"', at + field.size());
    return end == std::string::npos ? std::string() : body.substr(at + field.size(), end - at - field.size());
}

/// A number field of a small flat JSON answer.
bool JsonNumber(const std::string& body, const char* key, int& value) {
    const std::string field = std::string("\"") + key + "\":";
    const auto at = body.find(field);
    if (at == std::string::npos) return false;
    char* end = nullptr;
    const long n = std::strtol(body.c_str() + at + field.size(), &end, 10);
    if (end == body.c_str() + at + field.size()) return false;
    value = int(n);
    return true;
}

/// A true/false field of a small flat JSON answer.
bool JsonBool(const std::string& body, const char* key) {
    return body.find(std::string("\"") + key + "\":true") != std::string::npos;
}

NickCheck::Result AskNickStatus(const std::string& server, const std::string& nick) {
    // {"status":"...","linked":..,"discord_link":..,"discord":".."}; a server without this
    // endpoint answers something else.
    const std::string body = HttpGet(server, L"/ryunet/nick?name=" + Widen(nick));  // [A-Za-z0-9_-]
    NickCheck::Result r;
    r.status = JsonField(body, "status");
    r.linked = JsonBool(body, "linked");
    r.link_available = JsonBool(body, "discord_link");
    r.discord = JsonField(body, "discord");
    return r;
}

/// Cached answer for the current nickname, asking the server in the background once per
/// nickname. "?" while the question is out.
std::string NickAvailability() {
    const std::string nick = CurrentNick();
    const std::string server = Trim(g_app.game.Get("online_server", "octr.ryu7w7.xyz"));
    if (NickProblem(nick) || server.empty()) return "";
    const std::string id = server + "|" + nick;
    std::scoped_lock lock{g_nick_check.mutex};
    if (const auto it = g_nick_check.results.find(id); it != g_nick_check.results.end()) {
        if (!it->second.status.empty() || GetTickCount64() - it->second.at < 30000) return it->second.status;
    }
    if (!g_nick_check.in_flight.empty()) return "?";
    g_nick_check.in_flight = id;
    std::thread([server, nick, id] {
        NickCheck::Result result = AskNickStatus(server, nick);
        result.at = GetTickCount64();
        std::scoped_lock done{g_nick_check.mutex};
        g_nick_check.results[id] = result;
        g_nick_check.in_flight.clear();
    }).detach();
    return "?";
}

/// Whether the server can link Discord accounts, asked once in the background without a
/// nickname (a reinstalled launcher has none yet).
bool DiscordLinkAvailable() {
    const std::string server = Trim(g_app.game.Get("online_server", "octr.ryu7w7.xyz"));
    if (server.empty()) return false;
    const std::string id = server + "|*";
    std::scoped_lock lock{g_nick_check.mutex};
    if (const auto it = g_nick_check.results.find(id); it != g_nick_check.results.end()) {
        if (it->second.link_available || GetTickCount64() - it->second.at < 30000) return it->second.link_available;
    }
    if (!g_nick_check.in_flight.empty()) return false;
    g_nick_check.in_flight = id;
    std::thread([server, id] {
        NickCheck::Result result = AskNickStatus(server, "");
        result.at = GetTickCount64();
        std::scoped_lock done{g_nick_check.mutex};
        g_nick_check.results[id] = result;
        g_nick_check.in_flight.clear();
    }).detach();
    return false;
}

/// The last answer about the current nickname (status "" when unknown), without asking.
NickCheck::Result NickInfo() {
    const std::string server = Trim(g_app.game.Get("online_server", "octr.ryu7w7.xyz"));
    std::scoped_lock lock{g_nick_check.mutex};
    const auto it = g_nick_check.results.find(server + "|" + CurrentNick());
    return it == g_nick_check.results.end() ? NickCheck::Result{} : it->second;
}

/// One line under a nickname field: what the server says about it.
void NickAvailabilityLine() {
    const std::string s = NickAvailability();
    if (s == "?") {
        ImGui::TextColored(kGrey, "%s", T("Comprobando el apodo en el servidor...", "Checking the nickname with the server..."));
    } else if (s == "free") {
        ImGui::TextColored(kGreen, "%s", T("Disponible: será tuyo la primera vez que juegues online.",
                                           "Available: it becomes yours the first time you play online."));
    } else if (s == "yours") {
        ImGui::TextColored(kGreen, "%s", T("Este apodo es tuyo.", "This nickname is yours."));
    } else if (s == "taken" && NickInfo().linked) {
        ImGui::TextColored(kRed, "%s", T("Ese apodo está vinculado a una cuenta de Discord. Si es tuyo, recupéralo en la "
                                         "pestaña Online (Recuperar con Discord); si no, elige otro.",
                                         "That nickname is linked to a Discord account. If it is yours, recover it in the "
                                         "Online tab (Recover with Discord); otherwise choose another one."));
    } else if (s == "taken") {
        ImGui::TextColored(kRed, "%s", T("Ese apodo ya lo usa otra persona: elige otro.",
                                         "Someone else already uses that nickname: choose another one."));
    } else if (s == "reserved" || s == "invalid") {
        ImGui::TextColored(kRed, "%s", T("El servidor no acepta ese apodo: elige otro.", "The server does not accept that nickname: choose another one."));
    }
}

bool NickTaken() {
    const std::string s = NickAvailability();
    return s == "taken" || s == "reserved" || s == "invalid";
}

/// The lobby this player hosts (their party or private room), from the server's
/// /ryunet/party, refreshed in the background every 5 s while it is asked for: Discord's
/// "1 of 8" follows players joining and leaving. Only changes reach Discord (DiscordPresence
/// sends nothing for an unchanged activity), within its 5 updates per 20 s.
struct PartyPoll {
    std::mutex mutex;
    std::string id;  // "server|nick" of the last answer
    bool known = false;  // the server answered
    int players = 0, max = 0;
    ULONGLONG at = 0;
    bool in_flight = false;
};
PartyPoll g_party;

/// False while unknown (no answer yet, or a server without /ryunet/party).
bool PartyInfo(const std::string& server, const std::string& nick, int& players, int& max) {
    const std::string id = server + "|" + nick;
    std::scoped_lock lock{g_party.mutex};
    if ((g_party.id != id || GetTickCount64() - g_party.at >= 5000) && !g_party.in_flight) {
        g_party.in_flight = true;
        std::thread([server, nick, id] {
            const std::string body = HttpGet(server, L"/ryunet/party?name=" + Widen(nick));
            int p = 0, m = 0;
            const bool known = JsonNumber(body, "players", p) && JsonNumber(body, "max", m);
            std::scoped_lock done{g_party.mutex};
            g_party.id = id;
            g_party.known = known;
            g_party.players = p;
            g_party.max = m;
            g_party.at = GetTickCount64();
            g_party.in_flight = false;
        }).detach();
    }
    if (g_party.id != id || !g_party.known) return false;
    players = g_party.players;
    max = g_party.max;
    return true;
}

/// The NAT type test (nat_check.h), on a worker thread: once per server while the launcher is
/// open (the Play page's status line starts it), again with the Online tab's button.
struct NatState {
    std::mutex mutex;
    bool running = false, done = false;
    std::string server;  // what the last test asked
    NatCheck::Result result;
};
NatState g_nat;

void StartNatCheck(const std::string& server) {
    {
        std::scoped_lock lock{g_nat.mutex};
        if (g_nat.running) return;
        g_nat.running = true;
        g_nat.server = server;
    }
    std::thread([server] {
        const NatCheck::Result r = NatCheck::Check(server);
        std::scoped_lock lock{g_nat.mutex};
        g_nat.result = r;
        g_nat.running = false;
        g_nat.done = true;
    }).detach();
}

/// Short label and colour for the Play page ("NAT: type 2 (moderate)"); starts the first test
/// for this server.
std::string NatLabel(const std::string& server, ImVec4& color) {
    bool running, done;
    std::string checked;
    NatCheck::Result r;
    {
        std::scoped_lock lock{g_nat.mutex};
        running = g_nat.running;
        done = g_nat.done;
        checked = g_nat.server;
        r = g_nat.result;
    }
    if (!running && (!done || checked != server)) {
        StartNatCheck(server);
        running = true;
    }
    color = kGrey;
    if (running) return std::string("NAT: ") + T("comprobando...", "checking...");
    switch (r.type) {
    case NatCheck::Type::Open: color = kGreen; return T("NAT: tipo 1 (abierto)", "NAT: type 1 (open)");
    case NatCheck::Type::Moderate: color = kGreen; return T("NAT: tipo 2 (moderado)", "NAT: type 2 (moderate)");
    case NatCheck::Type::Strict: color = kYellow; return T("NAT: tipo 3 (estricto)", "NAT: type 3 (strict)");
    case NatCheck::Type::Unknown: break;
    }
    return T("NAT: desconocido", "NAT: unknown");
}

/// A server setting that can travel inside a Discord join secret (and be trusted coming out
/// of one): a host name or IP with an optional port.
bool ValidServer(const std::string& s) {
    return !s.empty() && s.size() <= 64 &&
           s.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-:") == std::string::npos;
}

bool ListHas(const std::string& csv, const std::string& name) {
    std::stringstream in(csv);
    for (std::string item; std::getline(in, item, ',');)
        if (Lower(Trim(item)) == Lower(name)) return true;
    return false;
}

void AddLog(const std::string& line) {
    std::scoped_lock lock{g_app.mutex};
    g_app.log.push_back(line);
    while (g_app.log.size() > 2000) g_app.log.pop_front();
    if (!line.empty()) g_app.last_status = line;
}

void JoinWorker() {
    if (g_app.worker.joinable()) g_app.worker.join();
}

void StartCheck() {
    App& a = g_app;
    a.game_info = Analyze(a.game_dir);
    a.game_checked = false;
    a.game_ok = false;
    a.check_message.clear();
    if (a.game_info.kind != Kind::Complete || !a.python) return;
    if (a.game_info.split) {  // Image0 + Sc0: PlayTab offers to prepare it
        a.game_checked = true;
        return;
    }
    JoinWorker();
    a.job = Job::Check;
    a.job_finished = false;
    const fs::path dir = a.game_dir;
    a.worker = std::thread([dir] {
        App& app = g_app;
        const std::wstring cmd = Quote(app.python->exe) + L" " + app.python->args + L"-X utf8 " +
                                 Quote((app.root / L"scripts" / L"game_check.py").wstring()) + L" " + Quote(dir.wstring());
        const Captured r = RunCaptured(app.python->exe, cmd, app.root, 120000);
        {
            std::scoped_lock lock{app.mutex};
            app.game_ok = r.started && r.code == 0;
            app.check_message = r.started ? Trim(r.output) : "Python could not be started.";
        }
        app.game_checked = true;
        app.job_finished = true;
    });
}

fs::path MergeTarget(const fs::path& near_dir) {
    App& a = g_app;
    const fs::path parent = near_dir.parent_path();
    fs::path target = parent / (GameTitle() + L"-1.21");
    if (target == near_dir || target == a.base_dir || target == a.update_dir || target == a.game_dir) {
        target = parent / (GameTitle() + L"-1.21-merged");
    }
    return target;
}

/// Base game + 1.21 update (or one already merged dump in the Image0 + Sc0 layout) -> a new
/// folder of hard links in the PS4 layout (copies across drives).
void StartMerge(std::vector<fs::path> sources) {
    App& a = g_app;
    if (sources.empty()) return;
    const fs::path target = MergeTarget(sources.front());
    JoinWorker();
    a.job = Job::Merge;
    a.job_finished = false;
    a.merge_done = 0;
    a.merge_total = 0;
    {
        std::scoped_lock lock{a.mutex};
        a.job_error.clear();
    }
    a.worker = std::thread([sources, target] {
        App& app = g_app;
        std::vector<std::pair<fs::path, fs::path>> files;  // source, relative
        std::error_code ec;
        for (const fs::path& from : sources) {
            auto more = LayoutFiles(from, ec);
            if (ec) break;
            files.insert(files.end(), std::make_move_iterator(more.begin()), std::make_move_iterator(more.end()));
        }
        std::string error;
        if (ec) error = "Cannot read the game folders: " + ec.message();
        app.merge_total = files.size();
        size_t copied = 0;
        for (size_t i = 0; error.empty() && i < files.size(); ++i) {
            const fs::path dest = target / files[i].second;
            std::error_code e2;
            fs::create_directories(dest.parent_path(), e2);
            if (fs::exists(dest, e2)) fs::remove(dest, e2);
            if (!CreateHardLinkW(dest.c_str(), files[i].first.c_str(), nullptr)) {
                if (!CopyFileW(files[i].first.c_str(), dest.c_str(), FALSE)) {
                    error = "Cannot create " + PathText(dest) + " (error " + std::to_string(GetLastError()) + ")";
                    break;
                }
                ++copied;
            }
            app.merge_done = i + 1;
        }
        {
            std::scoped_lock lock{app.mutex};
            app.job_error = error;
            if (error.empty()) {
                app.game_dir = target;
                app.log.push_back("Merged " + std::to_string(files.size()) + " files into " + PathText(target) +
                                  (copied ? " (" + std::to_string(copied) + " copied: different drive)" : ""));
            }
        }
        app.job_finished = true;
    });
}

/// The European edition is chosen (its languages differ from the Americas build's).
bool IsEuGame() { return GameTitle() == L"CUSA14876"; }

/// The game language of the launcher's own language, where the chosen edition has it.
const char* DefaultGameLanguage() {
    const bool eu = IsEuGame();
    if (g_active_locale == "es") return eu ? "3" : "20";
    if (g_active_locale == "fr") return "2";
    if (eu && g_active_locale == "de") return "4";
    if (eu && g_active_locale == "it") return "5";
    if (!eu && g_active_locale == "pt_BR") return "17";
    return "1";
}

/// The game language to start with: the saved one when the chosen edition has it, else its
/// counterpart there (Spanish: Latin American in the Americas build, Spain's in the European one),
/// else the default.
std::string GameLanguage() {
    const std::string saved = g_app.launcher.Get("language");
    const bool eu = IsEuGame();
    auto has = [&](const std::string& code) {
        if (eu) {
            for (const auto& c : kGameLanguagesEU)
                if (code == c.value) return true;
        } else {
            for (const auto& c : kGameLanguages)
                if (code == c.value) return true;
        }
        return false;
    };
    if (has(saved)) return saved;
    if (saved == "3" && !eu) return "20";
    if (saved == "20" && eu) return "3";
    return DefaultGameLanguage();
}

void SetEnv(const wchar_t* name, const std::string& value) {
    SetEnvironmentVariableW(name, value.empty() ? nullptr : Widen(value).c_str());
}

bool UpdateBusy();

void StartGame() {
    App& a = g_app;
    if (!a.python || a.game_running || UpdateBusy()) return;
    SaveGameIni();
    SaveLauncher();
    JoinWorker();
    {
        std::scoped_lock lock{a.mutex};
        a.log.clear();
        a.last_status.clear();
    }
    SetEnv(L"BB_GAME_DIR", PathText(a.game_dir));
    SetEnv(L"BB_NEO", EffectiveRenderRes() != "1080" ? "1" : "0");  // the resolution picks the path
    SetEnv(L"BB_LANGUAGE", GameLanguage());
    SetEnv(L"BB_DISPLAY", a.launcher.Get("display"));
    SetEnv(L"BB_PRESENT_MODE", a.launcher.Get("present_mode", "Mailbox"));
    SetEnv(L"BB_GAMEPAD", a.launcher.Get("gamepad"));
    SetEnv(L"BB_SAVE_LOG", a.launcher.Flag("save_log", false) ? "1" : "");
    SetEnv(L"BB_DLC", a.launcher.Flag("dlc", true) ? "1" : "0");
    SetEnv(L"BB_DLC_DISABLED", a.launcher.Get("dlc_disabled"));
    SetEnv(L"BB_FULLSCREEN", "");  // bbport.ini's fullscreen= (the menu switch) decides
    SetEnv(L"PYTHONUTF8", "1");
    SetEnv(L"PYTHONIOENCODING", "utf-8");

    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE read = nullptr, write = nullptr;
    if (!CreatePipe(&read, &write, &sa, 0)) return;
    SetHandleInformation(read, HANDLE_FLAG_INHERIT, 0);
    HANDLE nul = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa, OPEN_EXISTING, 0, nullptr);
    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = nul;
    si.hStdOutput = write;
    si.hStdError = write;
    PROCESS_INFORMATION pi{};
    std::wstring cmd = Quote(a.python->exe) + L" " + a.python->args + L"-X utf8 " + Quote((a.root / L"run.py").wstring());
    const BOOL ok = CreateProcessW(a.python->exe.c_str(), cmd.data(), nullptr, nullptr, TRUE,
                                   CREATE_NO_WINDOW | CREATE_SUSPENDED, nullptr, a.root.c_str(), &si, &pi);
    CloseHandle(write);
    if (nul != INVALID_HANDLE_VALUE) CloseHandle(nul);
    if (!ok) {
        CloseHandle(read);
        AddLog("Could not start Python (error " + std::to_string(GetLastError()) + ")");
        a.exit_code = 1;
        a.show_exit = true;
        return;
    }
    // A job object, so "Stop" ends run.py and the game it started.
    a.job_object = CreateJobObjectW(nullptr, nullptr);
    if (a.job_object) AssignProcessToJobObject(a.job_object, pi.hProcess);
    ResumeThread(pi.hThread);
    CloseHandle(pi.hThread);
    a.process = pi.hProcess;
    a.game_running = true;
    a.show_exit = false;
    a.stopped = false;
    a.job = Job::Play;
    a.job_finished = false;
    AddLog("Starting the game...");
    a.worker = std::thread([read] {
        App& app = g_app;
        std::string pending;
        char buf[4096];
        DWORD n = 0;
        while (ReadFile(read, buf, sizeof buf, &n, nullptr) && n) {
            pending.append(buf, n);
            size_t nl;
            while ((nl = pending.find('\n')) != std::string::npos) {
                AddLog(Trim(pending.substr(0, nl)));
                pending.erase(0, nl + 1);
            }
        }
        if (!pending.empty()) AddLog(Trim(pending));
        CloseHandle(read);
        WaitForSingleObject(app.process, INFINITE);
        DWORD code = 0;
        GetExitCodeProcess(app.process, &code);
        app.exit_code = code;
        app.job_finished = true;
    });
    if (a.hwnd) {
        if (a.launcher.Flag("hide_on_play", false)) ShowWindow(a.hwnd, SW_HIDE);
        else ShowWindow(a.hwnd, SW_MINIMIZE);
    }
}

void StopGame() {
    g_app.stopped = true;
    if (g_app.job_object) TerminateJobObject(g_app.job_object, 1);
    else if (g_app.process) TerminateProcess(g_app.process, 1);
}

/// Discord application whose name and art the presence shows (and whose OAuth2 links
/// nicknames). launcher.ini discord_app_id can name another one; empty or missing is this one.
constexpr const char* kDiscordAppId = "1560408801704943708";

std::string DiscordAppId() {
    const std::string id = g_app.launcher.Get("discord_app_id");
    return id.empty() ? kDiscordAppId : id;
}

/// Shows the game in the player's Discord status while it runs (launcher.ini discord_rpc,
/// on by default). Called every frame; DiscordPresence only talks to Discord on a change.
void UpdateDiscord() {
    App& a = g_app;
    static int64_t started = 0;
    if (!a.game_running) {
        started = 0;
    } else if (started == 0) {
        started = int64_t(std::time(nullptr));
    }
    const bool enabled = a.launcher.Flag("discord_rpc", true);
    const std::string app_id = DiscordAppId();
    if (!a.game_running) {
        DiscordPresence::Update(enabled, app_id, nullptr);
        return;
    }
    DiscordPresence::Activity activity;
    if (a.game.Flag("online", true)) {
        activity.details = T("Jugando online", "Playing online");
        const std::string nick = CurrentNick();
        if (!nick.empty()) activity.state = std::string(T("Apodo: ", "Nickname: ")) + nick;
        // Joinable: Discord's "Join" and the chat's "+ > Invite" hand our server and nickname to
        // whoever accepts; their launcher adds us as a friend and starts their game.
        const std::string server = Trim(a.game.Get("online_server", "octr.ryu7w7.xyz"));
        if (!NickProblem(nick) && ValidServer(server)) {
            int players = 0, max = 0;
            if (!PartyInfo(server, nick, players, max)) {
                players = 1;  // a server without /ryunet/party: offer it anyway
                max = 8;
            }
            if (players > 0 && max >= players) {
                activity.party_id = "ctr:" + Lower(server) + ":" + Lower(nick);
                activity.party_size = players;
                activity.party_max = max;
                if (players < max) activity.join_secret = "ctr1|" + server + "|" + nick;
            }
        }
    } else {
        activity.details = T("Jugando sin conexión", "Playing offline");
    }
    activity.start = started;
    activity.large_image = "logo";
    activity.large_text = "Crash Team Racing Nitro-Fueled";
    DiscordPresence::Update(enabled, app_id, &activity);
}

/// Lets Discord start this launcher when the player accepts an invite with it closed: the
/// discord-<app id> URL protocol, registered for the current user as Discord's own SDKs do.
/// Written on every start, so a portable folder that moved points at its new place.
void RegisterDiscordLaunch(const std::string& app_id) {
    if (app_id.empty() || app_id.find_first_not_of("0123456789") != std::string::npos) return;
    wchar_t exe[MAX_PATH];
    const DWORD n = GetModuleFileNameW(nullptr, exe, MAX_PATH);
    if (!n || n >= MAX_PATH) return;
    const std::wstring path(exe, n);
    const std::wstring base = L"Software\\Classes\\discord-" + Widen(app_id);
    const auto set = [](const std::wstring& key, const wchar_t* name, const std::wstring& value) {
        HKEY h = nullptr;
        if (RegCreateKeyExW(HKEY_CURRENT_USER, key.c_str(), 0, nullptr, 0, KEY_SET_VALUE, nullptr, &h, nullptr) != ERROR_SUCCESS)
            return;
        RegSetValueExW(h, name, 0, REG_SZ, reinterpret_cast<const BYTE*>(value.c_str()),
                       DWORD((value.size() + 1) * sizeof(wchar_t)));
        RegCloseKey(h);
    };
    set(base, nullptr, L"URL:Run game " + Widen(app_id) + L" protocol");
    set(base, L"URL Protocol", L"");
    set(base + L"\\DefaultIcon", nullptr, path + L",0");
    set(base + L"\\shell\\open\\command", nullptr, L"\"" + path + L"\"");
}

/// What the PLAY button does: online without a usable nickname asks for one first (NickPopup).
void PressPlay() {
    App& a = g_app;
    if (a.game.Flag("online", true) && (NickProblem(CurrentNick()) || NickTaken())) a.ask_nick = true;
    else StartGame();
}

bool GameReady() {
    const App& a = g_app;
    return a.game_info.kind == Kind::Complete && a.game_checked && a.game_ok && a.job == Job::None && a.python;
}

void BringLauncherToFront() {
    ShowWindow(g_app.hwnd, SW_RESTORE);
    SetForegroundWindow(g_app.hwnd);
}

std::string Format(const char* format, const std::string& a, const std::string& b = {}) {
    char buf[512];
    std::snprintf(buf, sizeof buf, format, a.c_str(), b.c_str());
    return buf;
}

/// An invite accepted in Discord, for a server we use (or agreed to switch to): the host
/// becomes a friend (the game lists friends' lobbies as joinable) and the game starts.
void AcceptDiscordJoin(const std::string& server, const std::string& nick) {
    App& a = g_app;
    a.game.Set("online", "1");
    a.game.Set("online_server", server);
    std::string friends = Trim(a.game.Get("online_friends"));
    if (!ListHas(friends, nick)) friends = friends.empty() ? nick : friends + "," + nick;
    a.game.Set("online_friends", friends);
    SaveGameIni();  // a running game reads the new friend from bbport.ini
    SyncOnlineBuffers();
    {
        std::scoped_lock lock{g_nick_check.mutex};  // the server may have changed
        g_nick_check.results.clear();
    }
    // The game takes this as a PS4 invitation accepted in the system UI and joins the host's
    // session by itself (src/runtime_services.c, SESSION_INVITATION). Sessions are named after
    // their host. The file is stamped so a game that starts much later ignores it.
    {
        std::ofstream join(GameIni().parent_path() / L"ryunet_join.txt", std::ios::binary | std::ios::trunc);
        join << "session=cusa13795-session-" << nick << "\nhost=" << nick << "\ntime=" << int64_t(std::time(nullptr))
             << "\n";
    }
    if (a.game_running) {
        a.notice = Format(T("Invitación de %s aceptada: el juego se une a su partida en unos segundos. Si no lo "
                            "hace, abre Amigos en el juego y únete a %s.",
                            "%s's invite accepted: the game joins their match in a few seconds. If it does "
                            "not, open Friends in the game and join %s."),
                          nick, nick);
        return;
    }
    a.notice = Format(T("Invitación de %s aceptada: el juego se abre y se une a su partida (si no, abre Amigos "
                        "y únete a %s).",
                        "%s's invite accepted: the game starts and joins their match (if not, open Friends "
                        "and join %s)."),
                      nick, nick);
    BringLauncherToFront();
    a.pending_play = true;  // PollJobs presses PLAY as soon as the game folder is checked
}

/// A join secret from Discord: "ctr1|<server>|<nickname>", written by UpdateDiscord.
void OnDiscordJoin(const std::string& secret) {
    App& a = g_app;
    const auto p1 = secret.find('|');
    const auto p2 = p1 == std::string::npos ? p1 : secret.find('|', p1 + 1);
    const std::string server = p2 == std::string::npos ? "" : secret.substr(p1 + 1, p2 - p1 - 1);
    const std::string nick = p2 == std::string::npos ? "" : secret.substr(p2 + 1);
    if (secret.compare(0, p1, "ctr1") != 0 || !ValidServer(server) || NickProblem(nick)) {
        a.notice = T("Esa invitación de Discord no es de este launcher.", "That Discord invite is not from this launcher.");
        BringLauncherToFront();
        return;
    }
    if (Lower(nick) == Lower(CurrentNick())) return;  // our own invite
    if (Lower(server) != Lower(Trim(a.game.Get("online_server", "octr.ryu7w7.xyz")))) {
        // Never switch servers silently: a crafted invite could send us to any server.
        a.join_server = server;
        a.join_nick = nick;
        a.ask_join_server = true;  // JoinServerPopup
        BringLauncherToFront();
        return;
    }
    AcceptDiscordJoin(server, nick);
}

/// A JSON string field with its escapes decoded (\" \\ \/ \n \t \uXXXX, surrogate pairs), as
/// UTF-8; "" when missing.
std::string JsonText(const std::string& body, const char* key) {
    const std::string field = std::string("\"") + key + "\":\"";
    size_t i = body.find(field);
    if (i == std::string::npos) return {};
    i += field.size();
    std::string out;
    const auto put = [&out](unsigned cp) {
        if (cp < 0x80) {
            out += char(cp);
        } else if (cp < 0x800) {
            out += char(0xC0 | (cp >> 6));
            out += char(0x80 | (cp & 0x3F));
        } else if (cp < 0x10000) {
            out += char(0xE0 | (cp >> 12));
            out += char(0x80 | ((cp >> 6) & 0x3F));
            out += char(0x80 | (cp & 0x3F));
        } else {
            out += char(0xF0 | (cp >> 18));
            out += char(0x80 | ((cp >> 12) & 0x3F));
            out += char(0x80 | ((cp >> 6) & 0x3F));
            out += char(0x80 | (cp & 0x3F));
        }
    };
    const auto hex4 = [&body](size_t at, unsigned& v) {
        if (at + 4 > body.size()) return false;
        v = 0;
        for (size_t k = at; k < at + 4; ++k) {
            const char c = body[k];
            v = v * 16 + unsigned(c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : 99);
            if (v > 0xFFFF) return false;
        }
        return true;
    };
    for (; i < body.size() && body[i] != '"'; ++i) {
        if (body[i] != '\\' || i + 1 >= body.size()) {
            out += body[i];
            continue;
        }
        const char e = body[++i];
        if (e == 'n') out += ' ';
        else if (e == 't') out += ' ';
        else if (e == 'u') {
            unsigned cp = 0, low = 0;
            if (!hex4(i + 1, cp)) break;
            i += 4;
            if (cp >= 0xD800 && cp < 0xDC00 && i + 6 < body.size() && body[i + 1] == '\\' && body[i + 2] == 'u' &&
                hex4(i + 3, low) && low >= 0xDC00 && low < 0xE000) {
                cp = 0x10000 + ((cp - 0xD800) << 10) + (low - 0xDC00);
                i += 6;
            }
            put(cp);
        } else {
            out += e;  // \" \ \/
        }
    }
    return out;
}

/// The digits of a JSON number field ("" when missing); IDs past 32 bits stay exact.
std::string JsonDigits(const std::string& body, const char* key) {
    const std::string field = std::string("\"") + key + "\":";
    const auto at = body.find(field);
    if (at == std::string::npos) return {};
    size_t end = at + field.size();
    while (end < body.size() && std::isdigit(static_cast<unsigned char>(body[end]))) ++end;
    return body.substr(at + field.size(), end - at - field.size());
}

/// Server announcements ("maintenance in 5 minutes"): /ryunet/announce, asked every 30 s while
/// online play is on. A new one goes to the game in ryunet_announce.txt next to bbport.ini
/// (the port draws it over the picture, gpu/shim/bbport_overlay.cpp) and to the launcher's
/// notice line.
struct AnnouncePoll {
    std::mutex mutex;
    ULONGLONG asked = 0;
    bool in_flight = false;
    std::string seen_id;   // the last announcement handed on
    std::string pending;   // its text, for the launcher's notice (UI thread)
};
AnnouncePoll g_announce;

void PollAnnouncement() {
    App& a = g_app;
    if (!a.game.Flag("online", true)) return;
    const std::string server = Trim(a.game.Get("online_server", "octr.ryu7w7.xyz"));
    std::string text;
    {
        std::scoped_lock lock{g_announce.mutex};
        text.swap(g_announce.pending);
        if (!g_announce.in_flight && !server.empty() && GetTickCount64() - g_announce.asked >= 30000) {
            g_announce.in_flight = true;
            g_announce.asked = GetTickCount64();
            const fs::path file = GameIni().parent_path() / L"ryunet_announce.txt";
            std::thread([server, file] {
                const std::string body = HttpGet(server, L"/ryunet/announce");
                const std::string id = JsonDigits(body, "id"), msg = JsonText(body, "text");
                int expires_in = 0;
                JsonNumber(body, "expires_in", expires_in);
                std::scoped_lock done{g_announce.mutex};
                g_announce.in_flight = false;
                if (id.empty() || id == "0" || msg.empty() || expires_in <= 0 || id == g_announce.seen_id) return;
                g_announce.seen_id = id;
                g_announce.pending = msg;
                std::ofstream out(file, std::ios::binary | std::ios::trunc);
                out << "id=" << id << "\nlevel=" << JsonText(body, "level") << "\nexpires="
                    << int64_t(std::time(nullptr)) + expires_in << "\ntext=" << msg << "\n";
            }).detach();
        }
    }
    if (!text.empty()) a.notice = std::string(T("Aviso del servidor: ", "Server notice: ")) + text;
}

/// Called every frame: picks up finished background work.
void ApplyRecoveredNick();

void PollJobs() {
    App& a = g_app;
    UpdateDiscord();
    ApplyRecoveredNick();
    PollAnnouncement();
    DiscordPresence::SetAcceptJoinRequests(a.launcher.Flag("discord_accept_requests", true));
    for (std::string secret; DiscordPresence::TakeJoin(secret);) OnDiscordJoin(secret);
    if (a.pending_play && !a.game_running && GameReady()) {
        a.pending_play = false;
        PressPlay();
    }
    if (a.probe_done && a.probe.joinable()) a.probe.join();
    if (!a.job_finished) return;
    const Job finished = a.job.exchange(Job::None);
    a.job_finished = false;
    JoinWorker();
    if (finished == Job::Merge) {
        std::string error;
        {
            std::scoped_lock lock{a.mutex};
            error = a.job_error;
        }
        if (error.empty()) {
            SaveLauncher();
            StartCheck();
        } else {
            a.notice = error;
        }
    } else if (finished == Job::Play) {
        CloseHandle(a.process);
        a.process = nullptr;
        if (a.job_object) CloseHandle(a.job_object);
        a.job_object = nullptr;
        a.game_running = false;
        a.show_exit = true;
        a.game.Load(GameIni());  // the in-game menu may have changed settings
        SyncOnlineBuffers();
        {
            std::scoped_lock lock{g_nick_check.mutex};  // a free nickname is now ours
            g_nick_check.results.clear();
        }
        a.saves_dirty = true;
        if (a.hwnd) {
            if (a.launcher.Flag("close_on_play", false)) {
                PostQuitMessage(0);
            } else {
                ShowWindow(a.hwnd, SW_RESTORE);
                SetForegroundWindow(a.hwnd);
            }
        }
    }
}

void StartProbe() {
    App& a = g_app;
    if (a.probe.joinable()) a.probe.join();
    a.probe_done = false;
    a.probe = std::thread([] {
        App& app = g_app;
        const fs::path tool = app.bin / L"bb-gpu-capabilities.exe";
        std::vector<std::pair<std::string, std::string>> displays, pads;
        const Captured d = RunCaptured(tool.wstring(), Quote(tool.wstring()) + L" --displays", app.bin, 10000);
        std::stringstream ds(d.output);
        std::string line;
        int number = 0;
        while (std::getline(ds, line)) {
            line = Trim(line);
            const auto t1 = line.find('\t');
            if (t1 == std::string::npos) continue;
            const auto t2 = line.find('\t', t1 + 1);
            ++number;
            std::string label = std::to_string(number) + ": " + line.substr(0, t1) + " (" +
                                line.substr(t1 + 1, t2 == std::string::npos ? std::string::npos : t2 - t1 - 1) + ")";
            if (t2 != std::string::npos && line.substr(t2 + 1) == "1") label += g_spanish ? " - principal" : " - primary";
            displays.emplace_back(std::to_string(number), label);
        }
        const Captured p = RunCaptured(tool.wstring(), Quote(tool.wstring()) + L" --gamepads", app.bin, 10000);
        std::stringstream ps(p.output);
        while (std::getline(ps, line)) {
            line = Trim(line);
            const auto t = line.find('\t');
            if (t != std::string::npos) pads.emplace_back(line.substr(0, t), line.substr(t + 1));
        }
        std::scoped_lock lock{app.mutex};
        app.displays = std::move(displays);
        app.gamepads = std::move(pads);
        app.probe_done = true;
    });
}

void ChooseFolder(fs::path& slot, FolderInfo& info, const wchar_t* title) {
    App& a = g_app;
    fs::path start = slot.empty() ? (a.base_dir.empty() ? a.root : a.base_dir.parent_path()) : slot.parent_path();
    auto picked = PickFolder(a.hwnd, title, start);
    if (!picked) return;
    *picked = GameRoot(*picked);
    const FolderInfo found = Analyze(*picked);
    // Whatever was picked goes where it belongs.
    switch (found.kind) {
    case Kind::Complete:
        a.game_dir = *picked;
        a.game_info = found;
        SaveLauncher();
        if (found.split) {
            StartMerge({*picked});  // Image0 + Sc0 -> the PS4 layout, next to it
        } else {
            StartCheck();
        }
        return;
    case Kind::Base:
        a.base_dir = *picked;
        a.base_info = found;
        break;
    case Kind::Update:
        a.update_dir = *picked;
        a.update_info = found;
        break;
    default:
        slot = *picked;
        info = found;
        break;
    }
    SaveLauncher();
}

// ---------------------------------------------------------------------------------------------
// Saves: <port>\user\savedata\<user>\CUSA13795\<dir> holds the game's files and <dir>.sce_sys its
// param.bin (title, subtitle, detail) and icon0.png, as src/runtime_savedata.c keeps them.






std::string FileTimeText(const fs::path& p) {
    WIN32_FILE_ATTRIBUTE_DATA data;
    if (!GetFileAttributesExW(p.c_str(), GetFileExInfoStandard, &data)) return {};
    FILETIME local;
    SYSTEMTIME st;
    FileTimeToLocalFileTime(&data.ftLastWriteTime, &local);
    FileTimeToSystemTime(&local, &st);
    char buf[64];
    std::snprintf(buf, sizeof buf, "%04u-%02u-%02u %02u:%02u", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute);
    return buf;
}

std::string Stamp() {
    SYSTEMTIME st;
    GetLocalTime(&st);
    char buf[64];
    std::snprintf(buf, sizeof buf, "%04u%02u%02u-%02u%02u%02u", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    return buf;
}

std::string Fixed(const char* s, size_t n) { return std::string(s, strnlen(s, n)); }

std::string FormatSize(std::uintmax_t bytes) {
    char buf[64];
    if (bytes >= (1ull << 20)) std::snprintf(buf, sizeof buf, "%.1f MB", double(bytes) / double(1ull << 20));
    else std::snprintf(buf, sizeof buf, "%.0f KB", double(bytes) / 1024.0);
    return buf;
}

fs::path SaveRoot() {
    const fs::path base = g_app.root / L"user" / L"savedata";
    std::error_code ec;
    for (fs::directory_iterator it(base, ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        if (fs::is_directory(it->path() / GameTitle(), e2)) return it->path() / GameTitle();
    }
    return base / L"1" / GameTitle();
}

fs::path BackupRoot() { return g_app.root / L"backups"; }

bool IsMetaName(const std::wstring& name) {
    auto ends = [&](const wchar_t* suffix) {
        const size_t n = wcslen(suffix);
        return name.size() > n && name.compare(name.size() - n, n, suffix) == 0;
    };
    return ends(L".sce_sys") || ends(L".memory");
}

std::vector<SaveSlot> ListSaves() {
    std::vector<SaveSlot> slots;
    const fs::path root = SaveRoot();
    std::error_code ec;
    for (fs::directory_iterator it(root, ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        if (!it->is_directory(e2) || IsMetaName(it->path().filename().wstring())) continue;
        SaveSlot s;
        s.dir = PathText(it->path().filename());
        s.bytes = FolderBytes(it->path());
        fs::path meta = it->path();
        meta += L".sce_sys";
        const std::string raw = ReadText(meta / L"param.bin");
        if (raw.size() >= sizeof(SaveParam)) {
            SaveParam p;
            std::memcpy(&p, raw.data(), sizeof p);
            s.title = Fixed(p.title, sizeof p.title);
            s.subtitle = Fixed(p.subtitle, sizeof p.subtitle);
            s.detail = Fixed(p.detail, sizeof p.detail);
        }
        s.modified = FileTimeText(it->path());
        for (fs::recursive_directory_iterator f(it->path(), e2), fend; !e2 && f != fend; f.increment(e2)) {
            std::error_code e3;
            if (f->is_regular_file(e3)) {
                const std::string t = FileTimeText(f->path());
                if (t > s.modified) s.modified = t;
            }
        }
        slots.push_back(std::move(s));
    }
    std::sort(slots.begin(), slots.end(), [](const SaveSlot& a, const SaveSlot& b) { return a.dir < b.dir; });
    return slots;
}

std::vector<Backup> ListBackups() {
    std::vector<Backup> list;
    std::error_code ec;
    for (fs::directory_iterator it(BackupRoot(), ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        const std::string name = PathText(it->path().filename());
        if (!it->is_directory(e2) || name.rfind("saves-", 0) != 0) continue;
        list.push_back({it->path(), name, FileTimeText(it->path()), FolderBytes(it->path())});
    }
    std::sort(list.begin(), list.end(), [](const Backup& a, const Backup& b) { return a.name > b.name; });
    return list;
}

bool HasSaves() {
    std::error_code ec;
    return fs::is_directory(SaveRoot(), ec) && !fs::is_empty(SaveRoot(), ec);
}

std::string CopyTree(const fs::path& from, const fs::path& to) {
    std::error_code ec;
    fs::create_directories(to, ec);
    fs::copy(from, to, fs::copy_options::recursive | fs::copy_options::overwrite_existing, ec);
    return ec ? PathText(from) + " -> " + PathText(to) + ": " + ec.message() : std::string();
}

/// A copy of all saves in backups\saves-<date>[-label]; empty error when there is nothing to copy.
std::string BackupSaves(const char* label, fs::path* made = nullptr) {
    if (!HasSaves()) return {};
    fs::path target = BackupRoot() / Widen("saves-" + Stamp() + (label ? std::string("-") + label : ""));
    const std::string error = CopyTree(SaveRoot(), target);
    if (error.empty() && made) *made = target;
    return error;
}

std::string RestoreBackup(const fs::path& backup) {
    std::string error = BackupSaves("auto");
    if (!error.empty()) return error;
    std::error_code ec;
    fs::remove_all(SaveRoot(), ec);
    if (ec) return PathText(SaveRoot()) + ": " + ec.message();
    return CopyTree(backup, SaveRoot());
}

/// A save folder from elsewhere: this launcher's backup or another PC's CUSA13795 folder (copied
/// as it is), or a decrypted PS4 save (Apollo Save Tool, Save Wizard: its files plus
/// sce_sys\param.sfo), converted to the runtime's layout.
std::string ImportSaves(const fs::path& from) {
    std::error_code ec;
    const fs::path sfo_path = from / L"sce_sys" / L"param.sfo";
    if (fs::is_regular_file(sfo_path, ec)) {
        const auto sfo = ReadSfo(sfo_path);
        auto get = [&](const char* k) {
            const auto it = sfo.find(k);
            return it == sfo.end() ? std::string() : it->second;
        };
        std::string dir = get("SAVEDATA_DIRECTORY");
        if (dir.empty() || dir.size() >= 32 || dir.find_first_of("\\/:") != std::string::npos) {
            return T("param.sfo no dice en qué ranura va la partida (SAVEDATA_DIRECTORY).",
                     "param.sfo does not name the save slot (SAVEDATA_DIRECTORY).");
        }
        std::string error = BackupSaves("antes-de-importar");
        if (!error.empty()) return error;
        const fs::path target = SaveRoot() / Widen(dir);
        fs::path meta = target;
        meta += L".sce_sys";
        fs::remove_all(target, ec);
        fs::create_directories(target, ec);
        fs::create_directories(meta, ec);
        for (fs::directory_iterator it(from, ec), end; !ec && it != end; it.increment(ec)) {
            if (it->path().filename() == L"sce_sys") continue;
            std::error_code e2;
            fs::copy(it->path(), target / it->path().filename(),
                     fs::copy_options::recursive | fs::copy_options::overwrite_existing, e2);
            if (e2) return PathText(it->path()) + ": " + e2.message();
        }
        SaveParam p{};
        std::snprintf(p.title, sizeof p.title, "%s", get("MAINTITLE").c_str());
        std::snprintf(p.subtitle, sizeof p.subtitle, "%s", get("SUBTITLE").c_str());
        std::snprintf(p.detail, sizeof p.detail, "%s", get("DETAIL").c_str());
        p.mtime = int64_t(time(nullptr));
        if (!WriteTextAtomic(meta / L"param.bin", std::string(reinterpret_cast<const char*>(&p), sizeof p))) {
            return T("No se pudo escribir param.bin.", "Could not write param.bin.");
        }
        fs::copy_file(from / L"sce_sys" / L"icon0.png", meta / L"icon0.png", fs::copy_options::overwrite_existing, ec);
        return {};
    }
    // The runtime's layout: <dir> next to <dir>.sce_sys.
    bool ours = false;
    for (fs::directory_iterator it(from, ec), end; !ec && it != end; it.increment(ec)) {
        fs::path meta = it->path();
        meta += L".sce_sys";
        std::error_code e2;
        if (!IsMetaName(it->path().filename().wstring()) && fs::is_directory(meta, e2)) ours = true;
    }
    if (!ours) {
        return T("No reconozco esa carpeta: elige una copia de seguridad, la carpeta CUSA13795 de las partidas de "
                 "otro PC o una partida de PS4 descifrada (con sce_sys\\param.sfo).",
                 "This folder is not recognized: choose a backup, the CUSA13795 saves folder from another PC or a "
                 "decrypted PS4 save (with sce_sys\\param.sfo).");
    }
    std::string error = BackupSaves("antes-de-importar");
    if (!error.empty()) return error;
    return CopyTree(from, SaveRoot());
}

// ---------------------------------------------------------------------------------------------
// Patches: every eboot patch for CUSA13795 01.21 in patches\*.xml (shadPS4/GoldHEN XML format).
// The three community patches keep their bbport.ini keys (shared with the in-game menu); others
// are switched in patches.json ({"enabled": [...], "disabled": [...]}), as scripts/patches.py reads.



constexpr std::pair<const char*, const char*> kIniPatches[] = {
    {"CrashTeamRacing.xml/60 FPS Unlock", "patch_60fps"},
    {"CrashTeamRacing.xml/Disable Motion Blur", "patch_no_motion_blur"},
    {"CrashTeamRacing.xml/Resolution Patch (1080p for PS4 Pro)", "patch_pro_1080p"},
    {"CrashTeamRacingUnlockAll.xml/Unlock Everything", "patch_unlock_all"},
    // The European edition's files: the same switches (scripts/patches.py BUNDLED_FILES).
    {"CrashTeamRacingEU.xml/60 FPS Unlock", "patch_60fps"},
    {"CrashTeamRacingEU.xml/Disable Motion Blur", "patch_no_motion_blur"},
    {"CrashTeamRacingEU.xml/Resolution Patch (1080p for PS4 Pro)", "patch_pro_1080p"},
};

/// "USA" or "EU" for a CTR title ID, "" otherwise.
const char* RegionOf(const std::string& title) {
    if (title == "CUSA13795") return "USA";
    if (title == "CUSA14876") return "EU";
    return "";
}

std::string XmlUnescape(std::string s) {
    const std::pair<const char*, const char*> entities[] = {
        {"&lt;", "<"}, {"&gt;", ">"}, {"&quot;", "\""}, {"&apos;", "'"}, {"&amp;", "&"}};
    for (const auto& [from, to] : entities) {
        for (size_t at = 0; (at = s.find(from, at)) != std::string::npos; at += std::strlen(to))
            s.replace(at, std::strlen(from), to);
    }
    return s;
}

std::map<std::string, std::string> XmlAttributes(const std::string& tag) {
    std::map<std::string, std::string> out;
    size_t i = 0;
    while (i < tag.size()) {
        const size_t eq = tag.find('=', i);
        if (eq == std::string::npos) break;
        size_t name_end = eq;
        while (name_end > i && (tag[name_end - 1] == ' ' || tag[name_end - 1] == '\n' || tag[name_end - 1] == '\r' || tag[name_end - 1] == '\t')) --name_end;
        size_t name_start = name_end;
        while (name_start > i && !std::isspace(static_cast<unsigned char>(tag[name_start - 1])) && tag[name_start - 1] != '<') --name_start;
        size_t q = eq + 1;
        while (q < tag.size() && std::isspace(static_cast<unsigned char>(tag[q]))) ++q;
        if (q >= tag.size() || (tag[q] != '"' && tag[q] != '\'')) break;
        const char quote = tag[q];
        const size_t close = tag.find(quote, q + 1);
        if (close == std::string::npos) break;
        out[tag.substr(name_start, name_end - name_start)] = XmlUnescape(tag.substr(q + 1, close - q - 1));
        i = close + 1;
    }
    return out;
}

std::vector<PatchInfo> LoadPatches() {
    std::vector<PatchInfo> list;
    std::error_code ec;
    std::vector<fs::path> files;
    for (fs::directory_iterator it(g_app.root / L"patches", ec), end; !ec && it != end; it.increment(ec)) {
        if (it->path().extension() == L".xml") files.push_back(it->path());
    }
    std::sort(files.begin(), files.end());
    for (const auto& file : files) {
        const std::string xml = ReadText(file);
        // Files naming other games are skipped; a file without <ID> applies to any.
        bool any_id = false, ours = false;
        std::string file_title;
        for (size_t at = 0; (at = xml.find("<ID>", at)) != std::string::npos; at += 4) {
            const size_t close = xml.find("</ID>", at);
            if (close == std::string::npos) break;
            any_id = true;
            const std::string id = Trim(xml.substr(at + 4, close - at - 4));
            if (IsCtrTitle(id)) {
                ours = true;
                if (file_title.empty()) file_title = id;
            }
        }
        if (any_id && !ours) continue;
        for (size_t at = 0; (at = xml.find("<Metadata", at)) != std::string::npos; ++at) {
            const size_t close = xml.find('>', at);
            if (close == std::string::npos) break;
            const auto attr = XmlAttributes(xml.substr(at + 9, close - at - 9));
            auto get = [&](const char* k) {
                const auto it = attr.find(k);
                return it == attr.end() ? std::string() : it->second;
            };
            const std::string elf = get("AppElf");
            if (get("AppVer") != kUpdateVersion || !(elf.empty() || elf == "eboot.bin")) continue;
            PatchInfo p;
            p.name = get("Name");
            p.key = PathText(file.filename()) + "/" + p.name;
            p.author = get("Author");
            p.note = get("Note");
            p.version = get("PatchVer");
            p.title = file_title;
            std::string on = get("isEnabled");
            std::transform(on.begin(), on.end(), on.begin(), [](unsigned char c) { return char(std::tolower(c)); });
            p.default_on = on == "true";
            for (const auto& [key, ini] : kIniPatches)
                if (p.key == key) p.ini_key = ini;
            list.push_back(std::move(p));
        }
    }
    return list;
}

/// patches.json's "enabled" and "disabled" string lists (the file only holds those).
void ReadPatchConfig(std::vector<std::string>& enabled, std::vector<std::string>& disabled) {
    enabled.clear();
    disabled.clear();
    const std::string json = ReadText(g_app.root / L"patches.json");
    auto read_list = [&](const char* name, std::vector<std::string>& out) {
        size_t at = json.find(std::string("\"") + name + "\"");
        if (at == std::string::npos) return;
        at = json.find('[', at);
        const size_t end = at == std::string::npos ? at : json.find(']', at);
        if (at == std::string::npos || end == std::string::npos) return;
        for (size_t i = at + 1; i < end; ++i) {
            if (json[i] != '"') continue;
            std::string value;
            for (++i; i < end && json[i] != '"'; ++i) {
                if (json[i] == '\\' && i + 1 < end) ++i;
                value += json[i];
            }
            out.push_back(value);
        }
    };
    read_list("enabled", enabled);
    read_list("disabled", disabled);
}

void WritePatchConfig(const std::vector<std::string>& enabled, const std::vector<std::string>& disabled) {
    auto list = [](const std::vector<std::string>& items) {
        std::string out = "[";
        for (size_t i = 0; i < items.size(); ++i) {
            out += i ? ", \"" : "\"";
            for (const char c : items[i]) {
                if (c == '"' || c == '\\') out += '\\';
                out += c;
            }
            out += '"';
        }
        return out + "]";
    };
    WriteTextAtomic(g_app.root / L"patches.json",
                    "{\n  \"enabled\": " + list(enabled) + ",\n  \"disabled\": " + list(disabled) + "\n}\n");
}

// ---------------------------------------------------------------------------------------------
// UI

std::string Describe(const FolderInfo& f) {
    switch (f.kind) {
    case Kind::Empty: return T("sin elegir", "not chosen");
    case Kind::Missing: return T("la carpeta no existe", "the folder does not exist");
    case Kind::NotGame:
        return T("no tiene eboot.bin y sce_sys\\param.sfo (ni Image0 y Sc0)", "no eboot.bin and sce_sys\\param.sfo (nor Image0 and Sc0)");
    case Kind::OtherTitle: return std::string(T("es otro juego o región: ", "another game or region: ")) + f.title;
    case Kind::OtherVersion: return std::string(T("actualización ", "update ")) + f.version + T(" (se necesita la 01.21)", " (01.21 is needed)");
    case Kind::Base: return std::string(T("juego base ", "base game ")) + f.title + " v" + f.version;
    case Kind::Update: return std::string(T("actualización ", "update ")) + f.version + " (" + FormatBytes(f.bytes) + ")";
    case Kind::Complete: return std::string(f.title) + " v" + f.version + " (" + FormatBytes(f.bytes) + ")";
    }
    return {};
}

void HelpMarker(const char* text) {
    ImGui::SameLine();
    ImGui::TextDisabled("(?)");
    if (ImGui::BeginItemTooltip()) {
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 30.0f);
        ImGui::TextUnformatted(text);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

void GameFlag(const char* key, const char* label, bool fallback, const char* help = nullptr) {
    bool v = g_app.game.Flag(key, fallback);
    if (ImGui::Checkbox(label, &v)) {
        g_app.game.Set(key, v ? "1" : "0");
        SaveGameIni();
    }
    if (help) HelpMarker(help);
}

void LauncherFlag(const char* key, const char* label, bool fallback, const char* help = nullptr) {
    bool v = g_app.launcher.Flag(key, fallback);
    if (ImGui::Checkbox(label, &v)) {
        g_app.launcher.Set(key, v ? "1" : "0");
        SaveLauncher();
    }
    if (help) HelpMarker(help);
}

template <size_t N>
void ChoiceCombo(const char* label, const char* key, const Choice (&choices)[N], const char* fallback) {
    const std::string current = g_app.launcher.Get(key, fallback);
    const Choice* selected = &choices[0];
    for (const auto& c : choices)
        if (current == c.value) selected = &c;
    if (ImGui::BeginCombo(label, T(selected->es, selected->en))) {
        for (const auto& c : choices) {
            if (ImGui::Selectable(T(c.es, c.en), &c == selected)) {
                g_app.launcher.Set(key, c.value);
                SaveLauncher();
            }
        }
        ImGui::EndCombo();
    }
}

bool CreateDesktopShortcut(std::string& out_error);
bool AddToSteam(std::string& out_msg);
void DrawMenuIcon(ImDrawList* d, int id, ImVec2 c, ImU32 ink, float s);

bool PrimaryPlayButton(const char* label, ImVec2 size, bool disabled) {
    const bool pressed = ImGui::InvisibleButton("##primary_play", size);
    const ImVec2 a = ImGui::GetItemRectMin();
    const ImVec2 actual_size = ImGui::GetItemRectSize();
    const bool hovered = ImGui::IsItemHovered();
    const bool active = ImGui::IsItemActive();
    const float press_offset = active ? 2.0f : 0.0f;
    const float y0 = a.y + 2.0f + press_offset;
    const float y1 = a.y + actual_size.y - 2.0f + press_offset;
    const float cy = (y0 + y1) * 0.5f;
    const float inset = 11.0f;
    ImVec2 shape[] = {
        {a.x + inset, y0}, {a.x + actual_size.x - 22.0f, y0}, {a.x + actual_size.x - 5.0f, cy},
        {a.x + actual_size.x - 22.0f, y1}, {a.x + inset, y1}, {a.x + inset + 13.0f, cy},
    };
    ImDrawList* d = ImGui::GetWindowDrawList();
    if (!active) {
        ImVec2 shadow[6];
        for (int i = 0; i < 6; ++i) shadow[i] = ImVec2(shape[i].x, shape[i].y + 4.0f);
        d->AddConvexPolyFilled(shadow, 6, IM_COL32(0, 29, 76, disabled ? 90 : 185));
    }
    const ImU32 fill = disabled ? IM_COL32(140, 190, 210, 190)
                                : hovered ? IM_COL32(250, 255, 255, 255) : IM_COL32(224, 247, 255, 255);
    d->AddConvexPolyFilled(shape, 6, fill);
    d->AddPolyline(shape, 6, disabled ? IM_COL32(177, 215, 230, 170) : IM_COL32(255, 255, 255, 255),
                   ImDrawFlags_Closed, hovered ? 2.4f : 1.8f);
    d->AddLine({a.x + 24.0f, y0 + 5.0f}, {a.x + actual_size.x - 28.0f, y0 + 5.0f},
               disabled ? IM_COL32(255, 255, 255, 70) : IM_COL32(255, 255, 255, 170), 1.0f);
    DrawMenuIcon(d, 0, {a.x + 39.0f, cy}, disabled ? IM_COL32(81, 119, 138, 255) : IM_COL32(5, 63, 109, 255), 1.0f);
    ImFont* font = ImGui::GetFont();
    const float font_size = ImGui::GetFontSize();
    const ImVec2 text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, label);
    const ImVec2 text_pos{a.x + (actual_size.x - text_size.x) * 0.5f, cy - text_size.y * 0.5f};
    d->AddText(font, font_size, text_pos,
               disabled ? IM_COL32(81, 119, 138, 255) : IM_COL32(4, 49, 86, 255), label);
    return pressed;
}

void PlayTab() {
    App& a = g_app;
    const bool busy = a.job != Job::None;
    ImGui::SeparatorText(T("Juego", "Game"));

    const bool ready = a.game_info.kind == Kind::Complete && a.game_checked && a.game_ok;
    if (!a.python) {
        ImGui::TextColored(kRed, "%s", T("Falta Python 3: no se encontró python\\python.exe ni Python instalado.",
                                         "Python 3 is missing: no python\\python.exe and no installed Python."));
    }
    if (a.game_info.kind == Kind::Complete) {
        if (a.job == Job::Merge) {
            const size_t total = a.merge_total, done = a.merge_done;
            char overlay[64];
            std::snprintf(overlay, sizeof overlay, "%zu / %zu", done, total);
            ImGui::TextColored(kYellow, "%s", T("Preparando el juego...", "Preparing the game..."));
            ImGui::ProgressBar(total ? float(done) / float(total) : 0.0f, ImVec2(-FLT_MIN, 0), overlay);
        } else if (a.game_info.split) {
            ImGui::PushTextWrapPos(0.0f);
            ImGui::TextColored(kYellow, "%s",
                               T("Esta carpeta tiene el formato de PS4 PKG Tool (Image0 y Sc0). Hay que prepararla: "
                                 "se crea una carpeta nueva con enlaces duros, sin tocar la tuya.",
                                 "This folder has the PS4 PKG Tool layout (Image0 and Sc0). It needs preparing: a "
                                 "new folder of hard links is created, yours is not changed."));
            ImGui::PopTextWrapPos();
            ImGui::BeginDisabled(busy);
            if (ImGui::Button(T("Preparar el juego", "Prepare the game"))) StartMerge({a.game_dir});
            ImGui::EndDisabled();
            ImGui::SameLine();
            ImGui::TextColored(kGrey, "%s %s", T("se crea", "creates"), PathText(MergeTarget(a.game_dir)).c_str());
        } else if (!a.game_checked) {
            ImGui::TextColored(kYellow, "%s", T("Comprobando el juego...", "Checking the game..."));
        } else if (a.game_ok) {
            ImGui::TextColored(kGreen, "%s %s", T("Listo:", "Ready:"), Describe(a.game_info).c_str());
            if (a.game.Flag("online", true)) {
                std::string srv = a.game.Get("online_server", "octr.ryu7w7.xyz");
                if (srv.empty()) srv = "octr.ryu7w7.xyz";
                const std::string nick = CurrentNick().empty() ? std::string("-") : CurrentNick();
                const std::string friends = a.game.Get("online_friends", "");
                if (!friends.empty()) {
                    ImGui::TextColored(ImVec4(0.35f, 0.75f, 1.0f, 1.0f), "[Online RyuNET] %s: %s  |  %s: %s  |  %s: %s",
                                       T("Servidor", "Server"), srv.c_str(),
                                       T("Apodo", "Nick"), nick.c_str(),
                                       T("Amigos", "Friends"), friends.c_str());
                } else {
                    ImGui::TextColored(ImVec4(0.35f, 0.75f, 1.0f, 1.0f), "[Online RyuNET] %s: %s  |  %s: %s",
                                       T("Servidor", "Server"), srv.c_str(),
                                       T("Apodo", "Nick"), nick.c_str());
                }
                {
                    ImVec4 nat_color;
                    const std::string nat = NatLabel(Trim(srv), nat_color);
                    ImGui::SameLine(0.0f, 0.0f);
                    ImGui::TextColored(ImVec4(0.35f, 0.75f, 1.0f, 1.0f), "  |  ");
                    ImGui::SameLine(0.0f, 0.0f);
                    ImGui::TextColored(nat_color, "%s", nat.c_str());
                    if (ImGui::IsItemHovered())
                        ImGui::SetTooltip("%s", T("Si otros jugadores pueden conectarse directamente contigo. Más detalles en la "
                                                  "pestaña Online. Tu IP no se muestra.",
                                                  "Whether other players can connect to you directly. Details in the Online "
                                                  "tab. Your IP is not shown."));
                }
                if (const char* problem = NickProblem(CurrentNick()))
                    ImGui::TextColored(kYellow, "%s %s", problem, T("Se te pedirá al pulsar Jugar.", "You will be asked when you press Play."));
            } else {
                ImGui::TextColored(kGrey, "[Online] %s", T("Modo offline (actívalo en la pestaña Online)", "Offline mode (enable it in the Online tab)"));
            }
        } else {
            ImGui::TextColored(kRed, "%s", T("Estos archivos no sirven:", "These files do not work:"));
            ImGui::PushTextWrapPos(0.0f);
            ImGui::TextUnformatted(a.check_message.c_str());
            ImGui::PopTextWrapPos();
        }
        ImGui::TextColored(kGrey, "%s", PathText(a.game_dir).c_str());
        if (ImGui::Button(T("Cambiar carpeta del juego...", "Change game folder...")) && !busy && !a.game_running) {
            ChooseFolder(a.game_dir, a.game_info, L"CUSA13795 + 1.21");
        }
    } else {
        if (a.game_info.kind == Kind::Update) {
            ImGui::TextColored(kRed, "%s: %s", PathText(a.game_dir).c_str(),
                               T("solo tiene la actualización 1.21, falta el juego base",
                                 "only has the 1.21 update, the base game is missing"));
        } else if (a.game_info.kind == Kind::Base) {
            ImGui::TextColored(kRed, "%s: %s", PathText(a.game_dir).c_str(),
                               T("es el juego base sin la actualización 1.21", "is the base game without the 1.21 update"));
        } else if (a.game_info.kind != Kind::Empty) {
            ImGui::TextColored(kRed, "%s: %s", PathText(a.game_dir).c_str(), Describe(a.game_info).c_str());
        }
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextUnformatted(T("Necesitas tu propio dump de PS4: el juego base (CUSA14876 en Europa, CUSA13795 en "
                                 "América) y la actualización 1.21. Si ya los tienes juntos en una carpeta, elige esa.",
                                 "You need your own PS4 dump: the base game (CUSA14876 in Europe, CUSA13795 in the "
                                 "Americas) and the 1.21 update. If they are already merged in one folder, choose that one."));
        ImGui::PopTextWrapPos();
        ImGui::Spacing();
        if (ImGui::BeginTable("setup", 3, ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("what", ImGuiTableColumnFlags_WidthFixed);
            ImGui::TableSetupColumn("state", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupColumn("button", ImGuiTableColumnFlags_WidthFixed);
            auto row = [&](const char* what, fs::path& slot, FolderInfo& info, Kind good, const wchar_t* title, const char* id) {
                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                ImGui::TextUnformatted(what);
                ImGui::TableNextColumn();
                const bool ok = info.kind == good;
                ImGui::TextColored(ok ? kGreen : (info.kind == Kind::Empty ? kGrey : kRed), "%s", Describe(info).c_str());
                if (!slot.empty()) ImGui::TextColored(kGrey, "%s", PathText(slot).c_str());
                ImGui::TableNextColumn();
                ImGui::PushID(id);
                if (ImGui::Button(T("Elegir...", "Choose...")) && !busy) ChooseFolder(slot, info, title);
                ImGui::PopID();
            };
            row(T("Juego base", "Base game"), a.base_dir, a.base_info, Kind::Base, L"CUSA13795", "base");
            row(T("Actualización 1.21", "Update 1.21"), a.update_dir, a.update_info, Kind::Update, L"CUSA13795-patch", "update");
            ImGui::EndTable();
        }
        const bool can_merge = a.base_info.kind == Kind::Base && a.update_info.kind == Kind::Update;
        if (a.job == Job::Merge) {
            const size_t total = a.merge_total, done = a.merge_done;
            const float fraction = total ? float(done) / float(total) : 0.0f;
            char overlay[64];
            std::snprintf(overlay, sizeof overlay, "%zu / %zu", done, total);
            ImGui::ProgressBar(fraction, ImVec2(-FLT_MIN, 0), overlay);
        } else {
            ImGui::BeginDisabled(!can_merge || busy);
            if (ImGui::Button(T("Preparar el juego (base + 1.21)", "Prepare the game (base + 1.21)"))) {
                StartMerge({a.base_dir, a.update_dir});
            }
            ImGui::EndDisabled();
            if (can_merge) {
                ImGui::SameLine();
                ImGui::TextColored(kGrey, "%s %s", T("se crea", "creates"),
                                   PathText(MergeTarget(a.base_dir)).c_str());
            }
            HelpMarker(T("Une la actualización con el juego base en una carpeta nueva usando enlaces duros: no ocupa "
                         "espacio extra ni cambia tus carpetas originales (si están en discos distintos, se copia).",
                         "Merges the update over the base game into a new folder with hard links: no extra disk "
                         "space and your original folders are not changed (copied if they are on different drives)."));
        }
        ImGui::Spacing();
        if (ImGui::Button(T("Ya tengo el juego preparado...", "I already have the merged game...")) && !busy) {
            ChooseFolder(a.game_dir, a.game_info, L"CUSA13795-1.21");
        }
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();
    const float play_height = ImGui::GetFontSize() * 3.0f;
    if (a.game_running) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.50f, 0.14f, 0.22f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.68f, 0.20f, 0.28f, 1.0f));
        if (ImGui::Button(T("Cerrar el juego", "Stop the game"), ImVec2(-FLT_MIN, play_height))) StopGame();
        ImGui::PopStyleColor(2);
    } else {
        ImGui::BeginDisabled(!ready || busy || !a.python);
        ImGui::PushFont(g_ctr_font, ImGui::GetStyle().FontSizeBase * 1.5f);
        if (PrimaryPlayButton(T("JUGAR", "PLAY"), ImVec2(-FLT_MIN, play_height),
                              !ready || busy || !a.python)) PressPlay();
        ImGui::PopFont();
        ImGui::EndDisabled();
    }

    if (ready && !a.game_running) {
        ImGui::Spacing();
        if (ImGui::Button(T("Crear acceso directo en el Escritorio", "Create Desktop Shortcut"))) {
            std::string err;
            if (CreateDesktopShortcut(err)) {
                a.notice = T("Acceso directo creado en el Escritorio con éxito (inicia directo sin el launcher).",
                             "Desktop shortcut created successfully (launches directly without launcher).");
            } else {
                a.notice = err;
            }
        }
    }

    std::string status;
    {
        std::scoped_lock lock{a.mutex};
        status = a.last_status;
    }
    if (a.game_running) {
        ImGui::TextColored(kYellow, "%s", T("El juego está abierto. El primer arranque compila shaders y tarda un poco.",
                                            "The game is running. The first start compiles shaders and takes a while."));
    } else if (a.show_exit) {
        if (a.exit_code == 0 || a.stopped) ImGui::TextColored(kGrey, "%s", T("El juego se cerró.", "The game was closed."));
        else ImGui::TextColored(kRed, T("El juego se cerró con un error (código %lu). Mira el registro abajo o en last_run.log.",
                                        "The game ended with an error (code %lu). See the log below or last_run.log."),
                                (unsigned long)a.exit_code);
    }
    if (!status.empty()) ImGui::TextColored(kGrey, "%s", status.c_str());

    ImGui::Spacing();
    if (ImGui::CollapsingHeader(T("Registro", "Log"), ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::BeginChild("log", ImVec2(0, 0), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar);
        {
            std::scoped_lock lock{a.mutex};
            ImGuiListClipper clipper;
            clipper.Begin(int(a.log.size()));
            while (clipper.Step())
                for (int i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i) ImGui::TextUnformatted(a.log[size_t(i)].c_str());
        }
        if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 4.0f) ImGui::SetScrollHereY(1.0f);
        ImGui::EndChild();
    }
}

// bbport.ini render_res: the scene size (scripts/patches.py, run.py; docs/sacredfire/13-resolution.md).
struct RenderRes {
    const char* value;
    const char* es;
    const char* en;
};
constexpr RenderRes kRenderRes[] = {
    {"480", "480p (854 x 480, PCs muy modestos)", "480p (854 x 480, very low-end PCs)"},
    {"720", "720p (1280 x 720, PCs modestos)", "720p (1280 x 720, low-end PCs)"},
    {"1080", "1080p (1920 x 1080)", "1080p (1920 x 1080)"},
    {"1440", "1440p (2560 x 1440, PS4 Pro)", "1440p (2560 x 1440, PS4 Pro)"},
    {"1620", "1620p (2880 x 1620)", "1620p (2880 x 1620)"},
    {"2160", "4K (3840 x 2160)", "4K (3840 x 2160)"},
};

// The render_res in effect: the setting, or for older settings the Pro mode and 1080p patch.
std::string EffectiveRenderRes() {
    const std::string v = g_app.game.Get("render_res");
    for (const auto& r : kRenderRes)
        if (v == r.value) return v;
    return "1080";
}

/// bbport.ini temporal (the upscaler), with the keys of v0.3 test builds before it: fsr3=1, fsr1=0.
std::string GameTemporal() {
    const Ini& game = g_app.game;
    const std::string value = game.Get("temporal");
    for (const char* known : {"off", "fsr1", "fsr3", "dlss"})
        if (value == known) return value;
    if (game.Flag("fsr3", false)) return "fsr3";
    return game.Flag("fsr1", true) ? "fsr1" : "off";
}

/// A combo over a bbport.ini key; true when the player picked another value (already set).
template <size_t N>
bool GameChoiceCombo(const char* label, const char* key, const Choice (&choices)[N], const char* fallback,
                     float width_em) {
    App& a = g_app;
    const std::string current = a.game.Get(key, fallback);
    const Choice* selected = &choices[0];
    for (const auto& c : choices)
        if (current == c.value) selected = &c;
    bool changed = false;
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * width_em);
    if (ImGui::BeginCombo(label, T(selected->es, selected->en))) {
        for (const auto& c : choices) {
            if (ImGui::Selectable(T(c.es, c.en), &c == selected) && &c != selected) {
                a.game.Set(key, c.value);
                changed = true;
            }
        }
        ImGui::EndCombo();
    }
    return changed;
}

void RenderResCombo() {
    App& a = g_app;
    const std::string current = EffectiveRenderRes();
    const RenderRes* selected = &kRenderRes[0];
    for (const auto& r : kRenderRes)
        if (current == r.value) selected = &r;
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 16.0f);
    if (ImGui::BeginCombo(T("Resolución interna", "Internal resolution"), T(selected->es, selected->en))) {
        for (const auto& r : kRenderRes) {
            if (ImGui::Selectable(T(r.es, r.en), &r == selected)) {
                a.game.Set("render_res", r.value);
                SaveGameIni();
            }
        }
        ImGui::EndCombo();
    }
    HelpMarker(T("El tamaño al que el juego dibuja la escena 3D. Por encima de 1080p usa el modo PS4 Pro del juego "
                 "y la imagen sale en 4K: en una pantalla 1080p eso quita los dientes de sierra. "
                 "4K necesita una GPU potente (una RTX 3070 va a unos 100 FPS); 720p y 480p alivian PCs modestos "
                 "(la imagen sale a 1080p).",
                 "The size the game draws its 3D scene at. Above 1080p it uses the game's PS4 Pro path (turned "
                 "on automatically) and the picture is output at 4K: on a 1080p screen that removes jagged "
                 "edges. 4K needs a strong GPU (an RTX 3070 runs it at about 100 FPS); 720p and 480p help low-end "
                 "PCs (the picture is output at 1080p)."));
}

void SettingsTab() {
    App& a = g_app;
    ImGui::TextColored(kGrey, "%s", T("Se aplican al pulsar Jugar. El menú del juego (Insert o L3+R3) cambia los mismos ajustes.",
                                      "Applied when you press Play. The in-game menu (Insert or L3+R3) changes the same settings."));

    ImGui::SeparatorText(T("Rendimiento", "Performance"));
    {
        int limit = a.game.Int("fps_limit", 60);
        auto name = [](int v) -> std::string {
            if (v == 0) return T("Sin límite", "No limit");
            return std::to_string(v) + " FPS";
        };
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 12.0f);
        if (ImGui::BeginCombo(T("Límite de FPS", "FPS limit"), name(limit).c_str())) {
            for (int v : kFpsLimits) {
                if (ImGui::Selectable(name(v).c_str(), v == limit)) {
                    a.game.Set("fps_limit", std::to_string(v));
                    SaveGameIni();
                }
            }
            ImGui::EndCombo();
        }
        HelpMarker(T("Con el parche de 60 FPS el juego va tan rápido como permita tu PC. En una pantalla de 144 Hz sin "
                     "G-Sync/FreeSync, 72 reparte los fotogramas de forma pareja.",
                     "With the 60 FPS patch the game runs as fast as your PC allows. On a 144 Hz screen without "
                     "G-Sync/FreeSync, 72 divides the refresh evenly."));
    }
    GameFlag("async_pipelines", T("Compilar shaders en segundo plano (experimental)", "Compile shaders in the background (experimental)"), false,
             T("Menos tirones la primera vez que aparece un efecto; a veces un efecto tarda un fotograma en verse.",
               "Fewer hitches when an effect is first seen; an effect may show up a frame late."));

    ImGui::SeparatorText(T("Pantalla", "Display"));
    GameFlag("msaa", T("MSAA del juego (2x)", "Game MSAA (2x)"), false,
             T("El antialiasing 2x de la PS4. Desactivado por defecto: en PC dibuja líneas punteadas en el "
               "cielo y en los rayos de luz. A resoluciones altas o con FSR/DLSS casi no se nota. "
               "Requiere reiniciar.",
               "The PS4's 2x anti-aliasing. Off by default: on PC it draws dotted lines in the sky and "
               "in light shafts. At high internal resolutions or with FSR/DLSS it is barely missed. "
               "Needs a restart."));
    const std::string temporal = GameTemporal();
    const bool dlss_sized = temporal == "dlss" && a.game.Get("dlss_quality", "auto") != "auto";
    ImGui::BeginDisabled(dlss_sized);
    RenderResCombo();
    ImGui::EndDisabled();
    if (dlss_sized) {
        ImGui::SameLine();
        ImGui::TextColored(kGrey, "%s", T("(la decide la calidad de DLSS)", "(set by the DLSS quality)"));
    }
    {
        // temporal=off|fsr1|fsr3|dlss (bbport.ini): one upscaler at a time.
        static constexpr Choice kTemporal[] = {{"Desactivado", "Off", "off"},
                                               {"AMD FSR 1", "AMD FSR 1", "fsr1"},
                                               {"AMD FSR 3 (experimental)", "AMD FSR 3 (experimental)", "fsr3"},
                                               {"NVIDIA DLSS (experimental)", "NVIDIA DLSS (experimental)", "dlss"}};
        if (GameChoiceCombo(T("Escalado", "Upscaling"), "temporal", kTemporal, temporal.c_str(), 16.0f)) {
            a.game.Erase("fsr1");
            a.game.Erase("fsr3");
            SaveGameIni();
        }
        HelpMarker(T("FSR 1 agranda una escena más pequeña con bordes más nítidos que el estirado simple del juego. "
                     "FSR 3 y DLSS reconstruyen el detalle a lo largo de varios cuadros con la profundidad y el movimiento "
                     "del juego, y a la misma resolución también suavizan los bordes. DLSS necesita una tarjeta NVIDIA "
                     "RTX (si no, se usa FSR 3). Experimentales: si ves estelas o parpadeos, cambia a FSR 1.",
                     "FSR 1 enlarges a smaller scene with sharper edges than the game's plain stretch. FSR 3 and DLSS "
                     "rebuild detail over several frames from the game's depth and motion, and smooth edges even at the "
                     "same resolution. DLSS needs an NVIDIA RTX card (FSR 3 runs otherwise). Experimental: switch to "
                     "FSR 1 if you see trails or shimmering."));
    }
    if (temporal == "dlss") {
        static constexpr Choice kQuality[] = {
            {"Automática (resolución interna)", "Auto (internal resolution)", "auto"},
            {"DLAA (nativa)", "DLAA (native)", "dlaa"},
            {"Calidad", "Quality", "quality"},
            {"Equilibrado", "Balanced", "balanced"},
            {"Rendimiento", "Performance", "performance"},
            {"Ultra rendimiento", "Ultra Performance", "ultra_performance"}};
        if (GameChoiceCombo(T("Calidad de DLSS", "DLSS quality"), "dlss_quality", kQuality, "auto", 16.0f)) SaveGameIni();
        HelpMarker(T("Automática usa la resolución interna de arriba. Las demás dibujan la escena a la proporción de NVIDIA "
                     "respecto a la salida de DLSS: Calidad 67 %, Equilibrado 58 %, Rendimiento 50 %, Ultra rendimiento "
                     "33 %, DLAA 100 %.",
                     "Auto uses the internal resolution above. The others draw the scene at NVIDIA's share of the DLSS "
                     "output: Quality 67%, Balanced 58%, Performance 50%, Ultra Performance 33%, DLAA 100%."));
        if (a.game.Get("dlss_quality", "auto") != "auto") {
            static constexpr Choice kOutput[] = {{"1920 x 1080", "1920 x 1080", "1080"},
                                                 {"3840 x 2160 (4K)", "3840 x 2160 (4K)", "2160"}};
            if (GameChoiceCombo(T("Salida de DLSS", "DLSS output"), "dlss_output", kOutput, "1080", 16.0f)) SaveGameIni();
        }
        static constexpr Choice kModel[] = {{"Transformer (recomendado)", "Transformer (recommended)", "transformer"},
                                            {"CNN", "CNN", "cnn"}};
        if (GameChoiceCombo(T("Modelo de DLSS", "DLSS model"), "dlss_model", kModel, "transformer", 16.0f)) SaveGameIni();
        HelpMarker(T("Transformer: el modelo actual de NVIDIA (DLSS 4), más nítido y estable, algo más pesado. CNN: el "
                     "modelo anterior (preset E), más ligero; NVIDIA lo marca como obsoleto.",
                     "Transformer: NVIDIA's current model (DLSS 4), sharper and steadier, a little heavier. CNN: the "
                     "older model (preset E), lighter; NVIDIA marks it deprecated."));
    }
    if (temporal == "fsr3") {
        float sharp = float(std::atof(a.game.Get("fsr3_sharpness", "0.30").c_str()));
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 16.0f);
        if (ImGui::SliderFloat(T("Nitidez de FSR 3", "FSR 3 sharpness"), &sharp, 0.0f, 1.0f, "%.2f")) {
            char text[16];
            std::snprintf(text, sizeof text, "%.2f", sharp);
            a.game.Set("fsr3_sharpness", text);
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) SaveGameIni();
    }
    GameFlag("fullscreen", T("Pantalla completa", "Fullscreen"), false);
    GameFlag("borderless", T("Ventana sin bordes", "Borderless window"), false,
             T("Quita los bordes de la ventana en modo ventana.", "Removes window borders in windowed mode."));
    GameFlag("show_fps", T("Contador de FPS en la esquina", "FPS counter in the corner"), false);
    {
        std::scoped_lock lock{a.mutex};
        const std::string current = a.launcher.Get("display");
        std::string preview = T("Principal", "Primary");
        for (const auto& [value, label] : a.displays)
            if (value == current) preview = label;
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 22.0f);
        if (ImGui::BeginCombo(T("Monitor", "Monitor"), preview.c_str())) {
            if (ImGui::Selectable(T("Principal", "Primary"), current.empty())) {
                a.launcher.Set("display", "");
                SaveLauncher();
            }
            for (const auto& [value, label] : a.displays) {
                if (ImGui::Selectable(label.c_str(), value == current)) {
                    a.launcher.Set("display", value);
                    SaveLauncher();
                }
            }
            ImGui::EndCombo();
        }
    }
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 14.0f);
    ChoiceCombo(T("Presentación", "Presentation"), "present_mode", kPresentModes, "Mailbox");

    ImGui::SeparatorText(T("Sonido", "Sound"));
    {
        int volume = std::clamp(a.game.Int("volume", 100), 0, 200);
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 16.0f);
        if (ImGui::SliderInt(T("Volumen del juego", "Game volume"), &volume, 0, 200, "%d%%")) {
            a.game.Set("volume", std::to_string(volume));
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) SaveGameIni();
        HelpMarker(T("100% es el nivel al que se mezcló el juego. Por encima, los picos más fuertes se suavizan en vez "
                     "de distorsionar. Mientras juegas también se cambia en el menú del juego (Insert o L3+R3).",
                     "100% is the level the game was mixed at. Above it, the loudest peaks are rounded off instead of "
                     "distorting. While you play it can also be changed in the in-game menu (Insert or L3+R3)."));
    }

    ImGui::SeparatorText(T("Mando", "Controller"));
    {
        std::scoped_lock lock{a.mutex};
        const std::string current = a.launcher.Get("gamepad");
        std::string preview = T("El primero conectado", "First connected");
        bool listed = current.empty();
        for (const auto& [guid, name] : a.gamepads)
            if (guid == current) {
                preview = name;
                listed = true;
            }
        if (!listed) preview = a.launcher.Get("gamepad_name", current) + T(" (no conectado)", " (not connected)");
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 22.0f);
        if (ImGui::BeginCombo(T("Mando", "Controller"), preview.c_str())) {
            if (ImGui::Selectable(T("El primero conectado", "First connected"), current.empty())) {
                a.launcher.Set("gamepad", "");
                a.launcher.Set("gamepad_name", "");
                SaveLauncher();
            }
            for (const auto& [guid, name] : a.gamepads) {
                ImGui::PushID(guid.c_str());
                if (ImGui::Selectable(name.c_str(), guid == current)) {
                    a.launcher.Set("gamepad", guid);
                    a.launcher.Set("gamepad_name", name);
                    SaveLauncher();
                }
                ImGui::PopID();
            }
            ImGui::EndCombo();
        }
    }
    ImGui::SameLine();
    ImGui::BeginDisabled(!a.probe_done && a.probe.joinable());
    if (ImGui::Button(T("Buscar mandos", "Refresh"))) {
        if (a.probe.joinable()) a.probe.join();
        StartProbe();
    }
    ImGui::EndDisabled();
    {
        // bbport.ini port.N=keyboard (N 2..4): that split-screen player plays on the keyboard and
        // player 1 on the controller alone (src/runtime_pad.c). None: the keyboard drives player 1 too.
        const auto port_key = [](int n) { return "port." + std::to_string(n); };
        int current = 1;
        for (int n = 2; n <= 4; ++n)
            if (Lower(Trim(a.game.Get(port_key(n)))) == "keyboard") current = n;
        const auto name = [](int n) {
            return n == 1 ? std::string(T("Jugador 1 (junto al mando)", "Player 1 (with the controller)"))
                          : std::string(T("Jugador ", "Player ")) + std::to_string(n);
        };
        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 16.0f);
        if (ImGui::BeginCombo(T("Teclado", "Keyboard"), name(current).c_str())) {
            for (int n = 1; n <= 4; ++n) {
                if (!ImGui::Selectable(name(n).c_str(), n == current) || n == current) continue;
                for (int k = 2; k <= 4; ++k)
                    if (Lower(Trim(a.game.Get(port_key(k)))) == "keyboard") a.game.Set(port_key(k), "");
                if (n > 1) a.game.Set(port_key(n), "keyboard");
                SaveGameIni();
            }
            ImGui::EndCombo();
        }
        HelpMarker(T("Para jugar dos en pantalla dividida, uno con teclado y otro con mando, elige Jugador 2: el mando "
                     "queda para el jugador 1 y el teclado para el 2 (Espacio es X). Si juegas solo con teclado, déjalo "
                     "en Jugador 1. También se cambia en el menú del juego (Insert o L3+R3).",
                     "For two players in split screen, one on the keyboard and one on a controller, choose Player 2: "
                     "the controller stays player 1 and the keyboard plays player 2 (Space is Cross). If you play on "
                     "the keyboard alone, leave it on Player 1. The in-game menu (Insert or L3+R3) changes it too."));
    }
    ImGui::TextColored(kGrey, "%s", T("Más mandos para la pantalla dividida: menú del juego (Insert o L3+R3), Controllers.",
                                      "More controllers for split screen: in-game menu (Insert or L3+R3), Controllers."));

    ImGui::SeparatorText(T("Consola", "Console"));
    if (a.launcher.Get("language") != GameLanguage()) a.launcher.Set("language", GameLanguage());
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 12.0f);
    if (IsEuGame()) {
        ChoiceCombo(T("Idioma del juego", "Game language"), "language", kGameLanguagesEU, DefaultGameLanguage());
        HelpMarker(T("Los idiomas que trae la versión europea (CUSA14876): inglés, español de España, francés, alemán, "
                     "italiano y árabe. La lista cambia sola según la versión del juego que elijas. Se aplica al "
                     "pulsar Jugar.",
                     "The languages of the European edition (CUSA14876): English, Spain's Spanish, French, German, "
                     "Italian and Arabic. The list follows the edition of the game you choose. Applied when you "
                     "press Play."));
    } else {
        ChoiceCombo(T("Idioma del juego", "Game language"), "language", kGameLanguages, DefaultGameLanguage());
        HelpMarker(T("Los idiomas que trae la versión de América (CUSA13795): inglés, español latinoamericano, francés "
                     "y portugués de Brasil. La lista cambia sola según la versión del juego que elijas (la europea "
                     "trae español de España, alemán, italiano y árabe). Se aplica al pulsar Jugar.",
                     "The languages of the Americas edition (CUSA13795): English, Latin American Spanish, French and "
                     "Brazilian Portuguese. The list follows the edition of the game you choose (the European one has "
                     "Spain's Spanish, German, Italian and Arabic). Applied when you press Play."));
    }

    ImGui::SeparatorText(T("Ventana y Launcher", "Window and Launcher"));
    LauncherFlag("hide_on_play", T("Ocultar ventana del launcher mientras se juega", "Hide launcher window while playing"), false,
                 T("Oculta completamente la ventana del launcher mientras juegas y la restaura automáticamente al salir.",
                   "Hides the launcher window completely while playing and restores it automatically when exiting."));
    LauncherFlag("close_on_play", T("Cerrar launcher tras jugar", "Close launcher after playing"), false,
                 T("Cierra el launcher por completo una vez que sales del juego.",
                   "Closes the launcher completely once you exit the game."));
}

/// Linking the nickname to the player's Discord account, so that a reinstall or another PC
/// recovers it. The browser half is discord_link.cpp; the server trades the code for the
/// account (ryunet-demonware-ctr/server/discord_link.go).
struct DiscordLinkState {
    std::mutex mutex;
    bool busy = false;
    bool error = false;
    std::string message;     // the last outcome, under the buttons
    std::string other_nick;  // "other_nick": the nickname this Discord account already has
    std::string recovered;   // a recovered nickname for the UI thread to put in the field
};
DiscordLinkState g_discord_link;

/// Link the current nickname, unlink it, or recover the Discord account's own nickname (for a
/// reinstalled launcher that does not know it any more).
enum class DiscordLinkMode { Link, Unlink, Recover };

void StartDiscordLink(DiscordLinkMode mode) {
    const bool unlink = mode == DiscordLinkMode::Unlink;
    App& a = g_app;
    const std::string server = Trim(a.game.Get("online_server", "octr.ryu7w7.xyz"));
    const std::string nick = mode == DiscordLinkMode::Recover ? std::string() : CurrentNick();
    const std::string app_id = DiscordAppId();
    {
        std::scoped_lock lock{g_discord_link.mutex};
        if (g_discord_link.busy) return;
        g_discord_link.busy = true;
        g_discord_link.error = false;
        g_discord_link.message.clear();
        g_discord_link.other_nick.clear();
    }
    std::thread([server, nick, app_id, unlink] {
        std::string message, other, recovered;
        bool error = true;
        const auto form = [](const char* key, const std::string& value) {
            return std::string(key) + "=" + DiscordLink::FormEncode(value);
        };
        if (unlink) {
            const std::string body = HttpRequest(server, L"POST", L"/ryunet/discord/unlink", form("nick", nick), 10000);
            if (JsonBool(body, "unlinked")) {
                error = false;
                message = T("Apodo desvinculado de Discord.", "Nickname unlinked from Discord.");
            } else {
                message = T("No se pudo desvincular.", "Could not unlink.");
            }
        } else {
            const DiscordLink::Result auth = DiscordLink::Authorize(app_id, 180, g_spanish);
            if (!auth.ok) {
                message = auth.error == "denied"  ? T("Cancelaste la autorización en Discord.", "You cancelled the authorization in Discord.")
                          : auth.error == "busy"  ? T("Los puertos 53134 a 53136 están ocupados: cierra otros launchers abiertos.",
                                                      "Ports 53134 to 53136 are in use: close other open launchers.")
                          : auth.error == "timeout" ? T("La autorización de Discord no llegó a tiempo (3 minutos).",
                                                        "Discord's authorization did not arrive in time (3 minutes).")
                                                    : T("No se pudo autorizar con Discord.", "Could not authorize with Discord.");
            } else {
                const std::string body =
                    HttpRequest(server, L"POST", L"/ryunet/discord/link",
                                form("nick", nick) + "&" + form("code", auth.code) + "&" + form("redirect_uri", auth.redirect_uri), 25000);
                const std::string status = JsonField(body, "status"), account = JsonField(body, "discord");
                if (status == "linked") {
                    error = false;
                    message = Format(T("Listo: %s queda vinculado a tu cuenta de Discord %s. Si reinstalas o cambias de PC, "
                                       "pulsa Recuperar con Discord.",
                                       "Done: %s is linked to your Discord account %s. If you reinstall or change PC, "
                                       "press Recover with Discord."),
                                     nick, account);
                } else if (status == "recovered") {
                    error = false;
                    recovered = nick.empty() ? JsonField(body, "nick") : nick;
                    message = Format(T("Recuperado: %s vuelve a ser tuyo en esta instalación (Discord: %s).",
                                       "Recovered: %s is yours again on this installation (Discord: %s)."),
                                     recovered, account);
                } else if (status == "own_nick") {
                    error = false;
                    recovered = JsonField(body, "nick");
                    message = Format(T("Esta instalación ya tenía el apodo %s, sin vincular a Discord. Ya está puesto: pulsa "
                                       "Vincular con Discord para poder recuperarlo en cualquier PC.",
                                       "This installation already had the nickname %s, not linked to Discord. It is filled "
                                       "in: press Link with Discord to recover it on any PC."),
                                     recovered);
                } else if (status == "no_nick") {
                    message = Format(T("Tu cuenta de Discord %s no tiene ningún apodo vinculado en este servidor: escribe "
                                       "uno y pulsa Vincular con Discord.",
                                       "Your Discord account %s has no nickname linked on this server: type one and "
                                       "press Link with Discord."),
                                     account);
                } else if (status == "other_nick") {
                    other = JsonField(body, "nick");
                    message = Format(T("Tu cuenta de Discord ya tiene el apodo %s: cada cuenta tiene uno.",
                                       "Your Discord account already has the nickname %s: one per account."),
                                     other);
                } else if (status == "taken") {
                    message = T("Ese apodo es de otra persona o de otra cuenta de Discord.",
                                "That nickname belongs to someone else or to another Discord account.");
                } else if (status == "invalid" || status == "reserved") {
                    message = T("El servidor no aceptó la solicitud.", "The server did not accept the request.");
                } else if (body.empty()) {
                    message = T("No se pudo contactar con el servidor.", "Could not reach the server.");
                } else {
                    message = T("El servidor no pudo confirmar la cuenta con Discord. Prueba otra vez.",
                                "The server could not confirm the account with Discord. Try again.");
                }
            }
        }
        {
            std::scoped_lock lock{g_discord_link.mutex};
            g_discord_link.busy = false;
            g_discord_link.error = error;
            g_discord_link.message = message;
            g_discord_link.other_nick = other;
            g_discord_link.recovered = recovered;
        }
        std::scoped_lock lock{g_nick_check.mutex};  // ask the server for the new state
        g_nick_check.results.clear();
    }).detach();
}

/// The running authorization or the last outcome, with "Use <nickname>" when Discord named one.
void DiscordLinkStatusLines() {
    App& a = g_app;
    bool busy, error;
    std::string message, other;
    {
        std::scoped_lock lock{g_discord_link.mutex};
        busy = g_discord_link.busy;
        error = g_discord_link.error;
        message = g_discord_link.message;
        other = g_discord_link.other_nick;
    }
    if (busy) {
        ImGui::TextColored(kGrey, "%s", T("Autoriza tu cuenta en la pestaña de Discord que se abrió en el navegador...",
                                          "Authorize your account in the Discord tab that opened in the browser..."));
        return;
    }
    if (message.empty()) return;
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextColored(error ? kYellow : kGreen, "%s", message.c_str());
    ImGui::PopTextWrapPos();
    if (!other.empty() && ImGui::SmallButton(Format(T("Usar %s", "Use %s"), other).c_str())) {
        std::snprintf(a.online_name_buf, sizeof a.online_name_buf, "%s", other.c_str());
        a.game.Set("online_name", a.online_name_buf);
        a.game.Set("user_name", a.online_name_buf);
        SaveGameIni();
        std::scoped_lock lock{g_discord_link.mutex};
        g_discord_link.message.clear();
        g_discord_link.other_nick.clear();
    }
}

/// With no usable nickname yet (a reinstall, another PC): recover the one linked to Discord.
void DiscordRecoverOffer() {
    if (!DiscordLinkAvailable()) return;
    bool busy;
    {
        std::scoped_lock lock{g_discord_link.mutex};
        busy = g_discord_link.busy;
    }
    ImGui::BeginDisabled(busy);
    if (ImGui::Button(T("Recuperar mi apodo con Discord", "Recover my nickname with Discord")))
        StartDiscordLink(DiscordLinkMode::Recover);
    ImGui::EndDisabled();
    HelpMarker(T("¿Reinstalaste el juego o cambiaste de PC y tu apodo estaba vinculado a Discord? Autoriza la misma "
                 "cuenta de Discord y el launcher pondrá tu apodo, aunque no lo recuerdes.",
                 "Did you reinstall the game or change PC, and your nickname was linked to Discord? Authorize the "
                 "same Discord account and the launcher fills in your nickname, even if you do not remember it."));
    DiscordLinkStatusLines();
}

/// The recovered nickname, put in the field by the UI thread (PollJobs).
void ApplyRecoveredNick() {
    App& a = g_app;
    std::string nick;
    {
        std::scoped_lock lock{g_discord_link.mutex};
        nick.swap(g_discord_link.recovered);
    }
    if (nick.empty() || NickProblem(nick)) return;
    std::snprintf(a.online_name_buf, sizeof a.online_name_buf, "%s", nick.c_str());
    a.game.Set("online_name", a.online_name_buf);
    a.game.Set("user_name", a.online_name_buf);
    SaveGameIni();
}

/// Under the nickname: its Discord account, and Link / Recover / Unlink.
void DiscordAccountSection() {
    if (NickProblem(CurrentNick())) {
        DiscordRecoverOffer();
        return;
    }
    const NickCheck::Result info = NickInfo();
    bool busy;
    std::string message;
    {
        std::scoped_lock lock{g_discord_link.mutex};
        busy = g_discord_link.busy;
        message = g_discord_link.message;
    }
    if (!info.link_available && message.empty()) return;  // unknown yet, or this server cannot link
    ImGui::BeginDisabled(busy);
    if (info.status == "yours" && info.linked) {
        ImGui::TextColored(kGreen, "%s", Format(T("Cuenta de Discord: %s", "Discord account: %s"), info.discord).c_str());
        ImGui::SameLine();
        // Unlinking frees the nickname field and stops Discord recovery: a second press confirms.
        static ULONGLONG unlink_armed = 0;
        const bool armed = unlink_armed && GetTickCount64() - unlink_armed < 5000;
        if (ImGui::SmallButton(armed ? T("Pulsa otra vez para desvincular", "Press again to unlink") : T("Desvincular", "Unlink"))) {
            if (armed) {
                unlink_armed = 0;
                StartDiscordLink(DiscordLinkMode::Unlink);
            } else {
                unlink_armed = GetTickCount64();
            }
        }
        if (!armed && ImGui::IsItemHovered())
            ImGui::SetTooltip("%s", T("Deja de estar vinculado: podrás cambiar el apodo, pero ya no lo recuperarás con Discord "
                                      "si reinstalas.",
                                      "Unlinks it: you can change the nickname, but can no longer recover it with Discord "
                                      "if you reinstall."));
    } else if (info.status == "yours" || info.status == "free") {
        if (ImGui::Button(T("Vincular con Discord", "Link with Discord"))) StartDiscordLink(DiscordLinkMode::Link);
        if (info.status == "free") {
            // A reinstall shows a free nickname the player just typed; theirs may be linked.
            ImGui::SameLine();
            if (ImGui::SmallButton(T("¿Ya tenías un apodo vinculado? Recupéralo", "Had a linked nickname already? Recover it")))
                StartDiscordLink(DiscordLinkMode::Recover);
        }
        HelpMarker(T("Tu apodo queda ligado a tu cuenta de Discord: si reinstalas el juego o juegas en otro PC, lo "
                     "recuperas autorizando Discord otra vez. Se abre Discord en el navegador para que lo autorices; "
                     "el launcher solo recibe tu identificador de Discord, nunca tu contraseña.",
                     "Your nickname is tied to your Discord account: if you reinstall the game or play on another PC, "
                     "you recover it by authorizing Discord again. Discord opens in the browser for you to authorize; "
                     "the launcher only receives your Discord ID, never your password."));
    } else if (info.status == "taken" && info.linked) {
        if (ImGui::Button(T("Recuperar con Discord", "Recover with Discord"))) StartDiscordLink(DiscordLinkMode::Link);
        HelpMarker(T("Si este apodo es tuyo, autoriza la misma cuenta de Discord con la que lo vinculaste y "
                     "podrás usarlo en esta instalación.",
                     "If this nickname is yours, authorize the same Discord account you linked it with and you can "
                     "use it on this installation."));
    } else if (info.status == "taken") {
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextColored(kGrey, "%s",
                           T("Si es tuyo y lo perdiste al reinstalar, pide al administrador del servidor que lo libere, "
                             "o espera: un apodo sin vincular y sin uso se libera a los 60 días.",
                             "If it is yours and you lost it when reinstalling, ask the server's administrator to "
                             "release it, or wait: an unlinked nickname nobody uses is released after 60 days."));
        ImGui::PopTextWrapPos();
    }
    ImGui::EndDisabled();
    DiscordLinkStatusLines();
}

void NatTypeSection(const std::string& server) {
    bool running, done;
    NatCheck::Result result;
    {
        std::scoped_lock lock{g_nat.mutex};
        running = g_nat.running;
        done = g_nat.done;
        result = g_nat.result;
    }
    ImGui::BeginDisabled(running);
    if (ImGui::Button(T("Comprobar tipo de NAT", "Check NAT type"))) StartNatCheck(server);
    ImGui::EndDisabled();
    HelpMarker(T("Comprueba si otros jugadores pueden conectarse directamente a tu PC. Pregunta a tu servidor RyuNET "
                 "y a un servidor STUN público (Cloudflare) con qué dirección te ven y las compara aquí: tu IP no se "
                 "muestra ni se guarda.",
                 "Checks whether other players can connect to your PC directly. It asks your RyuNET server and a "
                 "public STUN server (Cloudflare) which address they see you from and compares them here: your IP "
                 "is neither shown nor saved."));
    ImGui::SameLine();
    if (running) {
        ImGui::TextColored(kGrey, "%s", T("Comprobando...", "Checking..."));
        return;
    }
    if (!done) return;
    switch (result.type) {
    case NatCheck::Type::Open:
        ImGui::TextColored(kGreen, "%s", T("NAT tipo 1 (abierto): sin router de por medio.",
                                           "NAT type 1 (open): no router in between."));
        break;
    case NatCheck::Type::Moderate:
        ImGui::TextColored(kGreen, "%s", T("NAT tipo 2 (moderado): los demás jugadores pueden conectarse contigo.",
                                           "NAT type 2 (moderate): other players can connect to you."));
        break;
    case NatCheck::Type::Strict:
        ImGui::TextColored(kYellow, "%s", T("NAT tipo 3 (estricto): tu router cambia de puerto según con quién hables.",
                                            "NAT type 3 (strict): your router changes ports for each destination."));
        ImGui::TextWrapped("%s", T("Con otros jugadores de NAT estricto la conexión directa suele fallar y el juego pasa "
                                   "por el túnel del servidor. Ayuda activar UPnP en el router o abrir el puerto UDP 3074 "
                                   "hacia este PC.",
                                   "Direct connections with other strict-NAT players often fail and the game goes "
                                   "through the server's tunnel. Turning on UPnP in the router or forwarding UDP port "
                                   "3074 to this PC helps."));
        break;
    case NatCheck::Type::Unknown:
        ImGui::TextColored(kGrey, "%s",
                           result.error == "server" ? T("El servidor no respondió (¿está bien escrito? ¿UDP 3074 bloqueado?).",
                                                        "The server did not answer (is it spelled right? UDP 3074 blocked?).")
                           : result.error == "dns" ? T("No se encontró el servidor.", "The server was not found.")
                           : result.error == "stun" ? T("No se pudo comparar (el servidor STUN no respondió).",
                                                        "Could not compare (the STUN server did not answer).")
                                                    : T("No se pudo comprobar.", "Could not check."));
        break;
    }
}

void OnlineTab() {
    App& a = g_app;
    ImGui::TextColored(kGrey, "%s", T("Juego online con un servidor RyuNET. Se aplica al pulsar Jugar.",
                                      "Online play through a RyuNET server. Applied when you press Play."));

    ImGui::SeparatorText(T("Servidor", "Server"));
    {
        GameFlag("online", T("Habilitar modo online", "Enable online mode"), true,
                 T("Conecta a un servidor Demonware RyuNET para jugar online, emparejamiento, pit stop y marcadores.",
                   "Connects to a RyuNET Demonware server for online play, matchmaking, pit stop, and leaderboards."));

        const bool online_on = a.game.Flag("online", true);
        ImGui::BeginDisabled(!online_on);

        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 20.0f);
        if (ImGui::InputText(T("Servidor RyuNET (Server)", "RyuNET Server"), a.online_server_buf, sizeof(a.online_server_buf))) {
            a.game.Set("online_server", a.online_server_buf);
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            if (Trim(a.online_server_buf).empty()) {
                std::strncpy(a.online_server_buf, "octr.ryu7w7.xyz", sizeof(a.online_server_buf) - 1);
                a.online_server_buf[sizeof(a.online_server_buf) - 1] = '\0';
                a.game.Set("online_server", a.online_server_buf);
            }
            SaveGameIni();
        }
        ImGui::SameLine();
        if (ImGui::SmallButton(T("Por defecto", "Default"))) {
            std::strncpy(a.online_server_buf, "octr.ryu7w7.xyz", sizeof(a.online_server_buf) - 1);
            a.online_server_buf[sizeof(a.online_server_buf) - 1] = '\0';
            a.game.Set("online_server", a.online_server_buf);
            SaveGameIni();
        }
        ImGui::SameLine();
        if (ImGui::SmallButton("127.0.0.1")) {
            std::strncpy(a.online_server_buf, "127.0.0.1", sizeof(a.online_server_buf) - 1);
            a.online_server_buf[sizeof(a.online_server_buf) - 1] = '\0';
            a.game.Set("online_server", a.online_server_buf);
            SaveGameIni();
        }
        HelpMarker(T("IP o dominio del servidor RyuNET (predeterminado: octr.ryu7w7.xyz, o 127.0.0.1 para servidor local). Puerto HTTP opcional :8080.",
                     "IP or domain of the RyuNET server (default: octr.ryu7w7.xyz, or 127.0.0.1 for local server). Optional HTTP port :8080."));
        NatTypeSection(Trim(a.game.Get("online_server", "octr.ryu7w7.xyz")));
        ImGui::EndDisabled();
    }

    ImGui::SeparatorText(T("Jugador", "Player"));
    {
        ImGui::BeginDisabled(!a.game.Flag("online", true));

        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 16.0f);
        // A nickname linked to this player's Discord account is their identity: it is changed by
        // unlinking it first (DiscordAccountSection), not by typing over it.
        const NickCheck::Result nick_info = NickInfo();
        const bool nick_locked = nick_info.status == "yours" && nick_info.linked;
        ImGui::BeginDisabled(nick_locked);
        NickInput(T("Apodo (Nickname)", "Nickname"));
        if (ImGui::IsItemDeactivatedAfterEdit()) SaveGameIni();
        ImGui::EndDisabled();
        HelpMarker(nick_locked
                       ? T("Este apodo está vinculado a tu cuenta de Discord y queda fijo. Para cambiarlo, pulsa "
                           "Desvincular abajo.",
                           "This nickname is linked to your Discord account and stays fixed. To change it, press "
                           "Unlink below.")
                       : T("Tu nombre en el online, obligatorio: de 3 a 16 letras, números, _ o -. Cada apodo es una cuenta "
                           "distinta en el servidor (monedas, objetos del Pit Stop), así que no uses el de otra persona.",
                           "Your online name, required: 3 to 16 letters, digits, _ or -. Each nickname is a separate account "
                           "on the server (coins, Pit Stop items), so do not use someone else's."));
        if (const char* problem = NickProblem(CurrentNick())) {
            ImGui::TextColored(kYellow, "%s", problem);
            if (a.game.Flag("online", true)) DiscordRecoverOffer();
        } else if (a.game.Flag("online", true)) {
            NickAvailabilityLine();
            DiscordAccountSection();
        }

        ImGui::SetNextItemWidth(ImGui::GetFontSize() * 24.0f);
        if (ImGui::InputText(T("Amigos (Friends)", "Friends"), a.online_friends_buf, sizeof(a.online_friends_buf))) {
            a.game.Set("online_friends", a.online_friends_buf);
        }
        if (ImGui::IsItemDeactivatedAfterEdit()) SaveGameIni();
        HelpMarker(T("Lista de amigos para Partidas Privadas, separados por comas (ejemplo: ESDRONIX,Amigo2).",
                     "List of friends for Private Matches, separated by commas (example: ESDRONIX,Friend2)."));

        // Which Pit Stop items (characters, skins, karts) count as yours online: the server's,
        // bought with coins and tied to the nickname, or the save's (run.py sends it at login).
        ImGui::Spacing();
        ImGui::TextUnformatted(T("Personajes, skins y karts en online:", "Characters, skins and karts online:"));
        const bool from_save = Lower(Trim(a.game.Get("online_inventory", "server"))) == "save";
        if (ImGui::RadioButton(T("Progresión en el servidor", "Progress on the server"), !from_save)) {
            a.game.Set("online_inventory", "server");
            SaveGameIni();
        }
        HelpMarker(T("Lo consigues jugando: ganas monedas en las carreras y compras en el Pit Stop. Lo que compras "
                     "queda guardado en el servidor, ligado a tu apodo.",
                     "You earn it by playing: races give coins and you buy in the Pit Stop. What you buy is kept on "
                     "the server, tied to your nickname."));
        if (ImGui::RadioButton(T("De mi partida guardada (100%)", "From my save (100%)"), from_save)) {
            a.game.Set("online_inventory", "save");
            SaveGameIni();
        }
        HelpMarker(T("Online tienes lo mismo que en tu partida guardada, por ejemplo una partida al 100% importada en "
                     "la pestaña Guardados. El Pit Stop no vende nada en este modo: no gastas monedas en objetos que no "
                     "verías.",
                     "Online you have what your save has, for example a 100% save imported in the Saves tab. The Pit "
                     "Stop sells nothing in this mode: no coins are spent on items you would not see."));

        ImGui::EndDisabled();
    }

    ImGui::SeparatorText("Discord");
    LauncherFlag("discord_rpc", T("Mostrar actividad en Discord", "Show activity on Discord"), true,
                 T("Mientras juegas, tu estado de Discord muestra CTR Nitro-Fueled, si juegas online o sin conexión, "
                   "tu apodo y el tiempo de juego. Necesita la aplicación de Discord abierta en este PC.",
                   "While you play, your Discord status shows CTR Nitro-Fueled, whether you play online or offline, "
                   "your nickname and the time played. Needs the Discord app running on this PC."));
    if (a.launcher.Flag("discord_rpc", true)) {
        const char* status = "";
        ImVec4 color = kGrey;
        switch (DiscordPresence::GetStatus()) {
        case DiscordPresence::Status::Connected:
            status = T("Conectado a Discord.", "Connected to Discord.");
            color = ImVec4(0.45f, 0.8f, 0.45f, 1.0f);
            break;
        case DiscordPresence::Status::NoDiscord:
            status = T("Discord no está abierto; se conectará solo cuando lo abras.",
                       "Discord is not running; it connects on its own once you open it.");
            break;
        case DiscordPresence::Status::NoAppId:
            status = T("Falta el ID de la aplicación de Discord (discord_app_id en launcher.ini).",
                       "The Discord application ID is missing (discord_app_id in launcher.ini).");
            color = kYellow;
            break;
        case DiscordPresence::Status::Error:
            status = T("Discord rechazó la conexión:", "Discord refused the connection:");
            color = kYellow;
            break;
        case DiscordPresence::Status::Off:
            status = T("Conectando...", "Connecting...");
            break;
        }
        ImGui::TextColored(color, "%s", status);
        if (DiscordPresence::GetStatus() == DiscordPresence::Status::Error) {
            ImGui::SameLine();
            ImGui::TextColored(kGrey, "%s", DiscordPresence::LastError().c_str());
        }

        LauncherFlag("discord_accept_requests", T("Aceptar a quien pida unirse", "Accept people who ask to join"), true,
                     T("Cuando alguien pulsa \"Pedir unirse\" en tu perfil, se le acepta solo: recibe lo mismo que con "
                       "una invitación tuya (tu apodo y tu servidor).",
                       "When someone presses \"Ask to Join\" on your profile, they are accepted automatically: they "
                       "get the same as from an invite of yours (your nickname and your server)."));
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextColored(kGrey, "%s",
                           T("Invitar a una privada o a tu grupo: mientras juegas online, en un chat de Discord pulsa "
                             "+ y elige \"Invitar a jugar\". Quien acepte te tendrá en sus amigos y se le abrirá el "
                             "juego; dentro, abre Amigos y únete a ti. Hace falta este launcher y Discord en los dos PC.",
                             "Invite to a private match or your party: while you play online, press + in a Discord "
                             "chat and choose \"Invite to play\". Whoever accepts gets you as a friend and their game "
                             "starts; in it, they open Friends and join you. Both PCs need this launcher and Discord."));
        ImGui::PopTextWrapPos();
    }
}

void PatchesTab() {
    App& a = g_app;
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextColored(kGrey, "%s", T("Se aplican al iniciar el juego (o con \"Apply and restart\" del menú del juego).",
                                      "Applied when the game starts (or with the in-game menu's \"Apply and restart\")."));
    ImGui::PopTextWrapPos();
    const bool neo = a.launcher.Flag("neo", false);
    if (a.patches.empty()) {
        ImGui::TextColored(kYellow, "%s", T("No hay parches en la carpeta patches.", "No patches in the patches folder."));
    }
    // Only the patches of the detected edition (the other's are for another executable).
    const std::string game_title = Narrow(GameTitle());
    ImGui::TextColored(kGreen, "%s",
                       Format(T("Tu juego: versión %s (%s). Se muestran sus parches.",
                                "Your game: %s edition (%s). Its patches are shown."),
                              RegionOf(game_title), game_title).c_str());
    for (const auto& p : a.patches) {
        if (!p.title.empty() && p.title != game_title) continue;
        // The online key patch follows the Online tab's switch (run.py turns it on).
        if (p.key.find("Online: custom Demonware key") != std::string::npos) continue;
        ImGui::PushID(p.key.c_str());
        bool on;
        if (p.ini_key) {
            on = a.game.Flag(p.ini_key, false);
        } else {
            const bool listed_on = std::find(a.patch_enabled.begin(), a.patch_enabled.end(), p.key) != a.patch_enabled.end();
            const bool listed_off = std::find(a.patch_disabled.begin(), a.patch_disabled.end(), p.key) != a.patch_disabled.end();
            on = listed_on || (p.default_on && !listed_off);
        }
        const bool needs_neo = p.ini_key && std::strcmp(p.ini_key, "patch_pro_1080p") == 0;
        if (needs_neo) {  // replaced by Settings > Internal resolution
            ImGui::PopID();
            continue;
        }
        // render_res decides the 1080p Pro patch (Settings > Internal resolution).
        if (needs_neo) on = EffectiveRenderRes() == "1080" && neo;
        ImGui::BeginDisabled(needs_neo);
        const char* region = RegionOf(p.title);
        const std::string label = *region ? p.name + " [" + region + "]" : p.name;
        if (ImGui::Checkbox(label.c_str(), &on)) {
            if (p.ini_key) {
                a.game.Set(p.ini_key, on ? "1" : "0");
                SaveGameIni();
            } else {
                auto drop = [&](std::vector<std::string>& v) { v.erase(std::remove(v.begin(), v.end(), p.key), v.end()); };
                drop(a.patch_enabled);
                drop(a.patch_disabled);
                if (on) a.patch_enabled.push_back(p.key);
                else if (p.default_on) a.patch_disabled.push_back(p.key);
                WritePatchConfig(a.patch_enabled, a.patch_disabled);
            }
        }
        ImGui::EndDisabled();
        if (!p.author.empty()) {
            ImGui::SameLine();
            ImGui::TextColored(kGrey, "%s %s%s%s", T("de", "by"), p.author.c_str(), p.version.empty() ? "" : "  v",
                               p.version.c_str());
        }
        ImGui::Indent();
        ImGui::PushTextWrapPos(0.0f);
        if (needs_neo) ImGui::TextColored(kGrey, "%s", T("Lo controla Ajustes > Resolución interna (1080p con el modo PS4 Pro).",
                                                          "Controlled by Settings > Internal resolution (1080p with PS4 Pro mode)."));
        if (p.ini_key && std::strcmp(p.ini_key, "patch_unlock_all") == 0) {
            ImGui::TextColored(kYellow, "%s",
                               T("Desbloquea lo que el juego da al cumplir sus condiciones de desbloqueo, con el mismo "
                                 "interruptor que usaban las demos de feria (E3/PAX). El autor recomienda copiar antes tu "
                                 "partida (pestaña Guardados). Se aplica al iniciar el juego.",
                                 "Unlocks what the game grants when its unlock conditions are met, with the same switch "
                                 "the trade-show demos (E3/PAX) used. The author advises backing up your save first "
                                 "(Saves tab). Applied when the game starts."));
        }
        if (!p.note.empty()) ImGui::TextColored(kGrey, "%s", p.note.c_str());
        ImGui::TextColored(kGrey, "%s", p.key.c_str());
        ImGui::PopTextWrapPos();
        ImGui::Unindent();
        ImGui::PopID();
    }

    ImGui::SeparatorText(T("Añadir parches", "Add patches"));
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextUnformatted(T("Copia archivos .xml de parches en formato shadPS4 (como los de PS-Game-Patch o GoldHEN) en la "
                             "carpeta patches y pulsa Recargar. Solo aparecen los que son para CUSA13795 versión 01.21.",
                             "Copy patch .xml files in shadPS4 format (like PS-Game-Patch's or GoldHEN's) into the patches "
                             "folder and press Reload. Only those for CUSA13795 version 01.21 are listed."));
    ImGui::TextColored(kGrey, "%s", T("Para tener el juego desbloqueado: activa Unlock Everything (arriba) o importa una partida "
                                      "al 100% en la pestaña Guardados.",
                                      "To have the game unlocked: turn on Unlock Everything (above) or import a 100% save in "
                                      "the Saves tab."));
    ImGui::PopTextWrapPos();
    if (ImGui::Button(T("Abrir la carpeta de parches", "Open the patches folder"))) {
        std::error_code ec;
        fs::create_directories(a.root / L"patches", ec);
        OpenInShell(a.root / L"patches");
    }
    ImGui::SameLine();
    if (ImGui::Button(T("Recargar", "Reload"))) {
        a.patches = LoadPatches();
        ReadPatchConfig(a.patch_enabled, a.patch_disabled);
    }
}

void SavesTab() {
    App& a = g_app;
    if (a.saves_dirty) {
        a.saves = ListSaves();
        a.backups = ListBackups();
        a.saves_dirty = false;
    }
    const bool locked = a.game_running;
    if (locked) {
        ImGui::TextColored(kYellow, "%s", T("Cierra el juego para copiar, importar o restaurar partidas.",
                                            "Close the game to back up, import or restore saves."));
    }
    ImGui::SeparatorText(T("Partidas", "Saves"));
    ImGui::TextColored(kGrey, "%s", PathText(SaveRoot()).c_str());
    if (a.saves.empty()) {
        ImGui::TextUnformatted(T("Todavía no hay partidas guardadas.", "No saves yet."));
    } else if (ImGui::BeginTable("saves", 4, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn(T("Ranura", "Slot"), ImGuiTableColumnFlags_WidthFixed);
        ImGui::TableSetupColumn(T("Descripción", "Description"), ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableSetupColumn(T("Tamaño", "Size"), ImGuiTableColumnFlags_WidthFixed);
        ImGui::TableSetupColumn(T("Modificada", "Modified"), ImGuiTableColumnFlags_WidthFixed);
        ImGui::TableHeadersRow();
        for (const auto& s : a.saves) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(s.dir.c_str());
            ImGui::TableNextColumn();
            std::string text = s.title;
            if (!s.subtitle.empty()) text += (text.empty() ? "" : " - ") + s.subtitle;
            if (!s.detail.empty()) text += (text.empty() ? "" : " - ") + s.detail;
            ImGui::TextUnformatted(text.empty() ? "-" : text.c_str());
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(FormatSize(s.bytes).c_str());
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(s.modified.c_str());
        }
        ImGui::EndTable();
    }
    ImGui::BeginDisabled(locked);
    ImGui::BeginDisabled(a.saves.empty());
    if (ImGui::Button(T("Hacer copia de seguridad", "Back up now"))) {
        fs::path made;
        const std::string error = BackupSaves(nullptr, &made);
        a.notice = error.empty() ? std::string(T("Copia creada: ", "Backup created: ")) + PathText(made.filename()) : error;
        a.saves_dirty = true;
    }
    ImGui::SameLine();
    if (ImGui::Button(T("Exportar...", "Export..."))) {
        if (const auto dest = PickFolder(a.hwnd, L"Exportar partidas / Export saves", fs::path())) {
            const fs::path target = *dest / Widen("CTR-saves-" + Stamp());
            const std::string error = CopyTree(SaveRoot(), target);
            a.notice = error.empty() ? std::string(T("Partidas exportadas a ", "Saves exported to ")) + PathText(target) : error;
        }
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button(T("Importar...", "Import..."))) {
        if (const auto from = PickFolder(a.hwnd, L"Importar partida / Import save", fs::path())) {
            const std::string error = ImportSaves(*from);
            a.notice = error.empty() ? std::string(T("Partida importada. La anterior quedó en una copia de seguridad.",
                                                     "Save imported. The previous one was backed up."))
                                     : error;
            a.saves_dirty = true;
        }
    }
    HelpMarker(T("Acepta una copia de seguridad de este launcher, la carpeta CUSA13795 de las partidas de otro PC, o una "
                 "partida de PS4 descifrada (Apollo Save Tool, Save Wizard: una carpeta con sce_sys\\param.sfo). Antes de "
                 "importar se hace una copia de seguridad de tus partidas.",
                 "Takes a backup made by this launcher, the CUSA13795 saves folder from another PC, or a decrypted PS4 "
                 "save (Apollo Save Tool, Save Wizard: a folder with sce_sys\\param.sfo). Your saves are backed up "
                 "before importing."));
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button(T("Abrir carpeta", "Open folder"))) {
        std::error_code ec;
        fs::create_directories(SaveRoot(), ec);
        OpenInShell(SaveRoot());
    }

    ImGui::SeparatorText(T("Copias de seguridad", "Backups"));
    if (a.backups.empty()) {
        ImGui::TextColored(kGrey, "%s", T("Todavía no hay copias.", "No backups yet."));
    } else if (ImGui::BeginTable("backups", 4, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn(T("Copia", "Backup"), ImGuiTableColumnFlags_WidthStretch);
        ImGui::TableSetupColumn(T("Tamaño", "Size"), ImGuiTableColumnFlags_WidthFixed);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed);
        for (const auto& b : a.backups) {
            ImGui::PushID(b.name.c_str());
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(b.name.c_str());
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(FormatSize(b.bytes).c_str());
            ImGui::TableNextColumn();
            ImGui::BeginDisabled(locked);
            if (ImGui::SmallButton(T("Restaurar", "Restore"))) {
                a.pending_path = b.path;
                a.pending_action = 1;
            }
            ImGui::EndDisabled();
            ImGui::TableNextColumn();
            if (ImGui::SmallButton(T("Borrar", "Delete"))) {
                a.pending_path = b.path;
                a.pending_action = 2;
            }
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
    if (ImGui::Button(T("Abrir carpeta de copias", "Open backups folder"))) {
        std::error_code ec;
        fs::create_directories(BackupRoot(), ec);
        OpenInShell(BackupRoot());
    }
    ImGui::SameLine();
    if (ImGui::Button(T("Actualizar", "Refresh"))) a.saves_dirty = true;
}

// ---------------------------------------------------------------------------------------------
// DLC (optional): the player's add-on packages in <port>\dlc, as .pkg files or extracted folders.
// CTR Nitro-Fueled's DLC hold only the license; scripts/content_profile.py reads the same folder
// and the runtime reports each one installed (BB_DLC, BB_DLC_DISABLED from launcher.ini).

fs::path DlcRoot() { return g_app.root / L"dlc"; }

uint32_t Be32(const char* p) {
    return uint32_t(uint8_t(p[0])) << 24 | uint32_t(uint8_t(p[1])) << 16 | uint32_t(uint8_t(p[2])) << 8 | uint32_t(uint8_t(p[3]));
}

/// param.sfo of a PS4 package (entry 0x1000), when it is stored in the clear.
std::map<std::string, std::string> ReadPkgSfo(const fs::path& pkg, std::string& error) {
    std::ifstream f(pkg, std::ios::binary);
    char header[0x20];
    if (!f.read(header, sizeof header) || std::memcmp(header, "\x7f" "CNT", 4) != 0) {
        error = T("no es un paquete de PS4", "not a PS4 package");
        return {};
    }
    const uint32_t count = Be32(header + 0x10), table = Be32(header + 0x18);
    if (count == 0 || count > 4096) {
        error = T("paquete dañado", "damaged package");
        return {};
    }
    std::string entries(size_t(count) * 32, '\0');
    f.seekg(table);
    if (!f.read(entries.data(), std::streamsize(entries.size()))) {
        error = T("paquete dañado", "damaged package");
        return {};
    }
    for (uint32_t i = 0; i < count; ++i) {
        const char* e = entries.data() + size_t(i) * 32;
        if (Be32(e) != 0x1000) continue;
        const uint32_t flags = Be32(e + 8), offset = Be32(e + 16), size = Be32(e + 20);
        if (flags & 0x80000000u) {
            error = T("param.sfo está cifrado", "param.sfo is encrypted");
            return {};
        }
        if (size > (1u << 20)) break;
        std::string data(size, '\0');
        f.seekg(offset);
        if (!f.read(data.data(), size)) break;
        return ParseSfo(data);
    }
    error = T("no tiene param.sfo", "no param.sfo");
    return {};
}

DlcInfo DescribeDlc(const fs::path& path) {
    DlcInfo d;
    d.path = path;
    d.file = PathText(path.filename());
    std::error_code ec;
    std::map<std::string, std::string> sfo;
    if (fs::is_directory(path, ec)) {
        if (!fs::is_regular_file(path / L"sce_sys" / L"param.sfo", ec)) {
            d.problem = T("la carpeta no tiene sce_sys\\param.sfo", "the folder has no sce_sys\\param.sfo");
            return d;
        }
        sfo = ReadSfo(path / L"sce_sys" / L"param.sfo");
    } else {
        sfo = ReadPkgSfo(path, d.problem);
        if (!d.problem.empty()) return d;
    }
    auto get = [&](const char* k) {
        const auto it = sfo.find(k);
        return it == sfo.end() ? std::string() : it->second;
    };
    const std::string content = get("CONTENT_ID");
    const size_t dash = content.rfind('-');
    d.label = dash == std::string::npos ? std::string() : content.substr(dash + 1);
    d.title = get("TITLE");
    if (!IsCtrTitle(get("TITLE_ID")) || get("CATEGORY") != "ac" || d.label.size() != 16) {
        d.problem = T("no es un DLC de CTR Nitro-Fueled (CUSA13795 / CUSA14876)",
                      "not a CTR Nitro-Fueled (CUSA13795 / CUSA14876) DLC");
        return d;
    }
    if (d.title.empty()) d.title = d.label;
    d.ok = true;
    return d;
}

std::vector<DlcInfo> ScanDlc() {
    std::vector<DlcInfo> list;
    std::error_code ec;
    for (fs::directory_iterator it(DlcRoot(), ec), end; !ec && it != end; it.increment(ec)) {
        std::error_code e2;
        const bool pkg = it->is_regular_file(e2) && (it->path().extension() == L".pkg" || it->path().extension() == L".PKG");
        if (pkg || it->is_directory(e2)) list.push_back(DescribeDlc(it->path()));
    }
    std::sort(list.begin(), list.end(), [](const DlcInfo& a, const DlcInfo& b) { return a.title < b.title; });
    return list;
}

std::vector<std::string> SplitList(const std::string& text) {
    std::vector<std::string> out;
    std::stringstream ss(text);
    std::string item;
    while (std::getline(ss, item, ','))
        if (!Trim(item).empty()) out.push_back(Trim(item));
    return out;
}

std::string JoinList(const std::vector<std::string>& items) {
    std::string out;
    for (const auto& item : items) out += (out.empty() ? "" : ",") + item;
    return out;
}

void AddDlcPackages() {
    App& a = g_app;
    const auto files = PickFiles(a.hwnd, L"DLC (.pkg)", L"PS4 DLC (*.pkg)", L"*.pkg");
    if (files.empty()) return;
    std::error_code ec;
    fs::create_directories(DlcRoot(), ec);
    int added = 0;
    std::string problems;
    for (const auto& file : files) {
        const DlcInfo d = DescribeDlc(file);
        if (!d.ok) {
            problems += PathText(file.filename()) + ": " + d.problem + ". ";
            continue;
        }
        const fs::path target = DlcRoot() / file.filename();
        if (!CopyFileW(file.c_str(), target.c_str(), FALSE)) {
            problems += PathText(file.filename()) + ": error " + std::to_string(GetLastError()) + ". ";
            continue;
        }
        ++added;
    }
    a.notice = std::string(T("DLC añadidos: ", "DLC added: ")) + std::to_string(added) + (problems.empty() ? "" : ". " + problems);
    a.dlc_dirty = true;
}

void DlcTab() {
    App& a = g_app;
    if (a.dlc_dirty) {
        a.dlc = ScanDlc();
        a.dlc_dirty = false;
    }
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextUnformatted(T("Opcional: el juego funciona igual sin DLC. Los DLC de CTR Nitro-Fueled solo traen la licencia "
                             "(el contenido ya está en el juego); el port los marca como instalados al iniciar.",
                             "Optional: the game runs the same without DLC. CTR Nitro-Fueled's DLC only carry the license "
                             "(the content is already in the game); the port reports them installed at start."));
    ImGui::TextColored(kGrey, "%s", T("Usa tus propios paquetes DLC de PS4 (.pkg) de CUSA13795. Se copian a la carpeta dlc del "
                                      "port; tus archivos originales no cambian.",
                                      "Use your own PS4 DLC packages (.pkg) for CUSA13795. They are copied into the port's "
                                      "dlc folder; your original files are not changed."));
    ImGui::PopTextWrapPos();
    ImGui::Spacing();
    LauncherFlag("dlc", T("Activar los DLC", "Enable DLC"), true);
    const bool enabled = a.launcher.Flag("dlc", true);
    std::vector<std::string> disabled = SplitList(a.launcher.Get("dlc_disabled"));

    ImGui::SeparatorText(T("DLC encontrados", "DLC found"));
    if (a.dlc.empty()) ImGui::TextColored(kGrey, "%s", T("No hay DLC en la carpeta dlc.", "No DLC in the dlc folder."));
    ImGui::BeginDisabled(!enabled);
    for (const auto& d : a.dlc) {
        ImGui::PushID(d.file.c_str());
        if (d.ok) {
            bool on = std::find(disabled.begin(), disabled.end(), d.label) == disabled.end();
            if (ImGui::Checkbox(d.title.c_str(), &on)) {
                disabled.erase(std::remove(disabled.begin(), disabled.end(), d.label), disabled.end());
                if (!on) disabled.push_back(d.label);
                a.launcher.Set("dlc_disabled", JoinList(disabled));
                SaveLauncher();
            }
            ImGui::SameLine();
            ImGui::TextColored(kGrey, "%s", d.label.c_str());
        } else {
            ImGui::TextColored(kRed, "%s: %s", d.file.c_str(), d.problem.c_str());
        }
        ImGui::SameLine();
        ImGui::BeginDisabled(a.game_running);
        if (ImGui::SmallButton(T("Quitar", "Remove"))) {
            a.pending_path = d.path;
            a.pending_action = 3;
        }
        ImGui::EndDisabled();
        ImGui::PopID();
    }
    ImGui::EndDisabled();
    ImGui::Spacing();
    if (ImGui::Button(T("Añadir DLC (.pkg)...", "Add DLC (.pkg)..."))) AddDlcPackages();
    ImGui::SameLine();
    if (ImGui::Button(T("Abrir la carpeta dlc", "Open the dlc folder"))) {
        std::error_code ec;
        fs::create_directories(DlcRoot(), ec);
        OpenInShell(DlcRoot());
    }
    ImGui::SameLine();
    if (ImGui::Button(T("Actualizar##dlc", "Refresh##dlc"))) a.dlc_dirty = true;
    ImGui::TextColored(kGrey, "%s", T("Los cambios se aplican la próxima vez que pulses Jugar.", "Changes apply the next time you press Play."));
}

/// Asked when PLAY is pressed online without a usable nickname: the game only starts once one
/// is chosen (or online is turned off for this launch).
void NickPopup() {
    App& a = g_app;
    if (a.ask_nick) {
        ImGui::OpenPopup("nick_required");
        a.ask_nick = false;
    }
    if (!ImGui::BeginPopupModal("nick_required", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar))
        return;
    ImGui::TextUnformatted(T("Elige tu apodo para jugar online", "Choose your nickname to play online"));
    ImGui::PushTextWrapPos(ImGui::GetFontSize() * 28.0f);
    ImGui::TextColored(kGrey, "%s", T("Es tu nombre en el online y tu cuenta en el servidor: tus monedas y objetos del Pit Stop "
                                      "van ligados a él. De 3 a 16 letras, números, _ o -.",
                                      "It is your online name and your account on the server: your coins and Pit Stop items "
                                      "belong to it. 3 to 16 letters, digits, _ or -."));
    ImGui::PopTextWrapPos();
    if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
    ImGui::SetNextItemWidth(ImGui::GetFontSize() * 16.0f);
    NickInput(T("Apodo", "Nickname"));
    const char* problem = NickProblem(CurrentNick());
    if (problem) ImGui::TextColored(kYellow, "%s", problem);
    else NickAvailabilityLine();
    if (problem || NickTaken()) DiscordRecoverOffer();  // a reinstall: the nickname linked to Discord
    ImGui::BeginDisabled(problem != nullptr || NickTaken());
    if (ImGui::Button(T("Guardar y jugar", "Save and play"))) {
        SaveGameIni();
        ImGui::CloseCurrentPopup();
        StartGame();
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button(T("Cancelar", "Cancel"))) {
        a.game.Load(GameIni());  // drop what was typed: every other setting is already saved
        SyncOnlineBuffers();
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}

/// A Discord invite for a server other than ours: switching is the player's call.
void JoinServerPopup() {
    App& a = g_app;
    if (a.ask_join_server) {
        ImGui::OpenPopup("join_server");
        a.ask_join_server = false;
    }
    if (!ImGui::BeginPopupModal("join_server", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar))
        return;
    ImGui::Text(T("Invitación de %s", "Invite from %s"), a.join_nick.c_str());
    ImGui::PushTextWrapPos(ImGui::GetFontSize() * 28.0f);
    const std::string mine = Trim(a.game.Get("online_server", "octr.ryu7w7.xyz"));
    ImGui::TextColored(kYellow, T("Es para el servidor %s y tú usas %s.", "It is for the server %s and you use %s."),
                       a.join_server.c_str(), mine.c_str());
    ImGui::TextColored(kGrey, "%s", T("Cámbialo solo si confías en ese servidor: verá tu apodo y tu partida online. "
                                      "Puedes volver al tuyo en la pestaña Online.",
                                      "Only switch if you trust that server: it will see your nickname and your online "
                                      "play. You can switch back in the Online tab."));
    ImGui::PopTextWrapPos();
    if (ImGui::Button(T("Cambiar de servidor y unirme", "Switch server and join"))) {
        AcceptDiscordJoin(a.join_server, a.join_nick);
        ImGui::CloseCurrentPopup();
    }
    ImGui::SameLine();
    if (ImGui::Button(T("Cancelar", "Cancel"))) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

void SaveConfirmations() {
    App& a = g_app;
    if (a.pending_action) {
        ImGui::OpenPopup("save_confirm");
        a.confirm_action = a.pending_action;
        a.pending_action = 0;
    }
    if (ImGui::BeginPopupModal("save_confirm", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
        const std::string name = PathText(a.pending_path.filename());
        if (a.confirm_action == 1) {
            ImGui::Text(T("¿Restaurar %s?", "Restore %s?"), name.c_str());
            ImGui::TextColored(kGrey, "%s", T("Tus partidas actuales se guardan antes en una copia automática.",
                                              "Your current saves are backed up automatically first."));
        } else if (a.confirm_action == 3) {
            ImGui::Text(T("¿Quitar %s de la carpeta dlc?", "Remove %s from the dlc folder?"), name.c_str());
            ImGui::TextColored(kGrey, "%s", T("Solo se borra la copia del port.", "Only the port's copy is deleted."));
        } else {
            ImGui::Text(T("¿Borrar la copia %s? No se puede deshacer.", "Delete the backup %s? This cannot be undone."), name.c_str());
        }
        if (ImGui::Button(a.confirm_action == 1 ? T("Restaurar", "Restore") : a.confirm_action == 3 ? T("Quitar", "Remove") : T("Borrar", "Delete"))) {
            std::string error;
            if (a.confirm_action == 1) {
                error = RestoreBackup(a.pending_path);
                if (error.empty()) a.notice = std::string(T("Restaurada: ", "Restored: ")) + name;
            } else {
                std::error_code ec;
                fs::remove_all(a.pending_path, ec);
                if (ec) error = name + ": " + ec.message();
            }
            if (!error.empty()) a.notice = error;
            a.saves_dirty = true;
            a.dlc_dirty = true;
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button(T("Cancelar", "Cancel"))) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

// ---------------------------------------------------------------------------------------------
// Keyboard tab: bbport.ini key.<input>=<SDL key names> (src/runtime_pad.c reads them at start;
// a missing line keeps the runtime's default). Keys are captured by their scan code (the key's
// place on the keyboard, as SDL's scancodes), so the binding holds whatever the layout.

struct KeyInput {
    const char* id;      // runtime_pad.c input name
    const char* es;
    const char* en;
    const char* fallback;  // runtime_pad.c bind_defaults()
};
constexpr KeyInput kKeyInputs[] = {
    {"move_up", "Stick izquierdo arriba", "Left stick up", "W"},
    {"move_down", "Stick izquierdo abajo", "Left stick down", "S"},
    {"move_left", "Stick izquierdo izquierda (girar)", "Left stick left (steer)", "A"},
    {"move_right", "Stick izquierdo derecha (girar)", "Left stick right (steer)", "D"},
    {"cross", "X (acelerar)", "Cross (accelerate)", "Space"},
    {"square", "Cuadrado (frenar)", "Square (brake)", "E"},
    {"circle", "Círculo", "Circle", "Left Shift"},
    {"triangle", "Triángulo", "Triangle", "Q"},
    {"r1", "R1", "R1", "3"},
    {"l1", "L1", "L1", "1"},
    {"r2", "R2", "R2", "F"},
    {"l2", "L2", "L2", "R"},
    {"l3", "L3", "L3", "Z"},
    {"r3", "R3", "R3", "C"},
    {"options", "Options (pausa)", "Options (pause)", "Return"},
    {"touchpad", "Panel táctil", "Touchpad", "Tab"},
    {"touchpad_right", "Panel táctil (derecha)", "Touchpad (right)", "Backspace"},
    {"up", "Cruceta arriba", "D-pad up", "I"},
    {"down", "Cruceta abajo", "D-pad down", "K"},
    {"left", "Cruceta izquierda", "D-pad left", "J"},
    {"right", "Cruceta derecha", "D-pad right", "L"},
    {"look_up", "Stick derecho arriba", "Right stick up", "Up"},
    {"look_down", "Stick derecho abajo", "Right stick down", "Down"},
    {"look_left", "Stick derecho izquierda", "Right stick left", "Left"},
    {"look_right", "Stick derecho derecha", "Right stick right", "Right"},
};

// Scan code set 1 (WM_KEYDOWN lParam bits 16-23, + 0x100 for E0-extended) -> SDL scancode name.
const char* SdlKeyName(unsigned code) {
    static const std::map<unsigned, const char*> names = {
        {0x02, "1"}, {0x03, "2"}, {0x04, "3"}, {0x05, "4"}, {0x06, "5"}, {0x07, "6"}, {0x08, "7"},
        {0x09, "8"}, {0x0A, "9"}, {0x0B, "0"}, {0x0C, "-"}, {0x0D, "="}, {0x0E, "Backspace"},
        {0x0F, "Tab"}, {0x10, "Q"}, {0x11, "W"}, {0x12, "E"}, {0x13, "R"}, {0x14, "T"}, {0x15, "Y"},
        {0x16, "U"}, {0x17, "I"}, {0x18, "O"}, {0x19, "P"}, {0x1A, "["}, {0x1B, "]"},
        {0x1C, "Return"}, {0x1D, "Left Ctrl"}, {0x1E, "A"}, {0x1F, "S"}, {0x20, "D"}, {0x21, "F"},
        {0x22, "G"}, {0x23, "H"}, {0x24, "J"}, {0x25, "K"}, {0x26, "L"}, {0x27, ";"}, {0x28, "'"},
        {0x29, "`"}, {0x2A, "Left Shift"}, {0x2B, "\\"}, {0x2C, "Z"}, {0x2D, "X"}, {0x2E, "C"},
        {0x2F, "V"}, {0x30, "B"}, {0x31, "N"}, {0x32, "M"}, {0x33, ","}, {0x34, "."}, {0x35, "/"},
        {0x36, "Right Shift"}, {0x37, "Keypad *"}, {0x38, "Left Alt"}, {0x39, "Space"},
        {0x3A, "CapsLock"}, {0x3B, "F1"}, {0x3C, "F2"}, {0x3D, "F3"}, {0x3E, "F4"}, {0x3F, "F5"},
        {0x40, "F6"}, {0x41, "F7"}, {0x42, "F8"}, {0x43, "F9"}, {0x44, "F10"}, {0x57, "F11"},
        {0x58, "F12"}, {0x47, "Keypad 7"}, {0x48, "Keypad 8"}, {0x49, "Keypad 9"},
        {0x4A, "Keypad -"}, {0x4B, "Keypad 4"}, {0x4C, "Keypad 5"}, {0x4D, "Keypad 6"},
        {0x4E, "Keypad +"}, {0x4F, "Keypad 1"}, {0x50, "Keypad 2"}, {0x51, "Keypad 3"},
        {0x52, "Keypad 0"}, {0x53, "Keypad ."}, {0x56, "NonUSBackslash"},
        {0x11C, "Keypad Enter"}, {0x11D, "Right Ctrl"}, {0x135, "Keypad /"}, {0x138, "Right Alt"},
        {0x147, "Home"}, {0x148, "Up"}, {0x149, "PageUp"}, {0x14B, "Left"}, {0x14D, "Right"},
        {0x14F, "End"}, {0x150, "Down"}, {0x151, "PageDown"}, {0x153, "Delete"},
    };
    const auto it = names.find(code);
    return it == names.end() ? nullptr : it->second;
}

// How a key name reads in the launcher.
std::string KeyLabel(const std::string& name) {
    static const std::map<std::string, std::pair<const char*, const char*>> labels = {
        {"Space", {"Espacio", "Space"}}, {"Return", {"Enter", "Enter"}},
        {"Backspace", {"Retroceso", "Backspace"}}, {"Left Shift", {"Mayús izq.", "Left Shift"}},
        {"Right Shift", {"Mayús der.", "Right Shift"}}, {"Left Ctrl", {"Ctrl izq.", "Left Ctrl"}},
        {"Right Ctrl", {"Ctrl der.", "Right Ctrl"}}, {"Left Alt", {"Alt", "Left Alt"}},
        {"Right Alt", {"Alt Gr", "Right Alt"}}, {"Up", {"Flecha arriba", "Up arrow"}},
        {"Down", {"Flecha abajo", "Down arrow"}}, {"Left", {"Flecha izquierda", "Left arrow"}},
        {"Right", {"Flecha derecha", "Right arrow"}}, {"CapsLock", {"Bloq Mayús", "Caps Lock"}},
        {"Delete", {"Supr", "Delete"}}, {"Home", {"Inicio", "Home"}}, {"End", {"Fin", "End"}},
        {"PageUp", {"Re Pág", "Page Up"}}, {"PageDown", {"Av Pág", "Page Down"}},
        {"`", {"Tecla a la izquierda del 1", "` key"}},
        {"NonUSBackslash", {"Tecla < >", "< > key"}}, {"Keypad Enter", {"Enter (teclado num.)", "Keypad Enter"}},
    };
    const auto it = labels.find(name);
    if (it != labels.end()) return T(it->second.first, it->second.second);
    if (name.rfind("Keypad ", 0) == 0) return std::string(T("Num ", "Num ")) + name.substr(7);
    return name;
}

std::atomic<int> g_key_capture{-1};      // the input waiting for a key, -1 none
std::atomic<unsigned> g_key_captured{0};  // scan code + 1 (0: nothing yet)
bool g_key_replace = false;                 // the captured key replaces the default binding

std::vector<std::string> SplitKeys(const std::string& value) {
    std::vector<std::string> keys;
    std::stringstream ss(value);
    std::string key;
    while (std::getline(ss, key, ',')) {
        key = Trim(key);
        if (!key.empty()) keys.push_back(key);
    }
    return keys;
}

void KeyboardTab() {
    App& a = g_app;
    ImGui::TextWrapped("%s", T("Teclas del jugador 1. El teclado funciona a la vez que el mando. Pulsa \"Cambiar\" y luego la "
                               "tecla; cada acción admite hasta 4 teclas. Se guarda en bbport.ini y vale desde el próximo arranque.",
                               "Player 1's keys. The keyboard works together with the controller. Press \"Change\", then the key; "
                               "each action takes up to 4 keys. Saved in bbport.ini, used from the next start."));
    ImGui::TextColored(kGrey, "%s", T("Insert abre el menú del juego y Esc cancela, por eso no se pueden asignar.",
                                      "Insert opens the in-game menu and Esc cancels, so they cannot be bound."));
    const int capturing = g_key_capture;
    if (capturing >= 0) {
        const unsigned got = g_key_captured.exchange(0);
        if (got) {
            const unsigned code = got - 1;
            if (code == 0x01) {
                g_key_capture = -1;  // Esc: cancel
            } else if (const char* name = SdlKeyName(code); name && code != 0x152) {
                const KeyInput& in = kKeyInputs[capturing];
                const std::string key = std::string("key.") + in.id;
                auto keys = g_key_replace ? std::vector<std::string>{} : SplitKeys(a.game.Get(key));
                if (std::find(keys.begin(), keys.end(), name) == keys.end()) {
                    if (keys.size() >= 4) keys.erase(keys.begin());
                    keys.push_back(name);
                }
                std::string value;
                for (const auto& k : keys) value += (value.empty() ? "" : ",") + k;
                a.game.Set(key, value);
                SaveGameIni();
                g_key_capture = -1;
            } else {
                a.notice = T("Esa tecla no se puede asignar.", "That key cannot be bound.");
                g_key_capture = -1;
            }
        }
    }

    ImGui::SeparatorText(T("Controles", "Controls"));
    if (ImGui::BeginTable("keys", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn(T("Acción", "Action"), ImGuiTableColumnFlags_WidthStretch, 1.2f);
        ImGui::TableSetupColumn(T("Teclas", "Keys"), ImGuiTableColumnFlags_WidthStretch, 1.4f);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, ImGui::GetFontSize() * 11.0f);
        ImGui::TableHeadersRow();
        for (int i = 0; i < int(std::size(kKeyInputs)); ++i) {
            const KeyInput& in = kKeyInputs[i];
            const std::string key = std::string("key.") + in.id;
            const bool custom = a.game.values.count(key) > 0;
            const auto keys = SplitKeys(custom ? a.game.Get(key) : in.fallback);
            ImGui::PushID(i);
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(T(in.es, in.en));
            ImGui::TableNextColumn();
            ImGui::AlignTextToFramePadding();
            if (capturing == i) {
                ImGui::TextColored(kYellow, "%s", T("Pulsa una tecla... (Esc cancela)", "Press a key... (Esc cancels)"));
            } else if (keys.empty()) {
                ImGui::TextColored(kGrey, "%s", T("(sin tecla)", "(none)"));
            } else {
                std::string text;
                for (const auto& k : keys) text += (text.empty() ? "" : "  /  ") + KeyLabel(k);
                if (custom) ImGui::TextUnformatted(text.c_str());
                else ImGui::TextColored(kGrey, "%s", text.c_str());
            }
            ImGui::TableNextColumn();
            ImGui::BeginDisabled(capturing >= 0);
            if (ImGui::SmallButton(T("Cambiar", "Change"))) {
                // A key replaces the default binding; on a custom one it is added (up to 4).
                g_key_replace = !custom;
                g_key_captured = 0;
                g_key_capture = i;
            }
            ImGui::SameLine();
            if (ImGui::SmallButton(T("Quitar", "Clear"))) {
                a.game.Set(key, "");
                SaveGameIni();
            }
            ImGui::SameLine();
            ImGui::BeginDisabled(!custom);
            if (ImGui::SmallButton(T("Original", "Default"))) {
                a.game.Erase(key);
                SaveGameIni();
            }
            ImGui::EndDisabled();
            ImGui::EndDisabled();
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
    ImGui::Spacing();
    ImGui::BeginDisabled(capturing >= 0);
    if (ImGui::Button(T("Restaurar todas las teclas", "Restore all keys"))) {
        for (const auto& in : kKeyInputs) a.game.Erase(std::string("key.") + in.id);
        SaveGameIni();
    }
    ImGui::EndDisabled();
    ImGui::TextColored(kGrey, "%s", T("Gris: tecla original. Las teclas van por su posición en el teclado.",
                                      "Grey: default key. Keys go by their place on the keyboard."));
}

// ---------------------------------------------------------------------------------------------
// Gamepad tab: bbport.ini pad.<input>=<SDL gamepad button names> (src/runtime_pad.c reads them).

struct PadInput {
    const char* id;
    const char* es;
    const char* en;
    const char* fallback;
};

constexpr PadInput kPadInputs[] = {
    {"cross", "X (Acelerar / Seleccionar)", "Cross (Accelerate / Select)", "a"},
    {"square", "Cuadrado (Frenar / Marcha atrás)", "Square (Brake / Reverse)", "x"},
    {"circle", "Círculo", "Circle", "b"},
    {"triangle", "Triángulo", "Triangle", "y"},
    {"l1", "L1 / LB (Salto / Derrape)", "L1 / LB (Hop / Drift)", "leftshoulder"},
    {"r1", "R1 / RB (Salto / Derrape)", "R1 / RB (Hop / Drift)", "rightshoulder"},
    {"l2", "L2 / LT (Usar objeto / Ítem)", "L2 / LT (Use item)", "lefttrigger"},
    {"r2", "R2 / RT (Mirar atrás)", "R2 / RT (Look back)", "righttrigger"},
    {"l3", "L3 (Click stick izq.)", "L3 (Left stick click)", "leftstick"},
    {"r3", "R3 (Click stick der.)", "R3 (Right stick click)", "rightstick"},
    {"options", "Options / Start (Pausa)", "Options / Start (Pause)", "start"},
    {"touchpad", "Touchpad / Back / Select", "Touchpad / Back / Select", "back,touchpad"},
    {"up", "Cruceta arriba", "D-pad up", "dpup"},
    {"down", "Cruceta abajo", "D-pad down", "dpdown"},
    {"left", "Cruceta izquierda", "D-pad left", "dpleft"},
    {"right", "Cruceta derecha", "D-pad right", "dpright"},
};

std::string PadButtonLabel(const std::string& name) {
    static const std::map<std::string, std::pair<const char*, const char*>> labels = {
        {"a", {"Cruz / A (Sur)", "Cross / A (South)"}},
        {"b", {"Círculo / B (Este)", "Circle / B (East)"}},
        {"x", {"Cuadrado / X (Oeste)", "Square / X (West)"}},
        {"y", {"Triángulo / Y (Norte)", "Triangle / Y (North)"}},
        {"leftshoulder", {"L1 / LB", "L1 / LB"}},
        {"rightshoulder", {"R1 / RB", "R1 / RB"}},
        {"lefttrigger", {"Gatillo L2 / LT", "Trigger L2 / LT"}},
        {"righttrigger", {"Gatillo R2 / RT", "Trigger R2 / RT"}},
        {"leftstick", {"Click L3 (Stick Izq.)", "L3 Click (Left Stick)"}},
        {"rightstick", {"Click R3 (Stick Der.)", "R3 Click (Right Stick)"}},
        {"start", {"Options / Start", "Options / Start"}},
        {"back", {"Share / Back / Select", "Share / Back / Select"}},
        {"touchpad", {"Touchpad", "Touchpad"}},
        {"dpup", {"Cruceta Arriba", "D-pad Up"}},
        {"dpdown", {"Cruceta Abajo", "D-pad Down"}},
        {"dpleft", {"Cruceta Izquierda", "D-pad Left"}},
        {"dpright", {"Cruceta Derecha", "D-pad Right"}},
        {"guide", {"Botón Guía / PS", "Guide / PS"}},
        {"misc1", {"Captura / Misc", "Capture / Misc"}},
        {"paddle1", {"Palanca 1", "Paddle 1"}},
        {"paddle2", {"Palanca 2", "Paddle 2"}},
        {"paddle3", {"Palanca 3", "Paddle 3"}},
        {"paddle4", {"Palanca 4", "Paddle 4"}},
    };
    const auto it = labels.find(name);
    return it != labels.end() ? T(it->second.first, it->second.second) : name;
}

#pragma pack(push, 1)
struct LauncherXInputGamepad {
    WORD wButtons;
    BYTE bLeftTrigger;
    BYTE bRightTrigger;
    SHORT sThumbLX;
    SHORT sThumbLY;
    SHORT sThumbRX;
    SHORT sThumbRY;
};
struct LauncherXInputState {
    DWORD dwPacketNumber;
    LauncherXInputGamepad Gamepad;
};
#pragma pack(pop)

typedef DWORD (WINAPI *PFN_LauncherXInputGetState)(DWORD dwUserIndex, void* pState);

const char* PollGamepadButton() {
    static HMODULE s_xinput = nullptr;
    static PFN_LauncherXInputGetState s_getState = nullptr;
    static bool s_tried = false;
    if (!s_tried) {
        s_tried = true;
        s_xinput = LoadLibraryA("xinput1_4.dll");
        if (!s_xinput) s_xinput = LoadLibraryA("xinput1_3.dll");
        if (!s_xinput) s_xinput = LoadLibraryA("xinput9_1_0.dll");
        if (s_xinput) {
            s_getState = (PFN_LauncherXInputGetState)GetProcAddress(s_xinput, "XInputGetState");
        }
    }
    if (!s_getState) return nullptr;

    for (DWORD i = 0; i < 4; ++i) {
        LauncherXInputState state{};
        if (s_getState(i, &state) == 0) {
            if (state.Gamepad.bLeftTrigger > 80) return "lefttrigger";
            if (state.Gamepad.bRightTrigger > 80) return "righttrigger";
            if (state.Gamepad.wButtons & 0x1000) return "a";
            if (state.Gamepad.wButtons & 0x2000) return "b";
            if (state.Gamepad.wButtons & 0x4000) return "x";
            if (state.Gamepad.wButtons & 0x8000) return "y";
            if (state.Gamepad.wButtons & 0x0100) return "leftshoulder";
            if (state.Gamepad.wButtons & 0x0200) return "rightshoulder";
            if (state.Gamepad.wButtons & 0x0040) return "leftstick";
            if (state.Gamepad.wButtons & 0x0080) return "rightstick";
            if (state.Gamepad.wButtons & 0x0010) return "start";
            if (state.Gamepad.wButtons & 0x0020) return "back";
            if (state.Gamepad.wButtons & 0x0001) return "dpup";
            if (state.Gamepad.wButtons & 0x0002) return "dpdown";
            if (state.Gamepad.wButtons & 0x0004) return "dpleft";
            if (state.Gamepad.wButtons & 0x0008) return "dpright";
        }
    }
    return nullptr;
}

std::atomic<int> g_pad_capture{-1};
bool g_pad_waiting_release = false;

void GamepadTab() {
    App& a = g_app;
    ImGui::TextWrapped("%s", T("Mapeo de botones del mando (Jugador 1). Compatible con mandos de Xbox, PlayStation (DualShock / DualSense), Switch Pro y mandos genéricos. "
                               "Pulsa \"Cambiar\" y presiona el botón en tu mando o selecciónalo en la pantalla. Se guarda en bbport.ini y se aplica en el próximo inicio.",
                               "Player 1 gamepad button mapping. Supports Xbox, PlayStation (DualShock / DualSense), Switch Pro and generic controllers. "
                               "Press \"Change\" and press the button on your controller or choose it on screen. Saved to bbport.ini, applies on next launch."));

    const int capturing = g_pad_capture;
    if (capturing >= 0) {
        const char* polled = PollGamepadButton();
        if (g_pad_waiting_release) {
            if (!polled) g_pad_waiting_release = false;
        } else if (polled) {
            const PadInput& in = kPadInputs[capturing];
            a.game.Set(std::string("pad.") + in.id, polled);
            SaveGameIni();
            g_pad_capture = -1;
        }
    }

    if (capturing >= 0 && capturing < int(std::size(kPadInputs))) {
        const PadInput& in = kPadInputs[capturing];
        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Border, kYellow);
        ImGui::BeginChild("pad_assign_box", ImVec2(0, 160), true);
        ImGui::TextColored(kYellow, "%s: %s", T("ASIGNAR BOTÓN PARA", "ASSIGN BUTTON FOR"), T(in.es, in.en));
        ImGui::TextColored(kGrey, "%s", T("Presiona cualquier botón o gatillo en tu mando, o haz clic en uno de abajo:",
                                          "Press any button or trigger on your controller, or click one below:"));
        ImGui::Spacing();

        auto AddBtn = [&](const char* id, const char* label) {
            if (ImGui::Button(label)) {
                a.game.Set(std::string("pad.") + in.id, id);
                SaveGameIni();
                g_pad_capture = -1;
            }
            ImGui::SameLine();
        };

        AddBtn("a", "Cruz / A");
        AddBtn("b", "Círculo / B");
        AddBtn("x", "Cuadrado / X");
        AddBtn("y", "Triángulo / Y");
        AddBtn("leftshoulder", "L1 / LB");
        AddBtn("rightshoulder", "R1 / RB");
        ImGui::NewLine();
        AddBtn("lefttrigger", "Gatillo L2 / LT");
        AddBtn("righttrigger", "Gatillo R2 / RT");
        AddBtn("dpup", "Cruceta Arriba");
        AddBtn("dpdown", "Cruceta Abajo");
        AddBtn("dpleft", "Cruceta Izq.");
        AddBtn("dpright", "Cruceta Der.");
        ImGui::NewLine();
        AddBtn("leftstick", "L3 (Stick Izq.)");
        AddBtn("rightstick", "R3 (Stick Der.)");
        AddBtn("start", "Start / Options");
        AddBtn("back", "Select / Back");
        AddBtn("touchpad", "Touchpad");
        if (ImGui::Button(T("Cancelar (Esc)", "Cancel (Esc)"))) {
            g_pad_capture = -1;
        }

        ImGui::EndChild();
        ImGui::PopStyleColor();
        ImGui::Spacing();
    }

    ImGui::SeparatorText(T("Botones del mando", "Gamepad buttons"));
    if (ImGui::BeginTable("pad_table", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn(T("Acción", "Action"), ImGuiTableColumnFlags_WidthStretch, 1.2f);
        ImGui::TableSetupColumn(T("Botón asignado", "Assigned button"), ImGuiTableColumnFlags_WidthStretch, 1.4f);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, ImGui::GetFontSize() * 11.0f);
        ImGui::TableHeadersRow();

        for (int i = 0; i < int(std::size(kPadInputs)); ++i) {
            const PadInput& in = kPadInputs[i];
            const std::string key = std::string("pad.") + in.id;
            const bool custom = a.game.values.count(key) > 0;
            const auto buttons = SplitKeys(custom ? a.game.Get(key) : in.fallback);

            ImGui::PushID(i + 200);
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(T(in.es, in.en));

            ImGui::TableNextColumn();
            ImGui::AlignTextToFramePadding();
            if (capturing == i) {
                ImGui::TextColored(kYellow, "%s", T("Esperando botón...", "Waiting for button..."));
            } else if (buttons.empty()) {
                ImGui::TextColored(kGrey, "%s", T("(sin botón asignado)", "(unbound)"));
            } else {
                std::string text;
                for (const auto& b : buttons) text += (text.empty() ? "" : "  /  ") + PadButtonLabel(b);
                if (custom) ImGui::TextUnformatted(text.c_str());
                else ImGui::TextColored(kGrey, "%s", text.c_str());
            }

            ImGui::TableNextColumn();
            ImGui::BeginDisabled(capturing >= 0);
            if (ImGui::SmallButton(T("Cambiar", "Change"))) {
                g_pad_capture = i;
                g_pad_waiting_release = (PollGamepadButton() != nullptr);
            }
            ImGui::SameLine();
            if (ImGui::SmallButton(T("Quitar", "Clear"))) {
                a.game.Set(key, "");
                SaveGameIni();
            }
            ImGui::SameLine();
            ImGui::BeginDisabled(!custom);
            if (ImGui::SmallButton(T("Original", "Default"))) {
                a.game.Erase(key);
                SaveGameIni();
            }
            ImGui::EndDisabled();
            ImGui::EndDisabled();
            ImGui::PopID();
        }
        ImGui::EndTable();
    }

    ImGui::Spacing();
    ImGui::SeparatorText(T("Preajustes rápidos", "Quick presets"));
    ImGui::BeginDisabled(capturing >= 0);
    if (ImGui::Button(T("Cruceta Abajo = L2 (Usar Ítem)", "D-pad Down = L2 (Use Item)"))) {
        a.game.Set("pad.l2", "dpdown");
        a.game.Set("pad.down", "lefttrigger");
        SaveGameIni();
        a.notice = T("Preajuste aplicado: Cruceta Abajo configurada como L2 (Ítem) y Gatillo L2 como Cruceta Abajo.",
                     "Preset applied: D-pad Down set to L2 (Item) and Trigger L2 set to D-pad Down.");
    }
    HelpMarker(T("Intercambia la Cruceta Abajo con el Gatillo L2. Ideal para disparar objetos con la flecha de abajo.",
                 "Swaps D-pad Down with Trigger L2. Ideal for using items with down arrow."));
    ImGui::SameLine();
    if (ImGui::Button(T("Restaurar todos los botones", "Restore all pad buttons"))) {
        for (const auto& in : kPadInputs) a.game.Erase(std::string("pad.") + in.id);
        SaveGameIni();
        a.notice = T("Todos los botones del mando se restauraron a los valores originales.",
                     "All gamepad buttons restored to defaults.");
    }
    ImGui::EndDisabled();
    ImGui::Spacing();
    ImGui::TextColored(kGrey, "%s", T("Gris: asignación por defecto. Blanco: botón personalizado guardado en bbport.ini.",
                                      "Grey: default binding. White: custom binding saved to bbport.ini."));
}

// ---------------------------------------------------------------------------------------------
// Shortcuts & Steam integration (Desktop shortcut and Steam custom artwork / shortcuts.vdf)

uint32_t Crc32(const void* data, size_t size) {
    static uint32_t table[256];
    static bool init = false;
    if (!init) {
        for (uint32_t i = 0; i < 256; ++i) {
            uint32_t c = i;
            for (int j = 0; j < 8; ++j)
                c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            table[i] = c;
        }
        init = true;
    }
    const uint8_t* p = static_cast<const uint8_t*>(data);
    uint32_t c = 0xFFFFFFFFu;
    for (size_t i = 0; i < size; ++i)
        c = table[(c ^ p[i]) & 0xFF] ^ (c >> 8);
    return ~c;
}

fs::path FindSteamPath() {
    HKEY key = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Valve\\Steam", 0, KEY_READ, &key) == ERROR_SUCCESS) {
        wchar_t buf[MAX_PATH];
        DWORD size = sizeof(buf);
        DWORD type = 0;
        if (RegQueryValueExW(key, L"SteamPath", nullptr, &type, (LPBYTE)buf, &size) == ERROR_SUCCESS) {
            RegCloseKey(key);
            std::wstring s = buf;
            std::replace(s.begin(), s.end(), L'/', L'\\');
            return fs::path(s);
        }
        RegCloseKey(key);
    }
    for (const auto& p : {L"C:\\Program Files (x86)\\Steam", L"C:\\Program Files\\Steam", L"D:\\Steam"}) {
        std::error_code ec;
        if (fs::is_directory(p, ec)) return fs::path(p);
    }
    return {};
}

struct SteamShortcut {
    uint32_t appid = 0;
    std::string app_name;
    std::string exe;
    std::string start_dir;
    std::string icon;
    std::string shortcut_path;
    std::string launch_options;
    int32_t is_hidden = 0;
    int32_t allow_desktop_config = 1;
    int32_t allow_overlay = 1;
    int32_t open_vr = 0;
    int32_t devkit = 0;
    std::string devkit_game_id;
    int32_t devkit_override_app_id = 0;
    int32_t last_play_time = 0;
    std::string flatpak_app_id;
    std::string sortas;
    std::vector<std::string> tags;
};

[[maybe_unused]] std::vector<SteamShortcut> ParseShortcuts(const std::vector<uint8_t>& buf) {
    std::vector<SteamShortcut> list;
    size_t i = 0;
    auto read_sz = [&]() -> std::string {
        size_t start = i;
        while (i < buf.size() && buf[i] != 0) ++i;
        std::string s(reinterpret_cast<const char*>(&buf[start]), i - start);
        if (i < buf.size()) ++i;
        return s;
    };
    if (buf.size() < 12 || buf[i++] != 0) return list;
    std::string root = read_sz();
    if (root != "shortcuts") return list;
    while (i < buf.size() && buf[i] != 8) {
        if (buf[i++] != 0) break;
        std::string idx = read_sz();
        SteamShortcut sc;
        auto iequals = [](const std::string& s1, const std::string& s2) {
            if (s1.size() != s2.size()) return false;
            for (size_t k = 0; k < s1.size(); ++k)
                if (::tolower((unsigned char)s1[k]) != ::tolower((unsigned char)s2[k])) return false;
            return true;
        };
        while (i < buf.size() && buf[i] != 8) {
            uint8_t type = buf[i++];
            std::string key = read_sz();
            if (type == 1) { // String
                std::string val = read_sz();
                if (iequals(key, "appname")) sc.app_name = val;
                else if (iequals(key, "exe")) sc.exe = val;
                else if (iequals(key, "startdir")) sc.start_dir = val;
                else if (iequals(key, "icon")) sc.icon = val;
                else if (iequals(key, "shortcutpath")) sc.shortcut_path = val;
                else if (iequals(key, "launchoptions")) sc.launch_options = val;
                else if (iequals(key, "devkitgameid")) sc.devkit_game_id = val;
                else if (iequals(key, "flatpakappid")) sc.flatpak_app_id = val;
                else if (iequals(key, "sortas")) sc.sortas = val;
            } else if (type == 2) { // Int32
                if (i + 4 > buf.size()) break;
                uint32_t val = 0;
                std::memcpy(&val, &buf[i], 4);
                i += 4;
                if (iequals(key, "appid")) sc.appid = val;
                else if (iequals(key, "ishidden")) sc.is_hidden = val;
                else if (iequals(key, "allowdesktopconfig")) sc.allow_desktop_config = val;
                else if (iequals(key, "allowoverlay")) sc.allow_overlay = val;
                else if (iequals(key, "openvr")) sc.open_vr = val;
                else if (iequals(key, "devkit")) sc.devkit = val;
                else if (iequals(key, "devkitoverrideappid")) sc.devkit_override_app_id = val;
                else if (iequals(key, "lastplaytime")) sc.last_play_time = val;
            } else if (type == 0) { // Submap, e.g. tags
                while (i < buf.size() && buf[i] != 8) {
                    uint8_t subtype = buf[i++];
                    std::string tag_idx = read_sz();
                    if (subtype == 1) sc.tags.push_back(read_sz());
                    else if (subtype == 2) i += 4;
                }
                if (i < buf.size() && buf[i] == 8) ++i;
            }
        }
        if (i < buf.size() && buf[i] == 8) ++i;
        list.push_back(sc);
    }
    return list;
}

[[maybe_unused]] std::vector<uint8_t> SerializeShortcuts(const std::vector<SteamShortcut>& list) {
    std::vector<uint8_t> out;
    auto write_byte = [&](uint8_t b) { out.push_back(b); };
    auto write_sz = [&](const std::string& s) {
        out.insert(out.end(), s.begin(), s.end());
        out.push_back(0);
    };
    auto write_str = [&](const std::string& key, const std::string& val) {
        write_byte(1);
        write_sz(key);
        write_sz(val);
    };
    auto write_int = [&](const std::string& key, int32_t val) {
        write_byte(2);
        write_sz(key);
        uint8_t b[4];
        std::memcpy(b, &val, 4);
        out.insert(out.end(), b, b + 4);
    };

    write_byte(0);
    write_sz("shortcuts");
    for (size_t idx = 0; idx < list.size(); ++idx) {
        const auto& sc = list[idx];
        write_byte(0);
        write_sz(std::to_string(idx));
        write_int("appid", sc.appid);
        write_str("appname", sc.app_name);
        write_str("exe", sc.exe);
        write_str("StartDir", sc.start_dir);
        write_str("icon", sc.icon);
        write_str("ShortcutPath", sc.shortcut_path);
        write_str("LaunchOptions", sc.launch_options);
        write_int("IsHidden", sc.is_hidden);
        write_int("AllowDesktopConfig", sc.allow_desktop_config);
        write_int("AllowOverlay", sc.allow_overlay);
        write_int("OpenVR", sc.open_vr);
        write_int("Devkit", sc.devkit);
        write_str("DevkitGameID", sc.devkit_game_id);
        write_int("DevkitOverrideAppID", sc.devkit_override_app_id);
        write_int("LastPlayTime", sc.last_play_time);
        write_str("FlatpakAppID", sc.flatpak_app_id);
        write_str("sortas", sc.sortas);
        write_byte(0);
        write_sz("tags");
        for (size_t t = 0; t < sc.tags.size(); ++t) {
            write_byte(1);
            write_sz(std::to_string(t));
            write_sz(sc.tags[t]);
        }
        write_byte(8);
        write_byte(8);
    }
    write_byte(8);
    return out;
}

/// The launcher's name: the packaged executable, the desktop shortcut, Steam's entry and the
/// window all use it. Releases before v0.5.1 shipped CTR-NitroFueled-PC.exe and a desktop
/// shortcut named "CTR Nitro-Fueled".
constexpr const wchar_t* kLauncherName = L"Crash\u2122 Team Racing Nitro-Fueled";
constexpr const wchar_t* kOldLauncherExe = L"CTR-NitroFueled-PC.exe";
constexpr const wchar_t* kOldShortcut = L"CTR Nitro-Fueled.lnk";

/// Where a .lnk points (empty when it cannot be read).
fs::path ShortcutTarget(const fs::path& link) {
    fs::path target;
    IShellLinkW* psl = nullptr;
    if (FAILED(CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLinkW, (void**)&psl)))
        return target;
    IPersistFile* ppf = nullptr;
    if (SUCCEEDED(psl->QueryInterface(IID_IPersistFile, (void**)&ppf))) {
        wchar_t path[MAX_PATH] = {};
        if (SUCCEEDED(ppf->Load(link.c_str(), STGM_READ)) &&
            SUCCEEDED(psl->GetPath(path, MAX_PATH, nullptr, SLGP_RAWPATH)))
            target = path;
        ppf->Release();
    }
    psl->Release();
    return target;
}

/// This executable, whatever it is called.
fs::path LauncherExe() {
    wchar_t path[MAX_PATH];
    const DWORD n = GetModuleFileNameW(nullptr, path, MAX_PATH);
    return fs::path(std::wstring(path, n));
}

bool CreateDesktopShortcut(std::string& out_error) {
    App& a = g_app;
    wchar_t desktop[MAX_PATH];
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_DESKTOPDIRECTORY, nullptr, 0, desktop))) {
        out_error = T("No se pudo obtener la ruta del Escritorio.", "Could not get Desktop path.");
        return false;
    }
    const fs::path target_exe = LauncherExe();
    std::error_code ec;
    // A shortcut of that name may already open something else (another copy of the game, an
    // emulator): never replace it, use the "(PC)" name then.
    const auto ours = [&](const fs::path& link) {
        if (!fs::is_regular_file(link, ec)) return true;
        const fs::path t = ShortcutTarget(link);
        return t.parent_path() == a.root || t == target_exe;
    };
    fs::path link_path = fs::path(desktop) / (std::wstring(kLauncherName) + L".lnk");
    if (!ours(link_path)) link_path = fs::path(desktop) / (std::wstring(kLauncherName) + L" (PC).lnk");
    if (!ours(link_path)) {
        out_error = T("Ya hay accesos directos con ese nombre que abren otra cosa: no se ha cambiado nada.",
                      "Shortcuts with that name already open something else: nothing was changed.");
        return false;
    }

    IShellLinkW* psl = nullptr;
    HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLinkW, (void**)&psl);
    if (FAILED(hr)) {
        out_error = T("Error inicializando IShellLink.", "Error initializing IShellLink.");
        return false;
    }
    psl->SetPath(target_exe.c_str());
    psl->SetArguments(L"--launch");
    psl->SetWorkingDirectory(a.root.c_str());
    psl->SetDescription(kLauncherName);
    psl->SetIconLocation(target_exe.c_str(), 0);  // the icon in the executable

    IPersistFile* ppf = nullptr;
    hr = psl->QueryInterface(IID_IPersistFile, (void**)&ppf);
    if (SUCCEEDED(hr)) {
        hr = ppf->Save(link_path.c_str(), TRUE);
        ppf->Release();
    }
    psl->Release();
    if (FAILED(hr)) {
        out_error = T("No se pudo guardar el acceso directo en el Escritorio.", "Could not save shortcut to Desktop.");
        return false;
    }
    // The shortcut of releases before v0.5.1, when it opened this folder's launcher.
    const fs::path old_link = fs::path(desktop) / kOldShortcut;
    if (fs::is_regular_file(old_link, ec) && ShortcutTarget(old_link).parent_path() == a.root) fs::remove(old_link, ec);
    return true;
}

/// Releases before v0.5.1 called the launcher CTR-NitroFueled-PC.exe. An update unzipped over
/// one keeps that file and its shortcuts: the old executable becomes a copy of this one, so a
/// Steam entry or any other shortcut naming it opens this launcher, and the desktop shortcut
/// made by the old launcher is made again with the new name.
void MigrateOldLauncher() {
    App& a = g_app;
    std::error_code ec;
    const fs::path self = LauncherExe();
    const fs::path old_exe = a.root / kOldLauncherExe;
    if (self.filename() == kOldLauncherExe) return;
    if (fs::is_regular_file(old_exe, ec) &&
        (fs::file_size(old_exe, ec) != fs::file_size(self, ec) || ReadText(old_exe) != ReadText(self)))
        fs::copy_file(self, old_exe, fs::copy_options::overwrite_existing, ec);
    // The desktop shortcut too when the old executable is already gone (deleted by hand).
    wchar_t desktop[MAX_PATH];
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_DESKTOPDIRECTORY, nullptr, 0, desktop))) return;
    const fs::path old_link = fs::path(desktop) / kOldShortcut;
    if (fs::is_regular_file(old_link, ec) && ShortcutTarget(old_link).parent_path() == a.root) {
        std::string error;
        CreateDesktopShortcut(error);
    }
}

[[maybe_unused]] bool AddToSteam(std::string& out_msg) {
    App& a = g_app;
    fs::path steam_path = FindSteamPath();
    if (steam_path.empty()) {
        out_msg = T("No se encontró la instalación de Steam en este equipo.", "Steam installation not found on this computer.");
        return false;
    }
    fs::path userdata = steam_path / L"userdata";
    std::error_code ec;
    if (!fs::is_directory(userdata, ec)) {
        out_msg = T("No se encontró la carpeta userdata de Steam.", "Steam userdata folder not found.");
        return false;
    }

    bool steam_was_running = false;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32W pe{sizeof pe};
        if (Process32FirstW(snap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, L"steam.exe") == 0) {
                    steam_was_running = true;
                    break;
                }
            } while (Process32NextW(snap, &pe));
        }
        CloseHandle(snap);
    }

    if (steam_was_running) {
        fs::path steam_exe = steam_path / L"steam.exe";
        if (fs::is_regular_file(steam_exe, ec)) {
            RunCaptured(steam_exe.wstring(), Quote(steam_exe.wstring()) + L" -shutdown", steam_path, 4000);
            Sleep(1500);
        }
    }

    fs::path assets_dir;
    for (const auto& candidate : {a.root / L"steamgrid", a.root / L"packaging" / L"windows" / L"steamgrid"}) {
        if (fs::is_directory(candidate, ec)) {
            assets_dir = candidate;
            break;
        }
    }

    const fs::path target_exe = LauncherExe();

    const std::string app_name = Narrow(kLauncherName);
    const std::string exe_str = "\"" + PathText(target_exe) + "\"";
    const std::string start_dir_str = "\"" + PathText(a.root) + "\"";

    fs::path icon_path;
    if (!assets_dir.empty() && fs::is_regular_file(assets_dir / L"icono.jpg", ec)) {
        icon_path = assets_dir / L"icono.jpg";
    } else if (fs::is_regular_file(a.root / L"packaging" / L"windows" / L"icons" / L"ctr.ico", ec)) {
        icon_path = a.root / L"packaging" / L"windows" / L"icons" / L"ctr.ico";
    } else {
        icon_path = target_exe;
    }

    const std::string key = exe_str + app_name;
    const uint32_t crc = Crc32(key.data(), key.size());
    const uint32_t appid = crc | 0x80000000;
    const std::string id32 = std::to_string(appid);
    const std::string id64 = std::to_string(((uint64_t)appid << 32) | 0x02000000);

    int profiles_updated = 0;
    for (const auto& entry : fs::directory_iterator(userdata, fs::directory_options::skip_permission_denied, ec)) {
        if (!entry.is_directory()) continue;
        const std::string dirname = entry.path().filename().string();
        if (dirname.empty() || !std::all_of(dirname.begin(), dirname.end(), ::isdigit)) continue;

        fs::path config_dir = entry.path() / L"config";
        fs::path grid_dir = config_dir / L"grid";
        fs::create_directories(grid_dir, ec);

        if (!assets_dir.empty()) {
            const std::pair<const wchar_t*, const char*> mapping[] = {
                {L"portada.png", "p.png"},
                {L"fondo.png", "_hero.png"},
                {L"logo.png", "_logo.png"},
                {L"portada_ancha.png", ".png"},
                {L"icono.jpg", "_icon.jpg"}
            };
            for (const auto& [src_name, suffix] : mapping) {
                fs::path src = assets_dir / src_name;
                if (fs::is_regular_file(src, ec)) {
                    fs::copy_file(src, grid_dir / TextPath(id32 + suffix), fs::copy_options::overwrite_existing, ec);
                    fs::copy_file(src, grid_dir / TextPath(id64 + suffix), fs::copy_options::overwrite_existing, ec);
                }
            }
        }

        fs::path vdf_path = config_dir / L"shortcuts.vdf";
        std::vector<SteamShortcut> shortcuts;
        if (fs::is_regular_file(vdf_path, ec)) {
            std::ifstream f(vdf_path, std::ios::binary);
            if (f) {
                std::vector<uint8_t> buf((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
                shortcuts = ParseShortcuts(buf);
            }
        }

        bool found = false;
        for (auto& sc : shortcuts) {
            if (sc.app_name == app_name || sc.exe.find(PathText(kOldLauncherExe)) != std::string::npos ||
                sc.exe.find(PathText(target_exe.filename())) != std::string::npos) {
                sc.appid = appid;
                sc.app_name = app_name;
                sc.exe = exe_str;
                sc.start_dir = start_dir_str;
                sc.icon = PathText(icon_path);
                sc.launch_options = "--launch";
                found = true;
                break;
            }
        }
        if (!found) {
            SteamShortcut sc;
            sc.appid = appid;
            sc.app_name = app_name;
            sc.exe = exe_str;
            sc.start_dir = start_dir_str;
            sc.icon = PathText(icon_path);
            sc.launch_options = "--launch";
            shortcuts.push_back(sc);
        }

        auto serialized = SerializeShortcuts(shortcuts);
        std::ofstream out(vdf_path, std::ios::binary | std::ios::trunc);
        if (out) {
            out.write(reinterpret_cast<const char*>(serialized.data()), serialized.size());
            profiles_updated++;
        }
    }

    if (profiles_updated > 0) {
        if (steam_was_running) {
            out_msg = T("¡Añadido a Steam con portadas con éxito!\nSteam se cerró automáticamente para aplicar los cambios; vuelve a abrirlo para ver el juego en tu biblioteca.",
                        "Successfully added to Steam with custom artwork!\nSteam was closed automatically to apply changes; reopen it to see the game in your library.");
        } else {
            out_msg = T("¡Añadido a Steam con portadas con éxito!\nAbre Steam para ver el juego en tu biblioteca.",
                        "Successfully added to Steam with custom artwork!\nOpen Steam to see the game in your library.");
        }
        return true;
    } else {
        out_msg = T("No se encontró ningún perfil de usuario en Steam.", "No user profiles found in Steam.");
        return false;
    }
}

// ---------------------------------------------------------------------------------------------
// Updates (port_update.cpp): the latest published release's Windows ZIP, downloaded into
// update\, checked (size, SHA-256), unpacked with the bundled Python and copied over the port.
// Settings, the online key, friends, saves, backups, DLC, logs and the player's own patches are
// never in the package and never written; replaced files go to update\rollback\ first.

struct UpdateState {
    // Dismissed: a newer release the player chose not to install now (Tools offers it again).
    enum Stage { Idle, Checking, UpToDate, Available, Dismissed, Downloading, Unpacking, Installing, Done, Failed };
    std::mutex mutex;
    std::atomic<int> stage{Idle};
    PortUpdate::Release release;  // under mutex
    std::string error;            // under mutex
    PortUpdate::Progress progress;
    std::thread worker;
    std::atomic<bool> auto_install{false};  // install as soon as the check finds a newer release
    bool restart_sent = false;
};
UpdateState g_update;

bool UpdateBusy() {
    const int s = g_update.stage;
    return s == UpdateState::Checking || s == UpdateState::Downloading || s == UpdateState::Unpacking ||
           s == UpdateState::Installing || s == UpdateState::Done;
}

fs::path UpdateDir() { return g_app.root / L"update"; }

void UpdateFail(const std::string& error) {
    {
        std::scoped_lock lock{g_update.mutex};
        g_update.error = error;
    }
    g_update.stage = UpdateState::Failed;
}

void StartUpdateInstall();

/// Asks GitHub for the latest release; with auto_install a newer one is installed at once.
void StartUpdateCheck(bool auto_install) {
    if (UpdateBusy()) return;
    if (g_update.worker.joinable()) g_update.worker.join();
    g_update.stage = UpdateState::Checking;
    g_update.auto_install = auto_install;
    const std::string current = g_app.version;
    g_update.worker = std::thread([current, auto_install] {
        std::string error;
        const std::string url = std::string("https://api.github.com/repos/") + PortUpdate::kRepo + "/releases/latest";
        const auto body = PortUpdate::FetchText(Widen(url), &error);
        if (!body) {
            UpdateFail(std::string(T("No se pudo consultar GitHub: ", "Could not ask GitHub: ")) + error);
            return;
        }
        const auto release = PortUpdate::ParseRelease(*body);
        if (!release) {
            UpdateFail(T("GitHub no devolvió una versión para Windows.", "GitHub returned no Windows release."));
            return;
        }
        {
            std::scoped_lock lock{g_update.mutex};
            g_update.release = *release;
            g_update.error.clear();
        }
        const auto have = PortUpdate::ParseVersion(current);
        const auto latest = PortUpdate::ParseVersion(release->tag);
        if (!have.valid || !PortUpdate::IsNewer(have, latest)) {
            g_update.stage = UpdateState::UpToDate;
            return;
        }
        g_update.stage = UpdateState::Available;  // PollUpdate starts an automatic install
    });
}

void StartUpdateInstall() {
    App& a = g_app;
    if (g_update.stage != UpdateState::Available && g_update.stage != UpdateState::Dismissed &&
        g_update.stage != UpdateState::Failed)
        return;
    if (a.game_running) {
        a.notice = T("Cierra el juego para actualizar.", "Close the game to update.");
        return;
    }
    if (!a.python) {
        UpdateFail(T("Falta Python para descomprimir la actualización.", "Python is missing to unpack the update."));
        return;
    }
    PortUpdate::Release release;
    {
        std::scoped_lock lock{g_update.mutex};
        release = g_update.release;
        g_update.error.clear();
    }
    if (release.asset_url.empty()) return;
    if (g_update.worker.joinable()) g_update.worker.join();
    g_update.progress.cancel = false;
    g_update.stage = UpdateState::Downloading;
    const fs::path root = a.root;
    const Python python = *a.python;
    g_update.worker = std::thread([release, root, python] {
        const fs::path dir = root / L"update";
        const fs::path zip = dir / Widen(release.asset_name);
        const fs::path staging = dir / L"staging";
        std::error_code ec;
        fs::remove_all(staging, ec);
        std::string error = PortUpdate::Download(Widen(release.asset_url), zip, release.size, release.sha256,
                                                 g_update.progress);
        if (!error.empty()) {
            UpdateFail(std::string(T("La descarga falló: ", "The download failed: ")) + error);
            return;
        }
        g_update.stage = UpdateState::Unpacking;
        const std::wstring cmd = Quote(python.exe) + L" " + python.args + L"-I -X utf8 -c " +
                                 Quote(L"import sys,zipfile; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])") +
                                 L" " + Quote(zip.wstring()) + L" " + Quote(staging.wstring());
        const Captured r = RunCaptured(python.exe, cmd, dir, 600000);
        const fs::path package = staging / PortUpdate::kPackageFolder;
        const std::string unpacked_version = Trim(ReadText(package / L"bin" / L"VERSION"));
        if (!r.started || r.code != 0 || !fs::is_regular_file(package / L"bin" / L"sacredfire.exe", ec) ||
            !PortUpdate::ParseVersion(unpacked_version).valid) {
            fs::remove_all(staging, ec);
            UpdateFail(std::string(T("No se pudo descomprimir la actualización. ", "Could not unpack the update. ")) +
                       Trim(r.output).substr(0, 300));
            return;
        }
        if (g_app.game_running) {
            UpdateFail(T("Cierra el juego para actualizar.", "Close the game to update."));
            return;
        }
        g_update.stage = UpdateState::Installing;
        error = PortUpdate::Install(package, root, dir / L"rollback");
        fs::remove_all(staging, ec);
        if (!error.empty()) {
            UpdateFail(std::string(T("No se pudo instalar (todo quedó como estaba): ",
                                     "Could not install (everything was put back): ")) + error);
            return;
        }
        fs::remove(zip, ec);
        g_update.stage = UpdateState::Done;
    });
}

/// Every frame: an automatic update starts once the check found one; a finished install
/// restarts the launcher in its new version.
void PollUpdate() {
    App& a = g_app;
    if (g_update.auto_install && g_update.stage != UpdateState::Checking) {
        g_update.auto_install = false;
        if (g_update.stage == UpdateState::Available && !a.game_running) StartUpdateInstall();
    }
    if (g_update.stage == UpdateState::Done && !g_update.restart_sent) {
        g_update.restart_sent = true;
        SaveLauncher();
        wchar_t self[MAX_PATH * 4]{};
        GetModuleFileNameW(nullptr, self, DWORD(std::size(self)));
        fs::path exe = self;
        // The packaged launcher's name, if the running one is an older name next to it.
        std::error_code ec;
        const fs::path packaged = a.root / (std::wstring(kLauncherName) + L".exe");
        if (fs::is_regular_file(packaged, ec)) exe = packaged;
        std::wstring cmd = Quote(exe.wstring()) + L" --updated";
        STARTUPINFOW si{sizeof si};
        PROCESS_INFORMATION pi{};
        if (CreateProcessW(exe.c_str(), cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, a.root.c_str(), &si, &pi)) {
            CloseHandle(pi.hThread);
            CloseHandle(pi.hProcess);
            PostQuitMessage(0);
        } else {
            a.notice = T("Actualizado. Cierra y vuelve a abrir el launcher.", "Updated. Close and open the launcher again.");
        }
    }
}

/// At start: the previous update's leftovers (the old launcher in rollback\ may still be running
/// for a moment, so this retries in the background).
void CleanupUpdate() {
    const fs::path dir = UpdateDir();
    std::error_code ec;
    if (!fs::is_directory(dir, ec)) return;
    std::thread([dir] {
        for (int attempt = 0; attempt < 20; ++attempt) {
            std::error_code e;
            fs::remove_all(dir / L"rollback", e);
            fs::remove_all(dir / L"staging", e);
            if (!fs::exists(dir / L"rollback", e) && !fs::exists(dir / L"staging", e)) break;
            Sleep(500);
        }
        std::error_code e;
        fs::remove(dir, e);  // only when empty (a download in progress keeps it)
    }).detach();
}

/// The update line under the header: a newer version, the progress, or what went wrong.
void UpdateBanner() {
    const int stage = g_update.stage;
    if (stage == UpdateState::Idle || stage == UpdateState::Checking || stage == UpdateState::UpToDate ||
        stage == UpdateState::Dismissed)
        return;
    PortUpdate::Release release;
    std::string error;
    {
        std::scoped_lock lock{g_update.mutex};
        release = g_update.release;
        error = g_update.error;
    }
    if (stage == UpdateState::Available) {
        ImGui::TextColored(kGreen, "%s", Format(T("Hay una versión nueva: %s (tienes %s).", "A new version is out: %s (you have %s)."),
                                                release.tag, g_app.version).c_str());
        ImGui::SameLine();
        ImGui::BeginDisabled(g_app.game_running);
        if (ImGui::SmallButton(T("Actualizar ahora", "Update now"))) StartUpdateInstall();
        ImGui::EndDisabled();
        ImGui::SameLine();
        if (ImGui::SmallButton(T("Novedades", "What's new"))) OpenInShell(Widen(release.page_url));
        ImGui::SameLine();
        if (ImGui::SmallButton(T("Ahora no", "Not now"))) g_update.stage = UpdateState::Dismissed;
    } else if (stage == UpdateState::Downloading) {
        const double total = double(std::max<std::uint64_t>(1, g_update.progress.total));
        const float fraction = float(double(g_update.progress.done) / total);
        ImGui::TextColored(kGrey, "%s", Format(T("Descargando %s...", "Downloading %s..."), release.tag).c_str());
        ImGui::SameLine();
        char text[64];
        std::snprintf(text, sizeof text, "%.0f / %.0f MB", double(g_update.progress.done) / 1e6, total / 1e6);
        ImGui::ProgressBar(fraction, ImVec2(ImGui::GetFontSize() * 14.0f, 0.0f), text);
        ImGui::SameLine();
        if (ImGui::SmallButton(T("Cancelar", "Cancel"))) g_update.progress.cancel = true;
    } else if (stage == UpdateState::Unpacking || stage == UpdateState::Installing) {
        ImGui::TextColored(kGrey, "%s", stage == UpdateState::Unpacking ? T("Descomprimiendo la actualización...", "Unpacking the update...")
                                                                       : T("Instalando la actualización...", "Installing the update..."));
    } else if (stage == UpdateState::Done) {
        ImGui::TextColored(kGreen, "%s", T("Actualizado: reiniciando el launcher...", "Updated: restarting the launcher..."));
    } else if (stage == UpdateState::Failed) {
        ImGui::TextColored(kYellow, "%s", error.c_str());
        ImGui::SameLine();
        if (!release.asset_url.empty() && ImGui::SmallButton(T("Reintentar", "Retry"))) StartUpdateInstall();
        ImGui::SameLine();
        if (ImGui::SmallButton("OK")) g_update.stage = UpdateState::Idle;
    }
}

void UpdateSection() {
    App& a = g_app;
    ImGui::SeparatorText(T("Actualizaciones", "Updates"));
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextColored(kGrey, "%s",
                       T("Descarga la última versión publicada en GitHub y la instala encima. Tus ajustes, amigos, apodo, "
                         "parches propios, partidas, copias, DLC y registros se mantienen: la actualización solo cambia "
                         "los archivos del port. Si algo falla, todo vuelve a como estaba.",
                         "Downloads the latest release published on GitHub and installs it over this one. Your settings, "
                         "friends, nickname, own patches, saves, backups, DLC and logs are kept: the update only changes "
                         "the port's files. If anything fails, everything is put back."));
    ImGui::PopTextWrapPos();
    ImGui::Text("%s %s", T("Versión instalada:", "Installed version:"), a.version.c_str());
    const int stage = g_update.stage;
    ImGui::BeginDisabled(UpdateBusy());
    if (ImGui::Button(T("Comprobar actualizaciones", "Check for updates"))) StartUpdateCheck(false);
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (stage == UpdateState::Available || stage == UpdateState::Dismissed) {
        PortUpdate::Release release;
        {
            std::scoped_lock lock{g_update.mutex};
            release = g_update.release;
        }
        ImGui::TextColored(kGreen, "%s", Format(T("Versión nueva: %s", "New version: %s"), release.tag).c_str());
        ImGui::TextUnformatted(T("¿Quieres actualizar ahora?", "Do you want to update now?"));
        ImGui::BeginDisabled(a.game_running);
        if (ImGui::Button(T("Actualizar ahora", "Update now"))) StartUpdateInstall();
        ImGui::EndDisabled();
        ImGui::SameLine();
        if (stage == UpdateState::Available && ImGui::Button(T("Ahora no", "Not now")))
            g_update.stage = UpdateState::Dismissed;
        ImGui::SameLine();
        if (ImGui::Button(T("Novedades", "What's new"))) OpenInShell(Widen(release.page_url));
        if (a.game_running)
            ImGui::TextColored(kGrey, "%s", T("Cierra el juego para actualizar.", "Close the game to update."));
    } else if (stage == UpdateState::Checking) {
        ImGui::TextColored(kGrey, "%s", T("Consultando GitHub...", "Asking GitHub..."));
    } else if (stage == UpdateState::UpToDate) {
        std::string tag;
        {
            std::scoped_lock lock{g_update.mutex};
            tag = g_update.release.tag;
        }
        ImGui::TextColored(kGreen, "%s", Format(T("Estás al día (última versión: %s).", "You are up to date (latest: %s)."), tag).c_str());
    } else if (stage != UpdateState::Idle) {
        ImGui::TextColored(kGrey, "%s", T("Mira el aviso de arriba.", "See the notice at the top."));
    }
    LauncherFlag("update_check", T("Buscar actualizaciones al abrir el launcher", "Check for updates when the launcher opens"), true,
                 T("Una consulta pequeña a GitHub al abrir. No descarga nada sin tu permiso, salvo que actives la opción de abajo.",
                   "A small request to GitHub at start. Nothing is downloaded without your say, unless the option below is on."));
    LauncherFlag("update_auto", T("Instalar las actualizaciones automáticamente", "Install updates automatically"), false,
                 T("Al abrir el launcher, si hay una versión nueva se descarga e instala sola y el launcher se reinicia. "
                   "Nunca mientras juegas. Si abres el juego directo (acceso directo o Steam), no se actualiza.",
                   "When the launcher opens and a new version is out, it is downloaded and installed and the launcher "
                   "restarts. Never while you play. Starting straight into the game (shortcut, Steam) does not update."));
}

void ToolsTab() {
    App& a = g_app;
    UpdateSection();
    ImGui::SeparatorText(T("Carpetas y registro", "Folders and log"));
    if (ImGui::Button(T("Abrir last_run.log", "Open last_run.log"))) OpenInShell(a.root / L"last_run.log");
    ImGui::SameLine();
    if (ImGui::Button(T("Abrir la carpeta del port", "Open the port folder"))) OpenInShell(a.root);
    ImGui::SameLine();
    if (ImGui::Button(T("Abrir partidas guardadas", "Open saves"))) {
        std::error_code ec;
        fs::create_directories(a.root / L"user", ec);
        OpenInShell(a.root / L"user");
    }
    LauncherFlag("save_log", T("Guardar registro detallado (logs\\, con estadísticas de fotogramas)",
                               "Save a detailed log (logs\\, with frame statistics)"), false,
                 T("Para reportar fallos o tirones: adjunta el archivo de logs\\ en un issue.",
                   "To report crashes or stutter: attach the file from logs\\ to an issue."));

    ImGui::SeparatorText(T("Acceso directo", "Desktop shortcut"));
    if (ImGui::Button(T("Crear acceso directo en el Escritorio", "Create Desktop Shortcut"))) {
        std::string err;
        if (CreateDesktopShortcut(err)) {
            a.notice = T("Acceso directo creado en el Escritorio con éxito (inicia directo sin el launcher).",
                         "Desktop shortcut created successfully (launches directly without launcher).");
        } else {
            a.notice = err;
        }
    }
    HelpMarker(T("Crea un acceso directo en tu Escritorio para iniciar directamente el juego con su icono sin abrir la ventana del launcher.",
                 "Creates a shortcut on your Desktop to start the game directly with its icon without the launcher window."));

    ImGui::SeparatorText(T("Caché de shaders", "Shader cache"));
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextColored(kGrey, "%s", T("Los shaders se guardan para que los siguientes arranques vayan fluidos. Bórrala solo si "
                                      "actualizaste el driver de la GPU o ves fallos gráficos.",
                                      "Shaders are kept so later sessions run smoothly. Clear it only after a GPU driver "
                                      "update or if you see graphics glitches."));
    ImGui::PopTextWrapPos();
    ImGui::BeginDisabled(a.game_running);
    if (ImGui::Button(T("Borrar la caché de shaders", "Clear the shader cache"))) a.confirm_clear_cache = true;
    ImGui::EndDisabled();

    ImGui::SeparatorText(T("Idioma del launcher", "Launcher language"));
    const char* language_names[] = {"Auto (Windows)", "English", "Español", "Português (Brasil)", "Français",
                                    "Deutsch", "Italiano", "日本語", "简体中文", "Русский"};
    const char* language_codes[] = {"auto", "en", "es", "pt_BR", "fr", "de", "it", "ja", "zh_CN", "ru"};
    int selected_language = 0;
    for (int i = 0; i < 10; ++i) if (g_language == language_codes[i]) selected_language = i;
    if (ImGui::Combo(T("Idioma", "Language"), &selected_language, language_names, 10)) {
        g_language = language_codes[selected_language];
        ApplyLauncherLanguage();
        SaveLauncher();
    }

    ImGui::SeparatorText(T("Acerca de", "About"));
    ImGui::Text("CTR-NitroFueled-PC %s", a.version.c_str());
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextUnformatted(T("Fork de Windows de SacredFire (T3CHNOLOG1C), basado en bbport (deadinside28), el port de Windows "
                             "de Supermedo y shadPS4. Parches de illusion y TroyWarez. Sin afiliación con Sony, Activision "
                             "ni Beenox. Licencia GPL v2 o posterior.",
                             "Windows fork of SacredFire (T3CHNOLOG1C), built on bbport (deadinside28), Supermedo's Windows "
                             "port and shadPS4. Patches by illusion and TroyWarez. Not affiliated with Sony, Activision or "
                             "Beenox. GPL v2 or later."));
    ImGui::Spacing();
    ImGui::TextUnformatted(T("Escalado temporal: AMD FidelityFX FSR 3.1 (MIT) y NVIDIA DLSS. DLSS usa el SDK de "
                             "NVIDIA DLSS (nvngx_dlss.dll, redistribuido según su licencia, en licenses\\) a través del "
                             "puente de IFreemz (MIT). NVIDIA, DLSS y GeForce RTX son marcas de NVIDIA Corporation.",
                             "Temporal upscaling: AMD FidelityFX FSR 3.1 (MIT) and NVIDIA DLSS. DLSS uses the NVIDIA DLSS "
                             "SDK (nvngx_dlss.dll, redistributed under its license, in licenses\\) through IFreemz's "
                             "bridge (MIT). NVIDIA, DLSS and GeForce RTX are trademarks of NVIDIA Corporation."));
    ImGui::PopTextWrapPos();
    {
        std::error_code ec;
        const bool dlss = fs::is_regular_file(a.root / L"bin" / L"sacredfire_dlss.dll", ec) &&
                          fs::is_regular_file(a.root / L"bin" / L"nvngx_dlss.dll", ec);
        ImGui::TextColored(kGrey, "%s", dlss ? T("DLSS: archivos presentes (necesita una tarjeta NVIDIA RTX)",
                                                 "DLSS: files present (needs an NVIDIA RTX card)")
                                             : T("DLSS: archivos no incluidos (se usa FSR 3)",
                                                 "DLSS: files not included (FSR 3 is used)"));
    }
    ImGui::TextLinkOpenURL(kRepoUrl, kRepoUrl);
    if (a.python) ImGui::TextColored(kGrey, "Python: %s", a.python->description.c_str());
}

void ClearShaderCache() {
    std::error_code ec;
    const fs::path cache = g_app.root / L"user" / L"cache" / GameTitle();
    const auto removed = fs::remove_all(cache, ec);
    g_app.notice = ec ? std::string(T("No se pudo borrar la caché: ", "Could not clear the cache: ")) + ec.message()
                      : std::string(T("Caché borrada (", "Cache cleared (")) + std::to_string(removed) +
                            T(" archivos).", " files).");
}

void HeroHeader() {
    const ImVec2 origin = ImGui::GetCursorScreenPos();
    const float width = ImGui::GetContentRegionAvail().x;
    const float height = 270.0f;
    const ImVec2 end{origin.x + width, origin.y + height};
    ImDrawList* draw = ImGui::GetWindowDrawList();
    if (g_hero_art.texture) {
        const float image_aspect = float(g_hero_art.width) / float(g_hero_art.height);
        const float view_aspect = width / height;
        ImVec2 uv0{0.0f, 0.0f}, uv1{1.0f, 1.0f};
        if (image_aspect < view_aspect) {
            const float visible = image_aspect / view_aspect;
            uv0.y = (1.0f - visible) * 0.5f;
            uv1.y = 1.0f - uv0.y;
        } else {
            const float visible = view_aspect / image_aspect;
            uv0.x = (1.0f - visible) * 0.5f;
            uv1.x = 1.0f - uv0.x;
        }
        draw->AddImage((ImTextureID)(intptr_t)g_hero_art.texture, origin, end, uv0, uv1);
    } else {
        draw->AddRectFilled(origin, end, IM_COL32(48, 32, 20, 255));
    }
    if (g_logo_art.texture) {
        const float max_w = std::min(width * 0.34f, 390.0f);
        const float max_h = height * 0.78f;
        const float aspect = float(g_logo_art.width) / float(g_logo_art.height);
        float logo_w = max_w, logo_h = logo_w / aspect;
        if (logo_h > max_h) { logo_h = max_h; logo_w = logo_h * aspect; }
        const ImVec2 lo{origin.x + 28.0f, origin.y + (height - logo_h) * 0.5f};
        const ImVec2 hi{lo.x + logo_w, lo.y + logo_h};
        draw->AddImage((ImTextureID)(intptr_t)g_logo_art.texture, lo, hi);
    }
    draw->AddRectFilled(ImVec2(origin.x, end.y - 4.0f), end, IM_COL32(238, 169, 48, 255));
    ImGui::Dummy(ImVec2(width, height));
}

void WindowBar(float width) {
    const float height = 40.0f;
    ImGui::SetCursorPos(ImVec2(0, 0));
    const ImVec2 p = ImGui::GetWindowPos();
    ImDrawList* draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(p, ImVec2(p.x + width, p.y + height), IM_COL32(7, 72, 145, 255));
    draw->AddRectFilled(ImVec2(p.x, p.y + height - 1), ImVec2(p.x + width, p.y + height),
                        IM_COL32(44, 166, 228, 255));
    const float bw = 42.0f, bh = 30.0f, gap = 3.0f;
    const float left = width - 3.0f * bw - 2.0f * gap - 8.0f;
    auto button = [&](const char* id, int kind) {
        ImGui::SetCursorPos(ImVec2(left + kind * (bw + gap), 5.0f));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.04f, 0.25f, 0.47f, 1));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.08f, 0.40f, 0.66f, 1));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.10f, 0.55f, 0.78f, 1));
        const bool clicked = ImGui::Button(id, ImVec2(bw, bh));
        ImGui::PopStyleColor(3);
        const ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();
        const ImVec2 c{(a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f};
        const ImU32 ink = IM_COL32(255, 234, 198, 255);
        if (kind == 0) draw->AddLine(ImVec2(c.x - 5, c.y), ImVec2(c.x + 5, c.y), ink, 1.6f);
        else if (kind == 1) draw->AddRect(ImVec2(c.x - 5, c.y - 5), ImVec2(c.x + 5, c.y + 5), ink, 0, 0, 1.4f);
        else {
            draw->AddLine(ImVec2(c.x - 5, c.y - 5), ImVec2(c.x + 5, c.y + 5), ink, 1.6f);
            draw->AddLine(ImVec2(c.x + 5, c.y - 5), ImVec2(c.x - 5, c.y + 5), ink, 1.6f);
        }
        return clicked;
    };
    if (button("##minimize", 0)) ShowWindow(g_app.hwnd, SW_MINIMIZE);
    if (button("##maximize", 1)) ShowWindow(g_app.hwnd, IsZoomed(g_app.hwnd) ? SW_RESTORE : SW_MAXIMIZE);
    if (button("##close", 2)) SendMessageW(g_app.hwnd, WM_CLOSE, 0, 0);
    RECT client{};
    GetClientRect(g_app.hwnd, &client);
    g_titlebar_drag = RECT{0, 0, std::max<LONG>(0, client.right - LONG(3 * bw + 2 * gap + 8)), LONG(height)};
    ImGui::SetCursorPos(ImVec2(14, height + 10));
}

bool LoadArtworkFile(const fs::path& path, LauncherArtwork& artwork) {
    if (!g_device || !fs::is_regular_file(path)) return false;
    IWICImagingFactory* factory = nullptr;
    IWICBitmapDecoder* decoder = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICFormatConverter* converter = nullptr;
    ID3D11Texture2D* texture = nullptr;
    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&factory));
    if (SUCCEEDED(hr)) hr = factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ,
                                                                WICDecodeMetadataCacheOnLoad, &decoder);
    if (SUCCEEDED(hr)) hr = decoder->GetFrame(0, &frame);
    if (SUCCEEDED(hr)) hr = factory->CreateFormatConverter(&converter);
    if (SUCCEEDED(hr)) hr = converter->Initialize(frame, GUID_WICPixelFormat32bppRGBA,
        WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom);
    UINT w = 0, h = 0;
    if (SUCCEEDED(hr)) hr = converter->GetSize(&w, &h);
    std::vector<BYTE> pixels(size_t(w) * h * 4);
    if (SUCCEEDED(hr)) hr = converter->CopyPixels(nullptr, w * 4, UINT(pixels.size()), pixels.data());
    if (SUCCEEDED(hr)) {
        D3D11_TEXTURE2D_DESC td{}; td.Width = w; td.Height = h; td.MipLevels = 1; td.ArraySize = 1;
        td.Format = DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count = 1; td.Usage = D3D11_USAGE_DEFAULT;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sd{pixels.data(), w * 4, 0};
        hr = g_device->CreateTexture2D(&td, &sd, &texture);
    }
    if (SUCCEEDED(hr)) hr = g_device->CreateShaderResourceView(texture, nullptr, &artwork.texture);
    if (texture) texture->Release(); if (converter) converter->Release(); if (frame) frame->Release();
    if (decoder) decoder->Release(); if (factory) factory->Release();
    if (FAILED(hr)) { artwork = {}; return false; }
    artwork.width = w; artwork.height = h; return true;
}

void LoadArtwork() {
    const fs::path art = g_app.root / L"art";
    LoadArtworkFile(art / L"ctr-hero.png", g_hero_art);
    LoadArtworkFile(art / L"ctr-logo.png", g_logo_art);
    LoadArtworkFile(art / L"ctr-menu-background.png", g_menu_background);
}

void ReleaseArtwork() {
    for (auto* a : {&g_hero_art, &g_logo_art, &g_menu_background}) {
        if (a->texture) a->texture->Release();
        *a = {};
    }
}

void DrawMenuIcon(ImDrawList* d, int id, ImVec2 c, ImU32 ink, float s) {
    const ImU32 navy = IM_COL32(6, 39, 89, 255);
    auto line = [&](ImVec2 a, ImVec2 b, float t = 2.2f) { d->AddLine(a, b, navy, t * s); d->AddLine(a, b, ink, t * s * 0.58f); };
    if (id == 0) { // checkered flag / race
        line({c.x-7*s,c.y+8*s},{c.x-7*s,c.y-8*s},2.5f); d->AddRectFilled({c.x-5*s,c.y-8*s},{c.x+8*s,c.y+1*s},ink,1.5f*s);
        d->AddRectFilled({c.x-2*s,c.y-8*s},{c.x+1*s,c.y-3.5f*s},navy); d->AddRectFilled({c.x+4*s,c.y-3.5f*s},{c.x+7*s,c.y+1*s},navy);
    } else if (id == 1) { // gear
        d->AddCircleFilled(c,7*s,navy,12); d->AddCircleFilled(c,5.5f*s,ink,12); d->AddCircleFilled(c,2*s,navy,12);
        for (int i=0;i<8;++i) { float a=float(i)*0.785398f; ImVec2 p{c.x+7*s*std::cos(a),c.y+7*s*std::sin(a)}; d->AddCircleFilled(p,1.6f*s,ink,8); }
    } else if (id == 2) { // wireless
        d->PathArcTo({c.x,c.y+5*s},8*s,3.85f,5.58f,18); d->PathStroke(navy,0,4*s); d->PathArcTo({c.x,c.y+5*s},8*s,3.85f,5.58f,18); d->PathStroke(ink,0,2.2f*s);
        d->PathArcTo({c.x,c.y+5*s},5*s,3.85f,5.58f,18); d->PathStroke(ink,0,2*s); d->AddCircleFilled({c.x,c.y+5*s},1.7f*s,ink,10);
    } else if (id == 3) { // gamepad
        d->AddRect({c.x-9*s,c.y-5*s},{c.x+9*s,c.y+6*s},navy,5*s,0,3*s); d->AddRect({c.x-8*s,c.y-4*s},{c.x+8*s,c.y+5*s},ink,4*s,0,2*s);
        line({c.x-5*s,c.y},{c.x-1*s,c.y},2); line({c.x-3*s,c.y-2*s},{c.x-3*s,c.y+2*s},2); d->AddCircleFilled({c.x+4*s,c.y-1*s},1.4f*s,navy); d->AddCircleFilled({c.x+6*s,c.y+2*s},1.4f*s,navy);
    } else if (id == 4) { // keyboard
        d->AddRectFilled({c.x-9*s,c.y-6*s},{c.x+9*s,c.y+6*s},navy,2*s); d->AddRectFilled({c.x-7*s,c.y-4*s},{c.x+7*s,c.y+4*s},ink,1*s);
        for(int r=0;r<2;++r) for(int col=0;col<5;++col) d->AddRectFilled({c.x-6*s+col*2.5f*s,c.y-3*s+r*3*s},{c.x-4.5f*s+col*2.5f*s,c.y-1.8f*s+r*3*s},navy,0.4f*s);
    } else if (id == 5) { // patch badge
        const ImVec2 pts[]={{c.x,c.y-9*s},{c.x+8*s,c.y-6*s},{c.x+7*s,c.y+3*s},{c.x,c.y+9*s},{c.x-7*s,c.y+3*s},{c.x-8*s,c.y-6*s}};
        d->AddConvexPolyFilled(pts,6,navy); const ImVec2 in[]={{c.x,c.y-7*s},{c.x+6*s,c.y-4.5f*s},{c.x+5*s,c.y+2*s},{c.x,c.y+7*s},{c.x-5*s,c.y+2*s},{c.x-6*s,c.y-4.5f*s}}; d->AddConvexPolyFilled(in,6,ink);
        line({c.x-3*s,c.y},{c.x-0.5f*s,c.y+2.5f*s},2.4f); line({c.x-0.5f*s,c.y+2.5f*s},{c.x+4*s,c.y-3*s},2.4f);
    } else if (id == 6) { // save card
        d->AddRectFilled({c.x-7*s,c.y-9*s},{c.x+7*s,c.y+9*s},navy,1*s); d->AddRectFilled({c.x-5.5f*s,c.y-7*s},{c.x+5.5f*s,c.y+7*s},ink,0.8f*s);
        d->AddRectFilled({c.x-3.5f*s,c.y-6*s},{c.x+3.5f*s,c.y-2*s},navy); d->AddRectFilled({c.x-3.5f*s,c.y+1*s},{c.x+3.5f*s,c.y+5*s},navy,0.6f*s);
    } else if (id == 7) { // crate
        d->AddRectFilled({c.x-8*s,c.y-7*s},{c.x+8*s,c.y+7*s},navy,1*s); d->AddRectFilled({c.x-6*s,c.y-5*s},{c.x+6*s,c.y+5*s},ink,1*s);
        d->AddRect({c.x-4*s,c.y-3*s},{c.x+4*s,c.y+3*s},navy,0,0,1.6f*s); d->AddLine({c.x-2*s,c.y+1*s},{c.x,c.y-2*s},navy,1.8f*s); d->AddLine({c.x,c.y-2*s},{c.x+2*s,c.y+1*s},navy,1.8f*s);
    } else { // crossed tools
        line({c.x-7*s,c.y-7*s},{c.x+7*s,c.y+7*s},3); line({c.x+7*s,c.y-7*s},{c.x-7*s,c.y+7*s},3); d->AddCircleFilled(c,2.5f*s,ink,12);
    }
}

bool MenuEntry(int id, const char* label, bool selected, float width) {
    const ImVec2 start = ImGui::GetCursorScreenPos();
    const ImVec2 size{width, 44.0f};
    const bool clicked = ImGui::InvisibleButton(label, size);
    const bool hovered = ImGui::IsItemHovered();
    const ImVec2 a{start.x, start.y}, b{start.x + size.x, start.y + size.y};
    ImDrawList* d = ImGui::GetWindowDrawList();
    const double now = ImGui::GetTime();
    static double selected_since = 0.0;
    static int last_selected = -1;
    if (selected && last_selected != id) { last_selected = id; selected_since = now; }
    const float t = selected ? std::clamp(float((now - selected_since) / 0.26), 0.0f, 1.0f) : 1.0f;
    const float ease = 1.0f - (1.0f-t)*(1.0f-t);
    const float slide = selected ? (1.0f-ease) * -13.0f : 0.0f;
    ImVec2 p0{a.x+slide,a.y+4}, p1{b.x+slide-10,a.y+4}, p2{b.x+slide,a.y+size.y-4}, p3{a.x+slide+10,a.y+size.y-4};
    const ImU32 shadow=IM_COL32(0,31,79,95), dark=hovered?IM_COL32(7,65,130,218):IM_COL32(6,55,113,178);
    const ImVec2 sh[]={ImVec2(p0.x,p0.y+3),ImVec2(p1.x,p1.y+3),ImVec2(p2.x,p2.y+3),ImVec2(p3.x,p3.y+3)};
    d->AddConvexPolyFilled(sh,4,shadow);
    const ImVec2 poly[]={p0,p1,p2,p3};
    d->AddConvexPolyFilled(poly,4,selected?IM_COL32(234,250,255,248):dark);
    if (selected) {
        d->AddPolyline(poly,4,IM_COL32(255,255,255,215),ImDrawFlags_Closed,1.6f);
        d->AddRectFilled({p3.x+3,p3.y-1},{p3.x+8,p3.y+1},IM_COL32(29,211,255,255));
        const float elapsed = float(now-selected_since);
        if (elapsed < 0.42f) {
            const float shine = std::clamp(elapsed / 0.42f, 0.0f, 1.0f);
            const float sx = a.x+slide+12.0f+shine*(size.x-54.0f);
            d->PushClipRect({p0.x,p0.y},{p2.x,p2.y},true);
            d->AddLine({sx,p0.y+5},{sx+13,p2.y-5},IM_COL32(255,255,255,110),2.0f);
            d->PopClipRect();
        }
    }
    const ImVec2 icon{a.x+31.0f+slide,a.y+size.y*0.5f};
    DrawMenuIcon(d,id,icon,selected?IM_COL32(9,64,112,255):IM_COL32(234,249,255,235),0.75f);
    ImFont* label_font = g_ctr_font ? g_ctr_font : ImGui::GetFont();
    const float label_font_size = ImGui::GetFontSize();
    const ImVec2 text_size=label_font->CalcTextSizeA(label_font_size, FLT_MAX, 0.0f, label);
    const ImVec2 text{a.x+55.0f+slide,a.y+(size.y-text_size.y)*0.5f};
    d->AddText(label_font,label_font_size,text,selected?IM_COL32(4,46,84,255):IM_COL32(237,249,255,245),label);
    return clicked;
}

void Frame() {
    App& a = g_app;
    PollJobs();
    PollUpdate();
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->WorkPos);
    ImGui::SetNextWindowSize(vp->WorkSize);
    ImGui::Begin("launcher", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                     ImGuiWindowFlags_NoBringToFrontOnFocus);
    if (g_menu_background.texture) {
        const float wa=vp->WorkSize.x/vp->WorkSize.y;
        const float ia=float(g_menu_background.width)/float(g_menu_background.height);
        ImVec2 uv0{0,0},uv1{1,1};
        if (ia>wa) { const float v=wa/ia; uv0.x=(1-v)*0.5f; uv1.x=1-uv0.x; }
        else { const float v=ia/wa; uv0.y=(1-v)*0.5f; uv1.y=1-uv0.y; }
        ImGui::GetWindowDrawList()->AddImage((ImTextureID)(intptr_t)g_menu_background.texture,
                                             vp->WorkPos, ImVec2(vp->WorkPos.x + vp->WorkSize.x,
                                                                 vp->WorkPos.y + vp->WorkSize.y),uv0,uv1);
    }
    const float width = ImGui::GetWindowSize().x;
    WindowBar(width);
    HeroHeader();

    if (!a.notice.empty()) {
        ImGui::TextColored(kYellow, "%s", a.notice.c_str());
        ImGui::SameLine();
        if (ImGui::SmallButton("OK")) a.notice.clear();
    }
    UpdateBanner();

    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.025f, 0.19f, 0.40f, 0.78f));
    ImGui::BeginChild("menu_body", ImVec2(0, 0), ImGuiChildFlags_None);
    const float menu_w = 238.0f;
    ImGui::BeginChild("menu_navigation", ImVec2(menu_w, 0), ImGuiChildFlags_None);
    ImGui::SetCursorPos(ImVec2(18.0f, 14.0f));
    ImGui::TextColored(ImVec4(0.76f, 0.92f, 1.0f, 0.9f), "%s", T("MENÚ PRINCIPAL", "MAIN MENU"));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 8.0f);
    const char* pages[] = {T("Jugar", "Play"), T("Ajustes", "Settings"), "Online", T("Mando", "Gamepad"),
                           T("Teclado", "Keyboard"), T("Parches", "Patches"), T("Guardados", "Saves"), "DLC",
                           T("Herramientas", "Tools")};
    for (int i=0; i<9; ++i) {
        ImGui::SetCursorPosX(8.0f);
        if (MenuEntry(i, pages[i], a.active_page == i, menu_w - 16.0f)) {
            a.active_page = i;
            if (i != 3) g_pad_capture = -1;
            if (i != 4) g_key_capture = -1;
        }
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 3.0f);
    }
    ImGui::SetCursorPosY(std::max(ImGui::GetCursorPosY(), ImGui::GetWindowHeight() - 38.0f));
    ImGui::SetCursorPosX(18.0f);
    ImGui::TextColored(ImVec4(0.77f, 0.91f, 1.0f, 0.84f), "CTR  •  %s", a.version.c_str());
    ImGui::EndChild();
    ImGui::SameLine(0.0f, 0.0f);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.015f, 0.13f, 0.32f, 0.82f));
    ImGui::BeginChild("menu_content", ImVec2(0, 0), ImGuiChildFlags_None);
    ImGui::SetCursorPos(ImVec2(22.0f, 17.0f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.91f, 0.97f, 1.0f, 1.0f));
    switch (a.active_page) {
    case 0: PlayTab(); break;
    case 1: SettingsTab(); break;
    case 2: OnlineTab(); break;
    case 3: GamepadTab(); break;
    case 4: KeyboardTab(); break;
    case 5: PatchesTab(); break;
    case 6: SavesTab(); break;
    case 7: DlcTab(); break;
    default: ToolsTab(); break;
    }
    ImGui::PopStyleColor();
    ImGui::EndChild();
    ImGui::PopStyleColor();
    ImGui::EndChild();
    ImGui::PopStyleColor();

    SaveConfirmations();
    NickPopup();
    JoinServerPopup();
    if (a.confirm_clear_cache) {
        ImGui::OpenPopup("clear_cache");
        a.confirm_clear_cache = false;
    }
    if (ImGui::BeginPopupModal("clear_cache", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
        ImGui::TextUnformatted(T("¿Borrar la caché de shaders? El próximo arranque volverá a compilarlos.",
                                 "Clear the shader cache? The next start compiles them again."));
        if (ImGui::Button(T("Borrar", "Clear"))) {
            ClearShaderCache();
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button(T("Cancelar", "Cancel"))) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }

    if (a.want_close) {
        ImGui::OpenPopup("close");
        a.want_close = false;
    }
    if (ImGui::BeginPopupModal("close", nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoTitleBar)) {
        ImGui::TextUnformatted(T("El juego sigue abierto.", "The game is still running."));
        if (ImGui::Button(T("Cerrar el juego y el launcher", "Stop the game and quit"))) {
            StopGame();
            PostQuitMessage(0);
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button(T("Cancelar", "Cancel"))) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    ImGui::End();
}

void LoadState() {
    App& a = g_app;
    a.root = FindRoot();
    std::error_code ec;
    a.bin = fs::is_directory(a.root / L"bin", ec) ? a.root / L"bin" : a.root / L"out";
    for (const fs::path& v : {a.bin / L"VERSION", a.root / L"VERSION", a.root / L"out" / L"VERSION"}) {
        if (fs::is_regular_file(v, ec)) {
            a.version = Trim(ReadText(v));
            break;
        }
    }
    a.python = FindPython(a.root);
    // The portable package ships bbport.default.ini (an update unzipped over it keeps bbport.ini).
    if (!fs::exists(GameIni(), ec) && fs::is_regular_file(a.root / L"bbport.default.ini", ec)) {
        fs::copy_file(a.root / L"bbport.default.ini", GameIni(), ec);
    }
    a.launcher.Load(LauncherIni());
    a.game.Load(GameIni());
    SyncOnlineBuffers();
    const std::string lang = a.launcher.Get("ui_language");
    g_language = lang.empty() ? "auto" : lang;
    ApplyLauncherLanguage();
    a.game_dir = TextPath(a.launcher.Get("game_dir"));
    a.base_dir = TextPath(a.launcher.Get("base_dir"));
    a.update_dir = TextPath(a.launcher.Get("update_dir"));
    // First start of a portable package: a merged folder next to the launcher is picked up.
    if (a.game_dir.empty()) {
        for (const wchar_t* name : {L"CUSA14876-1.21", L"CUSA13795-1.21", L"CUSA14876", L"CUSA13795"}) {
            if (Analyze(a.root / name).kind == Kind::Complete) {
                a.game_dir = a.root / name;
                break;
            }
        }
        for (const wchar_t* title : {L"CUSA14876", L"CUSA13795"}) {
            const std::wstring base = title, update = base + L"-patch";
            if (a.base_dir.empty() && Analyze(a.root / base).kind == Kind::Base) a.base_dir = a.root / base;
            if (a.update_dir.empty() && Analyze(a.root / update).kind == Kind::Update) a.update_dir = a.root / update;
        }
    }
    a.base_info = Analyze(a.base_dir);
    a.update_info = Analyze(a.update_dir);
    a.patches = LoadPatches();
    ReadPatchConfig(a.patch_enabled, a.patch_disabled);
    StartCheck();
    StartProbe();
}

// ---------------------------------------------------------------------------------------------
// Win32 + Direct3D 11 (Dear ImGui's example_win32_directx11)

ID3D11Device* g_device = nullptr;
ID3D11DeviceContext* g_context = nullptr;
IDXGISwapChain* g_swapchain = nullptr;
ID3D11RenderTargetView* g_rtv = nullptr;
UINT g_resize_w = 0, g_resize_h = 0;
bool g_occluded = false;

void CreateRenderTarget() {
    ID3D11Texture2D* back = nullptr;
    g_swapchain->GetBuffer(0, IID_PPV_ARGS(&back));
    if (back) {
        g_device->CreateRenderTargetView(back, nullptr, &g_rtv);
        back->Release();
    }
}

void CleanupRenderTarget() {
    if (g_rtv) {
        g_rtv->Release();
        g_rtv = nullptr;
    }
}

bool CreateDevice(HWND hwnd) {
    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    const D3D_FEATURE_LEVEL levels[] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0};
    D3D_FEATURE_LEVEL level;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, levels, 2, D3D11_SDK_VERSION,
                                               &sd, &g_swapchain, &g_device, &level, &g_context);
    if (hr == DXGI_ERROR_UNSUPPORTED)
        hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, levels, 2, D3D11_SDK_VERSION, &sd,
                                           &g_swapchain, &g_device, &level, &g_context);
    if (hr != S_OK) return false;
    CreateRenderTarget();
    return true;
}

void CleanupDevice() {
    CleanupRenderTarget();
    if (g_swapchain) g_swapchain->Release();
    if (g_context) g_context->Release();
    if (g_device) g_device->Release();
    g_swapchain = nullptr;
    g_context = nullptr;
    g_device = nullptr;
}

} // namespace

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

static LRESULT WINAPI WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    if (msg == WM_NCHITTEST) {
        POINT pt{GET_X_LPARAM(lparam), GET_Y_LPARAM(lparam)};
        ScreenToClient(hwnd, &pt);
        RECT client{}; GetClientRect(hwnd, &client);
        if (!IsZoomed(hwnd)) {
            const LONG edge = LONG(8.0f * g_ui_scale);
            const bool l=pt.x<edge, r=pt.x>=client.right-edge, t=pt.y<edge, b=pt.y>=client.bottom-edge;
            if (t&&l) return HTTOPLEFT; if (t&&r) return HTTOPRIGHT;
            if (b&&l) return HTBOTTOMLEFT; if (b&&r) return HTBOTTOMRIGHT;
            if (l) return HTLEFT; if (r) return HTRIGHT; if (t) return HTTOP; if (b) return HTBOTTOM;
        }
        return PtInRect(&g_titlebar_drag, pt) ? HTCAPTION : HTCLIENT;
    }
    // Gamepad tab: Esc cancels capture
    if ((msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) && g_pad_capture >= 0) {
        if (wparam == VK_ESCAPE) {
            g_pad_capture = -1;
            return 0;
        }
    }
    // Keyboard tab: the next key's scan code, before ImGui sees it.
    if ((msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) && g_key_capture >= 0) {
        const unsigned code = unsigned((lparam >> 16) & 0xff) | ((lparam & (1 << 24)) ? 0x100u : 0u);
        g_key_captured = code + 1;
        return 0;
    }
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wparam, lparam)) return true;
    switch (msg) {
    case WM_NCCALCSIZE:
        if (wparam) {
            auto* params = reinterpret_cast<NCCALCSIZE_PARAMS*>(lparam);
            if (IsZoomed(hwnd)) {
                MONITORINFO monitor{sizeof monitor};
                if (GetMonitorInfoW(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &monitor))
                    params->rgrc[0] = monitor.rcWork;
            }
            return 0;
        }
        break;
    case WM_GETMINMAXINFO: {
        auto* info = reinterpret_cast<MINMAXINFO*>(lparam);
        info->ptMinTrackSize.x = LONG(900.0f * g_ui_scale);
        info->ptMinTrackSize.y = LONG(640.0f * g_ui_scale);
        MONITORINFO monitor{sizeof monitor};
        if (GetMonitorInfoW(MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST), &monitor)) {
            info->ptMaxPosition.x = monitor.rcWork.left - monitor.rcMonitor.left;
            info->ptMaxPosition.y = monitor.rcWork.top - monitor.rcMonitor.top;
            info->ptMaxSize.x = monitor.rcWork.right - monitor.rcWork.left;
            info->ptMaxSize.y = monitor.rcWork.bottom - monitor.rcWork.top;
        }
        return 0;
    }
    case WM_SIZE:
        if (wparam == SIZE_MINIMIZED) return 0;
        g_resize_w = LOWORD(lparam);
        g_resize_h = HIWORD(lparam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wparam & 0xfff0) == SC_KEYMENU) return 0;
        break;
    case WM_CLOSE:
        if (g_app.game_running) {
            g_app.want_close = true;
            ShowWindow(hwnd, SW_RESTORE);
            return 0;
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wparam, lparam);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int) {
#ifdef LAUNCHER_SELFTEST
    // Test build only (CMake never defines it): file operations without the window.
    //   --import <folder> <port>, --restore <backup> <port>, --patches <port>; result in <port>\selftest.txt
    {
        int argc = 0;
        LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
        if (argc >= 3) {
            const std::wstring op = argv[1];
            g_app.root = argv[argc - 1];
            std::string result;
            if (op == L"--import" && argc == 4) result = ImportSaves(argv[2]);
            else if (op == L"--restore" && argc == 4) result = RestoreBackup(argv[2]);
            else if (op == L"--dlc") {
                for (const auto& d : ScanDlc())
                    result += d.file + " | " + d.title + " | " + d.label + " | " + (d.ok ? "ok" : d.problem) + "\n";
            } else if (op == L"--patches") {
                for (const auto& p : LoadPatches())
                    result += p.key + " | " + p.author + " | " + p.version + " | " + (p.ini_key ? p.ini_key : "-") +
                              (p.default_on ? " | on" : "") + "\n";
                std::vector<std::string> on, off;
                ReadPatchConfig(on, off);
                for (const auto& k : on) result += "json enabled: " + k + "\n";
                for (const auto& k : off) result += "json disabled: " + k + "\n";
            }
            std::ofstream(g_app.root / L"selftest.txt", std::ios::binary) << (result.empty() ? "OK" : result) << "\n";
            return 0;
        }
    }
#endif
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

    int cmd_argc = 0;
    LPWSTR* cmd_argv = CommandLineToArgvW(GetCommandLineW(), &cmd_argc);
    bool direct_launch = false, updated = false;
    if (cmd_argv) {
        for (int i = 1; i < cmd_argc; ++i) {
            if (_wcsicmp(cmd_argv[i], L"--updated") == 0) updated = true;  // started by an update (PollUpdate)
            if (_wcsicmp(cmd_argv[i], L"--launch") == 0 || _wcsicmp(cmd_argv[i], L"--play") == 0 ||
                _wcsicmp(cmd_argv[i], L"-launch") == 0 || _wcsicmp(cmd_argv[i], L"-play") == 0 ||
                _wcsicmp(cmd_argv[i], L"--direct") == 0) {
                direct_launch = true;
                break;
            }
        }
        LocalFree(cmd_argv);
    }

    LoadState();
    MigrateOldLauncher();
    if (!direct_launch) {
        CleanupUpdate();
        if (updated) {
            g_app.notice = Format(T("Actualizado a %s. Tus ajustes, amigos, parches y partidas se mantienen.",
                                    "Updated to %s. Your settings, friends, patches and saves are kept."),
                                  g_app.version);
        } else if (g_app.launcher.Flag("update_check", true)) {
            StartUpdateCheck(g_app.launcher.Flag("update_auto", false));
        }
    }

    if (direct_launch) {
        if (g_app.worker.joinable()) g_app.worker.join();
        PollJobs();
        if (GameReady()) {
            if (g_app.launcher.Flag("discord_rpc", true))
                RegisterDiscordLaunch(DiscordAppId());
            StartGame();
            while (g_app.game_running) {
                MSG msg;
                while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
                    TranslateMessage(&msg);
                    DispatchMessageW(&msg);
                }
                PollJobs();
                UpdateDiscord();
                Sleep(50);
            }
            DiscordPresence::Shutdown();
            if (g_app.worker.joinable()) g_app.worker.join();
            if (g_app.probe.joinable()) g_app.probe.join();
            CoUninitialize();
            return g_app.exit_code;
        }
    }

    ImGui_ImplWin32_EnableDpiAwareness();
    const float scale = ImGui_ImplWin32_GetDpiScaleForMonitor(MonitorFromPoint(POINT{0, 0}, MONITOR_DEFAULTTOPRIMARY));

    WNDCLASSEXW wc{sizeof wc, CS_CLASSDC, WndProc, 0, 0, instance, nullptr, nullptr, nullptr, nullptr, L"CtrNitroFueledPcLauncher", nullptr};
    wc.hIcon = static_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXICON),
                                              GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR));
    wc.hIconSm = static_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(1), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON),
                                                GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR));
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    RegisterClassExW(&wc);
    const int width = int(1120 * scale), height = int(840 * scale);
    RECT work{};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    const int x = work.left + std::max(0, int(work.right - work.left - width) / 2);
    const int y = work.top + std::max(0, int(work.bottom - work.top - height) / 2);
    g_ui_scale = scale;
    HWND hwnd = CreateWindowW(wc.lpszClassName, kLauncherName,
                              WS_POPUP | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU,
                              x, y, width, height, nullptr, nullptr, instance, nullptr);
    g_app.hwnd = hwnd;
    const BOOL dark_titlebar = TRUE;
    DwmSetWindowAttribute(hwnd, 20 /* DWMWA_USE_IMMERSIVE_DARK_MODE */, &dark_titlebar, sizeof(dark_titlebar));
    if (!CreateDevice(hwnd)) {
        CleanupDevice();
        MessageBoxW(nullptr, L"Direct3D 11 is not available.", kLauncherName, MB_ICONERROR);
        return 1;
    }
    ShowWindow(hwnd, SW_SHOWDEFAULT);
    UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_NavEnableGamepad;
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.Colors[ImGuiCol_Text] = ImVec4(0.94f, 0.98f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.65f, 0.83f, 0.94f, 1.0f);
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.02f, 0.10f, 0.24f, 1.0f);
    style.Colors[ImGuiCol_ChildBg] = ImVec4(0.02f, 0.18f, 0.36f, 0.78f);
    style.Colors[ImGuiCol_PopupBg] = ImVec4(0.02f, 0.13f, 0.30f, 0.98f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.48f, 0.84f, 0.97f, 0.35f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.04f, 0.24f, 0.43f, 0.90f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.07f, 0.38f, 0.60f, 1.0f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.10f, 0.48f, 0.68f, 1.0f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.04f, 0.27f, 0.49f, 0.95f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.10f, 0.50f, 0.70f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.17f, 0.71f, 0.87f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.38f, 0.91f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_Header] = ImVec4(0.05f, 0.35f, 0.60f, 0.9f);
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.11f, 0.55f, 0.76f, 1.0f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.16f, 0.68f, 0.84f, 1.0f);
    style.FontSizeBase = 17.0f;
    style.ScaleAllSizes(scale);
    style.FontScaleDpi = scale;
    style.WindowPadding = ImVec2(16 * scale, 14 * scale);
    style.FramePadding = ImVec2(10 * scale, 6 * scale);
    style.ItemSpacing = ImVec2(10 * scale, 8 * scale);
    style.FrameRounding = 4 * scale;
    style.TabRounding = 4 * scale;
    style.WindowRounding = 9 * scale;
    wchar_t fonts[MAX_PATH];
    const UINT n = GetWindowsDirectoryW(fonts, MAX_PATH);
    const fs::path segoe = fs::path(std::wstring(fonts, n)) / L"Fonts" / L"segoeui.ttf";
    std::error_code ec;
    // Japanese and Chinese, which Segoe UI and the CTR font lack: Windows' own CJK fonts merged in
    // as fallbacks (ImGui 1.92 loads their glyphs only when a text uses them).
    const auto merge_fallbacks = [&](bool with_segoe) {
        std::vector<fs::path> files;
        if (with_segoe) files.push_back(segoe);
        for (const wchar_t* name : {L"msyh.ttc", L"YuGothM.ttc", L"msgothic.ttc"})
            files.push_back(fs::path(std::wstring(fonts, n)) / L"Fonts" / name);
        for (const fs::path& file : files) {
            if (!fs::is_regular_file(file, ec)) continue;
            ImFontConfig merge;
            merge.MergeMode = true;
            io.Fonts->AddFontFromFileTTF(PathText(file).c_str(), 0.0f, &merge);
        }
    };
    if (fs::is_regular_file(segoe, ec)) io.Fonts->AddFontFromFileTTF(PathText(segoe).c_str());
    else io.Fonts->AddFontDefault();
    merge_fallbacks(false);
    const fs::path ctr_font = g_app.root / L"art" / L"ctr-menu.ttf";
    if (fs::is_regular_file(ctr_font, ec)) {
        g_ctr_font = io.Fonts->AddFontFromFileTTF(PathText(ctr_font).c_str(), style.FontSizeBase);
        merge_fallbacks(true);  // Cyrillic and CJK labels in the CTR font's places
    }

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_device, g_context);
    LoadArtwork();
    if (g_app.launcher.Flag("discord_rpc", true))
        RegisterDiscordLaunch(DiscordAppId());

    bool done = false;
    while (!done) {
        MSG msg;
        // Idle while minimized or not in front: wait for input or 100 ms (background work).
        if (IsIconic(hwnd)) MsgWaitForMultipleObjects(0, nullptr, FALSE, 250, QS_ALLINPUT);
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            if (msg.message == WM_QUIT) done = true;
        }
        if (done) break;
        if (IsIconic(hwnd)) {
            PollJobs();
            continue;
        }
        if (g_occluded && g_swapchain->Present(0, DXGI_PRESENT_TEST) == DXGI_STATUS_OCCLUDED) {
            Sleep(10);
            PollJobs();
            continue;
        }
        g_occluded = false;
        if (g_resize_w && g_resize_h) {
            CleanupRenderTarget();
            g_swapchain->ResizeBuffers(0, g_resize_w, g_resize_h, DXGI_FORMAT_UNKNOWN, 0);
            g_resize_w = g_resize_h = 0;
            CreateRenderTarget();
        }
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        Frame();
        ImGui::Render();
        const float clear[4] = {0.08f, 0.08f, 0.10f, 1.0f};
        g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
        g_context->ClearRenderTargetView(g_rtv, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_occluded = g_swapchain->Present(1, 0) == DXGI_STATUS_OCCLUDED;
    }

    DiscordPresence::Shutdown();
    if (g_update.worker.joinable()) {  // a download stops; an install in progress finishes
        g_update.progress.cancel = true;
        g_update.worker.join();
    }
    // Background work finishes on its own; a running game keeps running.
    if (g_app.worker.joinable()) {
        if (g_app.job == Job::Play) g_app.worker.detach();
        else g_app.worker.join();
    }
    if (g_app.probe.joinable()) g_app.probe.join();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    ReleaseArtwork();
    CleanupDevice();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    CoUninitialize();
    return 0;
}
