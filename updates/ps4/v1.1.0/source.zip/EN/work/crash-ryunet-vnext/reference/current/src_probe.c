/* Minimal x86-64 native loader experiment. Not a PS4 emulator or game port. */
#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <cpuid.h>
#include "runtime.h"
#include "gpu/bbgpu.h"
#if !defined(__x86_64__) || !defined(__GNUC__)
#error This prototype requires x86-64 GCC or Clang (including MinGW).
#endif
#ifdef _WIN32
#include <windows.h>
#include <signal.h>
#else
#include <sys/mman.h>
#include <malloc.h>
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <execinfo.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#endif

typedef struct { uint64_t address, size, flags; } Segment;
typedef struct { uint64_t target, kind, value, addend; } Reloc;
static char (*names)[128];
static uint64_t import_count;
static unsigned char *image;
static size_t image_bytes; /* the size of the guest image (crash reports) */
static size_t page_size;
typedef struct { uint64_t base, size, init, tls_address, tls_memsz, tls_filesz, tls_module; } LinkedModule;
static LinkedModule modules[16];
static uint64_t module_count;
static int entered_game;
static int gpu_enabled;
int vulkan_smoke(void);

static void fail(const char *message) { fprintf(stderr, "ERROR: %s\n", message); exit(1); }

/* The game's code was compiled for the PS4's CPU (AMD Jaguar) and runs as it is: AVX, BMI1
 * (andn/bextr/blsr/tzcnt), MOVBE, LZCNT and POPCNT, thousands of each in eboot.bin. A CPU without
 * them stops at the first one with SIGILL (exit code 132, issue #26), and lzcnt/tzcnt even run as
 * bsr/bsf there, with other results. Said before the game starts; BB_SKIP_CPU_CHECK=1 skips it. */
static void check_cpu(void) {
    const char *skip = getenv("BB_SKIP_CPU_CHECK");
    if (skip && !strcmp(skip, "1")) return;
    unsigned a, b, c, d, leaf1_c = 0, leaf7_b = 0, ext1_c = 0;
    if (__get_cpuid(1, &a, &b, &c, &d)) leaf1_c = c;
    if (__get_cpuid_count(7, 0, &a, &b, &c, &d)) leaf7_b = b;
    if (__get_cpuid(0x80000001u, &a, &b, &c, &d)) ext1_c = c;
    int avx = (leaf1_c & bit_AVX) && (leaf1_c & bit_OSXSAVE);
    if (avx) {
        unsigned lo, hi;
        __asm__ volatile("xgetbv" : "=a"(lo), "=d"(hi) : "c"(0));
        avx = (lo & 6) == 6; /* the OS saves SSE and AVX state */
    }
    const struct { int present; const char *name; } features[] = {
        {avx, "AVX"}, {(leaf7_b & bit_BMI) != 0, "BMI1"}, {(leaf1_c & bit_MOVBE) != 0, "MOVBE"},
        {(ext1_c & bit_LZCNT) != 0, "LZCNT"}, {(leaf1_c & bit_POPCNT) != 0, "POPCNT"},
        {(leaf1_c & bit_SSE4_2) != 0, "SSE4.2"},
    };
    char missing[64] = "";
    for (unsigned i = 0; i < sizeof(features) / sizeof(features[0]); ++i) {
        if (features[i].present) continue;
        if (missing[0]) strcat(missing, ", ");
        strcat(missing, features[i].name);
    }
    if (!missing[0]) return;
    fprintf(stderr,
            "ERROR: this CPU lacks %s. The game's code was compiled for the PS4's CPU and uses "
            "these instructions directly: it needs an Intel Haswell (4th generation Core, 2013) or "
            "newer, or an AMD Ryzen. BB_SKIP_CPU_CHECK=1 starts anyway.\n", missing);
    exit(1);
}
static uint64_t read64(FILE *f) {
    unsigned char b[8];
    if (fread(b, 1, 8, f) != 8) fail("truncated boot file");
    uint64_t n = 0;
    for (int i = 7; i >= 0; --i) n = (n << 8) | b[i];
    return n;
}
static size_t round_page(size_t size) { return (size + page_size - 1) & ~(page_size - 1); }
static void *allocate(size_t size) {
    void *low=runtime_low_map(size,PROT_READ|PROT_WRITE);
    if (low) return low;
#ifdef _WIN32
    void *p = VirtualAlloc(NULL, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!p) fail("VirtualAlloc failed");
#else
    void *p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) fail("mmap failed");
#endif
    return p;
}
static void protect(void *p, size_t size, unsigned flags) {
#ifdef _WIN32
    DWORD old, mode = PAGE_NOACCESS;
    if (flags & 1) mode = (flags & 2) ? PAGE_EXECUTE_READWRITE : PAGE_EXECUTE_READ;
    else if (flags & 2) mode = PAGE_READWRITE;
    else if (flags & 4) mode = PAGE_READONLY;
    if (!VirtualProtect(p, size, mode, &old)) fail("VirtualProtect failed");
    FlushInstructionCache(GetCurrentProcess(), p, size);
#else
    int mode = ((flags & 4) ? PROT_READ : 0) | ((flags & 2) ? PROT_WRITE : 0) | ((flags & 1) ? PROT_EXEC : 0);
    if (mprotect(p, size, mode)) fail("mprotect failed");
#endif
}
static ABI __attribute__((noreturn)) void unresolved(uint32_t id, uintptr_t argument) {
    if (id >= import_count) fail("bad import trap index");
    printf("STOP: first unsupported PS4 import: %s (index %u)\n", names[id], id);
    printf("API: %s\n", runtime_import_name(names[id]));
    printf("Caller return offset: 0x%" PRIxPTR "; first argument: 0x%" PRIxPTR "\n",
           (uintptr_t)__builtin_return_address(0) - (uintptr_t)image, argument);
    uintptr_t caller=(uintptr_t)__builtin_return_address(0)-(uintptr_t)image;
    for (uint64_t m=0;m<module_count;++m)
        if (caller>=modules[m].base && caller-modules[m].base<modules[m].size)
            printf("Caller in linked module %" PRIu64 " (%s): +0x%" PRIxPTR "\n",m,m==0 ? "libc.prx" : "system module",caller-modules[m].base);
    runtime_report();
    puts(entered_game ? "Original guest entry instructions executed; game initialization is incomplete." :
                        "Native libc initialization is incomplete; game entry has not run.");
    fflush(NULL);
    _exit(20); /* no destructors: GPU, audio and guest threads are still running */
}
#ifndef _WIN32
/* enter_on_stack(entry, arg0, arg1, stack_top): call entry(arg0,arg1) on a new stack. */
void enter_on_stack(void *entry, void *arg0, void *arg1, void *top);
__asm__(".text\n.globl enter_on_stack\nenter_on_stack:\n"
        " push %rbp\n mov %rsp,%rbp\n and $-16,%rcx\n mov %rcx,%rsp\n"
        " mov %rdi,%rax\n mov %rsi,%rdi\n mov %rdx,%rsi\n call *%rax\n"
        " mov %rbp,%rsp\n pop %rbp\n ret\n");
#endif
static ABI void guest_exit(void) { puts("Runtime: process finalizer callback reached"); }
const char *runtime_thread_current_name(void);
#ifdef _WIN32
static void describe_address(char *out, size_t size, uintptr_t address) {
    HMODULE module=NULL;
    char name[MAX_PATH]="?";
    if (image && address-(uintptr_t)image<0x20000000) { snprintf(out,size,"guest offset 0x%" PRIxPTR,address-(uintptr_t)image); return; }
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)address,&module) && module) {
        GetModuleFileNameA(module,name,sizeof(name));
        const char *base=strrchr(name,'\\');
        snprintf(out,size,"%s+0x%" PRIxPTR,base ? base+1 : name,address-(uintptr_t)module);
        return;
    }
    snprintf(out,size,"%p",(void *)address);
}
int runtime_memory_vma_info(uintptr_t address, int *prot, int *type, uintptr_t *end);
/* SacredFire: an address in a crash report: the module or guest offset, what Windows has there
 * (free, reserved, committed and its protection) and the guest mapping over it, if any. */
static void describe_memory(const char *label, uintptr_t address) {
    char where[MAX_PATH+64];
    describe_address(where,sizeof(where),address);
    MEMORY_BASIC_INFORMATION m;
    const char *state="unknown";
    unsigned long protect=0;
    if (VirtualQuery((void *)address,&m,sizeof(m))) {
        state=m.State==MEM_FREE ? "free (never mapped, or unmapped)" : m.State==MEM_RESERVE ? "reserved, not committed" : "committed";
        protect=m.Protect;
    }
    int prot=0,type=0; uintptr_t end=0;
    const int guest=runtime_memory_vma_info(address,&prot,&type,&end);
    fprintf(stderr,"  %s %p (%s): %s, protection 0x%lx; guest mapping: ",label,(void *)address,where,state,protect);
    if (guest) fprintf(stderr,"prot 0x%x, type %d, up to %p\n",prot,type,(void *)end);
    else fprintf(stderr,"none\n");
    if (address<0x10000) fprintf(stderr,"  (a null pointer plus 0x%" PRIxPTR ": a field of an object that does not exist)\n",address);
    else if (address>>47) fprintf(stderr,"  (not a valid pointer: freed or overwritten memory read as one)\n");
}
/* abort(), a C runtime invalid parameter and a pure virtual call end the process with code 3
 * and no report of their own: they raise this, which the fault handler reports like a crash. */
#define BB_ABORT_EXCEPTION 0xE0AB0003u
static void raise_abort(const char *what) {
    ULONG_PTR arg=(ULONG_PTR)what;
    RaiseException(BB_ABORT_EXCEPTION,EXCEPTION_NONCONTINUABLE,1,&arg);
}
static void on_abort_signal(int sig) { (void)sig; raise_abort("an assertion, or an uncaught C++ exception: see the lines above"); }
static void on_invalid_parameter(const wchar_t *expression, const wchar_t *function, const wchar_t *file, unsigned line, uintptr_t reserved) {
    (void)expression; (void)function; (void)file; (void)line; (void)reserved;
    raise_abort("invalid parameter to a C runtime function");
}
static void on_purecall(void) { raise_abort("pure virtual function call"); }
static int fatal_reported;
static LONG fatal_exception(EXCEPTION_POINTERS *info) {
    if (__atomic_exchange_n(&fatal_reported,1,__ATOMIC_ACQ_REL)) { Sleep(INFINITE); }
    const EXCEPTION_RECORD *record=info->ExceptionRecord;
    const CONTEXT *c=info->ContextRecord;
    char where[MAX_PATH+64];
    describe_address(where,sizeof(where),(uintptr_t)c->Rip);
    if (record->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && record->NumberParameters>=2)
        fprintf(stderr,"Fault: %s access to %p at %s (thread %lu)\n",
                record->ExceptionInformation[0]==1 ? "write" : record->ExceptionInformation[0]==8 ? "execute" : "read",
                (void *)record->ExceptionInformation[1],where,GetCurrentThreadId());
    else if (record->ExceptionCode==BB_ABORT_EXCEPTION)
        fprintf(stderr,"Fault: abort() called (%s) at %s (thread %lu)\n",
                record->NumberParameters ? (const char *)record->ExceptionInformation[0] : "?",where,GetCurrentThreadId());
    else
        fprintf(stderr,"Fault: exception 0x%08lx at %s (thread %lu)\n",record->ExceptionCode,where,GetCurrentThreadId());
    fprintf(stderr,"  rax=%016llx rbx=%016llx rcx=%016llx rdx=%016llx\n  rsi=%016llx rdi=%016llx rbp=%016llx rsp=%016llx\n",
            c->Rax,c->Rbx,c->Rcx,c->Rdx,c->Rsi,c->Rdi,c->Rbp,c->Rsp);
    fprintf(stderr,"  r8=%016llx r9=%016llx r10=%016llx r11=%016llx\n  r12=%016llx r13=%016llx r14=%016llx r15=%016llx rip=%016llx\n",
            c->R8,c->R9,c->R10,c->R11,c->R12,c->R13,c->R14,c->R15,c->Rip);
    /* SacredFire: what the faulting address is (never mapped, freed, read-only) and the bytes of
     * the faulting instruction, to read the crash without a debugger. */
    if (record->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && record->NumberParameters>=2)
        describe_memory("fault address",(uintptr_t)record->ExceptionInformation[1]);
    {
        unsigned char code[24]; SIZE_T got=0;
        if (c->Rip && ReadProcessMemory(GetCurrentProcess(),(void *)(uintptr_t)c->Rip,code,sizeof(code),&got) && got) {
            fprintf(stderr,"  code at rip:");
            for (SIZE_T i=0;i<got;++i) fprintf(stderr," %02x",code[i]);
            fprintf(stderr,"\n");
        }
    }
    /* Guest return addresses on the stack: the frame chain of guest code often breaks (a leaf
     * function, a frame without rbp), these still name the callers. */
    if (image) {
        uintptr_t stack[512]; SIZE_T got=0;
        ReadProcessMemory(GetCurrentProcess(),(void *)(uintptr_t)c->Rsp,stack,sizeof(stack),&got);
        int shown=0;
        for (SIZE_T i=0;i<got/sizeof(stack[0]) && shown<16;++i) {
            const uintptr_t v=stack[i];
            if (v-(uintptr_t)image<image_bytes && v>(uintptr_t)image+0x80) {
                if (!shown) fprintf(stderr,"  guest code addresses on the stack (callers, newest first):");
                fprintf(stderr," 0x%" PRIxPTR "@rsp+0x%zx",v-(uintptr_t)image,(size_t)(i*sizeof(stack[0])));
                ++shown;
            }
        }
        if (shown) fprintf(stderr,"\n");
    }
    if (gpu_enabled) bbgpu_dump_guest_writes(info);
    /* SacredFire: the thread's name and its native call chain from the unwind tables (drivers and
     * system DLLs keep no frame pointers; this names the call into them). Guest frames have no
     * unwind data: the walk stops there and the rbp chain below continues. */
    {
        typedef HRESULT (WINAPI *GetDescription)(HANDLE,PWSTR *);
        GetDescription get_description=(GetDescription)(void (*)(void))GetProcAddress(GetModuleHandleA("kernel32.dll"),"GetThreadDescription");
        PWSTR description=NULL;
        if (get_description && SUCCEEDED(get_description(GetCurrentThread(),&description)) && description && *description)
            fprintf(stderr,"  thread name: %ls\n",description);
        if (description) LocalFree(description);
        const char *guest_name=runtime_thread_current_name();
        if (guest_name) fprintf(stderr,"  guest thread: %s\n",guest_name);
        static const char *const reg_names[]={"rax","rbx","rcx","rdx","rsi","rdi","rbp","r8","r9","r10","r11","r12","r13","r14","r15"};
        const DWORD64 regs[]={c->Rax,c->Rbx,c->Rcx,c->Rdx,c->Rsi,c->Rdi,c->Rbp,c->R8,c->R9,c->R10,c->R11,c->R12,c->R13,c->R14,c->R15};
        for (int r=0;r<15;++r) {
            describe_address(where,sizeof(where),(uintptr_t)regs[r]);
            if (strchr(where,'+')) fprintf(stderr,"  %s -> %s\n",reg_names[r],where);
        }
        CONTEXT walk=*c;
        if (!walk.Rip) {
            /* A call through a null pointer: the caller's return address is on top of the stack. */
            DWORD64 ret=0; SIZE_T got=0;
            if (ReadProcessMemory(GetCurrentProcess(),(void *)walk.Rsp,&ret,sizeof(ret),&got) && got==sizeof(ret)) {
                walk.Rip=ret; walk.Rsp+=8;
                fprintf(stderr,"  (called through a null pointer)\n");
            }
        }
        for (int depth=0; depth<32 && walk.Rip; ++depth) {
            describe_address(where,sizeof(where),(uintptr_t)walk.Rip);
            fprintf(stderr,"  native #%d %s\n",depth,where);
            DWORD64 module_base=0;
            PRUNTIME_FUNCTION function=RtlLookupFunctionEntry(walk.Rip,&module_base,NULL);
            if (!function) {
                /* A leaf function, or code without unwind data (guest): only the first frame
                 * can be stepped over, by its return address on the stack. */
                if (depth) break;
                DWORD64 ret=0; SIZE_T got=0;
                if (!ReadProcessMemory(GetCurrentProcess(),(void *)walk.Rsp,&ret,sizeof(ret),&got) || got!=sizeof(ret)) break;
                walk.Rip=ret; walk.Rsp+=8;
                continue;
            }
            PVOID handler_data=NULL; DWORD64 establisher=0;
            RtlVirtualUnwind(UNW_FLAG_NHANDLER,module_base,walk.Rip,function,&walk,&handler_data,&establisher,NULL);
        }
    }
    /* rbp chain (guest and host code keep frame pointers). */
    uintptr_t rbp=(uintptr_t)c->Rbp;
    for (int depth=0; depth<24 && rbp; ++depth) {
        uintptr_t frame[2];
        SIZE_T got=0;
        if (!ReadProcessMemory(GetCurrentProcess(),(void *)rbp,frame,sizeof(frame),&got) || got!=sizeof(frame) || frame[0]<=rbp) break;
        describe_address(where,sizeof(where),frame[1]);
        fprintf(stderr,"  #%d %s\n",depth,where);
        rbp=frame[0];
    }
    fflush(NULL);
    TerminateProcess(GetCurrentProcess(),3);
    return EXCEPTION_CONTINUE_SEARCH;
}
static LONG CALLBACK vectored_fault(EXCEPTION_POINTERS *info) {
    const EXCEPTION_RECORD *record=info->ExceptionRecord;
    DWORD code=record->ExceptionCode;
    if (code==EXCEPTION_ACCESS_VIOLATION && record->NumberParameters>=2) {
        /* GPU page tracking (write-protected guest pages) is resolved first. */
        if (gpu_enabled && bbgpu_handle_fault(info,(void *)record->ExceptionInformation[1])) return EXCEPTION_CONTINUE_EXECUTION;
        if (runtime_fault_recover) {
            /* A speculative guest memory read (GPU draw preparation) faulted: the thread resumes
             * in bb_longjmp, outside the exception dispatcher, back at its recovery point. */
            unsigned long long *buffer=*runtime_fault_recover;
            runtime_fault_recover=NULL;
            CONTEXT *c=info->ContextRecord;
            c->Rsp=((c->Rsp-128)&~(DWORD64)15)-40;
            c->Rcx=(DWORD64)(uintptr_t)buffer;
            c->Rdx=1;
            c->Rip=(DWORD64)(uintptr_t)bb_longjmp;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        CONTEXT *c=info->ContextRecord;
        if (image && (c->Rip==(uintptr_t)image+0x1590b7e || c->Rip==(uintptr_t)image+0x1590b82)) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null sentinel in TLSF malloc (rax=%p, rbx=%p, pool=%p)\n",(void *)c->Rax,(void *)c->Rbx,(void *)c->Rdi); }
            if (!c->Rax) c->Rax=c->Rdi;
            if (!c->Rbx) c->Rbx=c->Rdi;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && (c->Rip==(uintptr_t)image+0x1590825 || c->Rip==(uintptr_t)image+0x1590829)) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null sentinel in TLSF free (r10=%p, rax=%p, pool=%p)\n",(void *)c->R10,(void *)c->Rax,(void *)c->Rdi); }
            if (!c->R10) c->R10=c->Rdi;
            if (!c->Rax) c->Rax=c->Rdi;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x1590a0f) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null bucket in TLSF insert (rdx=%p, r9=%p, pool=%p)\n",(void *)c->Rdx,(void *)c->R9,(void *)c->Rdi); }
            if (!c->Rdx) {
                c->Rdx=c->Rdi;
                if (c->R9) {
                    uint64_t sentinel=c->Rdi;
                    WriteProcessMemory(GetCurrentProcess(),(void *)(c->R9+0x10),&sentinel,sizeof(sentinel),NULL);
                }
            }
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x15905d5) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null bucket in TLSF add_pool (rcx=%p, rsi=%p, pool=%p)\n",(void *)c->Rcx,(void *)c->Rsi,(void *)c->Rdi); }
            if (!c->Rcx) {
                c->Rcx=c->Rdi;
                if (c->Rsi) {
                    uint64_t sentinel=c->Rdi;
                    WriteProcessMemory(GetCurrentProcess(),(void *)(c->Rsi+0x10),&sentinel,sizeof(sentinel),NULL);
                }
            }
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x1590d50) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null bucket in TLSF malloc-split (rcx=%p, r11=%p, pool=%p)\n",(void *)c->Rcx,(void *)c->R11,(void *)c->Rdi); }
            if (!c->Rcx) {
                c->Rcx=c->Rdi;
                if (c->R11) {
                    uint64_t sentinel=c->Rdi;
                    WriteProcessMemory(GetCurrentProcess(),(void *)(c->R11+0x10),&sentinel,sizeof(sentinel),NULL);
                }
            }
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x1590ec5) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null bucket in TLSF insert-2 (rbx=%p, r8=%p, pool=%p)\n",(void *)c->Rbx,(void *)c->R8,(void *)c->Rdi); }
            if (!c->Rbx) {
                c->Rbx=c->Rdi;
                if (c->Rsi) {
                    uint64_t sentinel=c->Rdi;
                    WriteProcessMemory(GetCurrentProcess(),(void *)c->Rsi,&sentinel,sizeof(sentinel),NULL);
                }
            }
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x159133a) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null bucket in TLSF insert-3 (rsi=%p, r11=%p, pool=%p)\n",(void *)c->Rsi,(void *)c->R11,(void *)c->Rdi); }
            if (!c->Rsi) {
                c->Rsi=c->R14 ? c->R14 : c->Rdi;
                if (c->R11) {
                    uint64_t sentinel=c->Rsi;
                    WriteProcessMemory(GetCurrentProcess(),(void *)(c->R11+0x10),&sentinel,sizeof(sentinel),NULL);
                }
            }
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x42e6dd) {
            static int warned=0;
            if (!warned) { warned=1; fprintf(stderr,"Runtime: recovered null task in queue step (r14=%p, rbx=%p)\n",(void *)c->R14,(void *)c->Rbx); }
            if (!c->R14) {
                c->Rip=(uintptr_t)image+0x42e874;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
        }
        /* TLSF free() coalescing unlink */
        if (image && ((c->Rip >= (uintptr_t)image + 0x1590f46 && c->Rip <= (uintptr_t)image + 0x1590f70) ||
                      (c->Rip >= (uintptr_t)image + 0x159101b && c->Rip <= (uintptr_t)image + 0x1591040))) {
            static int count = 0;
            if (!count) fprintf(stderr, "Runtime: bailing corrupt TLSF free (rip=%p, next=%p, prev=%p, pool=%p)\n",
                (void *)c->Rip, (void *)c->Rcx, (void *)c->Rbx, (void *)c->Rdi);
            ++count;
            c->Rip = (uintptr_t)image + 0x1590eea;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && c->Rip==(uintptr_t)image+0x40e5f9) {
            static int count=0;
            if (!count) fprintf(stderr,"Runtime: bypassed null vtable in task cleanup (rax=%p, rdi=%p, r14=%p)\n",(void *)c->Rax,(void *)c->Rdi,(void *)c->R14);
            ++count;
            if (!c->Rax) {
                c->Rip=(uintptr_t)image+0x40e5fc;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
        }
        if (image && c->Rip==(uintptr_t)image+0x40e569) {
            static int count=0;
            if (!count) fprintf(stderr,"Runtime: bypassed null vtable in task cleanup 2 (rax=%p, rdi=%p)\n",(void *)c->Rax,(void *)c->Rdi);
            ++count;
            if (!c->Rax) {
                c->Rip=(uintptr_t)image+0x40e56c;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
        }
        if (image && c->Rip==(uintptr_t)image+0x40e759) {
            static int count=0;
            if (!count) fprintf(stderr,"Runtime: bypassed null vtable in task cleanup 3 (rax=%p, rdi=%p)\n",(void *)c->Rax,(void *)c->Rdi);
            ++count;
            if (!c->Rax) {
                c->Rip=(uintptr_t)image+0x40e75c;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
        }
        if (image && c->Rip==(uintptr_t)image+0x40ee05) {
            static int count=0;
            if (!count) fprintf(stderr,"Runtime: bypassed null vtable in task cleanup 4 (rax=%p, rdi=%p)\n",(void *)c->Rax,(void *)c->Rdi);
            ++count;
            if (!c->Rax) {
                c->Rip=(uintptr_t)image+0x40ee08;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
        }
        /* Task::cancel (0x3f28a0) fault recovery */
        if (image && ((c->Rip >= (uintptr_t)image + 0x3f28a9 && c->Rip <= (uintptr_t)image + 0x3f28ad) ||
                      (c->Rip >= (uintptr_t)image + 0x3f28b6 && c->Rip <= (uintptr_t)image + 0x3f28c8))) {
            static int count = 0;
            if (!count) fprintf(stderr, "Runtime: bypassed invalid task cancel at guest offset 0x%lx (rbx=%p)\n",
                (unsigned long)(c->Rip - (uintptr_t)image), (void *)c->Rbx);
            ++count;
            c->Rip = (uintptr_t)image + 0x3f28af;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
        if (image && !c->Rip) {
            uintptr_t ret_addr = 0;
            ReadProcessMemory(GetCurrentProcess(), (void *)c->Rsp, &ret_addr, sizeof(ret_addr), NULL);
            if (ret_addr == (uintptr_t)image + 0x42e73a) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task start() at 0x42e734 (r14=%p)\n", (void *)c->R14);
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x42e7a2) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task error handler at 0x42e79c (r14=%p)\n", (void *)c->R14);
                ++count;
                c->Rsp += 8;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x42e83f) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task method at 0x42e839 (r14=%p)\n", (void *)c->R14);
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x42e96b) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task run() at 0x42e965 (r15=%p)\n", (void *)c->R15);
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x42e981) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task cleanup at 0x42e97b (r15=%p)\n", (void *)c->R15);
                ++count;
                c->Rsp += 8;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x3f28c8) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task cancel method at 0x3f28c2\n");
                ++count;
                c->Rsp += 8;
                c->Rip = (uintptr_t)image + 0x3f28af;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x3f2706) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task method at 0x3f2700\n");
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x42e9df) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task method at 0x42e9dc\n");
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x42e9f2) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task method at 0x42e9ec\n");
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
            if (ret_addr == (uintptr_t)image + 0x4308ce) {
                static int count = 0;
                if (!count) fprintf(stderr, "Runtime: bypassed null task method at 0x4308c8\n");
                ++count;
                c->Rsp += 8;
                c->Rax = 1;
                c->Rip = ret_addr;
                return EXCEPTION_CONTINUE_EXECUTION;
            }
        }
    }
    if (code==EXCEPTION_ACCESS_VIOLATION || code==EXCEPTION_ILLEGAL_INSTRUCTION || code==EXCEPTION_PRIV_INSTRUCTION ||
        code==EXCEPTION_STACK_OVERFLOW || code==EXCEPTION_INT_DIVIDE_BY_ZERO || code==EXCEPTION_DATATYPE_MISALIGNMENT) {
        return fatal_exception(info);
    }
    /* BB_STRICT_HANDLES=1: a closed or invalid handle used anywhere is reported (diagnostics). */
    if (code==0xC0000008 /* STATUS_INVALID_HANDLE */) return fatal_exception(info);
    if (code==BB_ABORT_EXCEPTION) return fatal_exception(info);
    return EXCEPTION_CONTINUE_SEARCH;
}
static LONG WINAPI unhandled_fault(EXCEPTION_POINTERS *info) { return fatal_exception(info); }
/* Guest code reads its TCB with `mov rax, gs:[0]` (link_*.py rewrote fs:[0]); on Windows
 * the displacement becomes the TEB TLS slot that holds the guest TCB (runtime_thread.c). */
uint32_t runtime_thread_tcb_offset(void);
static uint64_t patch_tcb_loads(const Segment *segments, uint64_t count) {
    static const unsigned char load[]={0x65,0x48,0x8b,0x04,0x25,0,0,0,0};
    uint32_t displacement=runtime_thread_tcb_offset();
    uint64_t patched=0;
    for (uint64_t s=0;s<count;++s) {
        if (!(segments[s].flags&1) || segments[s].size<sizeof(load)) continue;
        unsigned char *at=image+segments[s].address, *end=at+segments[s].size-sizeof(load);
        for (; at<=end; ++at)
            if (at[0]==0x65 && !memcmp(at,load,sizeof(load))) { memcpy(at+5,&displacement,4); ++patched; at+=sizeof(load)-1; }
    }
    return patched;
}
#endif
#ifndef _WIN32
static ssize_t read_self_memory(void *out, uintptr_t address, size_t size) {
    struct iovec local={out,size}, remote={(void *)address,size};
    ssize_t n=process_vm_readv(getpid(),&local,1,&remote,1,0);
    if (n==(ssize_t)size) return n;
    /* Some sandboxes deny process_vm_readv even for the current process. */
    int fd=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
    if (fd<0) return n;
    n=pread(fd,out,size,(off_t)address);
    close(fd);
    return n;
}
static void fault(int sig, siginfo_t *info, void *context) {
    /* GPU page tracking (write-protected guest pages) is resolved first. */
    if (gpu_enabled && sig == SIGSEGV && bbgpu_handle_fault(context, info->si_addr)) return;
    /* A speculative guest memory read (runtime_memory.c) failed: resume its recovery point. */
    if ((sig == SIGSEGV || sig == SIGBUS) && runtime_fault_recover) {
        sigjmp_buf *recover = runtime_fault_recover;
        runtime_fault_recover = NULL;
        sigset_t unblock;
        sigemptyset(&unblock);
        sigaddset(&unblock, sig);
        pthread_sigmask(SIG_UNBLOCK, &unblock, NULL);
        siglongjmp(*recover, 1);
    }
    /* The process is terminating: dladdr/snprintf are acceptable here. */
    ucontext_t *uc = context;
    uintptr_t rip = (uintptr_t)uc->uc_mcontext.gregs[REG_RIP];
    char line[512];
    Dl_info where;
    if (rip - (uintptr_t)image < 0x10000000)
        snprintf(line, sizeof(line), "Guest fault (signal %d) at guest offset 0x%lx, address %p\n",
                 sig, (unsigned long)(rip - (uintptr_t)image), info->si_addr);
    else if (dladdr((void *)rip, &where) && where.dli_fname)
        snprintf(line, sizeof(line), "Host fault (signal %d) in %s+0x%lx (%s), address %p\n", sig, where.dli_fname,
                 (unsigned long)(rip - (uintptr_t)where.dli_fbase), where.dli_sname ? where.dli_sname : "?", info->si_addr);
    else
        snprintf(line, sizeof(line), "Fault (signal %d) at RIP %p, address %p\n", sig, (void *)rip, info->si_addr);
    { ssize_t written_=write(2, line, strlen(line)); (void)written_; }
    if (!rip) {
        /* An indirect call to zero leaves its return address at RSP. A jump or return to zero
         * may leave something else there, so report this as a candidate call site. */
        uintptr_t rsp=(uintptr_t)uc->uc_mcontext.gregs[REG_RSP], caller=0;
        if (rsp && read_self_memory(&caller,rsp,sizeof(caller))==(ssize_t)sizeof(caller)) {
            if (caller-(uintptr_t)image<0x10000000)
                snprintf(line,sizeof(line),"  stack return candidate: guest offset 0x%lx\n",
                         (unsigned long)(caller-(uintptr_t)image));
            else if (dladdr((void *)caller,&where) && where.dli_fname)
                snprintf(line,sizeof(line),"  stack return candidate: %s+0x%lx (%s)\n",where.dli_fname,
                         (unsigned long)(caller-(uintptr_t)where.dli_fbase),where.dli_sname ? where.dli_sname : "?");
            else
                snprintf(line,sizeof(line),"  stack return candidate: %p\n",(void *)caller);
            { ssize_t written_=write(2,line,strlen(line)); (void)written_; }
        }
        snprintf(line,sizeof(line),"  rsp=%p rbp=%p rax=%p rbx=%p rcx=%p rdx=%p\n",
                 (void *)rsp,(void *)(uintptr_t)uc->uc_mcontext.gregs[REG_RBP],
                 (void *)(uintptr_t)uc->uc_mcontext.gregs[REG_RAX],
                 (void *)(uintptr_t)uc->uc_mcontext.gregs[REG_RBX],
                 (void *)(uintptr_t)uc->uc_mcontext.gregs[REG_RCX],
                 (void *)(uintptr_t)uc->uc_mcontext.gregs[REG_RDX]);
        { ssize_t written_=write(2,line,strlen(line)); (void)written_; }
    }
    if (gpu_enabled) bbgpu_dump_guest_writes(context);
    /* Outside the image and any shared object (generated code, a freed mapping): the mapping
     * from /proc/self/maps, and the thread. */
    if (rip - (uintptr_t)image >= 0x10000000 && !(dladdr((void *)rip, &where) && where.dli_fname)) {
        char thread[32] = "?";
        pthread_getname_np(pthread_self(), thread, sizeof(thread));
        snprintf(line, sizeof(line), "  thread %s; mapping of RIP: ", thread);
        { ssize_t written_=write(2, line, strlen(line)); (void)written_; }
        FILE *maps = fopen("/proc/self/maps", "r");
        int found = 0;
        while (maps && fgets(line, sizeof(line), maps)) {
            unsigned long from, to;
            if (sscanf(line, "%lx-%lx", &from, &to) == 2 && rip >= from && rip < to) {
                ssize_t written_=write(2, line, strlen(line)); (void)written_;
                found = 1;
                break;
            }
        }
        if (maps) fclose(maps);
        if (!found) { ssize_t written_=write(2, "none\n", 5); (void)written_; }
        const char *guest_name=runtime_thread_current_name();
        if (guest_name) {
            snprintf(line,sizeof(line),"  guest thread: %s\n",guest_name);
            { ssize_t written_=write(2,line,strlen(line)); (void)written_; }
        }
    }
    /* Host call chain (frames with unwind info; guest frames end it). */
    void *frames[32];
    int depth = backtrace(frames, 32);
    for (int i = 2; i < depth; ++i) {
        if (dladdr(frames[i], &where) && where.dli_fname)
            snprintf(line, sizeof(line), "  #%d %s+0x%lx (%s)\n", i, where.dli_fname,
                     (unsigned long)((uintptr_t)frames[i] - (uintptr_t)where.dli_fbase), where.dli_sname ? where.dli_sname : "?");
        else
            snprintf(line, sizeof(line), "  #%d %p\n", i, frames[i]);
        ssize_t written_=write(2, line, strlen(line)); (void)written_;
    }
    _exit(128 + sig);
}
#endif
#ifndef _WIN32
/* Watchdog: dump RIP and the rbp frame chain of every thread (guest offsets
 * when inside the image). Reads use process_vm_readv so bad frames cannot fault. */
static uintptr_t exe_base;
static void write_hex(char *out, uint64_t v) {
    const char digits[] = "0123456789abcdef";
    for (int i = 0; i < 16; ++i) out[i] = digits[(v >> (60 - i * 4)) & 15];
}
static void dump_frames(ucontext_t *uc) {
    char line[] = "  tid=0000000000000000 rip=0000000000000000 image-relative=0000000000000000 host-relative=0000000000000000\n";
    uintptr_t rip=(uintptr_t)uc->uc_mcontext.gregs[REG_RIP], rbp=(uintptr_t)uc->uc_mcontext.gregs[REG_RBP];
    uint64_t tid=(uint64_t)gettid();
    /* First argument register: the lock address when a thread waits on a futex. */
    char arg[]="  tid=0000000000000000 rdi=0000000000000000\n";
    write_hex(arg+6,tid); write_hex(arg+27,(uint64_t)uc->uc_mcontext.gregs[REG_RDI]);
    { ssize_t written_=write(2,arg,sizeof(arg)-1); (void)written_; }
    for (int depth=0; depth<24; ++depth) {
        write_hex(line+6,tid); write_hex(line+27,rip); write_hex(line+59,rip-(uintptr_t)image); write_hex(line+90,rip-exe_base);
        { ssize_t written_=write(2,line,sizeof(line)-1); (void)written_; }
        uintptr_t frame[2];
        if (!rbp || read_self_memory(frame,rbp,sizeof(frame))!=(ssize_t)sizeof(frame)) break;
        if (frame[0]<=rbp) break;
        rbp=frame[0]; rip=frame[1];
    }
}
static void thread_dump(int sig, siginfo_t *info, void *context) { (void)sig; (void)info; dump_frames(context); }
static void watchdog(int sig, siginfo_t *info, void *context) {
    (void)info;
    const char head[]="STOP: watchdog timeout; thread stacks:\n";
    { ssize_t written_=write(2,head,sizeof(head)-1); (void)written_; }
    dump_frames(context);
    int dir=open("/proc/self/task",O_RDONLY|O_DIRECTORY);
    char buffer[4096];
    long n;
    pid_t self=gettid();
    while (dir>=0 && (n=syscall(SYS_getdents64,dir,buffer,sizeof(buffer)))>0)
        for (long at=0; at<n;) {
            struct { uint64_t ino; int64_t off; unsigned short reclen; unsigned char type; char name[]; } *d=(void *)(buffer+at);
            pid_t tid=(pid_t)strtol(d->name,NULL,10);
            if (tid>0 && tid!=self) { syscall(SYS_tgkill,getpid(),tid,SIGUSR2); usleep(20000); }
            at+=d->reclen;
        }
    usleep(100000);
    _exit(128 + sig);
}
#endif
/* param.sfo lookup: string or integer value of key, 0 when absent. */
static int sfo_value(const char *path, const char *key, char *text, size_t text_size, uint32_t *number) {
    FILE *f=fopen(path,"rb");
    if (!f) return 0;
    unsigned char data[65536];
    size_t n=fread(data,1,sizeof(data),f); fclose(f);
    if (n<20 || memcmp(data,"\0PSF",4)) return 0;
    uint32_t keys, values, count;
    memcpy(&keys,data+8,4); memcpy(&values,data+12,4); memcpy(&count,data+16,4);
    for (uint32_t i=0;i<count && 20+i*16+16<=n;++i) {
        const unsigned char *e=data+20+i*16;
        uint16_t key_offset, format; uint32_t length, offset;
        memcpy(&key_offset,e,2); memcpy(&format,e+2,2); memcpy(&length,e+4,4); memcpy(&offset,e+12,4);
        if (keys+key_offset>=n || values+offset+length>n || strcmp((const char *)data+keys+key_offset,key)) continue;
        if (format==0x0404 && number && length>=4) { memcpy(number,data+values+offset,4); return 1; }
        if (text && text_size) {
            size_t copy=length<text_size-1 ? length : text_size-1;
            memcpy(text,data+values+offset,copy); text[copy]=0;
        }
        return 1;
    }
    return 0;
}
static int mapped(Segment *segments, uint64_t count, uint64_t address, uint64_t bytes) {
    for (uint64_t i = 0; i < count; ++i)
        if (address >= segments[i].address && bytes <= segments[i].size &&
            address - segments[i].address <= segments[i].size - bytes) return 1;
    return 0;
}
/* BBPATCH2 (patches.py): the patches' image base, then byte writes at image offsets, applied
 * after relocation. A write may replace a whole base-relative pointer slot (60/90 FPS++ swap
 * function pointers): the patch holds the address at the patches' base, rebased here. */
static void apply_patches(const char *path, Segment *segments, uint64_t ns, const Reloc *relocs, uint64_t nr) {
    FILE *f=fopen(path,"rb");
    char magic[8];
    if (!f || fread(magic,1,8,f)!=8 || memcmp(magic,"BBPATCH2",8)) fail("invalid patch file");
    uint64_t base=read64(f), count=read64(f), bytes=0, rebased=0;
    unsigned char data[4096];
    for (uint64_t i=0;i<count;++i) {
        uint64_t offset=read64(f), length=read64(f);
        if (!length || length>sizeof(data) || !mapped(segments,ns,offset,length) || fread(data,1,length,f)!=length)
            fail("bad patch entry");
        uint64_t slots[sizeof(data)/8]; size_t nslots=0;
        for (uint64_t r=0;r<nr;++r) {
            if (!(relocs[r].target<offset+length && offset<relocs[r].target+8)) continue;
            uint64_t target=relocs[r].target, value;
            if (relocs[r].kind || target<offset || target+8>offset+length) fail("patch overlaps a relocation");
            memcpy(&value,data+(target-offset),8);
            if (value<base || !mapped(segments,ns,value-base,1)) fail("patch writes a pointer outside the image");
            slots[nslots++]=target;
        }
        memcpy(image+offset,data,length);
        for (size_t s=0;s<nslots;++s) {
            uint64_t value;
            memcpy(&value,image+slots[s],8);
            value=(uint64_t)(uintptr_t)image+(value-base);
            memcpy(image+slots[s],&value,8);
        }
        rebased+=nslots;
        bytes+=length;
    }
    if (fgetc(f)!=EOF) fail("trailing data in patch file");
    fclose(f);
    printf("Patches: %" PRIu64 " writes, %" PRIu64 " bytes applied, %" PRIu64 " pointers rebased\n",count,bytes,rebased);
}
/* Restarts the game through run.sh (the settings menu: a new render resolution is a patch
 * applied at start). Descriptors are closed first so the old GPU device and its memory are
 * released before the new process opens its own. */
volatile int runtime_restarting;
void runtime_restart(void) {
    fflush(NULL);
    /* The GPU threads still run until exec: their Vulkan calls fail once the device fd is
     * closed below, and an assertion there must not end the process (exit 23) before exec. */
    runtime_restarting = 1;
    __sync_synchronize();
#ifdef _WIN32
    /* SacredFire: run.py sets BB_RESTART_EXIT_CODE and starts the game again itself when it ends
     * with that code (new patches, same console and log). The process ends at once, as exec
     * replaces it on Linux: the GPU threads must not run its exit handlers. */
    const char *restart_code=getenv("BB_RESTART_EXIT_CODE");
    if (restart_code && *restart_code) {
        puts("Runtime: restarting (run.py starts the game again)");
        fflush(NULL);
        TerminateProcess(GetCurrentProcess(),(UINT)atoi(restart_code));
    }
    /* Otherwise BB_RESTART_COMMAND: the launch command line, started again (new patches). */
    const char *command=getenv("BB_RESTART_COMMAND");
    puts("Runtime: restarting through run.py");
    if (!command || !*command) { fputs("runtime_restart: BB_RESTART_COMMAND is not set\n",stderr); _exit(1); }
    char *line=_strdup(command);
    /* Same output handles: a launcher reading the game's log keeps reading the new launch. */
    STARTUPINFOA startup={.cb=sizeof(startup),.dwFlags=STARTF_USESTDHANDLES,
                          .hStdInput=GetStdHandle(STD_INPUT_HANDLE),.hStdOutput=GetStdHandle(STD_OUTPUT_HANDLE),
                          .hStdError=GetStdHandle(STD_ERROR_HANDLE)};
    PROCESS_INFORMATION process;
    if (!line || !CreateProcessA(NULL,line,NULL,NULL,TRUE,0,NULL,NULL,&startup,&process)) {
        fprintf(stderr,"runtime_restart: CreateProcess failed (%lu)\n",GetLastError()); _exit(1);
    }
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
    /* The new launch waits for this process's GPU device to go away (run.py --after). */
    TerminateProcess(GetCurrentProcess(),0);
#else
    puts("Runtime: restarting through run.sh");
    syscall(SYS_close_range, 3u, ~0u, 0u);
    execlp("bash", "bash", "run.sh", (char *)NULL);
    perror("runtime_restart: exec");
    _exit(1);
#endif
}

int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
#ifndef _WIN32
    /* Keep host heap objects handed to the guest (thread handles, TLS) in the
       non-PIE brk heap, i.e. below 1 TiB: the guest packs pointers into 40 bits. */
    mallopt(M_ARENA_MAX,1);
    mallopt(M_MMAP_THRESHOLD,32*1024*1024);
#endif
    if (argc == 2 && !strcmp(argv[1], "--vulkan-only")) return vulkan_smoke();
#ifdef _WIN32
    /* The PS4 user range must stay free of host allocations (GPU driver, heaps), and the guest
     * TCB needs one of the 64 TEB TLS slots before DLLs (Vulkan drivers) take them. */
    runtime_memory_reserve();
    runtime_thread_tcb_offset();
#endif
    check_cpu();
    int cpu_only = 0, strict_imports = 0, list_imports = 0;
    unsigned timeout_seconds = 10;
    const char *content_profile=NULL, *app0=NULL, *user_dir=NULL, *patch_file=NULL, *import_names=NULL;
    for (int i = 2; i < argc; ++i) {
        if (!strcmp(argv[i], "--cpu-only")) cpu_only = 1;
        else if (!strcmp(argv[i], "--strict-imports")) strict_imports = 1;
        /* SacredFire: --list-imports resolves every import, prints the outcome and exits without running. */
        else if (!strcmp(argv[i], "--list-imports")) { list_imports = 1; cpu_only = 1; }
        else if (!strcmp(argv[i], "--import-names") && i+1<argc) import_names=argv[++i];
        else if (!strcmp(argv[i], "--content-profile") && i+1<argc) content_profile=argv[++i];
        else if (!strcmp(argv[i], "--app0") && i+1<argc) app0=argv[++i];
        else if (!strcmp(argv[i], "--user") && i+1<argc) user_dir=argv[++i];
        else if (!strcmp(argv[i], "--patches") && i+1<argc) patch_file=argv[++i];
        else if (!strcmp(argv[i], "--timeout") && i+1<argc) timeout_seconds=(unsigned)strtoul(argv[++i],NULL,10);
        else { fprintf(stderr, "Unknown option: %s\n", argv[i]); return 1; }
    }
    if (argc < 2) {
        fprintf(stderr, "Usage: %s boot.bin [--cpu-only] [--strict-imports] [--list-imports] [--import-names file] [--content-profile file] [--app0 dir] [--user dir] [--patches file] [--timeout seconds] | --vulkan-only\n", argv[0]);
        return 1;
    }
    if (import_names) {
        int loaded = runtime_load_import_names(import_names);
        if (loaded < 0) fail("cannot read the import names file");
        printf("Import names: %d symbols from %s\n", loaded, import_names);
    }
    if (content_profile) {
        /* BBCONT01: SKU and the four user-defined parameters. BBCONT02 adds the installed
         * add-ons (DLC): a count and 20-byte entitlement labels (scripts/content_profile.py). */
        FILE *profile=fopen(content_profile,"rb");
        static unsigned char data[32+64*20+1];
        if (!profile) fail("cannot open content profile");
        size_t size=fread(data,1,sizeof(data),profile);
        fclose(profile);
        int v2=size>=32 && !memcmp(data,"BBCONT02",8);
        if (size==sizeof(data) || (!v2 && (size!=28 || memcmp(data,"BBCONT01",8)))) fail("invalid content profile");
        uint32_t values[6];
        for (unsigned i=0;i<(v2 ? 6u : 5u);++i) {
            unsigned char *p=data+8+i*4;
            values[i]=(uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
        }
        runtime_content_configure(values);
        if (v2) {
            if (values[5]>64 || size!=32+values[5]*20) fail("invalid content profile add-on list");
            for (uint32_t i=0;i<values[5];++i) runtime_content_add_addon((const char *)data+32+i*20);
        }
    }
    if (app0) {
        runtime_file_configure(app0, user_dir ? user_dir : "user");
        char sfo[4096], id[16]="";
        snprintf(sfo,sizeof(sfo),"%s/sce_sys/param.sfo",app0);
        if (sfo_value(sfo,"INSTALL_DIR_SAVEDATA",id,sizeof(id),NULL) || sfo_value(sfo,"TITLE_ID",id,sizeof(id),NULL))
            runtime_savedata_configure(id);
        char title_id[16]="";
        if (sfo_value(sfo,"TITLE_ID",title_id,sizeof(title_id),NULL)) runtime_np_set_title(title_id);
    }
    bbgpu_register_kernel();
#ifdef _WIN32
    SYSTEM_INFO system_info; GetSystemInfo(&system_info); page_size = system_info.dwPageSize;
    AddVectoredExceptionHandler(1, vectored_fault);
    SetUnhandledExceptionFilter(unhandled_fault);
    signal(SIGABRT, on_abort_signal);
    _set_invalid_parameter_handler(on_invalid_parameter);
    _set_purecall_handler(on_purecall);
    if (getenv("BB_STRICT_HANDLES")) {
        PROCESS_MITIGATION_STRICT_HANDLE_CHECK_POLICY strict={0};
        strict.RaiseExceptionOnInvalidHandleReference=1;
        strict.HandleExceptionsPermanentlyEnabled=1;
        if (!SetProcessMitigationPolicy(ProcessStrictHandleCheckPolicy,&strict,sizeof(strict)))
            fprintf(stderr,"BB_STRICT_HANDLES: policy not set (%lu)\n",GetLastError());
    }
    (void)timeout_seconds; /* no watchdog on Windows */
#else
    page_size = (size_t)sysconf(_SC_PAGESIZE);
    struct sigaction sa = {0}; sa.sa_sigaction = fault; sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL); sigaction(SIGILL, &sa, NULL); sigaction(SIGBUS, &sa, NULL);
    Dl_info self_info;
    if (dladdr((void *)main,&self_info)) exe_base=(uintptr_t)self_info.dli_fbase;
    struct sigaction dump = {0}; dump.sa_sigaction = thread_dump; dump.sa_flags = SA_SIGINFO|SA_RESTART;
    sigemptyset(&dump.sa_mask); sigaction(SIGUSR2, &dump, NULL);
    struct sigaction alarm_action = {0}; alarm_action.sa_sigaction = watchdog; alarm_action.sa_flags = SA_SIGINFO;
    sigemptyset(&alarm_action.sa_mask); sigaction(SIGALRM, &alarm_action, NULL);
    alarm(timeout_seconds); /* 0 disables the watchdog */
#endif
    FILE *f = fopen(argv[1], "rb");
    if (!f) fail("cannot open boot file; run prepare.py first");
    char magic[8];
    if (fread(magic, 1, 8, f) != 8 || (memcmp(magic, "BBPROBE1", 8) && memcmp(magic, "BBPROBE2", 8) && memcmp(magic,"BBPROBE3",8) && memcmp(magic,"BBPROBE4",8) && memcmp(magic,"BBPROBE5",8))) fail("bad boot file signature");
    uint64_t size = read64(f), entry = read64(f), ns = read64(f), nr = read64(f);
    import_count = read64(f);
    uint64_t capabilities = memcmp(magic, "BBPROBE1", 8) ? read64(f) : 0;
    if (capabilities & ~UINT64_C(1)) fail("unknown runtime capabilities");
    runtime_start(strict_imports ? 0 : capabilities);
    if (!size || size > 512*1024*1024 || entry >= size || !ns || ns > 64 || nr > 1000000 || import_count > 100000)
        fail("boot file limits exceeded");
    int multi=!memcmp(magic,"BBPROBE5",8);
    int linked=!memcmp(magic,"BBPROBE3",8) || !memcmp(magic,"BBPROBE4",8) || multi;
    int native_libc=linked && !strict_imports && (capabilities&1);
    uint64_t main_tls[4]={0};
    uint64_t nb=0,procparam=0;
    uint64_t *bindings=calloc(import_count ? import_count : 1,sizeof(*bindings));
    uint64_t *binding_kinds=calloc(import_count ? import_count : 1,sizeof(*binding_kinds));
    if (!bindings || !binding_kinds) fail("allocation failed");
    if (multi) {
        /* BBPROBE5: procparam, eboot TLS, module table, bindings (link_modules.py). */
        procparam=read64(f);
        for (int i=0;i<4;++i) main_tls[i]=read64(f);
        module_count=read64(f);
        if (!module_count || module_count>sizeof(modules)/sizeof(*modules)) fail("invalid module count");
        for (uint64_t m=0;m<module_count;++m) {
            LinkedModule *x=&modules[m];
            x->base=read64(f); x->size=read64(f); x->init=read64(f); x->tls_address=read64(f);
            x->tls_memsz=read64(f); x->tls_filesz=read64(f); x->tls_module=read64(f);
        }
        nb=read64(f);
    } else if (linked) {
        LinkedModule *x=&modules[0];
        module_count=1;
        x->base=read64(f); x->size=read64(f); x->init=read64(f);
        x->tls_address=read64(f); x->tls_memsz=read64(f); x->tls_filesz=read64(f); x->tls_module=2; nb=read64(f);
        procparam=read64(f);
        if (!memcmp(magic,"BBPROBE4",8)) for (int i=0;i<4;++i) main_tls[i]=read64(f);
    }
    if (linked) {
        if (main_tls[1]>main_tls[2] || main_tls[2]>1024*1024 || main_tls[0]>size ||
            main_tls[1]>size-main_tls[0] || (main_tls[3] & (main_tls[3]-1)) || main_tls[3]>4096)
            fail("invalid eboot TLS metadata");
        for (uint64_t m=0;m<module_count;++m) {
            LinkedModule *x=&modules[m];
            if (x->base>=size || !x->size || x->size>size-x->base || x->init<x->base || x->init-x->base>=x->size ||
                (x->tls_module && (x->tls_address>=size || x->tls_memsz>size-x->tls_address || x->tls_memsz>1024*1024 ||
                                   x->tls_filesz>x->tls_memsz || x->tls_module<2 || x->tls_module>7)))
                fail("invalid linked module metadata");
        }
        if (nb>import_count) fail("invalid binding count");
        for (uint64_t i=0;i<nb;++i) {
            uint64_t index=read64(f),address=read64(f),kind=read64(f);
            int inside=0;
            for (uint64_t m=0;m<module_count;++m)
                if (address>=modules[m].base && address-modules[m].base<modules[m].size) inside=1;
            if (index>=import_count || !inside || (kind!=1 && kind!=2) || bindings[index]) fail("invalid native binding");
            bindings[index]=address; binding_kinds[index]=kind;
        }
    }
    Segment *segments = calloc(ns, sizeof(*segments));
    Reloc *relocs = calloc(nr ? nr : 1, sizeof(*relocs));
    names = calloc(import_count ? import_count : 1, sizeof(*names));
    if (!segments || !relocs || !names) fail("allocation failed");
    for (uint64_t i = 0; i < ns; ++i) {
        segments[i].address = read64(f);
        segments[i].size = read64(f);
        segments[i].flags = read64(f);
        if (segments[i].address > size || segments[i].size > size - segments[i].address ||
            segments[i].address % page_size || segments[i].flags > 7) fail("bad segment");
    }
    if (fread(names, 128, import_count, f) != import_count) fail("truncated import names");
    for (uint64_t i = 0; i < import_count; ++i)
        if (!memchr(names[i], 0, 128)) fail("unterminated import name");
    for (uint64_t i = 0; i < nr; ++i) {
        relocs[i].target = read64(f);
        relocs[i].kind = read64(f);
        relocs[i].value = read64(f);
        relocs[i].addend = read64(f);
        if (!mapped(segments, ns, relocs[i].target, 8) || relocs[i].kind > 2 ||
            (relocs[i].kind && relocs[i].value >= import_count) ||
            (relocs[i].kind != 2 && relocs[i].addend) || relocs[i].addend >= page_size) fail("bad relocation");
    }
    for (uint64_t m=0;m<module_count;++m)
        if (!mapped(segments,ns,modules[m].init,1) || (modules[m].tls_module && !mapped(segments,ns,modules[m].tls_address,modules[m].tls_memsz)))
            fail("unmapped module metadata");
    if (module_count && !mapped(segments,ns,procparam,64)) fail("unmapped procparam");
    for (uint64_t i=0;i<import_count;++i) {
        if (!bindings[i]) continue;
        if (!mapped(segments,ns,bindings[i],1)) fail("unmapped native export");
        if (binding_kinds[i]==1) {
            int executable=0;
            for (uint64_t s=0;s<ns;++s)
                if ((segments[s].flags&1) && bindings[i]>=segments[s].address &&
                    bindings[i]-segments[s].address<segments[s].size) executable=1;
            if (!executable) fail("native function is not executable");
        }
    }
    image = allocate(round_page(size));
    image_bytes = size;
    if (fread(image, 1, size, f) != size || fgetc(f) != EOF) fail("incorrect memory image size");
    fclose(f);
    if (!cpu_only) {
        char title[128]="PS4 game", serial[16]="UNKNOWN", sfo[4096];
        uint32_t attributes=0;
        snprintf(sfo,sizeof(sfo),"%s/sce_sys/param.sfo",app0 ? app0 : ".");
        sfo_value(sfo,"TITLE",title,sizeof(title),NULL);
        sfo_value(sfo,"TITLE_ID",serial,sizeof(serial),NULL);
        sfo_value(sfo,"ATTRIBUTE",NULL,0,&attributes);
        uint64_t sdk=0;
        if (procparam) memcpy(&sdk,image+procparam+16,8); /* procparam: size, magic, count, sdk_version */
        char icon[4200];
        snprintf(icon,sizeof(icon),"%s/sce_sys/icon0.png",app0);
        BbGpuConfig gpu={title,serial,user_dir ? user_dir : "user",(uint32_t)sdk,attributes,1920,1080,icon};
        gpu_enabled=1; /* page tracking starts while the rasterizer registers guest memory */
        if (bbgpu_init(&gpu)) fail("GPU initialization failed");
        printf("GPU: window and Vulkan presenter ready; SDK 0x%08x, %u HLE symbols\n",(unsigned)sdk,bbgpu_symbol_count());
    }
    unsigned char *traps = allocate(round_page((import_count + 1) * 32));
    unsigned char *data_traps = allocate((import_count + 1) * page_size);
    protect(data_traps, (import_count + 1) * page_size, 0);
    for (uint64_t i = 0; i < import_count; ++i) {
        unsigned char *t = traps + i * 32;
        /* SysV: mov edi, index; movabs rax, handler; jmp rax. No fake return values. */
        uint32_t index = (uint32_t)i;
        uintptr_t handler = (uintptr_t)unresolved;
        t[0] = 0x48; t[1] = 0x89; t[2] = 0xfe; /* mov rsi,rdi: preserve arg0 */
        t[3] = 0xbf; memcpy(t + 4, &index, 4);
        t[8] = 0x48; t[9] = 0xb8; memcpy(t + 10, &handler, 8);
        t[18] = 0xff; t[19] = 0xe0;
    }
    /* SacredFire (--list-imports): how each import was bound: 1 runtime, 2 native module, 3 trap. */
    unsigned char *outcome = calloc(import_count ? import_count : 1, 1);
    if (!outcome) fail("allocation failed");
    for (uint64_t i = 0; i < nr; ++i) {
        uintptr_t value = relocs[i].kind == 2 ? (uintptr_t)(data_traps + page_size * relocs[i].value + relocs[i].addend)
                        : relocs[i].kind == 1 ? (uintptr_t)(traps + 32 * relocs[i].value)
                        : (uintptr_t)image + relocs[i].value;
        if (relocs[i].kind) {
            uintptr_t resolved = runtime_resolve(names[relocs[i].value], relocs[i].kind == 2);
            if (resolved) { value = resolved + relocs[i].addend; outcome[relocs[i].value] = 1; }
            else if (native_libc && bindings[relocs[i].value]) {
                uint64_t address=bindings[relocs[i].value];
                if (binding_kinds[relocs[i].value]!=relocs[i].kind || !mapped(segments,ns,address,relocs[i].addend+1)) fail("native export kind/range mismatch");
                value=(uintptr_t)image+address+relocs[i].addend;
                outcome[relocs[i].value] = 2;
            } else outcome[relocs[i].value] = 3;
        }
        memcpy(image + relocs[i].target, &value, 8);
    }
    if (list_imports) {
        static const char *words[] = {"unreferenced", "runtime", "native", "unresolved"};
        unsigned counts[4] = {0};
        for (uint64_t i = 0; i < import_count; ++i) {
            const char *symbol = runtime_symbol(names[i]);
            printf("%-12s %-40s %s\n", words[outcome[i]], names[i], symbol ? symbol : "?");
            ++counts[outcome[i]];
        }
        printf("Imports: %u runtime, %u native, %u unresolved, %u unreferenced\n", counts[1], counts[2], counts[3], counts[0]);
        return 0;
    }
    if (patch_file) apply_patches(patch_file, segments, ns, relocs, nr);
#ifdef _WIN32
    printf("Guest TCB loads redirected to the TEB TLS slot: %" PRIu64 "\n", patch_tcb_loads(segments, ns));
#endif
    if (!cpu_only) bbgpu_patch_image(image, size);
    protect(traps, round_page((import_count + 1) * 32), 5);
    protect(image, round_page(size), 0);
    int executable_entry = 0;
    for (uint64_t i = 0; i < ns; ++i) {
        unsigned flags = (unsigned)segments[i].flags;
        if (!(flags & 1)) {
            /* Non-code segments (data, bss, relro) need read-write access */
            flags |= 2;
        }
        protect(image + segments[i].address, round_page(segments[i].size), flags);
        if ((segments[i].flags & 1) && entry >= segments[i].address && entry - segments[i].address < segments[i].size)
            executable_entry = 1;
    }
    if (!executable_entry) fail("entry is not executable");
    printf("Mapped %" PRIu64 " bytes, %" PRIu64 " segments; applied %" PRIu64 " relocations\n", size, ns, nr);
    if (native_libc) {
        for (uint64_t m=0;m<module_count;++m) {
            int init_executable=0;
            for (uint64_t i=0;i<ns;++i)
                if ((segments[i].flags&1) && modules[m].init>=segments[i].address && modules[m].init-segments[i].address<segments[i].size) init_executable=1;
            if (!init_executable) fail("module init is not executable");
            if (modules[m].tls_module)
                runtime_set_module_tls(modules[m].tls_module,image+modules[m].tls_address,modules[m].tls_filesz,modules[m].tls_memsz);
        }
        runtime_set_main_tls(image+main_tls[0],main_tls[1],main_tls[2],main_tls[3]);
        runtime_thread_attach_main();
        runtime_set_procparam(image+procparam);
        /* Dependencies start in link order (libc first), as the PS4 dynamic linker does. */
        for (uint64_t m=0;m<module_count;++m) {
            printf("Starting linked module %" PRIu64 " at image offset 0x%" PRIx64 "; native bindings=%" PRIu64 "\n",m,modules[m].init,nb);
            typedef int (ABI *ModuleInit)(uint64_t,void *,void *);
            int result=((ModuleInit)(image+modules[m].init))(0,NULL,NULL);
            printf("Module %" PRIu64 " initializer returned %d\n",m,result);
            if (result) fail("module initializer failed");
        }
    }
    runtime_cinematic_start(image);
    runtime_frontend_start(image);
    printf("Entering original x86-64 code at guest offset 0x%" PRIx64 "\n", entry);
    entered_game=1;
    struct { uint64_t argc; const char *argv[2]; } params = {1, {"/app0/eboot.bin", NULL}};
#ifdef _WIN32
    typedef void (ABI *Entry)(void *, void (ABI *)(void));
    ((Entry)(image + entry))(&params, guest_exit);
#else
    /* The guest main thread runs on a stack below 1 TiB like PS4 stacks. */
    enum { MAIN_STACK=8*1024*1024 };
    unsigned char *stack=runtime_low_map(MAIN_STACK,PROT_READ|PROT_WRITE);
    if (!stack) fail("cannot allocate guest main stack");
    enter_on_stack(image+entry,&params,(void *)guest_exit,stack+MAIN_STACK-64);
#endif
    fail("entry unexpectedly returned");
}
