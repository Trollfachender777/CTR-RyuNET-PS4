"""Actual native SELF: fresh startup, user isolation and no global imports."""
import json,struct,unittest
from test_native_bridge import ModuleMachine,ROOT,P,UI,SCRATCH,prepare,UC_X86_REG_RAX
PREFIX='/data/ryunet/users/12345678/'
def name(m):
    m.call(m.exports[prepare.nid('ctr_player_name')]);pointer=m.uc.reg_read(UC_X86_REG_RAX)
    return bytes(m.uc.mem_read(pointer,17)).split(b'\0')[0]
class Tests(unittest.TestCase):
    def test_existing_global_profile_key_and_contacts_are_ignored_without_modifying_them(self):
        m=ModuleMachine('ui_profile_missing');m.files={
          '/data/ryunet/profile.ini':b'version=2\nnickname=OldPersonalName\nidentity=installation\n',
          '/data/ryunet/identity.key':bytes(range(32)).hex().encode(),
          '/data/ryunet/settings.ini':b'version=1\nfps=0\nfriends=OldContact\n'}
        before=dict(m.files);self.assertEqual(m.initialize(),0);self.assertEqual(name(m),b'RyuNET')
        for path,data in before.items():self.assertEqual(m.files[path],data)
        # Settings are defaulted, without bringing old contacts into a new user.
        m.allowed.append((SCRATCH,SCRATCH+4096))
        self.assertEqual(m.call(m.exports[prepare.nid('ctr_settings_snapshot')],SCRATCH),0)
        self.assertEqual(struct.unpack('<I',m.uc.mem_read(SCRATCH+28,4))[0],0)
        poll=m.exports[prepare.nid('ctr_menu_poll')]
        for _ in range(120):m.call(poll,7,0)
        self.assertEqual(m.opened_dialogs,1);self.assertEqual(m.random_calls,0)
    def test_two_local_users_load_only_their_own_name_key_and_settings(self):
        for user,wanted,keybyte in ((0x12345678,b'FirstPlayer',1),(42,b'SecondPlayer',2)):
            m=ModuleMachine('ui_user_scope');m.initial_user=user
            m.files={}
            for uid,alias,byte in ((0x12345678,b'FirstPlayer',1),(42,b'SecondPlayer',2)):
                prefix=f'/data/ryunet/users/{uid:08x}/'
                m.files[prefix+'profile.ini']=b'version=2\nnickname='+alias+b'\nidentity=installation\n'
                m.files[prefix+'identity.key']=(bytes([byte])*32).hex().encode()
                m.files[prefix+'settings.ini']=b'version=1\nfps=30\nfriends=Contact'+str(byte).encode()+b'\n'
            before=dict(m.files);self.assertEqual(m.initialize(),0);self.assertEqual(name(m),wanted)
            for path,data in before.items():self.assertEqual(m.files[path],data)
            self.assertEqual(m.random_calls,0)
            record=next(r for r in UI['imports'] if r['name']=='sceUserServiceGetUserName')
            pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+record['got'],8))[0]
            m.allowed.append((SCRATCH,SCRATCH+4096));self.assertEqual(m.call(pointer,user,SCRATCH,64),0)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH,17)).split(b'\0')[0],wanted)
            self.assertEqual(m.original_username_calls,0)
    def test_legacy_ownerless_profile_inside_new_namespace_cannot_authenticate(self):
        m=ModuleMachine('ui_ownerless');m.files={PREFIX+'profile.ini':b'version=1\nnickname=OldPersonalName\n'}
        before=dict(m.files);self.assertEqual(m.initialize(),0);self.assertEqual(name(m),b'RyuNET')
        record=next(r for r in P[1]['records'] if r['name']=='sceNpGetState')
        pointer=struct.unpack('<Q',m.uc.mem_read(0x904000000+record['cache'],8))[0]
        m.allowed.append((SCRATCH,SCRATCH+4096));self.assertEqual(m.call(pointer,0x12345678,SCRATCH),0)
        self.assertEqual(struct.unpack('<i',m.uc.mem_read(SCRATCH,4))[0],1)
        for path,data in before.items():self.assertEqual(m.files[path],data)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/user-isolation-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'actual native SELF; old global identity and friends ignored; two local users isolated; ownerless profile stays offline'},indent=2))
    raise SystemExit(not result.wasSuccessful())
