// SPDX-License-Identifier: GPL-2.0-only
// From OCTR v0.4 src/runtime_np_online.c.
#include "online_core.h"
static inline uint32_t ror32_online(uint32_t val, int shift) {
    return (val >> shift) | (val << (32 - shift));
}

void ctr_sha256(const uint8_t *data, size_t len, uint8_t hash[32]) {
    static const uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };
    uint32_t H[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };
    uint8_t buf[64];
    size_t padded_len = ((len + 8 + 64) / 64) * 64;
    for (size_t chunk = 0; chunk < padded_len; chunk += 64) {
        for (int i = 0; i < 64; i++) {
            size_t idx = chunk + i;
            if (idx < len) buf[i] = data[idx];
            else if (idx == len) buf[i] = 0x80;
            else if (idx >= padded_len - 8) {
                int shift = (7 - (int)(idx - (padded_len - 8))) * 8;
                buf[i] = (uint8_t)(((uint64_t)len * 8) >> shift);
            } else buf[i] = 0;
        }
        uint32_t W[64];
        for (int t = 0; t < 16; t++) {
            W[t] = ((uint32_t)buf[t*4] << 24) | ((uint32_t)buf[t*4+1] << 16) |
                   ((uint32_t)buf[t*4+2] << 8) | ((uint32_t)buf[t*4+3]);
        }
        for (int t = 16; t < 64; t++) {
            uint32_t s0 = ror32_online(W[t-15], 7) ^ ror32_online(W[t-15], 18) ^ (W[t-15] >> 3);
            uint32_t s1 = ror32_online(W[t-2], 17) ^ ror32_online(W[t-2], 19) ^ (W[t-2] >> 10);
            W[t] = W[t-16] + s0 + W[t-7] + s1;
        }
        uint32_t a=H[0], b=H[1], c=H[2], d=H[3], e=H[4], f=H[5], g=H[6], h=H[7];
        for (int t = 0; t < 64; t++) {
            uint32_t S1 = ror32_online(e, 6) ^ ror32_online(e, 11) ^ ror32_online(e, 25);
            uint32_t ch = (e & f) ^ ((~e) & g);
            uint32_t temp1 = h + S1 + ch + K[t] + W[t];
            uint32_t S0 = ror32_online(a, 2) ^ ror32_online(a, 13) ^ ror32_online(a, 22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t temp2 = S0 + maj;
            h = g; g = f; f = e; e = d + temp1;
            d = c; c = b; b = a; a = temp1 + temp2;
        }
        H[0] += a; H[1] += b; H[2] += c; H[3] += d;
        H[4] += e; H[5] += f; H[6] += g; H[7] += h;
    }
    for (int i = 0; i < 8; i++) {
        hash[i*4]   = (uint8_t)(H[i] >> 24);
        hash[i*4+1] = (uint8_t)(H[i] >> 16);
        hash[i*4+2] = (uint8_t)(H[i] >> 8);
        hash[i*4+3] = (uint8_t)(H[i]);
    }
}

uint64_t ctr_pid_for_name(const char *name) {
    if (!name || !*name) return 0;
    uint64_t h = 14695981039346656037ULL;
    char lower[128];
    size_t i = 0;
    for (; name[i] && i < sizeof(lower) - 1; i++) {
        char c = (name[i] >= 'A' && name[i] <= 'Z') ? (char)(name[i] + 32) : name[i];
        lower[i] = c;
        h ^= (uint8_t)c;
        h *= 1099511628211ULL;
    }
    lower[i] = '\0';
    uint8_t sha[32];
    ctr_sha256((const uint8_t *)lower, i, sha);
    uint64_t sha_u64 = 0;
    ctr_memcpy(&sha_u64, sha, sizeof(sha_u64));
    uint64_t mix = sha_u64 ^ h;
    uint64_t pid = 1810000000ULL + (mix % 80000000ULL);
    if (pid == 0) pid = 1810000001ULL;
    return pid;
}

