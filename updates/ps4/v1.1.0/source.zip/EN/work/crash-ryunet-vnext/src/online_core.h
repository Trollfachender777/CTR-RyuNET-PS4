// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include <stdint.h>
#include <stddef.h>
#if defined(_WIN32)
#define CTR_EXPORT __declspec(dllexport)
#else
#define CTR_EXPORT __attribute__((visibility("default")))
#endif

// Fixed-width ABI shared by the native PS4 bridge and the host regression tests.
typedef struct {
    int32_t (*resolve)(int32_t,const char*,void*,int32_t,int32_t,int32_t);
    int32_t (*http_connection)(int32_t,const char*,int32_t);
    int32_t (*http_request)(int32_t,int32_t,const char*,uint64_t);
    int32_t (*http_request2)(int32_t,const char*,const char*,uint64_t);
    int32_t (*http_status)(int32_t,int32_t*);
    int32_t (*sysmodule_load)(uint16_t);
    void (*refresh_modules)(void);
    void (*trace)(int32_t,int32_t);
} CtrNativeApi;

CTR_EXPORT int32_t ctr_core_init(const CtrNativeApi *api,const char *name);
// Startup gate: no valid local nickname means no community authentication.
CTR_EXPORT void ctr_core_set_online(int enabled);
CTR_EXPORT void *ctr_find_hook(const char *name);
CTR_EXPORT uint64_t ctr_pid_for_name(const char *name);
CTR_EXPORT const char *ctr_player_name(void);
CTR_EXPORT void ctr_core_set_user(int32_t user);
CTR_EXPORT int32_t ctr_rewrite_url(const char *url,char *output,size_t capacity);
void *ctr_memcpy(void *d,const void *s,size_t n);
void *ctr_memset(void *d,int c,size_t n);
int ctr_strcmp(const char *a,const char *b);
int ctr_strncmp(const char *a,const char *b,size_t n);
size_t ctr_strlen(const char *s);
const char *ctr_strstr(const char *text,const char *find);
