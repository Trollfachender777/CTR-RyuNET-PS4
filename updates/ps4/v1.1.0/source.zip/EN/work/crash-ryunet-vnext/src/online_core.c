// SPDX-License-Identifier: GPL-2.0-only
// Native adaptation of the NP / Demonware routing contracts used by OCTR v0.4.
// No CRT initialization, heap allocations, FILE objects or background threads.
#include "online_core.h"
#include "settings.h"
#include "sessions.h"
#include "profile.h"
#include "net_transport.h"
#define OK 0
#define INVALID ((int32_t)0x80550003)
#define SIGNED_OUT ((int32_t)0x80550006)
#define HTTP_ERROR ((int32_t)0x80431061)
#define COUNT(a) (sizeof(a)/sizeof((a)[0]))

static CtrNativeApi platform;
static char player[17];
static int32_t local_user=-1;
static uint64_t account;
static int initialized;
static uint32_t trace_counts[64];
static uint32_t next_request=100;
static int32_t request_id(void){return (int32_t)__atomic_fetch_add(&next_request,1,__ATOMIC_RELAXED);}
static void refresh(void){if(platform.refresh_modules)platform.refresh_modules();}
static void trace(int32_t stage,int32_t code){
    if(stage<0||stage>=64||!platform.trace)return;
    if(__atomic_fetch_add(&trace_counts[stage],1,__ATOMIC_RELAXED)<16)platform.trace(stage,code);
}
CTR_EXPORT const char *ctr_player_name(void){return player;}
CTR_EXPORT void ctr_core_set_user(int32_t user){if(user>=0)local_user=user;}
CTR_EXPORT void ctr_core_set_online(int enabled){initialized=enabled!=0;}

CTR_EXPORT int32_t ctr_core_init(const CtrNativeApi *api,const char *name){
    if(!api || !name)return INVALID;
    size_t n=ctr_strlen(name);if(!n || n>16)return INVALID;
    for(size_t i=0;i<n;i++){char c=name[i];if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-'))return INVALID;}
    platform=*api;ctr_memset(trace_counts,0,sizeof(trace_counts));ctr_memcpy(player,name,n+1);account=ctr_pid_for_name(name);ctr_sessions_reset();ctr_profile_reset();initialized=1;trace(1,0);return 0;
}
static int32_t np_state(int32_t user,int32_t *state){if(!state)return INVALID;refresh();local_user=user;*state=initialized?2:1;trace(30,*state);return 0;}
static int32_t np_online(int32_t user,void *out){if(!out)return INVALID;refresh();local_user=user;ctr_memset(out,0,20);size_t n=ctr_strlen(player);if(n>16)n=16;ctr_memcpy(out,player,n);return initialized?0:SIGNED_OUT;}
static int32_t np_id(int32_t user,void *out){if(!out)return INVALID;ctr_memset(out,0,36);return np_online(user,out);}
static int32_t np_account(int32_t user,uint64_t *out){if(!out)return INVALID;refresh();local_user=user;*out=account;return initialized?0:SIGNED_OUT;}
static int32_t np_user_for_account(uint64_t id,int32_t *out){if(!out)return INVALID;*out=-1;if(!initialized)return SIGNED_OUT;if(id==account && local_user>=0){*out=local_user;return 0;}return (int32_t)0x80550005;}
static int32_t np_plus(int32_t request,const void *param,void *result){(void)request;(void)param;if(result){ctr_memset(result,0,33);*(unsigned char*)result=1;}return initialized?0:SIGNED_OUT;}
static int32_t np_available(void){refresh();int32_t r=initialized?0:SIGNED_OUT;trace(32,r);return r;}
static int32_t np_parental(int32_t request,void *user,int8_t *age,void *info){(void)request;(void)user;if(age)*age=21;if(info)ctr_memset(info,0,3);return initialized?0:SIGNED_OUT;}
static int32_t np_poll(int32_t id,int32_t *out){(void)id;if(!out)return INVALID;*out=initialized?0:SIGNED_OUT;trace(33,*out);return 0;}
static int32_t np_token(int32_t request,const void *param,void *out){(void)request;(void)param;if(!out)return INVALID;ctr_memcpy(out,player,ctr_strlen(player)+1);int32_t r=initialized?0:SIGNED_OUT;trace(34,r);return r;}
static int32_t np_auth_code(int32_t request,const void *param,void *out){(void)request;(void)param;if(!out)return INVALID;ctr_memcpy(out,"AUTH_CODE",10);int32_t r=initialized?0:SIGNED_OUT;trace(35,r);return r;}
static int32_t np_request(const void *param){(void)param;return request_id();}
static int32_t generic_id(void){return request_id();}
static int32_t generic_ok(void){return 0;}
static int32_t unavailable(void){return SIGNED_OUT;}
typedef void (*LegacyCallback)(int32_t,int32_t,const void*,void*);
typedef void (*ToolkitCallback)(int32_t,int32_t,void*);
static LegacyCallback legacy_cb;
static ToolkitCallback toolkit_cb;
static void *legacy_arg,*toolkit_arg;
static int legacy_pending,toolkit_pending;
static int32_t register_legacy(void *cb,void *arg){if(!cb)return INVALID;legacy_arg=arg;legacy_cb=(LegacyCallback)cb;legacy_pending=1;trace(36,0);return 0;}
static int32_t register_toolkit(void *cb,void *arg){if(!cb)return INVALID;toolkit_arg=arg;toolkit_cb=(ToolkitCallback)cb;toolkit_pending=1;trace(37,0);return 0;}
static int32_t unregister_legacy(void *cb,void *arg){(void)arg;if(legacy_cb==(LegacyCallback)cb){legacy_cb=0;legacy_pending=0;}return 0;}
static int32_t unregister_toolkit(void *cb,void *arg){(void)arg;if(toolkit_cb==(ToolkitCallback)cb){toolkit_cb=0;toolkit_pending=0;}return 0;}
static int32_t check_callbacks(void){
    refresh();if(local_user<0 || !initialized)return 0;
    if(toolkit_cb && toolkit_pending){ToolkitCallback cb=toolkit_cb;void *arg=toolkit_arg;toolkit_pending=0;trace(38,2);cb(local_user,2,arg);}
    if(legacy_cb && legacy_pending){unsigned char id[36];LegacyCallback cb=legacy_cb;void *arg=legacy_arg;legacy_pending=0;np_id(local_user,id);trace(39,2);cb(local_user,2,id,arg);}return 0;
}

static const char *hosts[]={
 "lavender-ps4-auth3.prod.demonware.net","lavender-ps4-auth3.cert.demonware.net","lavender-ps4-auth3.dev.demonware.net",
 "prod.umbrella.demonware.net","cert.umbrella.demonware.net","dev.umbrella.demonware.net",
 "prod.uno.demonware.net","cert.uno.demonware.net","dev.uno.demonware.net",
 "lavender-ps4-lobby.prod.demonware.net","lavender-ps4-lobby.cert.demonware.net","lavender-ps4-lobby.dev.demonware.net",
 "stun.us.demonware.net","stun.eu.demonware.net","stun.jp.demonware.net","stun.au.demonware.net",
 "pipes-prod-glutton.public.aws.demonware.net","objectstore.prod.demonware.net","friends.dev.demonware.net"
};
static const char server[]="octr.ryu7w7.xyz";
static int redirects(const char *host){if(!host)return 0;for(size_t i=0;i<COUNT(hosts);i++)if(!ctr_strcmp(host,hosts[i]))return 1;return 0;}
CTR_EXPORT int32_t ctr_rewrite_url(const char *url,char *out,size_t capacity){
    if(!url || !out || !capacity)return INVALID;
    const char *scheme=ctr_strstr(url,"://");if(!scheme)return 0;
    const char *start=scheme+3,*end=start;
    while(*end && *end!='/' && *end!=':' && *end!='?' && *end!='#')end++;
    size_t n=(size_t)(end-start);char host[256];if(!n||n>=sizeof(host))return 0;
    ctr_memcpy(host,start,n);host[n]=0;if(!redirects(host))return 0;
    const char *path=end;if(*path==':'){path++;while(*path && *path!='/' && *path!='?' && *path!='#')path++;}
    const char prefix[]="http://octr.ryu7w7.xyz:8080";size_t a=sizeof(prefix)-1,b=ctr_strlen(path),slash=*path!='/'?1:0;
    if(a+slash+b+1>capacity)return INVALID;
    ctr_memcpy(out,prefix,a);if(slash)out[a++]='/';ctr_memcpy(out+a,path,b+1);return 1;
}
static int32_t http_conn(int32_t id,const char *url,int32_t keep){char out[4096];int r=ctr_rewrite_url(url,out,sizeof(out));trace(40,r);if(r<0||!platform.http_connection)return HTTP_ERROR;int32_t result=platform.http_connection(id,r?out:url,keep);trace(41,result);return result;}
static int32_t http_req(int32_t id,int32_t method,const char *url,uint64_t size){char out[4096];int r=ctr_rewrite_url(url,out,sizeof(out));trace(42,r);if(r<0||!platform.http_request)return HTTP_ERROR;int32_t result=platform.http_request(id,method,r?out:url,size);trace(43,result);return result;}
static int32_t http_req2(int32_t id,const char *method,const char *url,uint64_t size){char out[4096];int r=ctr_rewrite_url(url,out,sizeof(out));trace(44,r);if(r<0||!platform.http_request2)return HTTP_ERROR;int32_t result=platform.http_request2(id,method,r?out:url,size);trace(45,result);return result;}
static int32_t http_status(int32_t id,int32_t *status){if(!platform.http_status)return HTTP_ERROR;int32_t r=platform.http_status(id,status);trace(20,r?r:(status?*status:0));return r;}
static int32_t resolve(int32_t id,const char *host,void *out,int32_t timeout,int32_t retry,int32_t flags){if(!platform.resolve)return -1;int change=redirects(host);int32_t r=platform.resolve(id,change?server:host,out,timeout,retry,flags);if(change){trace(21,r);for(size_t i=0;i<COUNT(hosts);i++)if(!ctr_strcmp(host,hosts[i])){trace(22,(int32_t)i);break;}if(r==0&&out){uint32_t address;ctr_memcpy(&address,out,4);ctr_net_server(address);}}return r;}
static int32_t sysmodule_load(uint16_t id){if(!platform.sysmodule_load)return -1;int32_t r=platform.sysmodule_load(id);refresh();return r;}

typedef struct {int32_t status;void *error_object;uint64_t error_size;uint64_t data_size;} WebResponse;
_Static_assert(sizeof(WebResponse)==32,"NP WebApi response ABI");
typedef struct {int64_t id;int used;int method;uint32_t position;uint32_t length;char path[256];char response[32768];} WebRequest;
static WebRequest web_requests[32];
static WebRequest *find_request(int64_t id){for(size_t i=0;i<COUNT(web_requests);i++)if(web_requests[i].used && web_requests[i].id==id)return &web_requests[i];return 0;}
static size_t append(char *out,size_t pos,size_t capacity,const char *text){size_t n=ctr_strlen(text);if(pos+n>=capacity)return pos;ctr_memcpy(out+pos,text,n);out[pos+n]=0;return pos+n;}
static void account_decimal(char out[24]){char reverse[24];size_t n=0;uint64_t value=account;do{reverse[n++]=(char)('0'+value%10);value/=10;}while(value);for(size_t i=0;i<n;i++)out[i]=reverse[n-i-1];out[n]=0;}
static int32_t web_context(int32_t library,void *id){(void)library;(void)id;return request_id();}
static int32_t web_context_a(int32_t library,int32_t user){(void)library;local_user=user;return request_id();}
static int32_t web_create(int32_t context,const char *group,const char *path,int32_t method,const void *param,int64_t *out){
    (void)context;(void)group;(void)param;if(!out)return INVALID;*out=-1;
    size_t length=path?ctr_strlen(path):0;if(length>=256)return INVALID;
    for(size_t i=0;i<COUNT(web_requests);i++){int zero=0;if(__atomic_compare_exchange_n(&web_requests[i].used,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED)){
        WebRequest *r=&web_requests[i];r->id=request_id();r->method=method;r->position=0;r->length=0;if(path)ctr_memcpy(r->path,path,length+1);else r->path[0]=0;*out=r->id;return 0;}}
    return -1;
}
static int web_prepare(WebRequest *r){
    const char *json="{}";
    int session_length=ctr_sessions_json(r->path,r->method,r->response,sizeof(r->response));
    if(session_length<0)return INVALID;
    if(session_length>0){r->length=(uint32_t)session_length;r->position=0;return 0;}
    int friend_length=ctr_friends_json(r->path,r->response,sizeof(r->response));
    if(friend_length>0){r->length=(uint32_t)friend_length;r->position=0;return 0;}
    char id[24];account_decimal(id);size_t pos=0;r->response[0]=0;
    if(ctr_strstr(r->path,"profile")){
        #define ADD(s) pos=append(r->response,pos,sizeof(r->response),s)
        ADD("{\"profiles\":[{\"accountId\":\"");ADD(id);ADD("\",\"onlineId\":\"");ADD(player);
        ADD("\",\"region\":\"US\",\"isOfficiallyVerified\":false,\"user\":{\"accountId\":\"");ADD(id);ADD("\",\"onlineId\":\"");ADD(player);
        ADD("\"},\"relation\":\"me\",\"aboutMe\":\"Crash Team Racing Nitro-Fueled\",\"languagesUsed\":[\"es\"],\"avatarUrl\":\"\",\"profilePictureUrl\":\"\",\"personalDetail\":{\"displayName\":\"");ADD(player);
        ADD("\",\"firstName\":\"");ADD(player);ADD("\",\"middleName\":\"\",\"lastName\":\"\",\"profilePictureUrl\":\"\"}}],\"size\":1,\"totalResults\":1}");
        r->length=(uint32_t)pos;r->position=0;return 0;
    }
    if(ctr_strstr(r->path,"friendOnlineIdLists")){
        ADD("{\"friendOnlineIdLists\":[{\"user\":{\"accountId\":\"");ADD(id);ADD("\",\"onlineId\":\"");ADD(player);ADD("\"},\"friendOnlineIdList\":[]}]}");
        r->length=(uint32_t)pos;r->position=0;return 0;
    }
    #undef ADD
    if(ctr_strstr(r->path,"/v1/sessions"))json=r->method==1?"{\"sessionId\":\"ctr-ryunet-session\"}":"{\"sessions\":[],\"totalResults\":0}";
    else if(ctr_strstr(r->path,"friend")||ctr_strstr(r->path,"friendList"))json="{\"friendList\":[],\"friends\":[],\"totalResults\":0,\"offset\":0,\"limit\":500,\"start\":0,\"size\":0}";
    else if(ctr_strstr(r->path,"entitlements"))json="{\"entitlements\":[],\"totalResults\":0,\"start\":0,\"size\":0}";
    else if(ctr_strstr(r->path,"invitations"))json="{\"invitations\":[],\"totalResults\":0,\"size\":0}";
    r->length=(uint32_t)ctr_strlen(json);r->position=0;ctr_memcpy(r->response,json,r->length+1);
    return 0;
}
static int32_t web_send(int64_t id,const void *data,uint64_t size){(void)data;(void)size;WebRequest *r=find_request(id);if(!r)return INVALID;return web_prepare(r);}
static int32_t web_send2(int64_t id,const void *data,uint64_t size,WebResponse *response){int32_t ret=web_send(id,data,size);if(ret)return ret;WebRequest *r=find_request(id);if(response){response->status=200;response->error_object=0;response->error_size=0;response->data_size=r->length;}return 0;}
static int32_t web_read(int64_t id,void *out,uint64_t size){WebRequest *r=find_request(id);if(!r)return INVALID;if(!out && size)return INVALID;size_t n=r->length-r->position;if(size<n)n=(size_t)size;if(n){ctr_memcpy(out,r->response+r->position,n);r->position+=(uint32_t)n;}return (int32_t)n;}
static int32_t web_delete(int64_t id){WebRequest *r=find_request(id);if(!r)return INVALID;__atomic_store_n(&r->used,0,__ATOMIC_RELEASE);return 0;}
static int32_t web_header(int64_t id,const char *name,char *out,uint64_t size){(void)id;(void)name;if(out && size)out[0]=0;return 0;}
static int32_t web_header_length(int64_t id,const char *name,uint64_t *out){(void)id;(void)name;if(out)*out=0;return 0;}
static int32_t web_pool(int32_t id,void *out){(void)id;if(out)ctr_memset(out,0,32);return 0;}
static int32_t web_parse_npid(const char *json,void *out){if(!out)return INVALID;ctr_memset(out,0,32);if(!json)return 0;const char *p=ctr_strstr(json,"\"onlineId\"");if(!p)p=ctr_strstr(json,"\"npId\"");if(!p)return 0;while(*p&&*p!=':')p++;if(!*p)return 0;p++;while(*p&&*p!='\"')p++;if(!*p)return 0;p++;size_t n=0;while(p[n]&&p[n]!='\"'&&n<16)n++;ctr_memcpy(out,p,n);return 0;}

typedef struct {const char *name;void *fn;} Hook;
#define H(n,f) {n,(void*)f}
static const Hook hooks[]={
 H("sceNpGetState",np_state),H("sceNpGetOnlineId",np_online),H("sceNpGetNpId",np_id),H("sceNpGetAccountIdA",np_account),H("sceNpGetUserIdByAccountId",np_user_for_account),
 H("sceNpCheckPlus",np_plus),H("sceNpCheckNpAvailabilityA",np_available),H("sceNpGetParentalControlInfoA",np_parental),H("sceNpPollAsync",np_poll),
 H("sceNpCreateRequest",np_request),H("sceNpCreateAsyncRequest",np_request),H("sceNpDeleteRequest",generic_ok),H("sceNpAbortRequest",generic_ok),
 H("sceNpAuthCreateRequest",np_request),H("sceNpAuthCreateAsyncRequest",np_request),H("sceNpAuthDeleteRequest",generic_ok),H("sceNpAuthAbortRequest",generic_ok),H("sceNpAuthPollAsync",np_poll),H("sceNpAuthGetIdTokenA",np_token),H("sceNpAuthGetAuthorizationCodeA",np_auth_code),
 H("sceNpRegisterStateCallback",register_legacy),H("sceNpUnregisterStateCallback",unregister_legacy),H("sceNpRegisterStateCallbackForToolkit",register_toolkit),H("sceNpUnregisterStateCallbackForToolkit",unregister_toolkit),H("sceNpCheckCallback",check_callbacks),H("sceNpCheckCallbackForLib",check_callbacks),
 H("sceNpSetNpTitleId",generic_ok),H("sceNpNotifyPlusFeature",generic_ok),H("sceNpSetContentRestriction",generic_ok),
 H("sceNpInGameMessageInitialize",generic_ok),H("sceNpInGameMessageTerminate",generic_ok),H("sceNpInGameMessageCreateHandle",generic_id),H("sceNpInGameMessageDeleteHandle",generic_ok),H("sceNpInGameMessagePrepareA",generic_ok),H("sceNpInGameMessageSendDataA",generic_ok),H("sceNpInGameMessageGetMemoryPoolStatistics",web_pool),
 H("sceNpWebApiInitialize",generic_id),H("sceNpWebApiTerminate",generic_ok),H("sceNpWebApiCreateContext",web_context),H("sceNpWebApiCreateContextA",web_context_a),H("sceNpWebApiCreateHandle",generic_id),H("sceNpWebApiDeleteHandle",generic_ok),H("sceNpWebApiDeleteContext",generic_ok),
 H("sceNpWebApiCreateExtdPushEventFilter",generic_id),H("sceNpWebApiDeleteExtdPushEventFilter",generic_ok),H("sceNpWebApiRegisterExtdPushEventCallbackA",generic_id),H("sceNpWebApiUnregisterExtdPushEventCallback",generic_ok),
 H("sceNpWebApiCreateRequest",web_create),H("sceNpWebApiSendRequest",web_send),H("sceNpWebApiSendRequest2",web_send2),H("sceNpWebApiReadData",web_read),H("sceNpWebApiDeleteRequest",web_delete),H("sceNpWebApiAbortRequest",generic_ok),H("sceNpWebApiAddHttpRequestHeader",generic_ok),H("sceNpWebApiGetHttpResponseHeaderValue",web_header),H("sceNpWebApiGetHttpResponseHeaderValueLength",web_header_length),H("sceNpWebApiGetMemoryPoolStats",web_pool),H("sceNpWebApiUtilityParseNpId",web_parse_npid),
 H("sceHttpCreateConnectionWithURL",http_conn),H("sceHttpCreateRequestWithURL",http_req),H("sceHttpCreateRequestWithURL2",http_req2),H("sceHttpGetStatusCode",http_status),H("sceNetResolverStartNtoa",resolve),H("sceSysmoduleLoadModule",sysmodule_load)
};
#include "generic_contracts.h"
CTR_EXPORT void *ctr_find_hook(const char *name){
    if(!name)return 0;for(size_t i=0;i<COUNT(hooks);i++)if(!ctr_strcmp(name,hooks[i].name))return hooks[i].fn;
    for(size_t i=0;i<COUNT(generic_contracts);i++)if(!ctr_strcmp(name,generic_contracts[i].name))return generic_contracts[i].fn;
    return 0;
}
