// SPDX-License-Identifier: GPL-2.0-only
// Fixed global code paths, never a profile/save directory. Staged code is not
// loaded into the running game. The next bootstrap loads it or its bundled copy.
static uint8_t verify_update[CTR_UPDATER_MAX];
static int read_update_file(const char *path,uint8_t *out,size_t cap){
    int64_t fd=ctr_syscall(5,path,0,0);if(fd<0)return fd==-2?-2:-1;size_t used=0;int result=0;
    while(used<cap){int64_t n=ctr_syscall(3,fd,out+used,cap-used);if(n<0||(uint64_t)n>cap-used){result=-1;break;}if(!n)break;used+=(size_t)n;}
    if(!result&&used==cap){uint8_t extra;int64_t n=ctr_syscall(3,fd,&extra,1);if(n!=0)result=-1;}
    if(ctr_syscall(6,fd)<0)result=-1;return result?-1:(int)used;
}
static int write_update_file(const char *path,const uint8_t *data,size_t size){
    int64_t fd=ctr_syscall(5,path,0x601,0644);if(fd<0)return -1;size_t used=0;int result=0;
    while(used<size){int64_t n=ctr_syscall(4,fd,data+used,size-used);if(n<=0||(uint64_t)n>size-used){result=-1;break;}used+=(size_t)n;}
    if(!result&&ctr_syscall(95,fd)<0)result=-1;if(ctr_syscall(6,fd)<0)result=-1;return result;
}
static int stage_update(const uint8_t *data,size_t size,const uint8_t expected[32]){
    static const char marker[]="RYUNET-PS4-UPDATER-ABI1:" CTR_UPDATER_LANGUAGE "\n";
    uint8_t header[64];int n=read_update_file("/app0/sce_module/ryunet-updater.txt",header,sizeof(header));
    if(n!=(int)sizeof(marker)-1||ctr_strncmp((const char*)header,marker,sizeof(marker)-1)){
        n=read_update_file("/data/ryunet/update-route-" CTR_UPDATER_LANGUAGE ".v1",header,sizeof(header));
        if(n!=(int)sizeof(marker)-1||ctr_strncmp((const char*)header,marker,sizeof(marker)-1))return -100;
    }
    if(!ctr_update_self_valid(data,size))return -30;
    const char *folders[]={"/data/ryunet","/data/ryunet/" CTR_UPDATER_LANGUAGE};
    for(size_t i=0;i<2;i++){int64_t r=ctr_syscall(136,folders[i],0755);if(r<0&&r!=-17)return -31;}
    const char *temporary=CTR_UPDATER_TARGET ".download",*previous=CTR_UPDATER_TARGET ".previous",*backup=CTR_UPDATER_TARGET ".previous.tmp";
    int error=-32;
    if(write_update_file(temporary,data,size))goto fail;
    n=read_update_file(temporary,verify_update,sizeof(verify_update));if(n!=(int)size)goto fail;
    uint8_t hash[32];ctr_sha256(verify_update,size,hash);
    for(int i=0;i<32;i++)if(hash[i]!=expected[i])goto fail;
    n=read_update_file(CTR_UPDATER_TARGET,verify_update,sizeof(verify_update));
    if(n>=0){
        if(!ctr_update_self_valid(verify_update,(size_t)n)||write_update_file(backup,verify_update,(size_t)n))goto fail;
        if(ctr_syscall(128,backup,previous)<0)goto fail;
    }else if(n!=-2)goto fail;
    // Atomic replacement: the process retains its old mapped inode. The next
    // process gets the complete verified replacement; profiles are untouched.
    if(ctr_syscall(128,temporary,CTR_UPDATER_TARGET)<0)goto fail;return 0;
fail:
    ctr_syscall(10,temporary);ctr_syscall(10,backup);return error;
}
