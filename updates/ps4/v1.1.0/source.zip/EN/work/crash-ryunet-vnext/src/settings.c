// SPDX-License-Identifier: GPL-2.0-only
#include "settings.h"
static CtrSettings current={.fps=60,.motion_blur=1};
static int guard;
static char lower(char c){return c>='A'&&c<='Z'?(char)(c+32):c;}
int ctr_name_equal(const char *a,const char *b){while(*a&&lower(*a)==lower(*b)){a++;b++;}return lower(*a)==lower(*b);}
int ctr_name_valid(const char *name){
    if(!name)return 0;size_t n=0;
    while(name[n]){char c=name[n++];if(n>16||!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'))return 0;}
    return n!=0;
}
CTR_EXPORT void ctr_settings_defaults(CtrSettings *s){ctr_memset(s,0,sizeof(*s));s->fps=60;s->motion_blur=1;}
static int valid(const CtrSettings *s){
    if(!s||(s->fps!=CTR_FPS_UNLIMITED&&s->fps!=30&&s->fps!=60)||(s->motion_blur!=0&&s->motion_blur!=1)||(s->pro_1080!=0&&s->pro_1080!=1)||(s->performance!=0&&s->performance!=1)||(s->light_effects!=0&&s->light_effects!=1)||(s->low_quality!=0&&s->low_quality!=1)||(s->no_shadows!=0&&s->no_shadows!=1)||s->count>CTR_MAX_FRIENDS)return 0;
    for(uint32_t i=0;i<s->count;i++){
        if(s->friends[i][16]||!ctr_name_valid(s->friends[i]))return 0;
        for(uint32_t j=0;j<i;j++)if(ctr_name_equal(s->friends[i],s->friends[j]))return 0;
    }return 1;
}
CTR_EXPORT int ctr_settings_resolution(const CtrSettings *s){
    if(!valid(s))return -1;
    // Read older files exactly as the renderer did, including both old flags.
    return s->low_quality?CTR_RES_480P:s->performance?CTR_RES_720P:CTR_RES_NATIVE;
}
CTR_EXPORT int ctr_settings_set_resolution(CtrSettings *s,int resolution){
    if(!valid(s)||resolution<CTR_RES_NATIVE||resolution>CTR_RES_480P)return -1;
    s->performance=resolution==CTR_RES_720P;s->low_quality=resolution==CTR_RES_480P;
    s->pro_1080=0;return 0;
}
CTR_EXPORT int ctr_settings_reset_graphics(CtrSettings *s){
    if(!valid(s))return -1;
    CtrSettings defaults;ctr_settings_defaults(&defaults);
    // Keep FPS and the entire contact list; nickname and saves are separate.
    s->motion_blur=defaults.motion_blur;s->pro_1080=defaults.pro_1080;
    s->performance=defaults.performance;s->light_effects=defaults.light_effects;
    s->low_quality=defaults.low_quality;s->no_shadows=defaults.no_shadows;
    return 0;
}
CTR_EXPORT int ctr_settings_add(CtrSettings *s,const char *name,const char *self){
    if(!valid(s)||!ctr_name_valid(name))return -1;
    if(self&&ctr_name_equal(name,self))return -2;
    for(uint32_t i=0;i<s->count;i++)if(ctr_name_equal(name,s->friends[i]))return -3;
    if(s->count==CTR_MAX_FRIENDS)return -4;
    ctr_memset(s->friends[s->count],0,17);ctr_memcpy(s->friends[s->count++],name,ctr_strlen(name));return 0;
}
CTR_EXPORT int ctr_settings_remove(CtrSettings *s,const char *name){
    if(!valid(s)||!ctr_name_valid(name))return -1;
    for(uint32_t i=0;i<s->count;i++)if(ctr_name_equal(name,s->friends[i])){
        for(uint32_t j=i+1;j<s->count;j++)ctr_memcpy(s->friends[j-1],s->friends[j],17);
        ctr_memset(s->friends[--s->count],0,17);return 0;
    }
    return -2;
}
CTR_EXPORT int ctr_settings_publish(const CtrSettings *s){
    if(!valid(s))return -1;int zero=0;
    if(!__atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return -2;
    current=*s;__atomic_store_n(&guard,0,__ATOMIC_RELEASE);return 0;
}
CTR_EXPORT int ctr_settings_snapshot(CtrSettings *s){
    if(!s)return -1;
    for(int i=0;i<32;i++){int zero=0;if(__atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED)){
        *s=current;__atomic_store_n(&guard,0,__ATOMIC_RELEASE);return 0;
    }}return -2;
}
CTR_EXPORT int ctr_settings_parse(CtrSettings *s,const char *text,size_t size){
    if(!s||!text||size>4096)return -1;CtrSettings parsed;ctr_settings_defaults(&parsed);int version=0;
    for(size_t i=0;i<size;i++)if(!text[i])return -1;
    size_t p=0;
    while(p<size){
        size_t start=p;while(p<size&&text[p]!='\n')p++;size_t n=p-start;if(p<size)p++;
        if(n&&text[start+n-1]=='\r')n--;
        if(!n||text[start]=='#')continue;
        if(n>=1100)return -1;char line[1100];ctr_memcpy(line,text+start,n);line[n]=0;
        if(!ctr_strcmp(line,"version=1")){version=1;continue;}
        if(!ctr_strcmp(line,"fps=0")){parsed.fps=CTR_FPS_UNLIMITED;continue;}
        if(!ctr_strcmp(line,"fps=30")){parsed.fps=30;continue;}
        if(!ctr_strcmp(line,"fps=60")){parsed.fps=60;continue;}
        if(!ctr_strcmp(line,"motion_blur=0")){parsed.motion_blur=0;continue;}
        if(!ctr_strcmp(line,"motion_blur=1")){parsed.motion_blur=1;continue;}
        if(!ctr_strcmp(line,"pro_1080=0")){parsed.pro_1080=0;continue;}
        if(!ctr_strcmp(line,"pro_1080=1")){parsed.pro_1080=1;continue;}
        if(!ctr_strcmp(line,"performance=0")){parsed.performance=0;continue;}
        if(!ctr_strcmp(line,"performance=1")){parsed.performance=1;continue;}
        if(!ctr_strcmp(line,"light_effects=0")){parsed.light_effects=0;continue;}
        if(!ctr_strcmp(line,"light_effects=1")){parsed.light_effects=1;continue;}
        if(!ctr_strcmp(line,"low_quality=0")){parsed.low_quality=0;continue;}
        if(!ctr_strcmp(line,"low_quality=1")){parsed.low_quality=1;continue;}
        if(!ctr_strcmp(line,"no_shadows=0")){parsed.no_shadows=0;continue;}
        if(!ctr_strcmp(line,"no_shadows=1")){parsed.no_shadows=1;continue;}
        if(!ctr_strncmp(line,"friends=",8)){
            size_t a=8;
            while(line[a]){
                while(line[a]==' '||line[a]=='\t'||line[a]==',')a++;
                if(!line[a])break;size_t b=a;while(line[b]&&line[b]!=',')b++;
                size_t end=b;while(end>a&&(line[end-1]==' '||line[end-1]=='\t'))end--;
                if(end-a>16||end==a)return -1;char name[17];ctr_memcpy(name,line+a,end-a);name[end-a]=0;
                // A renamed profile may leave its new self-name in an old
                // contact list. Skip only that contact, preserving all settings.
                if(!ctr_name_equal(name,ctr_player_name())&&ctr_settings_add(&parsed,name,0)!=0)return -1;a=line[b]?b+1:b;
            }continue;
        }return -1;
    }
    if(!version)return -1;*s=parsed;return 0;
}
CTR_EXPORT int ctr_settings_format(const CtrSettings *s,char *out,size_t capacity){
    if(!valid(s)||!out)return -1;
    char temp[1024];size_t n=0;
    const char *parts[]={"version=1\nfps=",s->fps==60?"60":s->fps==30?"30":"0","\nmotion_blur=",s->motion_blur?"1":"0","\npro_1080=",s->pro_1080?"1":"0","\nperformance=",s->performance?"1":"0","\nlight_effects=",s->light_effects?"1":"0","\nlow_quality=",s->low_quality?"1":"0","\nno_shadows=",s->no_shadows?"1":"0","\nfriends="};
    for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t l=ctr_strlen(parts[i]);ctr_memcpy(temp+n,parts[i],l);n+=l;}
    for(uint32_t i=0;i<s->count;i++){if(i)temp[n++]=',';size_t l=ctr_strlen(s->friends[i]);ctr_memcpy(temp+n,s->friends[i],l);n+=l;}
    temp[n++]='\n';temp[n]=0;if(n+1>capacity)return -1;ctr_memcpy(out,temp,n+1);return (int)n;
}
