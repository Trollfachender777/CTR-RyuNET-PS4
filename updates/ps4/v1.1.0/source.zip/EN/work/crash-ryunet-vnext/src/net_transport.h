// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
typedef struct {uint8_t length,family;uint16_t port;uint32_t ip;uint8_t zero[8];} CtrNetAddress;
_Static_assert(sizeof(CtrNetAddress)==16,"PS4 IPv4 sockaddr ABI");
typedef struct {
    int32_t(*bind)(int32_t,const void*,uint32_t);
    int32_t(*sendto)(int32_t,const void*,size_t,int32_t,const void*,uint32_t);
    int32_t(*recvfrom)(int32_t,void*,size_t,int32_t,void*,uint32_t*);
    int32_t(*close)(int32_t);
    int32_t(*getsockopt)(int32_t,int32_t,int32_t,void*,uint32_t*);
    int32_t*(*errno_location)(void);
    uint64_t(*clock_us)(void);
    void(*trace)(int32_t,int32_t);
} CtrNetApi;
CTR_EXPORT int ctr_net_init(const CtrNetApi*);
CTR_EXPORT void ctr_net_server(uint32_t);
CTR_EXPORT int32_t ctr_net_bind(int32_t,const void*,uint32_t);
CTR_EXPORT int32_t ctr_net_sendto(int32_t,const void*,size_t,int32_t,const void*,uint32_t);
CTR_EXPORT int32_t ctr_net_recvfrom(int32_t,void*,size_t,int32_t,void*,uint32_t*);
CTR_EXPORT int32_t ctr_net_close(int32_t);

