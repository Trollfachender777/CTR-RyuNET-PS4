// SPDX-License-Identifier: MIT
#include <stddef.h>
int module_start(size_t n,const void *p){(void)n;(void)p;return 0;}
int module_stop(size_t n,const void *p){(void)n;(void)p;return 0;}
