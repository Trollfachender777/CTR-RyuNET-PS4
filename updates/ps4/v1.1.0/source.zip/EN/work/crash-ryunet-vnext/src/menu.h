// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "settings.h"
// Explicit native dialog layouts, independent of host wchar_t width.
typedef struct {uint64_t size;uint8_t reserved[36];uint32_t magic;} CtrDialogBase;
typedef struct {const char *first,*second;uint8_t reserved[32];} CtrDialogButtons;
typedef struct {int32_t buttons,padding;const char *message;CtrDialogButtons *custom;uint8_t reserved[24];} CtrDialogMessage;
typedef struct {CtrDialogBase base;uint64_t size;int32_t mode,padding;CtrDialogMessage *message;void *progress,*system;int32_t user;uint8_t reserved[40];int32_t padding2;} CtrDialogParam;
typedef struct {int32_t mode,result,button;uint8_t reserved[32];} CtrDialogResult;
typedef struct {int32_t user,type;uint64_t languages;int32_t label,method;void *filter;uint32_t option,max_length;uint16_t *buffer;float x,y;int32_t horizontal,vertical;const uint16_t *placeholder,*title;uint8_t reserved[16];} CtrImeParam;
typedef struct {int32_t result;uint8_t reserved[12];} CtrImeResult;
_Static_assert(sizeof(CtrDialogParam)==136,"MsgDialog param ABI");
_Static_assert(sizeof(CtrDialogMessage)==48,"MsgDialog message ABI");
_Static_assert(sizeof(CtrImeParam)==96,"ImeDialog UTF16 param ABI");
typedef struct {
    int32_t (*message_init)(void);
    int32_t (*message_open)(const CtrDialogParam*);
    int32_t (*message_status)(void);
    int32_t (*message_update)(void);
    int32_t (*message_result)(CtrDialogResult*);
    int32_t (*message_term)(void);
    int32_t (*ime_init)(const CtrImeParam*,const void*);
    int32_t (*ime_status)(void);
    int32_t (*ime_result)(CtrImeResult*);
    int32_t (*ime_term)(void);
    int32_t (*ime_abort)(void);
    int32_t (*save)(const CtrSettings*);
    int32_t (*save_name)(const char*);
    void (*trace)(int32_t,int32_t);
    int32_t user;
    int32_t pro;
} CtrMenuApi;
CTR_EXPORT int ctr_menu_init(const CtrMenuApi *api);
// Returns 1 while game input must be neutral, including the closing frame.
CTR_EXPORT int ctr_menu_poll(int32_t handle,uint32_t buttons);
// The game's own IME manager must not consume this menu's global OS dialog.
CTR_EXPORT int ctr_menu_ime_owned(void);
CTR_EXPORT int ctr_menu_active(void);
// Explicit first-run request; never opens a dialog inside the initializer.
CTR_EXPORT void ctr_menu_request_setup(void);
