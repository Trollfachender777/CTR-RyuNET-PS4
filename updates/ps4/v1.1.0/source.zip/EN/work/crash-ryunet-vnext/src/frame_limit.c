// SPDX-License-Identifier: GPL-2.0-only
#include "frame_limit.h"
static uint64_t (*read_clock)(void);
static int32_t (*wait_us)(uint32_t);
static void (*record)(int32_t,int32_t);
static uint64_t deadline,last_frame;
static uint32_t active_path=0xffffffffU;
static int guard,last_fps,missing_reported;
static uint32_t reported_paths;
static void (*render_probe)(void);
static uint64_t sample_last,sample_start,sample_sum;
static uint32_t sample_path,sample_count,sample_worst,sample_slow,sample_reports;
static int sample_fps;
FRAME_EXPORT void ctr_frame_probe(void(*probe)(void)){render_probe=probe;}
static void reset_samples(uint64_t now,uint32_t path,int fps){
    sample_last=sample_start=now;sample_path=path;sample_fps=fps;
    sample_sum=0;sample_count=sample_worst=sample_slow=0;
}
static void observe_frame(uint32_t path,int fps){
    if(render_probe){void(*probe)(void)=render_probe;render_probe=0;probe();}
    if(!read_clock||!record||sample_reports>=64)return;
    uint64_t now=read_clock();
    if(!sample_last||sample_fps!=fps||now<sample_last){reset_samples(now,path,fps);return;}
    // A second flip API in the same frame must not count as another frame.
    if(path!=sample_path){
        if(now-sample_last<100000)return;
        reset_samples(now,path,fps);return;
    }
    uint64_t interval=now-sample_last;
    if(interval<1000)return;
    // Loading pauses are not useful race samples. Restart the window after one.
    if(interval>250000){reset_samples(now,path,fps);return;}
    sample_last=now;sample_sum+=interval;sample_count++;
    if(interval>sample_worst)sample_worst=(uint32_t)interval;
    if(interval>25000)sample_slow++;
    if(now-sample_start<10000000)return;
    record(130,(int32_t)(sample_sum/sample_count));record(131,(int32_t)sample_worst);
    record(132,(int32_t)sample_slow);record(133,(int32_t)sample_count);record(134,(int32_t)path);
    sample_reports++;reset_samples(now,path,fps);
}
FRAME_EXPORT void ctr_frame_init(uint64_t(*clock_us)(void),int32_t(*sleep_us)(uint32_t),void(*trace)(int32_t,int32_t)){
    read_clock=clock_us;wait_us=sleep_us;record=trace;deadline=last_frame=0;active_path=0xffffffffU;
    last_fps=-1;missing_reported=guard=0;reported_paths=0;
    render_probe=0;sample_last=sample_start=sample_sum=0;sample_count=sample_worst=sample_slow=sample_reports=0;
    sample_path=0xffffffffU;sample_fps=0;
}
FRAME_EXPORT void ctr_frame_wait(uint32_t path){
    CtrSettings settings;if(ctr_settings_snapshot(&settings))return;
    int zero=0;if(!__atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return;
    if(path<32&&!(reported_paths&(1U<<path))){if(record)record(70,(int32_t)path);reported_paths|=1U<<path;}
    if(last_fps!=settings.fps){
        if(record)record(71,settings.fps);last_fps=settings.fps;
        deadline=last_frame=0;active_path=0xffffffffU;
    }
    if(settings.fps==CTR_FPS_UNLIMITED){deadline=last_frame=0;active_path=0xffffffffU;goto done;}
    if(!read_clock||!wait_us){if(!missing_reported&&record)record(72,-1);missing_reported=1;goto done;}
    uint64_t now=read_clock();
    uint32_t period=settings.fps==30?33333:16667;
    if(deadline&&now<last_frame){deadline=last_frame=0;active_path=0xffffffffU;}
    // A game may submit and request a flip in one frame. Pick one presentation
    // path, and migrate only when that path has been idle for at least 100 ms.
    if(active_path!=path){
        if(active_path!=0xffffffffU&&now>=last_frame&&now-last_frame<100000)goto done;
        active_path=path;deadline=0;
    }
    if(!deadline){deadline=now+period;last_frame=now;goto done;}
    uint64_t scheduled=deadline,target=scheduled;
    // Keep a wall-clock phase at 60. PS4's sleeper can round 16.667 ms to
    // 17 ms; rebasing on every wake would turn that rounding into 58.8 FPS.
    // Compensate at most 1 ms relative to a normal frame interval. Rebase
    // after actual slow work or a substantial scheduler delay.
    if(settings.fps==60&&target<last_frame+15667)target=last_frame+15667;
    // Sleep rather than spin. Retry an early wakeup a bounded number of times;
    // a broken timer/sleeper must never trap the game in a waiting loop.
    unsigned attempts=0;
    while(now<target){
        uint64_t remaining=target-now;if(remaining>period)remaining=period;
        if(attempts++==4||wait_us((uint32_t)remaining)<0){
            if(!missing_reported&&record)record(72,-2);missing_reported=1;deadline=0;goto done;
        }
        uint64_t previous=now;now=read_clock();
        if(now<previous){deadline=last_frame=0;goto done;}
    }
    if(settings.fps==60&&attempts&&now>=scheduled&&now-scheduled<=1000)
        deadline=scheduled+period;
    else deadline=now+period;
    last_frame=now;
done:
    observe_frame(path,settings.fps);
    __atomic_store_n(&guard,0,__ATOMIC_RELEASE);
}
