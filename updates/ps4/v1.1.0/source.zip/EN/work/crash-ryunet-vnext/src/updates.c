// SPDX-License-Identifier: GPL-2.0-only
#include "updates.h"
#include "update_json.h"
static int valid_tag(const char *s){size_t n=ctr_strlen(s);if(!n)return 0;for(size_t i=0;i<n;i++)if(!((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')||(s[i]>='0'&&s[i]<='9')||s[i]=='.'||s[i]=='_'||s[i]=='-'))return 0;return 1;}
static int date(const char *s){
    if(ctr_strlen(s)!=20)return 0;
    for(int i=0;i<20;i++){char expected=i==4||i==7?'-':i==10?'T':i==13||i==16?':':i==19?'Z':0;if(expected?s[i]!=expected:s[i]<'0'||s[i]>'9')return 0;}
    unsigned month=(s[5]-'0')*10+s[6]-'0',day=(s[8]-'0')*10+s[9]-'0';
    unsigned hour=(s[11]-'0')*10+s[12]-'0',minute=(s[14]-'0')*10+s[15]-'0',second=(s[17]-'0')*10+s[18]-'0';
    unsigned year=(s[0]-'0')*1000+(s[1]-'0')*100+(s[2]-'0')*10+s[3]-'0';
    const unsigned days[]={31,28,31,30,31,30,31,31,30,31,30,31};
    if(!month||month>12||!day||hour>23||minute>59||second>59)return 0;
    unsigned max=days[month-1]+(month==2&&(!(year%400)||(!(year%4)&&year%100)));
    return day<=max;
}
CTR_EXPORT int ctr_release_parse(const char *json,size_t length,CtrRelease *out){
    if(!json||!out||!length||length>CTR_UPDATE_BODY_MAX)return -1;
    Json j={json,json+length};CtrRelease r;ctr_memset(&r,0,sizeof(r));unsigned seen=0;
    if(take(&j,'{'))return -1;ws(&j);if(j.p<j.end&&*j.p=='}')return -1;
    for(;;){
        char key[128];if(string(&j,key,sizeof(key))||take(&j,':'))return -1;unsigned bit=0;int result=0;
        if(!ctr_strcmp(key,"id")){bit=1;result=unsigned_id(&j,&r.id);}
        else if(!ctr_strcmp(key,"tag_name")){bit=2;result=string(&j,r.tag,sizeof(r.tag));}
        else if(!ctr_strcmp(key,"published_at")){bit=4;result=string(&j,r.published,sizeof(r.published));}
        else if(!ctr_strcmp(key,"html_url")){bit=8;result=string(&j,r.url,sizeof(r.url));}
        else if(!ctr_strcmp(key,"draft")){bit=16;result=literal(&j,"false");}
        else if(!ctr_strcmp(key,"prerelease")){bit=32;result=literal(&j,"false");}
        else result=skip(&j,0);
        if(result||(bit&&(seen&bit)))return -1;seen|=bit;ws(&j);
        if(j.p<j.end&&*j.p=='}'){j.p++;break;}if(take(&j,','))return -1;
    }
    ws(&j);if(j.p!=j.end||seen!=63||!valid_tag(r.tag)||!date(r.published))return -1;
    const char prefix[]=CTR_UPDATE_RELEASES "/tag/";size_t n=sizeof(prefix)-1;
    if(ctr_strncmp(r.url,prefix,n)||ctr_strcmp(r.url+n,r.tag))return -1;
    *out=r;return 0;
}
static CtrUpdateApi platform;
static CtrUpdateResult result;
static int guard,attempted;
static uint64_t last_attempt;
static char response[CTR_UPDATE_BODY_MAX];
static int acquire(void){int zero=0;return __atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void release(void){__atomic_store_n(&guard,0,__ATOMIC_RELEASE);}
static void *worker(void *unused){
    (void)unused;CtrUpdateResult next;ctr_memset(&next,0,sizeof(next));size_t length=0;int32_t status=0;
    int r=platform.fetch(CTR_UPDATE_ENDPOINT,response,sizeof(response),&length,&status);next.error=r?r:status;
    if(r)next.state=CTR_UPDATE_NETWORK;
    else if(status==403||status==429)next.state=CTR_UPDATE_RATE_LIMIT;
    else if(status==404)next.state=CTR_UPDATE_NO_RELEASE;
    else if(status!=200)next.state=CTR_UPDATE_NETWORK;
    else if(ctr_release_parse(response,length,&next.release))next.state=CTR_UPDATE_INVALID;
    else {next.error=0;next.state=ctr_strcmp(next.release.tag,CTR_PS4_RELEASE_TAG)&&next.release.id!=CTR_PS4_RELEASE_ID&&ctr_strcmp(next.release.published,CTR_PS4_RELEASE_DATE)>0?CTR_UPDATE_AVAILABLE:CTR_UPDATE_CURRENT;}
    while(!acquire())__asm__ volatile("pause");result=next;release();return 0;
}
CTR_EXPORT int ctr_updates_init(const CtrUpdateApi *api){
    if(!acquire())return -1;if(result.state==CTR_UPDATE_BUSY){release();return -1;}
    ctr_memset(&platform,0,sizeof(platform));ctr_memset(&result,0,sizeof(result));attempted=0;last_attempt=0;
    if(api)platform=*api;
    result.state=platform.spawn&&platform.fetch&&platform.time_us?CTR_UPDATE_IDLE:CTR_UPDATE_UNAVAILABLE;release();return 0;
}
CTR_EXPORT int ctr_updates_snapshot(CtrUpdateResult *out){if(!out||!acquire())return -1;*out=result;release();return 0;}
CTR_EXPORT int ctr_updates_start(void){
    if(!acquire())return 0;
    if(result.state==CTR_UPDATE_BUSY||!platform.spawn||!platform.fetch||!platform.time_us){release();return 0;}
    uint64_t now=platform.time_us();if(attempted&&now>=last_attempt&&now-last_attempt<60000000ULL){release();return 0;}
    attempted=1;last_attempt=now;ctr_memset(&result,0,sizeof(result));result.state=CTR_UPDATE_BUSY;release();
    int r=platform.spawn(worker,0);
    if(r){while(!acquire())__asm__ volatile("pause");result.state=CTR_UPDATE_UNAVAILABLE;result.error=r;release();return -1;}return 1;
}
