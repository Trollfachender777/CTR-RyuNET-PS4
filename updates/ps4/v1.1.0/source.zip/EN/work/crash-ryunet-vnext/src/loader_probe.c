// SPDX-License-Identifier: MIT
// Standalone loader diagnostic. Never modifies game or save files.
#include <orbis/libkernel.h>
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
extern int64_t ctr_syscall(int64_t,...);
static void trace(const char *label,int32_t code){
    char line[128];
    int n=snprintf(line,sizeof(line),"CTR probe %s=%08x\n",label,(uint32_t)code);
    int64_t fd=ctr_syscall(5,"/data/GoldHEN/ctr_loader_probe.log",0x209,0666);
    if(fd>=0){ctr_syscall(4,fd,line,(size_t)n);ctr_syscall(6,fd);}
}
int main(void){
    trace("started",0);
    const char *paths[]={"/app0/sce_module/probe_ref.prx","/app0/sce_module/probe_wrap.prx","/app0/sce_module/probe_inline.prx"};
    const char *labels[]={"reference","wrapper","inline"};
    int32_t status[3];
    for(int i=0;i<3;i++){
        int32_t result=0;
        status[i]=(int32_t)sceKernelLoadStartModule(paths[i],0,0,0,0,&result);
        trace(labels[i],status[i]);
        if(status[i]>=0){
            int32_t unload=sceKernelStopUnloadModule(status[i],0,0,0,0,&result);
            trace("unload",unload);
        }
    }
    OrbisNotificationRequest note;
    memset(&note,0,sizeof(note));note.type=NotificationRequest;note.targetId=-1;
    snprintf(note.message,sizeof(note.message),"RyuNET 1.02: base=%08x envoltura=%08x integrado=%08x. Cierra la prueba desde el menu PS.",(uint32_t)status[0],(uint32_t)status[1],(uint32_t)status[2]);
    sceKernelSendNotificationRequest(0,&note,sizeof(note),0);
    trace("complete",0);
    // The first hardware run completed all tests but the musl return-to-exit
    // path triggered SIGSYS in libkernel's _exit. Keep a sleeping app instead;
    // normal PS menu -> Close Application performs the console's own teardown.
    for(;;)sceKernelUsleep(1000000);
}
