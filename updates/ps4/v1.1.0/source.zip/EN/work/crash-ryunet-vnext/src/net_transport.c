// SPDX-License-Identifier: GPL-2.0-only
// Native PS4 adapter for OCTR 0.5.3's UDP tunnel. No workers or spin waits.
// Only the game's IPv4 datagram socket bound to 3074 is intercepted.
#include "net_transport.h"
#include "net_tunnel.h"
static CtrNetApi api;
static int lock,receive_lock,enabled;
static int32_t game_fd=-1;
static uint32_t server_ip,generation,trace_sent,trace_received;
// Preserve ordinary datagrams, including a long direct packet. Only relay
// envelopes are restricted to the upstream protocol's 2048-byte payload.
static uint8_t received[65536];
static struct {int valid;uint32_t generation;size_t length;CtrNetAddress from;uint8_t data[65536];} peeked;
static int take(void){int zero=0;return __atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void give(void){__atomic_store_n(&lock,0,__ATOMIC_RELEASE);}
static int take_receive(void){int zero=0;return __atomic_compare_exchange_n(&receive_lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void give_receive(void){__atomic_store_n(&receive_lock,0,__ATOMIC_RELEASE);}
static uint16_t swap(uint16_t n){return (uint16_t)((n>>8)|(n<<8));}
static int32_t *error_ptr(void){return api.errno_location?api.errno_location():0;}
static int32_t error_get(void){int32_t *p=error_ptr();return p?*p:0;}
static void error_set(int32_t n){int32_t *p=error_ptr();if(p)*p=n;}
static void trace(int stage,int value){if(api.trace)api.trace(stage,value);}
static uint64_t now(void){return api.clock_us()/1000;}
static int ipv4(const void *addr,uint32_t n){return addr&&n>=16&&((const CtrNetAddress*)addr)->family==2&&((const CtrNetAddress*)addr)->length==16;}
static CtrNetAddress server(void){CtrNetAddress a={16,2,swap(3074),__atomic_load_n(&server_ip,__ATOMIC_ACQUIRE),{0}};return a;}
static void keepalive(int32_t fd,const CtrNetAddress *to){
    if(ctr_tun_keepalive(now())){int r=api.sendto(fd,"RYUKA1",6,0x40,to,16);if(r<0)trace(156,r);}
}
CTR_EXPORT int ctr_net_init(const CtrNetApi *platform){
    if(!platform||!platform->bind||!platform->sendto||!platform->recvfrom||!platform->close||!platform->getsockopt||!platform->errno_location||!platform->clock_us)return -1;
    api=*platform;game_fd=-1;peeked.valid=0;server_ip=0;generation=0;trace_sent=trace_received=0;lock=receive_lock=0;ctr_tun_reset();enabled=1;return 0;
}
CTR_EXPORT void ctr_net_server(uint32_t ip){
    if(!ip)return;
    uint32_t previous=__atomic_exchange_n(&server_ip,ip,__ATOMIC_ACQ_REL);
    if(previous!=ip)trace(152,1); // Do not log public or private IP addresses.
}
CTR_EXPORT int32_t ctr_net_bind(int32_t fd,const void *addr,uint32_t length){
    int32_t result=api.bind(fd,addr,length),saved=error_get();
    if(result||!enabled||!ipv4(addr,length)||swap(((const CtrNetAddress*)addr)->port)!=3074)return result;
    int32_t type=0;uint32_t size=4;
    if(api.getsockopt(fd,0xffff,0x1008,&type,&size)||size!=4||type!=2){error_set(saved);return result;}
    if(take()){
        if(game_fd<0||game_fd==fd){
            __atomic_fetch_add(&generation,1,__ATOMIC_ACQ_REL);
            __atomic_store_n(&game_fd,fd,__ATOMIC_RELEASE);ctr_tun_reset();
            CtrNetAddress to=server();if(to.ip)keepalive(fd,&to);trace(153,0);
        }
        give();
    }
    error_set(saved);return result;
}
CTR_EXPORT int32_t ctr_net_sendto(int32_t fd,const void *data,size_t length,int32_t flags,const void *addr,uint32_t addrlen){
    int32_t result=api.sendto(fd,data,length,flags,addr,addrlen),saved=error_get();
    if(result<0||!enabled||fd!=__atomic_load_n(&game_fd,__ATOMIC_ACQUIRE)||!ipv4(addr,addrlen)||length>CTR_TUN_PAYLOAD||(!data&&length)||!take())return result;
    CtrNetAddress to=server();
    if(to.ip){
        keepalive(fd,&to);const CtrNetAddress *peer=addr;uint8_t bits=0;
        if(ctr_tun_candidate(peer->ip,to.ip)&&ctr_tun_send(peer->ip,swap(peer->port),now(),&bits)){
            uint8_t wrapped[CTR_TUN_PAYLOAD+CTR_TUN_HEADER];
            size_t n=ctr_tun_wrap(wrapped,sizeof(wrapped),bits,peer->ip,swap(peer->port),data,length);
            if(n){int r=api.sendto(fd,wrapped,n,0x40,&to,16);if(r>=0){if(trace_sent++<4)trace(154,0);}else if(trace_sent++<4)trace(156,r);}
        }
    }
    give();error_set(saved);return result;
}
static int32_t copy_result(void *out,size_t capacity,void *from,uint32_t *fromlen,const uint8_t *data,size_t length,const CtrNetAddress *address){
    if(from&&fromlen){size_t n=*fromlen<16?*fromlen:16;if(n)ctr_memcpy(from,address,n);*fromlen=16;}
    size_t n=length<capacity?length:capacity;if(n)ctr_memcpy(out,data,n);return (int32_t)n;
}
CTR_EXPORT int32_t ctr_net_recvfrom(int32_t fd,void *out,size_t capacity,int32_t flags,void *from,uint32_t *fromlen){
    if(!enabled||fd!=__atomic_load_n(&game_fd,__ATOMIC_ACQUIRE)||(!out&&capacity))return api.recvfrom(fd,out,capacity,flags,from,fromlen);
    if(!take_receive()){error_set(35);return -1;}
    uint32_t epoch=__atomic_load_n(&generation,__ATOMIC_ACQUIRE);
    if(peeked.valid&&peeked.generation!=epoch)peeked.valid=0;
    if(peeked.valid){
        int32_t r=copy_result(out,capacity,from,fromlen,peeked.data,peeked.length,&peeked.from);
        if(!(flags&2))peeked.valid=0;give_receive();return r;
    }
    CtrNetAddress to=server();
    if(!to.ip){give_receive();return api.recvfrom(fd,out,capacity,flags,from,fromlen);}
    int32_t prior=error_get();if(take()){keepalive(fd,&to);give();}error_set(prior);
    // Never hold the peer bookkeeping lock across a potentially blocking
    // socket read: a sender on another game thread must still use the relay.
    uint8_t *wrapped=received;CtrNetAddress address;uint32_t size=16;
    int32_t r=api.recvfrom(fd,wrapped,sizeof(received),flags&~2,&address,&size),saved=error_get();
    if(r<0){give_receive();error_set(saved);return r;}
    if((size_t)r>sizeof(received)||size!=16||address.family!=2){give_receive();error_set(35);return -1;}
    size_t length=(size_t)r;const uint8_t *data=wrapped;
    if(address.ip==to.ip&&address.port==to.port){
        uint8_t bits;uint32_t ip;uint16_t port;
        if(ctr_tun_unwrap(wrapped,length,&bits,&ip,&port)){
            if(!ctr_tun_candidate(ip,to.ip)){give_receive();error_set(35);return -1;}
            if(take()){ctr_tun_received(ip,port,bits,now());give();}address.ip=ip;address.port=swap(port);
            data+=CTR_TUN_HEADER;length-=CTR_TUN_HEADER;
            if(trace_received++<4)trace(155,0);
        }else if(length>=6&&!ctr_strncmp((const char*)wrapped,"RYUTN1",6)){
            give_receive();error_set(35);return -1; // Invalid server envelope never reaches the engine.
        }
    }else if(take()){ctr_tun_direct(address.ip,swap(address.port),now());give();}
    if((flags&2)&&epoch==__atomic_load_n(&generation,__ATOMIC_ACQUIRE)){
        peeked.valid=1;peeked.generation=epoch;peeked.length=length;peeked.from=address;if(length)ctr_memcpy(peeked.data,data,length);
    }
    r=copy_result(out,capacity,from,fromlen,data,length,&address);give_receive();error_set(saved);return r;
}
CTR_EXPORT int32_t ctr_net_close(int32_t fd){
    int32_t r=api.close(fd),saved=error_get();
    if(!r&&fd==__atomic_load_n(&game_fd,__ATOMIC_ACQUIRE)){
        __atomic_store_n(&game_fd,-1,__ATOMIC_RELEASE);
        __atomic_fetch_add(&generation,1,__ATOMIC_ACQ_REL);
        if(take()){ctr_tun_reset();give();}trace(157,0);
    }
    error_set(saved);return r;
}
