// SPDX-License-Identifier: GPL-2.0-only
// Adapted from OCTR runtime_services.c, commit
// 64ea69db82784a3361211933e5e8643141acf3ee. The game's own Demonware client
// looks up the creator's lobby; this module supplies its local NP metadata.
#include "sessions.h"
static const char session_prefix[]="cusa13795-session-";
typedef struct {char host[17],id[35];uint64_t expires,next;int active,taken,joined,offers;} Join;
static Join join;
// Stock CTR's friend button joins directly, without our invitation queue.
// Membership and queued invitations must not cancel one another.
static char member_id[35];
static int member_active;
static int lock,ready,own_active;
static int32_t accepting_user=-1;
static uint64_t(*clock_now)(void);
static void(*record)(int32_t,int32_t);
static uint32_t route_counts[10];
typedef struct {char *out;size_t size,capacity;int failed;} Json;
static int acquire(void){int zero=0;return __atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void release(void){__atomic_store_n(&lock,0,__ATOMIC_RELEASE);}
static void trace(int32_t stage,int32_t value){if(record)record(stage,value);}
static void route(unsigned index){if(index<8&&route_counts[index]++<8)trace(95,(int32_t)index);}
static void add(Json *j,const char *text){size_t n=ctr_strlen(text);if(j->size+n>=j->capacity){j->failed=1;return;}ctr_memcpy(j->out+j->size,text,n+1);j->size+=n;}
static void number(Json *j,uint64_t value){char reverse[24],text[24];size_t n=0;do{reverse[n++]=(char)('0'+value%10);value/=10;}while(value);for(size_t i=0;i<n;i++)text[i]=reverse[n-1-i];text[n]=0;add(j,text);}
static void identity(Json *j,const char *name){add(j,"{\"accountId\":\"");number(j,ctr_pid_for_name(name));add(j,"\",\"onlineId\":\"");add(j,name);add(j,"\",\"platform\":\"PS4\"}");}
static void make_id(char out[35],const char *name){ctr_memcpy(out,session_prefix,sizeof(session_prefix)-1);ctr_memcpy(out+sizeof(session_prefix)-1,name,ctr_strlen(name)+1);}
static int contact_session(const char *id){
    size_t prefix=sizeof(session_prefix)-1;
    if(ctr_strncmp(id,session_prefix,prefix)||!ctr_name_valid(id+prefix)||ctr_name_equal(id+prefix,ctr_player_name()))return 0;
    CtrSettings settings;if(ctr_settings_snapshot(&settings))return 0;
    for(uint32_t i=0;i<settings.count;i++)if(ctr_name_equal(id+prefix,settings.friends[i]))return 1;
    return 0;
}
static int boundary(char c){return !c||c=='?'||c=='#';}
static void expire(uint64_t now){if(join.active&&now>=join.expires){join.active=0;trace(94,join.taken);}}
CTR_EXPORT void ctr_sessions_reset(void){
    ctr_memset(&join,0,sizeof(join));ctr_memset(route_counts,0,sizeof(route_counts));
    ctr_memset(member_id,0,sizeof(member_id));member_active=0;
    own_active=0;accepting_user=-1;clock_now=0;record=0;
    __atomic_store_n(&ready,0,__ATOMIC_RELEASE);__atomic_store_n(&lock,0,__ATOMIC_RELEASE);
}
CTR_EXPORT void ctr_sessions_init(int32_t user,uint64_t(*clock_us)(void),void(*logger)(int32_t,int32_t)){
    accepting_user=user;clock_now=clock_us;record=logger;
}
CTR_EXPORT void ctr_sessions_ready(int enabled){__atomic_store_n(&ready,enabled&&clock_now&&accepting_user>=0,__ATOMIC_RELEASE);}
CTR_EXPORT int ctr_session_queue(const char *name){
    if(!__atomic_load_n(&ready,__ATOMIC_ACQUIRE))return -1;
    if(!ctr_name_valid(name)||ctr_name_equal(name,ctr_player_name()))return -2;
    CtrSettings settings;if(ctr_settings_snapshot(&settings))return -1;
    uint32_t i=0;while(i<settings.count&&!ctr_name_equal(name,settings.friends[i]))i++;
    if(i==settings.count)return -2;
    if(!acquire())return -1;
    uint64_t now=clock_now();ctr_memset(&join,0,sizeof(join));
    ctr_memcpy(join.host,settings.friends[i],ctr_strlen(settings.friends[i])+1);make_id(join.id,join.host);
    join.expires=now+240000000ULL;join.next=now+250000ULL;join.active=1;
    release();trace(90,0);return 0;
}
CTR_EXPORT int ctr_session_due(void){
    if(!__atomic_load_n(&ready,__ATOMIC_ACQUIRE)||!acquire())return 0;
    uint64_t now=clock_now();expire(now);int due=join.active&&!join.taken&&now>=join.next;
    release();return due;
}
CTR_EXPORT int ctr_session_event(void *out,size_t capacity){
    if(!out||capacity<CTR_SESSION_EVENT_BYTES||!__atomic_load_n(&ready,__ATOMIC_ACQUIRE)||!acquire())return 0;
    uint64_t now=clock_now();expire(now);
    if(!join.active||join.taken||now<join.next){release();return 0;}
    uint8_t *event=out,*param=event+4;ctr_memset(event,0,CTR_SESSION_EVENT_BYTES);
    const uint32_t type=0x10000002,flag=1;ctr_memcpy(event,&type,4);
    ctr_memcpy(param,join.id,ctr_strlen(join.id)+1);
    ctr_memcpy(param+0x30,"inv-",4);ctr_memcpy(param+0x34,join.host,ctr_strlen(join.host)+1);
    ctr_memcpy(param+0x70,&flag,4);
    ctr_memcpy(param+0x78,ctr_player_name(),ctr_strlen(ctr_player_name())+1);
    ctr_memcpy(param+0x8c,&accepting_user,4);
    ctr_memcpy(param+0x90,join.host,ctr_strlen(join.host)+1);
    uint64_t account=ctr_pid_for_name(join.host);ctr_memcpy(param+0xa8,&account,8);
    join.next=now+4000000ULL;int offers=++join.offers;release();trace(91,offers);return 1;
}
static void session_id(Json *j,const char *id){add(j,"{\"sessionId\":\"");add(j,id);add(j,"\"}");}
static void invitation(Json *j){
    add(j,"{\"invitationId\":\"inv-");add(j,join.host);add(j,"\",\"sessionId\":\"");add(j,join.id);
    add(j,"\",\"receivedDate\":\"2026-10-14T00:00:00.000Z\",\"updateDate\":\"2026-10-14T00:00:00.000Z\",\"expired\":false,\"usedFlag\":false,\"fromUser\":");
    identity(j,join.host);add(j,",\"session\":{\"sessionId\":\"");add(j,join.id);add(j,"\",\"sessionName\":\"CTR Private Match\",\"sessionLockFlag\":false}}");
}
static void session_info(Json *j,const char *id,const char *host,int member){
    add(j,"{\"sessionId\":\"");add(j,id);add(j,"\",\"sessionName\":\"CTR Private Match\",\"sessionPrivacy\":\"public\",\"sessionType\":\"owner-bind\",\"sessionMaxUser\":8,\"sessionStatus\":\"in_lobby\",\"sessionLockFlag\":false,\"availablePlatforms\":[\"PS4\"],\"sessionCreator\":");
    identity(j,host);add(j,",\"members\":[");identity(j,host);
    if(member&&!ctr_name_equal(host,ctr_player_name())){add(j,",");identity(j,ctr_player_name());}
    add(j,"]}");
}
// Copy only a validated path segment. User-provided path text is never JSON.
static const char *segment(const char *p,char out[64]){
    size_t n=0;while(p[n]&&p[n]!='/'&&p[n]!='?'&&p[n]!='#'){if(n>=63)return 0;out[n]=p[n];n++;}
    out[n]=0;return p+n;
}
CTR_EXPORT int ctr_sessions_json(const char *path,int method,char *out,size_t capacity){
    if(!path||!out||!capacity)return -1;
    const char root[]="/v1/sessions";
    const char *base=!ctr_strncmp(path,root,sizeof(root)-1)?path+sizeof(root)-1:0;
    const char *inv=ctr_strstr(path,"/invitations");
    int friends=ctr_strstr(path,"/friends/sessions")!=0;
    int users=ctr_strstr(path,"/@users/sessions")!=0;
    if(!base&&!inv&&!friends&&!users)return 0;
    if(!acquire())return -1;
    if(clock_now)expire(clock_now());
    Json json={out,0,capacity,0};out[0]=0;int action=0;
    char target_id[35]={0};int queued=0,member=0,direct=0;
    char own_id[35];make_id(own_id,ctr_player_name());
    if(friends||users){add(&json,users?"{\"users\":[],\"size\":0,\"totalResults\":0}":"{\"sessions\":[],\"size\":0,\"totalResults\":0}");route(5);}
    else if(inv){
        const char *tail=inv+12;
        if(method==0&&*tail=='/'){
            char name[64];const char *end=segment(tail+1,name);
            if(!end||!boundary(*end)||ctr_strncmp(name,"inv-",4)||!ctr_name_valid(name+4)||!join.active||!ctr_name_equal(name+4,join.host))goto invalid;
            invitation(&json);route(6);
        }else if(method==0&&boundary(*tail)){
            add(&json,"{\"invitations\":[");if(join.active&&!join.joined)invitation(&json);add(&json,"],\"size\":");number(&json,join.active&&!join.joined?1:0);add(&json,"}");route(6);
        }else if(method==2){add(&json,"{}");}
        else {add(&json,"{\"invitations\":[],\"size\":0}");}
    }else if(boundary(*base)){
        if(method==1){session_id(&json,own_id);action=1;route(0);}
        else if(method==3){add(&json,"{}");action=2;route(4);}
        else {add(&json,"{\"sessions\":[],\"totalResults\":0}");route(5);}
    }else if(*base=='/'){
        char id[64];const char *tail=segment(base+1,id);if(!tail)goto invalid;
        int self=own_active&&!ctr_strcmp(id,own_id);
        queued=(join.active||join.joined)&&!ctr_strcmp(id,join.id);
        member=member_active&&!ctr_strcmp(id,member_id);
        int contact=contact_session(id);
        int target=queued||member||contact;
        if(!self&&!target)goto invalid;
        const char *host=self?ctr_player_name():id+sizeof(session_prefix)-1;
        if(target){ctr_memcpy(target_id,id,ctr_strlen(id)+1);direct=!queued;}
        int members=!ctr_strncmp(tail,"/members",8)&&(boundary(tail[8])||tail[8]=='/');
        if(members&&method==1){session_id(&json,id);action=self?0:3;route(2);}
        else if(members&&method==3){add(&json,"{}");action=self?0:4;route(4);}
        else if(boundary(*tail)&&method==0){session_info(&json,id,host,member);action=target?5:0;route(1);}
        else if(boundary(*tail)&&method==3){add(&json,"{}");action=self?2:4;route(4);}
        else if(boundary(*tail)&&method==2){
            // Match the stock PC runtime's update response. The game's NP
            // toolkit receives the session metadata after PUT as after GET.
            session_info(&json,id,host,member);action=target?5:0;
            route(3);if(route_counts[7]<8){route_counts[7]++;trace(114,self?1:2);}
        }
        else goto invalid;
    }else goto invalid;
    if(json.failed)goto invalid;
    if(direct&&route_counts[8]++<8)trace(115,method);
    if(action==1)own_active=1;
    else if(action==2)own_active=0;
    else if(action==3){
        ctr_memcpy(member_id,target_id,ctr_strlen(target_id)+1);member_active=1;
        if(queued){join.joined=1;join.active=0;}
        trace(93,0);
    }
    else if(action==4){
        if(member){ctr_memset(member_id,0,sizeof(member_id));member_active=0;}
        if(queued)ctr_memset(&join,0,sizeof(join));
        trace(96,0);
    }
    else if(action==5&&queued&&!join.taken){join.taken=1;trace(92,0);}
    int result=(int)json.size;release();return result;
invalid:
    if(route_counts[9]++<8)trace(116,method);
    out[0]=0;release();return -1;
}
