// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "settings.h"
#if defined(_WIN32)
#define FRAME_EXPORT CTR_EXPORT
#else
#define FRAME_EXPORT __attribute__((visibility("hidden")))
#endif
FRAME_EXPORT void ctr_frame_init(uint64_t(*clock_us)(void),int32_t(*sleep_us)(uint32_t),void(*trace)(int32_t,int32_t));
FRAME_EXPORT void ctr_frame_wait(uint32_t path);
// Optional read-only renderer snapshot, invoked once from presentation.
FRAME_EXPORT void ctr_frame_probe(void(*probe)(void));
