from pathlib import Path
import json,sys,struct,re,hashlib
ROOT=Path(__file__).resolve().parent
CHAT=ROOT.parents[1]
PORT=CHAT/'outputs/Crash_Online/CTR-NitroFueled-PC-portable'
sys.path.insert(0,str(PORT/'scripts'))
import prepare
p=json.loads((ROOT/'build/native-profiles.json').read_text())[0]
p['elf']=str((ROOT/p['elf']).resolve())
data=Path(p['elf']).read_bytes()
assert hashlib.sha256(data).hexdigest()==p['native_elf_sha256']
elf,eh,ph,_,_=prepare.parse_elf(data)
dp=next(x for x in ph if x['type']==2)
tags=dict(prepare.unpack('<QQ',elf,i) for i in range(dp['offset'],dp['offset']+dp['filesz'],16))
dd=next(x for x in ph if x['type']==0x61000000)
blob=prepare.span(elf,dd['offset'],dd['filesz'])
strings=prepare.span(blob,tags[0x61000035],tags[0x61000037])
symbols=prepare.span(blob,tags[0x61000039],tags[0x6100003f])
names=dict(re.findall(r'STUB\("([^"]+)",\s*([^)\s]+)\s*\)',(PORT/'out/aerolib.inl').read_text()))
required={'scePadReadState','sceVideoOutSubmitFlip','sceVideoOutSetFlipRate'}
required|={'sceGnmSubmitAndFlipCommandBuffers','sceGnmSubmitAndFlipCommandBuffersForWorkload','sceGnmRequestFlipAndSubmitDone','sceGnmRequestFlipAndSubmitDoneForWorkload'}
required|={'sceImeDialogGetStatus','sceImeDialogGetResult','sceImeDialogTerm'}
required|={'sceSystemServiceGetStatus','sceSystemServiceReceiveEvent'}
required|={'sceUserServiceGetUserName'}
ui_names=required|{'sceMsgDialogInitialize','sceMsgDialogOpen','sceMsgDialogGetStatus','sceMsgDialogUpdateStatus','sceMsgDialogGetResult','sceMsgDialogTerminate','sceImeDialogInit','sceImeDialogGetStatus','sceImeDialogGetResult','sceImeDialogTerm','sceKernelIsNeoMode','sceCommonDialogInitialize'}
ui_names|={'sceKernelGetProcessTime','sceKernelUsleep'}
ui_names|={'sceImeDialogAbort'}
ui_names|={'sceKernelQueryMemoryProtection'}
imports=[];auxiliary={}
def span_rva(rva,size):
    seg=next(x for x in ph if x['type'] in (1,0x61000010) and x['vaddr']<=rva and rva+size<=x['vaddr']+x['filesz'])
    return prepare.span(elf,seg['offset']+rva-seg['vaddr'],size)
for ot,st in ((0x61000029,0x6100002d),(0x6100002f,0x61000031)):
    table=prepare.span(blob,tags[ot],tags[st])
    for i in range(0,len(table),24):
        target,info,addend=prepare.unpack('<QQq',table,i)
        if info&0xffffffff not in (1,6,7):continue
        n,typ,other,section,value,size=prepare.unpack('<IBBHQQ',symbols,(info>>32)*24)
        text=strings[n:strings.index(0,n)].decode()
        name=names.get(text.split('#')[0],'?')
        if section or name not in ui_names:continue
        stubs=[]
        for seg in ph:
            if seg['type']!=1 or not(seg['flags']&1):continue
            code=prepare.span(elf,seg['offset'],seg['filesz']);start=0
            while True:
                found=code.find(b'\xff\x25',start)
                if found<0:break
                if found+6<=len(code) and seg['vaddr']+found+6+struct.unpack_from('<i',code,found+2)[0]==target:stubs.append(seg['vaddr']+found)
                start=found+2
        assert len(stubs)==1
        record={'name':name,'got':target,'unresolved':stubs[0]+6}
        auxiliary[name]=record
        if name in required:imports.append(record)
assert len(imports)==13
patches=[]
low_resolution=bytearray(span_rva(0x13aa648,38))
# The same scene-scale/output changes used by the official PC port at 720p.
# Keep the hardware's real Neo mode unchanged. Only this display-setup branch
# is selected on base PS4; none of the Pro's larger heaps or GPU flags is used.
assert low_resolution.hex()=='01c941898e40050000458b86440500004501c045898644050000418b44244841898648050000'
low_resolution[0:2]=b'\x90\x90'
low_resolution[16:19]=b'\x90\x90\x90'
low_resolution[26:31]=b'\xb8'+struct.pack('<f',720/1080)
light_resolution=bytearray(low_resolution)
# Existing engine scene-scale path, also documented by the PC port at 480p.
# This scales the entire scene; it does not remove post-processing effects.
light_resolution[26:31]=b'\xb8'+struct.pack('<f',480/1080)
for name,rva,size,index,original,replacement in (
    ('motion_blur',0xaf0f3c,35,9,b'\x75',b'\xeb'),
    ('pro_1080',0x13a9db3,13,1,b'\x85',b'\x84'),
    ('performance_scale',0x13aa648,43,0,span_rva(0x13aa648,38),bytes(low_resolution)),
    # cmp bool-is-Neo, 2; jne: true for both actual hardware values (0 or 1).
    # Apply this gate last, after the scene scale and output size are ready.
    ('performance_path',0x13a9da5,14,13,b'\x00',b'\x02'),
    # Feed zero into the original shadow-fade path. It derives BOTH shader
    # enable flags and CascadeShadowRenderData.enable from the same zero fade.
    # The engine's normal disabled path then disables its four split cameras.
    ('shadows_cascade_fade',0xaf87ce,58,4,bytes.fromhex('c4c17a10878c020000'),bytes.fromhex('c5f857c09090909090')),
    # All hero-shadow option/handle paths converge here before the original
    # disabled branch installs its normal neutral bundles and skips rendering.
    ('shadows_hero_gate',0xaf7dc1,47,8,bytes.fromhex('4584e4'),bytes.fromhex('4530e4')),
    # Display scale alone is insufficient on base hardware: the original
    # dimension helper otherwise returns 1.0 before reading display+0x548.
    # Select its existing multiplication path, without changing real Neo mode.
    ('scene_scale_consumer',0x13e2ec7,34,16,b'\x00',b'\x02'),
    ('scene_scale_consumer_lazy',0x13e2f13,24,6,b'\x00',b'\x02')):
    window=span_rva(rva,size)
    assert len(original)==len(replacement) and window[index:index+len(original)]==original
    if name=='motion_blur':
        assert window[9:11]==b'\x75\x10' and window[22]==0xe8
        assert 11+window[10]==27 # same end as the established NOP-call patch
    alternate=bytes(light_resolution) if name=='performance_scale' else replacement
    patches.append({'name':name,'rva':rva,'size':size,'index':index,'length':len(original),'original':original.hex(),'replacement':replacement.hex(),'alternate':alternate.hex(),'bytes':window.hex()})
for i,a in enumerate(patches):
    for b in patches[i+1:]:assert a['rva']+a['size']<=b['rva'] or b['rva']+b['size']<=a['rva'],'graphics guard windows must not overlap'
lines=['// Generated from the exact installed RYUN00001 image; no pattern scanning.','static UiImport ui_imports[] = {']
for r in imports:lines.append('{"%s",0x%x,0x%x,0,0},'%(r['name'],r['got'],r['unresolved']))
lines+=['};','static UiPatch ui_patches[] = {']
for p in patches:lines.append('{"%s",0x%x,%d,%d,%d,{%s},{%s},{%s}},'%(p['name'],p['rva'],p['size'],p['index'],p['length'],','.join('0x'+p['bytes'][i:i+2] for i in range(0,len(p['bytes']),2)),','.join('0x'+p['replacement'][i:i+2] for i in range(0,len(p['replacement']),2)),','.join('0x'+p['alternate'][i:i+2] for i in range(0,len(p['alternate']),2))))
lines+=['};']
lines+=['static UiSymbol ui_symbols[] = {']
for name in sorted(ui_names):
    r=auxiliary.get(name,{'got':0,'unresolved':0})
    lines.append('{"%s","%s",0x%x,0x%x},'%(name,prepare.nid(name),r['got'],r['unresolved']))
lines+=['};']
(ROOT/'src/ui_profile.h').write_text('\n'.join(lines)+'\n')
unchanged_effects=[]
for name,rva,size in (('high_vfx_graph',0xaf057f,24),('high_vfx_shader',0xaf0597,30),('sunshaft_graph',0xaf0609,21),('dof_strength',0xaf8de4,49)):
    unchanged_effects.append({'name':name,'rva':rva,'size':size,'bytes':span_rva(rva,size).hex()})
(ROOT/'build/ui-profile.json').write_text(json.dumps({'imports':imports,'patches':patches,'auxiliary':list(auxiliary.values()),'unchanged_effects':unchanged_effects},indent=2))
print(json.dumps({'imports':imports,'patches':patches},indent=2))
