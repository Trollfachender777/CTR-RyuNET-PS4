"""Test actual C pacing with a deterministic clock and simulated render work."""
from pathlib import Path
import ctypes as C,json,unittest
from test_settings_menu import lib,Settings,defaults
ROOT=Path(__file__).resolve().parent
lib.ctr_frame_init.argtypes=[C.c_void_p,C.c_void_p,C.c_void_p]
lib.ctr_frame_wait.argtypes=[C.c_uint32]
lib.ctr_frame_probe.argtypes=[C.c_void_p]
class Tests(unittest.TestCase):
    def setUp(self):
        self.now=1000000;self.sleeps=[];self.events=[]
        self.clock=C.CFUNCTYPE(C.c_uint64)(lambda:self.now)
        def sleep(us):self.sleeps.append(us);self.now+=us;return 0
        self.sleep=C.CFUNCTYPE(C.c_int32,C.c_uint32)(sleep)
        self.trace=C.CFUNCTYPE(None,C.c_int32,C.c_int32)(lambda a,b:self.events.append((a,b)))
        lib.ctr_frame_init(self.clock,self.sleep,self.trace);self.fps(60)
    def fps(self,value):
        s=defaults();s.fps=value;assert lib.ctr_settings_publish(C.byref(s))==0
    def test_unlimited_does_not_wait(self):
        self.fps(0)
        for _ in range(120):lib.ctr_frame_wait(0);self.now+=5000
        self.assertEqual(self.sleeps,[])
        self.assertIn((71,0),self.events)
    def test_sixty_has_real_cap_under_fast_and_slow_workloads(self):
        for work in (0,5000,16000,40000):
            lib.ctr_frame_init(self.clock,self.sleep,self.trace);self.fps(60);times=[]
            for _ in range(121):
                self.now+=work;lib.ctr_frame_wait(0);times.append(self.now)
            expected=max(work,16667)
            self.assertTrue(all(b-a==expected for a,b in zip(times,times[1:])))
            self.assertGreaterEqual(times[-1]-times[0],2000000)
    def test_thirty_paces_presentations_to_33333_microseconds(self):
        self.fps(30);times=[]
        for _ in range(60):
            self.now+=5000;lib.ctr_frame_wait(1);times.append(self.now)
        self.assertTrue(all(b-a==33333 for a,b in zip(times,times[1:])))
        self.assertEqual(len(self.sleeps),59);self.assertTrue(all(0<n<=33333 for n in self.sleeps))
    def test_duplicate_presentation_paths_do_not_double_throttle(self):
        self.fps(30)
        for _ in range(20):
            self.now+=5000;lib.ctr_frame_wait(1);time=self.now;lib.ctr_frame_wait(3);self.assertEqual(self.now,time)
        self.assertEqual(len(self.sleeps),19)
        self.assertEqual(len([e for e in self.events if e[0]==70]),2)
    def test_mode_switch_and_long_frame_do_not_cause_catchup_or_long_sleep(self):
        self.fps(30);lib.ctr_frame_wait(0);self.now+=250000;lib.ctr_frame_wait(0)
        self.assertEqual(self.sleeps,[])
        self.now+=1000;lib.ctr_frame_wait(0);self.assertEqual(self.sleeps[-1],32333)
        self.fps(60);before=len(self.sleeps);lib.ctr_frame_wait(0);self.assertEqual(len(self.sleeps),before)
        self.fps(30);lib.ctr_frame_wait(2);self.assertEqual(len(self.sleeps),before)
    def test_missing_clock_disables_waiting_safely(self):
        lib.ctr_frame_init(None,None,self.trace);self.fps(30)
        lib.ctr_frame_wait(0);lib.ctr_frame_wait(0);self.assertEqual(self.events.count((72,-1)),1)
    def test_diagnostics_measure_single_path_without_sleep_or_per_frame_logs(self):
        self.fps(0)
        lib.ctr_frame_wait(0)
        intervals=[16000]*599+[42000]
        for interval in intervals:
            self.now+=interval;lib.ctr_frame_wait(0);lib.ctr_frame_wait(4)
        self.assertFalse(any(stage>=130 for stage,code in self.events))
        self.now+=16000;lib.ctr_frame_wait(0)
        for _ in range(25):self.now+=16000;lib.ctr_frame_wait(0)
        reports=[e for e in self.events if e[0]>=130]
        self.assertEqual([s for s,c in reports],[130,131,132,133,134])
        values=dict(reports);self.assertEqual(values[131],42000);self.assertEqual(values[132],1)
        self.assertEqual(values[134],0);self.assertGreater(values[133],600)
        self.assertEqual(values[130],(values[133]*16000+26000)//values[133])
        self.assertEqual(self.sleeps,[])
    def test_diagnostics_restart_after_loading_path_migration_and_mode_switch(self):
        lib.ctr_frame_wait(0);self.now+=700000;lib.ctr_frame_wait(0)
        self.now+=110000;lib.ctr_frame_wait(2)
        self.fps(30);lib.ctr_frame_wait(2)
        for _ in range(302):self.now+=5000;lib.ctr_frame_wait(2)
        values=dict(e for e in self.events if e[0]>=130)
        self.assertEqual(values[130],33333);self.assertEqual(values[131],33333)
        self.assertEqual(values[132],values[133]);self.assertEqual(values[134],2)
        self.assertTrue(all(n<=33333 for n in self.sleeps))
    def test_renderer_probe_runs_once_and_reinitialization_clears_it(self):
        calls=[];probe=C.CFUNCTYPE(None)(lambda:calls.append(True))
        lib.ctr_frame_probe(probe)
        lib.ctr_frame_wait(0);lib.ctr_frame_wait(4);self.assertEqual(len(calls),1)
        lib.ctr_frame_probe(probe);lib.ctr_frame_init(self.clock,self.sleep,self.trace)
        lib.ctr_frame_wait(0);self.assertEqual(len(calls),1)
    def test_duplicate_paths_do_not_double_limit_sixty(self):
        for path in range(5):
            lib.ctr_frame_init(self.clock,self.sleep,self.trace);self.sleeps.clear()
            for _ in range(10):
                self.now+=1000;lib.ctr_frame_wait(path);before=self.now
                lib.ctr_frame_wait((path+1)%5);self.assertEqual(self.now,before)
            self.assertEqual(self.sleeps,[15667]*9)
    def test_switch_between_all_modes_resets_previous_deadline(self):
        for fps,period in ((30,33333),(60,16667),(0,None),(60,16667),(30,33333)):
            self.fps(fps);before=len(self.sleeps);lib.ctr_frame_wait(0)
            self.assertEqual(len(self.sleeps),before)
            self.now+=1000;lib.ctr_frame_wait(0)
            self.assertEqual(len(self.sleeps),before+(period is not None))
            if period:self.assertEqual(self.sleeps[-1],period-1000)
    def test_slow_frame_and_sleep_overshoot_do_not_produce_catchup_bursts(self):
        def oversleep(us):self.sleeps.append(us);self.now+=us+2000;return 0
        self.sleep=C.CFUNCTYPE(C.c_int32,C.c_uint32)(oversleep)
        lib.ctr_frame_init(self.clock,self.sleep,self.trace)
        lib.ctr_frame_wait(0)
        for work in (1000,1000,19000,1000,60000,1000):
            before=self.now;self.now+=work;lib.ctr_frame_wait(0)
            self.assertGreaterEqual(self.now-before,16667)
    def test_early_wakeup_retries_sleep_without_spinning(self):
        calls=[]
        def early(us):calls.append(us);self.now+=us-100 if len(calls)==1 else us;return 0
        self.sleep=C.CFUNCTYPE(C.c_int32,C.c_uint32)(early)
        lib.ctr_frame_init(self.clock,self.sleep,self.trace)
        lib.ctr_frame_wait(0);before=self.now;self.now+=1000;lib.ctr_frame_wait(0)
        self.assertEqual(calls,[15667,100]);self.assertEqual(self.now-before,16667)
    def test_quantized_millisecond_sleeper_does_not_accumulate_58fps_drift(self):
        def quantized(us):self.sleeps.append(us);self.now+=((us+999)//1000)*1000;return 0
        self.sleep=C.CFUNCTYPE(C.c_int32,C.c_uint32)(quantized)
        for work in (1000,5000,10000):
            lib.ctr_frame_init(self.clock,self.sleep,self.trace);times=[];self.sleeps.clear()
            for _ in range(601):
                self.now+=work;lib.ctr_frame_wait(0);times.append(self.now)
            intervals=[b-a for a,b in zip(times,times[1:])]
            self.assertTrue(all(16000<=us<=17000 for us in intervals))
            elapsed=times[-1]-times[0]
            self.assertLessEqual(abs(elapsed-10000000),1000)
            self.assertTrue(59.99<=600000000/elapsed<=60.01)
            self.assertEqual(len(self.sleeps),600)
    def test_small_wakeup_lag_is_compensated_but_slow_work_rebases_deadline(self):
        def mild_lag(us):self.sleeps.append(us);self.now+=us+700;return 0
        self.sleep=C.CFUNCTYPE(C.c_int32,C.c_uint32)(mild_lag)
        lib.ctr_frame_init(self.clock,self.sleep,self.trace);times=[]
        for _ in range(601):
            self.now+=1000;lib.ctr_frame_wait(0);times.append(self.now)
        self.assertGreaterEqual(min(b-a for a,b in zip(times,times[1:])),15667)
        self.assertLessEqual(abs((times[-1]-times[0])-10000200),1000)
        self.now+=50000;lib.ctr_frame_wait(0);after_slow=self.now
        self.now+=1000;lib.ctr_frame_wait(0)
        self.assertEqual(self.now-after_slow,17367)
    def test_broken_sleep_and_clock_rewind_return_without_hanging(self):
        calls=[]
        self.sleep=C.CFUNCTYPE(C.c_int32,C.c_uint32)(lambda us:calls.append(us) or 0)
        lib.ctr_frame_init(self.clock,self.sleep,self.trace)
        lib.ctr_frame_wait(0);self.now+=1000;lib.ctr_frame_wait(0)
        self.assertEqual(len(calls),4);self.assertIn((72,-2),self.events)
        lib.ctr_frame_init(self.clock,None,self.trace)
        lib.ctr_frame_wait(0);self.assertIn((72,-1),self.events)
        lib.ctr_frame_init(self.clock,self.sleep,self.trace)
        lib.ctr_frame_wait(0);self.now-=500000;before=len(calls);lib.ctr_frame_wait(0)
        self.assertEqual(len(calls),before)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/frame-limit-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'actual C presentation scheduler; 60-frame timing, mode switches, long frames and duplicate paths'},indent=2))
    raise SystemExit(not result.wasSuccessful())
