"""Check the real C invitation ABI, bounded lifecycle and NP session contract."""
from pathlib import Path
import ctypes as C,json,struct,unittest
import test_core as core
from test_settings_menu import Settings,defaults
lib=core.lib
ROOT=Path(__file__).resolve().parent
lib.ctr_sessions_init.argtypes=[C.c_int32,C.c_void_p,C.c_void_p]
lib.ctr_sessions_ready.argtypes=[C.c_int]
lib.ctr_session_queue.argtypes=[C.c_char_p]
lib.ctr_session_due.argtypes=[]
lib.ctr_session_event.argtypes=[C.c_void_p,C.c_size_t]
lib.ctr_sessions_json.argtypes=[C.c_char_p,C.c_int,C.c_void_p,C.c_size_t]
ME='DemoPlayerPS4001';FRIEND='DemoPlayerPC0001';SID='cusa13795-session-'+FRIEND

class Tests(unittest.TestCase):
    def setUp(self):
        self.api=core.Api();self.assertEqual(lib.ctr_core_init(C.byref(self.api),ME.encode()),0)
        s=defaults();lib.ctr_settings_add(C.byref(s),FRIEND.encode(),ME.encode());lib.ctr_settings_publish(C.byref(s))
        self.now=1000000;self.traces=[]
        self.clock=C.CFUNCTYPE(C.c_uint64)(lambda:self.now)
        self.trace=C.CFUNCTYPE(None,C.c_int32,C.c_int32)(lambda a,b:self.traces.append((a,b)))
        lib.ctr_sessions_init(0x12345678,C.cast(self.clock,C.c_void_p),C.cast(self.trace,C.c_void_p));lib.ctr_sessions_ready(1)
    def queue(self):
        self.assertEqual(lib.ctr_session_queue(FRIEND.encode()),0);self.now+=250000
    def doc(self,path,method=0):
        out=C.create_string_buffer(4096);n=lib.ctr_sessions_json(path.encode(),method,out,len(out))
        self.assertGreater(n,0,path);return json.loads(out.value)
    def test_event_abi_real_local_user_creator_and_canaries(self):
        self.assertEqual(lib.ctr_session_queue(FRIEND.encode()),0)
        data=(C.c_ubyte*212)(*([0xa5]*212))
        self.assertEqual(lib.ctr_session_event(C.byref(data,16),180),0)
        self.assertEqual(bytes(data),b'\xa5'*212)
        self.now+=250000;self.assertEqual(lib.ctr_session_due(),1)
        self.assertEqual(lib.ctr_session_event(C.byref(data,16),180),1)
        raw=bytes(data)[16:196];param=raw[4:]
        self.assertEqual(struct.unpack_from('<I',raw)[0],0x10000002)
        self.assertEqual(param[:46].split(b'\0')[0].decode(),SID)
        self.assertEqual(param[0x30:0x6d].split(b'\0')[0],('inv-'+FRIEND).encode())
        self.assertEqual(struct.unpack_from('<I',param,0x70)[0],1)
        self.assertEqual(param[0x78:0x8c].split(b'\0')[0],ME.encode())
        self.assertEqual(struct.unpack_from('<i',param,0x8c)[0],0x12345678)
        self.assertEqual(param[0x90:0xa8].split(b'\0')[0],FRIEND.encode())
        self.assertEqual(struct.unpack_from('<Q',param,0xa8)[0],core.expected_pid(FRIEND))
        self.assertEqual(bytes(data[:16]),b'\xa5'*16);self.assertEqual(bytes(data[196:]),b'\xa5'*16)
    def test_ready_gate_names_buffer_limits_and_invalid_requests_keep_pending(self):
        lib.ctr_sessions_ready(0);self.assertLess(lib.ctr_session_queue(FRIEND.encode()),0)
        lib.ctr_sessions_ready(1);self.queue()
        for name in (b'',ME.encode(),b'NotInList',b'bad/name',b'x'*17):self.assertLess(lib.ctr_session_queue(name),0)
        data=(C.c_ubyte*212)(*([0xa5]*212))
        self.assertEqual(lib.ctr_session_event(C.byref(data,16),179),0)
        self.assertEqual(bytes(data),b'\xa5'*212);self.assertEqual(lib.ctr_session_due(),1)
    def test_retry_interval_expiry_and_taken_stop_repeat_events(self):
        self.queue();out=C.create_string_buffer(180)
        self.assertEqual(lib.ctr_session_event(out,180),1);self.assertEqual(lib.ctr_session_due(),0)
        self.now+=3999999;self.assertEqual(lib.ctr_session_due(),0)
        self.now+=1;self.assertEqual(lib.ctr_session_event(out,180),1)
        self.doc('/v1/sessions/'+SID);self.assertEqual(lib.ctr_session_due(),0)
        self.now+=10000000;self.assertEqual(lib.ctr_session_event(out,180),0)
        self.now+=240000000;self.assertEqual(self.doc('/v1/users/me/invitations')['size'],0)
    def test_session_creator_and_members_post_joins_target_without_creating_self(self):
        self.queue()
        doc=self.doc('/v1/sessions/'+SID)
        self.assertEqual(doc['sessionCreator']['onlineId'],FRIEND)
        self.assertEqual(int(doc['sessionCreator']['accountId']),core.expected_pid(FRIEND))
        self.assertEqual([x['onlineId'] for x in doc['members']],[FRIEND])
        joined=self.doc('/v1/sessions/'+SID+'/members',1);self.assertEqual(joined['sessionId'],SID)
        doc=self.doc('/v1/sessions/'+SID)
        self.assertEqual([x['onlineId'] for x in doc['members']],[FRIEND,ME])
        self.assertEqual(lib.ctr_session_due(),0)
        self.doc('/v1/sessions/'+SID+'/members/me',3)
        # Stock friend-menu joins can request metadata without an invitation.
        # Leaving removes membership, not the configured contact's metadata.
        self.assertEqual([m['onlineId'] for m in self.doc('/v1/sessions/'+SID)['members']],[FRIEND])
        self.assertEqual(self.doc('/v1/users/me/invitations')['size'],0)
    def test_invitation_shape_and_self_create_delete(self):
        self.queue();doc=self.doc('/v1/users/me/invitations/inv-'+FRIEND)
        self.assertEqual(doc['sessionId'],SID);self.assertEqual(doc['fromUser']['onlineId'],FRIEND)
        self.assertEqual(self.doc('/v1/users/me/invitations')['size'],1)
        own='cusa13795-session-'+ME
        self.assertEqual(self.doc('/v1/sessions',1)['sessionId'],own)
        self.assertEqual(self.doc('/v1/sessions/'+own)['sessionCreator']['onlineId'],ME)
        self.doc('/v1/sessions/'+own,3)
        out=C.create_string_buffer(1024);self.assertLess(lib.ctr_sessions_json(('/v1/sessions/'+own).encode(),0,out,len(out)),0)
    def test_json_bounds_invalid_paths_and_no_fabricated_remote_session_discovery(self):
        self.queue()
        for path in ('/v1/sessions/'+SID,'/v1/users/me/invitations'):
            guard=(C.c_ubyte*48)(*([0xa5]*48))
            self.assertLess(lib.ctr_sessions_json(path.encode(),0,C.byref(guard,16),16),0)
            self.assertEqual(bytes(guard[:16]),b'\xa5'*16);self.assertEqual(bytes(guard[32:]),b'\xa5'*16)
        self.assertEqual(lib.ctr_session_due(),1)
        for path in ('/v1/sessions/../bad','/v1/sessions/'+SID+'/unexpected','/v1/sessions/cusa13795-session-Unknown','/v1/users/me/invitations/inv-NotFriend'):
            out=C.create_string_buffer(4096);self.assertLess(lib.ctr_sessions_json(path.encode(),0,out,len(out)),0)
        self.assertEqual(self.doc('/v1/users/me/friends/sessions')['sessions'],[])
        self.assertEqual(self.doc('/v1/users/@users/sessions')['users'],[])
        out=C.create_string_buffer(b'unchanged',32)
        self.assertEqual(lib.ctr_sessions_json(b'/v1/profiles',0,out,len(out)),0);self.assertEqual(out.value,b'unchanged')
    def test_renamed_identity_agrees_across_np_invitation_and_session_membership(self):
        # A real rename exposed a failed cross-client join. Do not let the
        # prior nickname survive in any of the game's local identity contracts.
        self.queue();self.doc('/v1/sessions',1)
        renamed='DemoPlayerPS4002'
        self.assertEqual(lib.ctr_core_init(C.byref(self.api),renamed.encode()),0)
        self.assertEqual(lib.ctr_session_due(),0)
        s=defaults();self.assertEqual(lib.ctr_settings_add(C.byref(s),FRIEND.encode(),renamed.encode()),0)
        lib.ctr_settings_publish(C.byref(s))
        lib.ctr_sessions_init(0x12345678,C.cast(self.clock,C.c_void_p),C.cast(self.trace,C.c_void_p));lib.ctr_sessions_ready(1)
        get_id=core.function('sceNpGetOnlineId',C.c_int32,C.c_int32,C.c_void_p)
        get_account=core.function('sceNpGetAccountIdA',C.c_int32,C.c_int32,C.POINTER(C.c_uint64))
        get_token=core.function('sceNpAuthGetIdTokenA',C.c_int32,C.c_int32,C.c_void_p,C.c_void_p)
        online=C.create_string_buffer(20);account=C.c_uint64();token=C.create_string_buffer(128)
        self.assertEqual(get_id(0x12345678,online),0);self.assertEqual(online.value.decode(),renamed)
        self.assertEqual(get_account(0x12345678,C.byref(account)),0);self.assertEqual(account.value,core.expected_pid(renamed))
        self.assertEqual(get_token(1,None,token),0);self.assertEqual(token.value.decode(),renamed)
        self.queue();event=C.create_string_buffer(180);self.assertEqual(lib.ctr_session_event(event,180),1)
        self.assertEqual(event.raw[4+0x78:4+0x8c].split(b'\0')[0].decode(),renamed)
        self.doc('/v1/sessions/'+SID+'/members',1)
        members=self.doc('/v1/sessions/'+SID)['members']
        self.assertEqual([(m['onlineId'],int(m['accountId'])) for m in members],
                         [(FRIEND,core.expected_pid(FRIEND)),(renamed,core.expected_pid(renamed))])
        own='cusa13795-session-'+renamed
        self.assertEqual(self.doc('/v1/sessions',1)['sessionId'],own)
        self.assertEqual(self.doc('/v1/sessions/'+own)['sessionCreator']['onlineId'],renamed)
    def test_host_update_returns_pc_session_metadata_without_changing_owner(self):
        # The stock PC runtime handles PUT .../sessions/<id> through the same
        # complete metadata response as GET (runtime_services.c). An empty
        # object differs from that established cross-client contract.
        own='cusa13795-session-'+ME
        self.assertEqual(self.doc('/v1/sessions',1)['sessionId'],own)
        before=self.doc('/v1/sessions/'+own)
        updated=self.doc('/v1/sessions/'+own,2)
        self.assertEqual(updated,before)
        self.assertEqual(updated['sessionCreator']['accountId'],str(core.expected_pid(ME)))
        self.assertEqual(self.doc('/v1/sessions/'+own),before)
        self.queue()
        updated=self.doc('/v1/sessions/'+SID,2)
        self.assertEqual(updated['sessionCreator']['onlineId'],FRIEND)
        self.assertEqual([m['onlineId'] for m in updated['members']],[FRIEND])
        self.assertEqual(self.doc('/v1/sessions/'+own)['sessionId'],own)
    def test_actual_webapi_preserves_host_session_id_and_partial_reads(self):
        self.queue()
        create=core.function('sceNpWebApiCreateRequest',C.c_int32,C.c_int32,C.c_char_p,C.c_char_p,C.c_int32,C.c_void_p,C.POINTER(C.c_int64))
        send=core.function('sceNpWebApiSendRequest',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        read=core.function('sceNpWebApiReadData',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        delete=core.function('sceNpWebApiDeleteRequest',C.c_int32,C.c_int64)
        for path,method in (('/v1/sessions/'+SID+'/members',1),('/v1/sessions/'+SID,0)):
            handle=C.c_int64();self.assertEqual(create(1,b'sdk:session',path.encode(),method,None,C.byref(handle)),0)
            self.assertEqual(send(handle.value,None,0),0);chunks=[]
            for _ in range(100):
                buf=C.create_string_buffer(31);n=read(handle.value,buf,len(buf))
                if not n:break
                chunks.append(buf.raw[:n])
            self.assertEqual(json.loads(b''.join(chunks))['sessionId'],SID);delete(handle.value)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/sessions-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'actual C invitation ABI, creator account, local accepting user, session membership, bounded retries and NP WebApi'}))
    raise SystemExit(not result.wasSuccessful())
