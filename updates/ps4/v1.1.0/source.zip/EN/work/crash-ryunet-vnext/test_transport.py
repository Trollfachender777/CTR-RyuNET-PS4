from pathlib import Path
import json,unittest,struct
from ps4_transport import prepare
from ps4_transport import require_self,decrypted_view,matches_readback,SELF_MAGIC
ROOT=Path(__file__).resolve().parent
def expected_readback(source):
    # Construct the documented decrypted ELF layout without private FTP fixtures.
    data=bytearray(prepare.parse_self(source)[0])
    struct.pack_into('<Q',data,40,0);struct.pack_into('<HHH',data,58,0,0,0)
    return bytes(data)
class Tests(unittest.TestCase):
    def test_self_matches_expected_goldhen_decrypted_layout(self):
        source=(ROOT/'build/ctr_online.prx').read_bytes()
        download=expected_readback(source)
        self.assertEqual(decrypted_view(source),download)
        self.assertTrue(matches_readback(source,download));self.assertTrue(matches_readback(source,source))
        self.assertNotEqual(source,download)
    def test_raw_elf_is_never_accepted_as_deployable_module(self):
        download=expected_readback((ROOT/'build/ctr_online.prx').read_bytes())
        with self.assertRaises(ValueError):require_self(download)
        with self.assertRaises(ValueError):matches_readback(download,download)
    def test_current_build_is_self_and_both_transfer_views_match(self):
        source=(ROOT/'build/ctr_online.prx').read_bytes()
        self.assertEqual(source[:4],SELF_MAGIC)
        self.assertTrue(matches_readback(source,source))
        self.assertTrue(matches_readback(source,decrypted_view(source)))
    def test_corrupted_or_truncated_payload_is_detected(self):
        source=(ROOT/'build/ctr_online.prx').read_bytes()
        download=bytearray(decrypted_view(source));download[0x4010]^=1
        self.assertFalse(matches_readback(source,download));self.assertFalse(matches_readback(source,download[:-16]))
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/transport-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'locally built SELF and generated decrypted ELF layout; reject bare ELF deployment; no private FTP fixtures'},indent=2))
    raise SystemExit(not result.wasSuccessful())
