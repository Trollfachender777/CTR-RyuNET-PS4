"""Run isolated host suites and retain their per-suite verification reports."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import subprocess
import sys
root=Path(__file__).resolve().parent
names=('core','settings_menu','profile','installation','sessions','frame_limit','transport','network','friend_routes','original_friend_join')
def run(name):
    result=subprocess.run([sys.executable,str(root/('test_'+name+'.py'))],capture_output=True,text=True)
    (root/'build'/('network-r19-'+name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
    return {'suite':name,'exit_code':result.returncode}
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,names))
print(json.dumps(results,indent=2))
raise SystemExit(0 if all(row['exit_code']==0 for row in results) else 1)
