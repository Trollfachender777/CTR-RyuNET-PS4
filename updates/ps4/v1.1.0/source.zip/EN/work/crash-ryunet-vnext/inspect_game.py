"""Read-only address, cross-reference and disassembly helper for the exact PS4 ELF."""
import hashlib,json,re,struct,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts'))
import prepare
p=json.loads((ROOT/'build/native-profiles.json').read_text())[0]
p['elf']=str((ROOT/p['elf']).resolve())
data=Path(p['elf']).read_bytes()
assert hashlib.sha256(data).hexdigest()==p['native_elf_sha256']
elf,eh,ph,_,_=prepare.parse_elf(data)
def offset(addr):
    seg=next((s for s in ph if s['type'] in (1,0x61000010) and s['vaddr']<=addr<s['vaddr']+s['filesz']),None)
    return None if seg is None else seg['offset']+addr-seg['vaddr']
def address(off):
    seg=next((s for s in ph if s['type'] in (1,0x61000010) and s['offset']<=off<s['offset']+s['filesz']),None)
    return None if seg is None else seg['vaddr']+off-seg['offset']
def string(addr):
    off=offset(addr)
    if off is None:return ''
    b=elf[off:off+120].split(b'\0',1)[0]
    return b.decode('ascii') if b and all(32<=x<127 for x in b) else ''
def xrefs(target):
    refs=[]
    for seg in ph:
        if seg['type']!=1 or not(seg['flags']&1):continue
        code=elf[seg['offset']:seg['offset']+seg['filesz']]
        for m in re.finditer(rb'[\x40-\x4f]?[\x8d\x8b\x89][\x05\x0d\x15\x1d\x25\x2d\x35\x3d]....|[\xe8\xe9]....',code,re.S):
            end=seg['vaddr']+m.end()
            if end+struct.unpack_from('<i',m.group(),len(m.group())-4)[0]==target:
                refs.append(hex(seg['vaddr']+m.start()))
    pat=struct.pack('<Q',target)
    refs_data=[hex(address(m.start()) or m.start()) for m in re.finditer(re.escape(pat),elf)]
    return {'target':hex(target),'text':string(target),'code_refs':refs,'pointer_refs':refs_data}
if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='dis':
        start=int(sys.argv[2],0);stop=int(sys.argv[3],0)
        r=subprocess.run([str(ROOT.parents[0]/'ps4-online/llvm/bin/llvm-objdump.exe'),'-d','--no-show-raw-insn',f'--start-address={start}',f'--stop-address={stop}',p['elf']],capture_output=True,text=True)
        print('\n'.join(line for line in r.stdout.splitlines() if not re.search(r':\s+nop',line)))
    elif mode=='refs':
        print(json.dumps([xrefs(int(a,0)) for a in sys.argv[2:]],indent=2))
    elif mode=='table':
        start=int(sys.argv[2],0);count=int(sys.argv[3],0)
        for a in range(start,start+count*8,8):
            off=offset(a);v=struct.unpack_from('<Q',elf,off)[0]
            print(f'{a:#x}: {v:#x} {string(v)}')
