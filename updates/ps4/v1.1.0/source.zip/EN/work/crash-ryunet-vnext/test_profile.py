"""Execute nickname validation, persistence format and network identity boundaries."""
from pathlib import Path
import ctypes as C,json,unittest
import test_core as core
lib=core.lib;ROOT=Path(__file__).resolve().parent
lib.ctr_profile_name_valid.argtypes=[C.c_char_p]
lib.ctr_profile_parse.argtypes=[C.c_void_p,C.c_char_p,C.c_size_t]
lib.ctr_profile_format.argtypes=[C.c_char_p,C.c_void_p,C.c_size_t]
lib.ctr_profile_publish.argtypes=[C.c_char_p]
lib.ctr_profile_snapshot.argtypes=[C.c_void_p]
lib.ctr_core_set_online.argtypes=[C.c_int]
lib.ctr_player_name.restype=C.c_char_p
class Profile(C.Structure):_fields_=[('nickname',C.c_char*17),('owned',C.c_uint8)]
lib.ctr_profile_parse_record.argtypes=[C.POINTER(Profile),C.c_char_p,C.c_size_t]
lib.ctr_profile_format_record.argtypes=[C.POINTER(Profile),C.c_void_p,C.c_size_t]
lib.ctr_profile_publish_record.argtypes=[C.POINTER(Profile)]
lib.ctr_profile_snapshot_record.argtypes=[C.POINTER(Profile)]
class Tests(unittest.TestCase):
    def setUp(self):
        self.api=core.Api();self.assertEqual(lib.ctr_core_init(C.byref(self.api),b'DemoPlayerPS4001'),0)
    def test_name_rules_match_pc_and_reserved_defaults_are_refused(self):
        for name in (b'Abc',b'AliasPrivado_123',b'Jugador_45',b'Name-X'):self.assertEqual(lib.ctr_profile_name_valid(name),1)
        for name in (b'',b'ab',b'x'*17,b'bad/name',b'has space',b'RyUnEt',b'Player',b'RyuPC',b'Guest',b'Jugador',b'ni\xc3\xb1o'):self.assertEqual(lib.ctr_profile_name_valid(name),0)
    def test_profile_roundtrip_and_bad_input_leaves_output_untouched(self):
        text=C.create_string_buffer(128);n=lib.ctr_profile_format(b'AliasPrivado_123',text,len(text));self.assertGreater(n,0)
        out=C.create_string_buffer(17);self.assertEqual(lib.ctr_profile_parse(out,text,n),0);self.assertEqual(out.value,b'AliasPrivado_123')
        for bad in (b'version=2\nnickname=Valid\n',b'nickname=Valid\n',b'version=1\nnickname=Valid\nnickname=Other\n',b'version=1\nnickname=Bad\0Name\n',b'version=1\nnickname=Player\n',b'version=1\npsn_name=Private\n',b'x'*129):
            previous=out.raw;self.assertLess(lib.ctr_profile_parse(out,bad,len(bad)),0);self.assertEqual(out.raw,previous)
        tiny=C.create_string_buffer(b'abc',4);self.assertLess(lib.ctr_profile_format(b'ValidName',tiny,len(tiny)),0);self.assertEqual(tiny.value,b'abc')
    def test_saved_name_does_not_rebind_active_identity_mid_session(self):
        self.assertEqual(lib.ctr_profile_publish(b'AliasPrivado_123'),0)
        out=C.create_string_buffer(17);self.assertEqual(lib.ctr_profile_snapshot(out),0);self.assertEqual(out.value,b'AliasPrivado_123')
        self.assertEqual(lib.ctr_player_name(),b'DemoPlayerPS4001')
        account=C.c_uint64();fn=core.function('sceNpGetAccountIdA',C.c_int32,C.c_int32,C.POINTER(C.c_uint64))
        self.assertEqual(fn(42,C.byref(account)),0);self.assertEqual(account.value,core.expected_pid('DemoPlayerPS4001'))
    def test_next_start_uses_all_sixteen_characters_and_matching_account(self):
        name=b'AliasPrivado_123';self.assertEqual(len(name),16);self.assertEqual(lib.ctr_core_init(C.byref(self.api),name),0)
        for symbol,size in (('sceNpGetOnlineId',20),('sceNpGetNpId',36)):
            buf=(C.c_ubyte*(size+32))(*([0xa5]*(size+32)))
            fn=core.function(symbol,C.c_int32,C.c_int32,C.c_void_p);self.assertEqual(fn(42,C.byref(buf,16)),0)
            self.assertEqual(bytes(buf)[16:33],name+b'\0');self.assertEqual(bytes(buf[:16]),b'\xa5'*16);self.assertEqual(bytes(buf[-16:]),b'\xa5'*16)
        token=C.create_string_buffer(64);fn=core.function('sceNpAuthGetIdTokenA',C.c_int32,C.c_int32,C.c_void_p,C.c_void_p)
        self.assertEqual(fn(1,None,token),0);self.assertEqual(token.value,name)
        account=C.c_uint64();fn=core.function('sceNpGetAccountIdA',C.c_int32,C.c_int32,C.POINTER(C.c_uint64))
        self.assertEqual(fn(42,C.byref(account)),0);self.assertEqual(account.value,core.expected_pid(name.decode()))
    def test_missing_profile_gate_refuses_authentication_without_psn_fallback(self):
        self.assertEqual(lib.ctr_core_init(C.byref(self.api),b'RyuNET'),0);lib.ctr_core_set_online(0)
        state=C.c_int32();fn=core.function('sceNpGetState',C.c_int32,C.c_int32,C.POINTER(C.c_int32))
        self.assertEqual(fn(42,C.byref(state)),0);self.assertEqual(state.value,1)
        token=C.create_string_buffer(64);fn=core.function('sceNpAuthGetIdTokenA',C.c_int32,C.c_int32,C.c_void_p,C.c_void_p)
        self.assertLess(fn(1,None,token),0);self.assertEqual(token.value,b'RyuNET')
    def test_owned_profile_marker_roundtrip_and_strict_legacy_compatibility(self):
        p=Profile(b'NuevoJugador',1);text=C.create_string_buffer(128)
        n=lib.ctr_profile_format_record(C.byref(p),text,len(text));self.assertGreater(n,0)
        self.assertEqual(text.value,b'version=2\nnickname=NuevoJugador\nidentity=installation\n')
        out=Profile();self.assertEqual(lib.ctr_profile_parse_record(C.byref(out),text,n),0);self.assertEqual(bytes(out),bytes(p))
        self.assertEqual(lib.ctr_profile_publish_record(C.byref(p)),0)
        self.assertEqual(lib.ctr_profile_publish(b'OtroJugador'),0)
        self.assertEqual(lib.ctr_profile_snapshot_record(C.byref(out)),0);self.assertEqual(out.owned,1)
        for bad in (b'version=1\nnickname=Valid\nidentity=installation\n',b'version=2\nnickname=Valid\nidentity=other\n',b'version=2\nnickname=Valid\nidentity=installation\nidentity=installation\n'):
            before=bytes(out);self.assertLess(lib.ctr_profile_parse_record(C.byref(out),bad,len(bad)),0);self.assertEqual(bytes(out),before)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/profile-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'actual C nickname format and validation, deferred identity change, 16-character ABI and offline privacy gate'}))
    raise SystemExit(not result.wasSuccessful())
