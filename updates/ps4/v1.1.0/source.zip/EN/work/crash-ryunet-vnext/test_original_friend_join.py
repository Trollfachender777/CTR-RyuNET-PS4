"""Exercise the stock friend-menu NP join without a synthetic invitation."""
from pathlib import Path
import ctypes as C
import hashlib
import json
import unittest

import test_core as core
from test_settings_menu import defaults

ROOT = Path(__file__).resolve().parent
lib = core.lib
lib.ctr_sessions_json.argtypes = [C.c_char_p, C.c_int, C.c_void_p, C.c_size_t]
lib.ctr_session_queue.argtypes = [C.c_char_p]
lib.ctr_sessions_init.argtypes = [C.c_int32, C.c_void_p, C.c_void_p]
lib.ctr_sessions_ready.argtypes = [C.c_int]
lib.ctr_session_due.argtypes = []
lib.ctr_session_event.argtypes = [C.c_void_p, C.c_size_t]
ME = 'Ps4Player'
FRIEND = 'PcFriend'
OTHER = 'OtherFriend'
SID = 'cusa13795-session-' + FRIEND
OTHER_SID = 'cusa13795-session-' + OTHER


class Tests(unittest.TestCase):
    def setUp(self):
        self.api = core.Api()
        self.assertEqual(lib.ctr_core_init(C.byref(self.api), ME.encode()), 0)
        self.settings = defaults()
        for name in (FRIEND, OTHER):
            self.assertEqual(lib.ctr_settings_add(C.byref(self.settings), name.encode(), ME.encode()), 0)
        self.assertEqual(lib.ctr_settings_publish(C.byref(self.settings)), 0)
        self.now = 1000000
        self.traces = []
        self.clock = C.CFUNCTYPE(C.c_uint64)(lambda: self.now)
        self.trace = C.CFUNCTYPE(None, C.c_int32, C.c_int32)(lambda a, b: self.traces.append((a, b)))
        lib.ctr_sessions_init(123, C.cast(self.clock, C.c_void_p), C.cast(self.trace, C.c_void_p))
        lib.ctr_sessions_ready(1)

    def request(self, path, method=0, capacity=4096):
        out = C.create_string_buffer(capacity)
        n = lib.ctr_sessions_json(path.encode(), method, out, capacity)
        self.assertGreater(n, 0, (path, method, n))
        return json.loads(out.value)

    def assert_no_invitation(self):
        self.now += 5000000
        self.assertEqual(lib.ctr_session_due(), 0)
        event = C.create_string_buffer(180)
        self.assertEqual(lib.ctr_session_event(event, len(event)), 0)
        self.assertEqual(self.request('/v1/users/me/invitations')['size'], 0)

    def test_stock_webapi_join_without_queue_keeps_the_requested_host(self):
        # The original friend button does not call ctr_session_queue. Stock PC
        # accepts POST .../members and supplies metadata for that same session.
        create = core.function('sceNpWebApiCreateRequest', C.c_int32, C.c_int32, C.c_char_p,
                               C.c_char_p, C.c_int32, C.c_void_p, C.POINTER(C.c_int64))
        send = core.function('sceNpWebApiSendRequest', C.c_int32, C.c_int64, C.c_void_p, C.c_uint64)
        read = core.function('sceNpWebApiReadData', C.c_int32, C.c_int64, C.c_void_p, C.c_uint64)
        delete = core.function('sceNpWebApiDeleteRequest', C.c_int32, C.c_int64)
        for path, method in (('/v1/sessions/' + SID + '/members', 1),
                             ('/v1/sessions/' + SID, 0)):
            handle = C.c_int64()
            self.assertEqual(create(1, b'sdk:session', path.encode(), method, None, C.byref(handle)), 0)
            try:
                self.assertEqual(send(handle.value, None, 0), 0, path)
                pieces = []
                for _ in range(200):
                    buf = C.create_string_buffer(29)
                    n = read(handle.value, buf, len(buf))
                    self.assertGreaterEqual(n, 0)
                    if not n:
                        break
                    pieces.append(buf.raw[:n])
                doc = json.loads(b''.join(pieces))
                self.assertEqual(doc['sessionId'], SID)
                if method == 0:
                    self.assertEqual(doc['sessionCreator']['onlineId'], FRIEND)
                    self.assertEqual(int(doc['sessionCreator']['accountId']), core.expected_pid(FRIEND))
                    self.assertEqual([m['onlineId'] for m in doc['members']], [FRIEND, ME])
            finally:
                self.assertEqual(delete(handle.value), 0)
        self.assert_no_invitation()

    def test_metadata_is_not_membership_or_remote_discovery(self):
        doc = self.request('/v1/sessions/' + SID + '?fields=sessionCreator,members')
        self.assertEqual(doc['sessionId'], SID)
        self.assertEqual([m['onlineId'] for m in doc['members']], [FRIEND])
        self.assertEqual(self.request('/v1/users/me/friends/sessions')['sessions'], [])
        self.assertEqual(self.request('/v1/users/@users/sessions')['users'], [])
        self.assert_no_invitation()
        formatted = C.create_string_buffer(1024)
        self.assertGreater(lib.ctr_settings_format(C.byref(self.settings), formatted, len(formatted)), 0)
        snapshot = type(self.settings)()
        self.assertEqual(lib.ctr_settings_snapshot(C.byref(snapshot)), 0)
        self.assertEqual(bytes(snapshot), bytes(self.settings))

    def test_leaving_one_friend_does_not_leave_the_other_or_destroy_own_session(self):
        own = self.request('/v1/sessions', 1)['sessionId']
        self.request('/v1/sessions/' + SID + '/members', 1)
        self.request('/v1/sessions/' + SID + '/members/me', 3)
        self.assertEqual([m['onlineId'] for m in self.request('/v1/sessions/' + SID)['members']], [FRIEND])
        self.request('/v1/sessions/' + OTHER_SID + '/members', 1)
        self.request('/v1/sessions/' + SID + '/members/me', 3)
        self.assertEqual([m['onlineId'] for m in self.request('/v1/sessions/' + OTHER_SID)['members']], [OTHER, ME])
        self.assertEqual(self.request('/v1/sessions/' + own)['sessionCreator']['onlineId'], ME)
        self.assert_no_invitation()

    def test_known_contact_metadata_does_not_cancel_another_queued_join(self):
        self.assertEqual(lib.ctr_session_queue(OTHER.encode()), 0)
        self.now += 300000
        self.assertEqual(lib.ctr_session_due(), 1)
        self.request('/v1/sessions/' + SID)
        self.assertEqual(lib.ctr_session_due(), 1)
        self.request('/v1/sessions/' + SID + '/members/me', 3)
        self.assertEqual(lib.ctr_session_due(), 1)
        event = C.create_string_buffer(180)
        self.assertEqual(lib.ctr_session_event(event, len(event)), 1)
        self.assertEqual(event.raw[4:50].split(b'\0')[0].decode(), OTHER_SID)

    def test_invalid_or_small_requests_do_not_commit_membership(self):
        for path, method in ((
                '/v1/sessions/' + SID + '/members', 1),
                ('/v1/sessions/' + SID, 0)):
            guard = (C.c_ubyte * 48)(*([0xa5] * 48))
            self.assertLess(lib.ctr_sessions_json(path.encode(), method, C.byref(guard, 16), 16), 0)
            self.assertEqual(bytes(guard[:16]), b'\xa5' * 16)
            self.assertEqual(bytes(guard[32:]), b'\xa5' * 16)
        self.assertEqual([m['onlineId'] for m in self.request('/v1/sessions/' + SID)['members']], [FRIEND])
        for suffix in ('Unknown', '', '../PcFriend', 'PcFriend%22', FRIEND + '/unexpected',
                       FRIEND + '/members/other/unexpected'):
            out = C.create_string_buffer(4096)
            self.assertLess(lib.ctr_sessions_json(('/v1/sessions/cusa13795-session-' + suffix).encode(),
                                                 0, out, len(out)), 0)
        for method in (-1, 4, 255):
            out = C.create_string_buffer(4096)
            self.assertLess(lib.ctr_sessions_json(('/v1/sessions/' + SID).encode(), method, out, len(out)), 0)
        self.assert_no_invitation()

    def test_removing_contact_blocks_new_metadata_but_membership_can_be_cleaned_up(self):
        self.request('/v1/sessions/' + SID + '/members', 1)
        self.assertEqual(lib.ctr_settings_remove(C.byref(self.settings), FRIEND.encode()), 0)
        self.assertEqual(lib.ctr_settings_publish(C.byref(self.settings)), 0)
        self.request('/v1/sessions/' + SID + '/members/me', 3)
        out = C.create_string_buffer(4096)
        self.assertLess(lib.ctr_sessions_json(('/v1/sessions/' + SID).encode(), 0, out, len(out)), 0)
        self.assert_no_invitation()


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    report = {'successful': result.wasSuccessful(), 'groups': result.testsRun,
              'tested_host_dll_sha256': hashlib.sha256((ROOT / 'build/ctr_core_test.dll').read_bytes()).hexdigest(),
              'scope': 'stock friend-menu WebAPI join without custom queue; metadata, membership, contacts and invitation isolation'}
    (ROOT / 'build/original-friend-join-test-result.json').write_text(json.dumps(report, indent=2))
    raise SystemExit(not result.wasSuccessful())
