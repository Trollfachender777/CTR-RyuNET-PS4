"""Actual PS4 SELF: deferred pthread ABI, TLS policy, HTTP cleanup and no profile writes."""
import json, struct, unittest
from test_native_bridge import ModuleMachine,prepare,STUB,SCRATCH
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *

URL='https://api.github.com/repos/Trollfachender777/CTR-RyuNET-PS4/releases/latest'
def body():
    return json.dumps(dict(id=419889397,tag_name='v1.1-ps4',published_at='2026-10-25T12:00:00Z',html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/v1.1-ps4',draft=False,prerelease=False)).encode()
class UpdateMachine(ModuleMachine):
    def __init__(self,fail=None,status=200,response=None):
        super().__init__('ui_updates')
        self.calls=[];self.cleanup=[];self.tasks=[];self.policy={};self.requested=[];self.detached=[];self.offset=0
        self.response=body() if response is None else response;self.responses=None
        names=['scePthreadCreate','scePthreadAttrInit','scePthreadAttrSetdetachstate','scePthreadAttrDestroy','sceNetPoolCreate','sceNetPoolDestroy','sceSslInit','sceSslTerm','sceHttpInit','sceHttpTerm','sceHttpCreateTemplate','sceHttpDeleteTemplate','sceHttpSetResolveTimeOut','sceHttpSetConnectTimeOut','sceHttpSetSendTimeOut','sceHttpSetRecvTimeOut','sceHttpSetAutoRedirect','sceHttpsEnableOption','sceHttpCreateConnectionWithURL','sceHttpDeleteConnection','sceHttpCreateRequestWithURL','sceHttpDeleteRequest','sceHttpAddRequestHeader','sceHttpSendRequest','sceHttpGetStatusCode','sceHttpReadData']
        for i,name in enumerate(names):
            if name not in self.ui_symbols:self.ui_symbols[name]=STUB+0x800+i*16
        if fail=='missing_pthread':del self.ui_symbols['scePthreadCreate']
        self.allowed.append((SCRATCH,SCRATCH+4096))
        def text(pointer):
            value=bytearray()
            while len(value)<1024:
                c=self.uc.mem_read(pointer+len(value),1)[0]
                if not c:return value.decode()
                value.append(c)
            raise AssertionError('Unterminated argument')
        def hook(uc,address,size,user):
            name=next((n for n in names if self.ui_symbols.get(n)==address),None)
            if not name:return
            regs=[uc.reg_read(r) for r in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8)]
            a,b,c,d,e=regs;self.calls.append(name);ret=0
            if name=='scePthreadAttrInit':uc.mem_write(a,struct.pack('<Q',0x1234))
            elif name=='scePthreadAttrSetdetachstate':self.detached.append(b)
            elif name=='scePthreadCreate':
                assert struct.unpack('<Q',uc.mem_read(b,8))[0]==0x1234
                assert text(e)=='RyuNET-update'
                if fail==name:ret=7
                else:self.tasks.append((c,d));uc.mem_write(a,struct.pack('<Q',0x4567))
            elif name in ['sceNetPoolCreate','sceSslInit','sceHttpInit','sceHttpCreateTemplate','sceHttpCreateConnectionWithURL','sceHttpCreateRequestWithURL']:
                ret={'sceNetPoolCreate':601,'sceSslInit':602,'sceHttpInit':603,'sceHttpCreateTemplate':604,'sceHttpCreateConnectionWithURL':605,'sceHttpCreateRequestWithURL':606}[name]
                if name=='sceHttpCreateConnectionWithURL':self.requested.append(text(b));assert c==0
                if name=='sceHttpCreateRequestWithURL':self.requested.append(text(c));assert b==0 and d==0
            elif name.startswith('sceHttpSet') or name=='sceHttpsEnableOption':self.policy[name]=(a,b)
            elif name=='sceHttpSendRequest':
                if self.responses is not None:self.response=self.responses.pop(0);self.offset=0
            elif name=='sceHttpGetStatusCode':uc.mem_write(b,struct.pack('<i',status))
            elif name=='sceHttpReadData':
                chunk=self.response[self.offset:self.offset+c];uc.mem_write(b,chunk);ret=len(chunk);self.offset+=ret
                if fail=='total_timeout':self.now_us+=21000000
            elif name in ['sceHttpDeleteRequest','sceHttpDeleteConnection','sceHttpDeleteTemplate','sceHttpTerm','sceSslTerm','sceNetPoolDestroy']:self.cleanup.append((name,a))
            if fail==name and name!='scePthreadCreate':ret=0xffffffff
            uc.reg_write(UC_X86_REG_RAX,ret)
        self.uc.hook_add(UC_HOOK_CODE,hook,begin=STUB,end=STUB+4095)
    def start(self):return self.call(self.exports[prepare.nid('ctr_updates_start')])
    def finish(self):entry,arg=self.tasks.pop(0);return self.call(entry,arg)
    def result(self):
        self.call(self.exports[prepare.nid('ctr_updates_snapshot')],SCRATCH)
        return struct.unpack('<ii',self.uc.mem_read(SCRATCH,8))
class Tests(unittest.TestCase):
    def test_real_self_defers_http_to_detached_worker_checks_ps4_only_and_cleans_resources(self):
        m=UpdateMachine();self.assertEqual(m.initialize(),0);before=dict(m.files)
        self.assertEqual(m.calls,[]);self.assertEqual(m.start(),1);self.assertEqual(m.result()[0],1)
        self.assertEqual(m.detached,[1]);self.assertNotIn('sceHttpSendRequest',m.calls);m.finish()
        self.assertEqual(m.result()[0],3);self.assertEqual(m.requested,[URL,URL])
        self.assertEqual(m.policy['sceHttpsEnableOption'],(604,0xbd));self.assertEqual(m.policy['sceHttpSetAutoRedirect'],(604,0))
        for n in ['Resolve','Connect','Send','Recv']:self.assertEqual(m.policy['sceHttpSet'+n+'TimeOut'],(604,5000000))
        self.assertEqual([name for _,name,value,_ in m.http_headers],['Accept','X-GitHub-Api-Version','Accept-Encoding'])
        self.assertEqual(m.cleanup,[('sceHttpDeleteRequest',606),('sceHttpDeleteConnection',605),('sceHttpDeleteTemplate',604),('sceHttpTerm',603),('sceSslTerm',602),('sceNetPoolDestroy',601)])
        self.assertEqual(m.files,before)
    def test_every_allocation_and_network_failure_cleans_only_owned_resources(self):
        allocations=['sceNetPoolCreate','sceSslInit','sceHttpInit','sceHttpCreateTemplate','sceHttpCreateConnectionWithURL','sceHttpCreateRequestWithURL']
        cleanup=['sceNetPoolDestroy','sceSslTerm','sceHttpTerm','sceHttpDeleteTemplate','sceHttpDeleteConnection','sceHttpDeleteRequest']
        for failure in allocations+['sceHttpsEnableOption','sceHttpSendRequest','sceHttpReadData']:
            with self.subTest(failure=failure):
                m=UpdateMachine(failure);self.assertEqual(m.initialize(),0);m.start();m.finish();self.assertEqual(m.result()[0],4)
                owned=allocations.index(failure) if failure in allocations else 4 if failure=='sceHttpsEnableOption' else 6
                self.assertEqual([n for n,_ in m.cleanup],list(reversed(cleanup[:owned])))
    def test_missing_or_failed_thread_creation_does_not_block_or_start_http(self):
        for failure in ['missing_pthread','scePthreadCreate']:
            m=UpdateMachine(failure);self.assertEqual(m.initialize(),0);self.assertEqual(m.start()&0xffffffff,0xffffffff)
            self.assertEqual(m.result()[0],7);self.assertFalse(m.tasks);self.assertNotIn('sceNetPoolCreate',m.calls)
    def test_rate_limit_invalid_payload_and_total_deadline_leave_no_false_update(self):
        for fail,status,response,expected in [(None,403,b'',5),(None,200,b'broken',6),('total_timeout',200,b'x'*1024,4),(None,200,b'x'*65537,4)]:
            m=UpdateMachine(fail,status,response);self.assertEqual(m.initialize(),0);m.start();m.finish()
            self.assertEqual(m.result()[0],expected);self.assertEqual(len(m.cleanup),6)
if __name__=='__main__':unittest.main(verbosity=2)
