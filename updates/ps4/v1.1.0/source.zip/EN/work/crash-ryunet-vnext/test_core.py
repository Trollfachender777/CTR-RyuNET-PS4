"""Execute the actual freestanding port core on Windows with native API mocks."""
from pathlib import Path
import ctypes as C
import hashlib,json,unittest

ROOT=Path(__file__).resolve().parent
lib=C.CDLL(str(ROOT/'build/ctr_core_test.dll'))
lib.ctr_find_hook.argtypes=[C.c_char_p];lib.ctr_find_hook.restype=C.c_void_p
lib.ctr_pid_for_name.argtypes=[C.c_char_p];lib.ctr_pid_for_name.restype=C.c_uint64
lib.ctr_rewrite_url.argtypes=[C.c_char_p,C.c_void_p,C.c_size_t];lib.ctr_rewrite_url.restype=C.c_int32
lib.ctr_core_init.argtypes=[C.c_void_p,C.c_char_p];lib.ctr_core_init.restype=C.c_int32

class Api(C.Structure):
    _fields_=[(n,C.c_void_p) for n in ('resolve','http_connection','http_request','http_request2','http_status','sysmodule_load','refresh_modules','trace')]

def function(name,result,*args):
    address=lib.ctr_find_hook(name.encode())
    assert address,name
    return C.CFUNCTYPE(result,*args)(address)

def expected_pid(name):
    b=name.lower().encode();fnv=14695981039346656037
    for value in b:fnv=((fnv^value)*1099511628211)&((1<<64)-1)
    return 1810000000+((int.from_bytes(hashlib.sha256(b).digest()[:8],'little')^fnv)%80000000)

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api=Api()
        assert lib.ctr_core_init(C.byref(cls.api),b'DemoPlayerPS4001')==0
    def test_identity_matches_existing_pc_account(self):
        for name in ('DemoPlayerPS4001','RyUnEt','Player_2','a'):
            self.assertEqual(lib.ctr_pid_for_name(name.encode()),expected_pid(name))
        self.assertEqual(lib.ctr_pid_for_name(b'DemoPlayerPS4001'),1886534036)
    def test_invalid_names_fail_without_changing_identity(self):
        for name in (b'',b'x'*17,b'bad/name',b'bad"name',b'name with spaces'):
            self.assertLess(lib.ctr_core_init(C.byref(self.api),name),0)
        account=C.c_uint64()
        fn=function('sceNpGetAccountIdA',C.c_int32,C.c_int32,C.POINTER(C.c_uint64))
        self.assertEqual(fn(0x12345678,C.byref(account)),0)
        self.assertEqual(account.value,1886534036)
    def test_native_user_id_and_callback_once(self):
        state=C.c_int32();user=0x12345678
        get=function('sceNpGetState',C.c_int32,C.c_int32,C.POINTER(C.c_int32))
        self.assertEqual(get(user,C.byref(state)),0);self.assertEqual(state.value,2)
        events=[]
        cb=C.CFUNCTYPE(None,C.c_int32,C.c_int32,C.c_void_p)(lambda u,s,a:events.append((u,s,a)))
        register=function('sceNpRegisterStateCallbackForToolkit',C.c_int32,C.c_void_p,C.c_void_p)
        check=function('sceNpCheckCallbackForLib',C.c_int32)
        unregister=function('sceNpUnregisterStateCallbackForToolkit',C.c_int32,C.c_void_p,C.c_void_p)
        self.assertEqual(register(cb,C.c_void_p(123)),0)
        check();check();self.assertEqual(events,[(user,2,123)])
        unregister(cb,C.c_void_p(123));check();self.assertEqual(len(events),1)
    def test_guest_buffers_do_not_overwrite_canaries(self):
        for symbol,size,args in (
            ('sceNpGetOnlineId',20,(C.c_int32,C.c_void_p)),
            ('sceNpGetNpId',36,(C.c_int32,C.c_void_p)),
        ):
            data=(C.c_ubyte*(size+32))(*([0xa5]*(size+32)))
            fn=function(symbol,C.c_int32,*args)
            self.assertEqual(fn(0x12345678,C.byref(data,16)),0)
            self.assertEqual(bytes(data[:16]),b'\xa5'*16)
            self.assertEqual(bytes(data[-16:]),b'\xa5'*16)
        data=(C.c_ubyte*65)(*([0xa5]*65))
        fn=function('sceNpCheckPlus',C.c_int32,C.c_int32,C.c_void_p,C.c_void_p)
        self.assertEqual(fn(1,None,C.byref(data,16)),0)
        self.assertEqual(bytes(data[:16]),b'\xa5'*16);self.assertEqual(bytes(data[-16:]),b'\xa5'*16)
    def test_only_configured_community_hosts_redirect(self):
        vectors={
          b'https://lavender-ps4-auth3.prod.demonware.net:443/auth/?x=1':b'http://octr.ryu7w7.xyz:8080/auth/?x=1',
          b'https://prod.umbrella.demonware.net':b'http://octr.ryu7w7.xyz:8080/',
          b'https://objectstore.prod.demonware.net/a?b=c':b'http://octr.ryu7w7.xyz:8080/a?b=c',
        }
        for url,expected in vectors.items():
            out=C.create_string_buffer(4096)
            self.assertEqual(lib.ctr_rewrite_url(url,out,len(out)),1);self.assertEqual(out.value,expected)
        for url in (b'https://example.com/a',b'https://lavender-ps4-auth3.prod.demonware.net.example.com/a',b'/local/path'):
            out=C.create_string_buffer(b'unchanged',64)
            self.assertEqual(lib.ctr_rewrite_url(url,out,len(out)),0);self.assertEqual(out.value,b'unchanged')
        out=C.create_string_buffer(8)
        self.assertLess(lib.ctr_rewrite_url(next(iter(vectors)),out,len(out)),0)
    def test_request_pool_limits_partial_reads_and_reuse(self):
        create=function('sceNpWebApiCreateRequest',C.c_int32,C.c_int32,C.c_char_p,C.c_char_p,C.c_int32,C.c_void_p,C.POINTER(C.c_int64))
        send=function('sceNpWebApiSendRequest',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        read=function('sceNpWebApiReadData',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        delete=function('sceNpWebApiDeleteRequest',C.c_int32,C.c_int64)
        handles=[]
        for _ in range(32):
            value=C.c_int64();self.assertEqual(create(1,b'userProfile',b'/friendList',0,None,C.byref(value)),0);handles.append(value.value)
        extra=C.c_int64();self.assertLess(create(1,b'g',b'/p',0,None,C.byref(extra)),0)
        self.assertEqual(extra.value,-1);self.assertEqual(len(set(handles)),32)
        self.assertEqual(send(handles[0],None,0),0)
        chunks=[]
        for _ in range(100):
            buffer=C.create_string_buffer(7);n=read(handles[0],buffer,7)
            self.assertGreaterEqual(n,0)
            if n==0:break
            chunks.append(buffer.raw[:n])
        document=json.loads(b''.join(chunks));self.assertEqual(document['totalResults'],0)
        for handle in handles:self.assertEqual(delete(handle),0)
        again=C.c_int64();self.assertEqual(create(1,b'g',b'/p',0,None,C.byref(again)),0);delete(again.value)
        self.assertLess(read(-999,None,0),0)
    def test_http_failure_propagates_without_an_original_function(self):
        fn=function('sceHttpCreateConnectionWithURL',C.c_int32,C.c_int32,C.c_char_p,C.c_int32)
        self.assertLess(fn(1,b'https://prod.umbrella.demonware.net',1),0)
    def test_all_selected_network_imports_have_native_adapters(self):
        profiles=json.loads((ROOT/'build/native-profiles.json').read_text())
        for profile in profiles:
            for record in profile['records']:
                if record['name'] not in ('sceUserServiceGetInitialUser','sceNetCtlInit'):
                    self.assertTrue(lib.ctr_find_hook(record['name'].encode()),record['name'])
    def test_profile_response_and_http_status_use_native_contract(self):
        class Response(C.Structure):
            _fields_=[('status',C.c_int32),('error',C.c_void_p),('error_size',C.c_uint64),('data_size',C.c_uint64)]
        self.assertEqual(C.sizeof(Response),32)
        create=function('sceNpWebApiCreateRequest',C.c_int32,C.c_int32,C.c_char_p,C.c_char_p,C.c_int32,C.c_void_p,C.POINTER(C.c_int64))
        send=function('sceNpWebApiSendRequest2',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64,C.POINTER(Response))
        read=function('sceNpWebApiReadData',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        delete=function('sceNpWebApiDeleteRequest',C.c_int32,C.c_int64)
        handle=C.c_int64();self.assertEqual(create(1,b'userProfile',b'/v1/profiles',0,None,C.byref(handle)),0)
        response=Response();self.assertEqual(send(handle.value,None,0,C.byref(response)),0)
        self.assertEqual((response.status,response.error,response.error_size),(200,None,0))
        buffer=C.create_string_buffer(response.data_size+1);self.assertEqual(read(handle.value,buffer,len(buffer)),response.data_size)
        document=json.loads(buffer.value);self.assertEqual(document['profiles'][0]['onlineId'],'DemoPlayerPS4001')
        self.assertEqual(document['profiles'][0]['accountId'],'1886534036');delete(handle.value)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/core-test-result.json').write_text(json.dumps({'run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'successful':result.wasSuccessful(),'scope':'actual freestanding C core; mocked native APIs; not a console or online session test'},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
