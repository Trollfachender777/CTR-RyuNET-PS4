"""Ownership protocol, cryptography and failure-safe per-install persistence."""
from pathlib import Path
import ctypes as C,hashlib,hmac,json,os,unittest
import test_core as core
lib=core.lib;ROOT=Path(__file__).resolve().parent
Read=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_void_p,C.c_size_t)
Write=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_char_p,C.c_void_p,C.c_size_t,C.c_int)
Random=C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_size_t)
class Io(C.Structure):_fields_=[('read',Read),('write',Write),('random',Random)]
lib.ctr_identity_parse.argtypes=[C.c_void_p,C.c_char_p,C.c_size_t]
lib.ctr_identity_derive.argtypes=[C.c_void_p,C.c_void_p]
lib.ctr_identity_prepare.argtypes=[C.POINTER(Io),C.c_int]
lib.ctr_identity_activate.argtypes=[C.POINTER(Io),C.c_int]
lib.ctr_identity_header.argtypes=[C.c_char_p];lib.ctr_identity_header.restype=C.c_char_p
PRIMARY=b'/data/ryunet/identity.key';BACKUP=PRIMARY+b'.bak'
ROOT_URL=b'http://octr.ryu7w7.xyz:8080'
class Disk:
    def __init__(self,files=None,fail=None,random_failure=False):
        self.files=dict(files or {});self.fail=fail;self.generated=0;self.writes=[]
        def read(path,out,size):
            if path not in self.files:return -2
            value=self.files[path][:size];C.memmove(out,value,len(value));return len(value)
        def write(path,temp,data,size,mode):
            self.writes.append((path,mode))
            if self.fail==path:return -1
            self.files[path]=C.string_at(data,size);return 0
        def random(out,size):
            self.generated+=1
            if random_failure:return -1
            C.memmove(out,os.urandom(size),size);return 0
        self.io=Io(Read(read),Write(write),Random(random))
class Tests(unittest.TestCase):
    def setUp(self):self.assertEqual(lib.ctr_identity_activate(None,0),0)
    def test_hmac_matches_official_pc_server_key_for_distinct_installations(self):
        for key in (bytes(range(32)),bytes([0x0b])*32,os.urandom(32),bytes([0xff])*32):
            out=C.create_string_buffer(65);self.assertEqual(lib.ctr_identity_derive(key,out),0)
            self.assertEqual(out.value,hmac.new(key,b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest().encode())
    def test_key_validation_is_bounded_and_does_not_partially_publish(self):
        key=bytes(range(32)).hex().encode();out=C.create_string_buffer(b'X'*32,32)
        for text in (key,key.upper(),key+b'\n'):
            self.assertEqual(lib.ctr_identity_parse(out,text,len(text)),0);self.assertEqual(out.raw,bytes(range(32)))
        for text in (b'',b'0'*64,key[:-1],key+b'\r\n',key+b'\0',b'g'+key[1:],key+b'\nextra'):
            before=out.raw;self.assertLess(lib.ctr_identity_parse(out,text,len(text)),0);self.assertEqual(out.raw,before)
    def test_fresh_consoles_create_different_keys_once_and_keep_them_across_restarts(self):
        a,b=Disk(),Disk()
        for disk in (a,b):
            self.assertEqual(lib.ctr_identity_prepare(C.byref(disk.io),1),0)
            self.assertEqual(disk.generated,1);self.assertEqual(disk.files[PRIMARY],disk.files[BACKUP])
            self.assertTrue(all(mode==0o600 for _,mode in disk.writes))
            self.assertEqual(lib.ctr_identity_prepare(C.byref(disk.io),1),0);self.assertEqual(disk.generated,1)
        self.assertNotEqual(a.files[PRIMARY],b.files[PRIMARY])
        self.assertEqual(lib.ctr_identity_activate(C.byref(a.io),1),0);value=lib.ctr_identity_header(ROOT_URL)
        self.assertEqual(lib.ctr_identity_activate(C.byref(a.io),1),0);self.assertEqual(lib.ctr_identity_header(ROOT_URL),value)
    def test_secret_only_attached_to_exact_canonical_community_authority(self):
        disk=Disk({PRIMARY:bytes(range(32)).hex().encode()})
        self.assertEqual(lib.ctr_identity_activate(C.byref(disk.io),1),0)
        for url in (ROOT_URL,ROOT_URL+b'/',ROOT_URL+b'/auth/',ROOT_URL+b'?x=1'):self.assertIsNotNone(lib.ctr_identity_header(url))
        for url in (None,b'',b'https://octr.ryu7w7.xyz:8080/auth',b'http://sony.com',ROOT_URL+b'.evil/auth',ROOT_URL+b'@evil/auth',ROOT_URL+b'0/auth',b'http://octr.ryu7w7.xyz:80/auth',b'http://octr.ryu7w7.xyz.evil:8080/auth'):
            self.assertIsNone(lib.ctr_identity_header(url))
    def test_legacy_profile_ignores_orphan_key_from_interrupted_migration(self):
        disk=Disk();self.assertEqual(lib.ctr_identity_prepare(C.byref(disk.io),1),0)
        self.assertEqual(lib.ctr_identity_activate(C.byref(disk.io),0),0);self.assertIsNone(lib.ctr_identity_header(ROOT_URL))
        self.assertEqual(lib.ctr_identity_prepare(C.byref(disk.io),1),0);self.assertEqual(disk.generated,1)
    def test_owned_profile_with_lost_or_corrupt_key_never_silently_regenerates(self):
        for files in ({},{PRIMARY:b'broken'},{PRIMARY:b'0'*64,BACKUP:b'bad'}):
            disk=Disk(files);self.assertLess(lib.ctr_identity_activate(C.byref(disk.io),1),0)
            self.assertLess(lib.ctr_identity_prepare(C.byref(disk.io),0),0)
            self.assertEqual(disk.generated,0);self.assertEqual(disk.files,files);self.assertIsNone(lib.ctr_identity_header(ROOT_URL))
    def test_backup_recovers_original_key_and_does_not_change_owned_identity(self):
        key=bytes(range(32)).hex().encode();disk=Disk({PRIMARY:b'broken',BACKUP:key})
        self.assertEqual(lib.ctr_identity_activate(C.byref(disk.io),1),0)
        self.assertEqual(lib.ctr_identity_header(ROOT_URL),hmac.new(bytes(range(32)),b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest().encode())
        self.assertEqual(lib.ctr_identity_prepare(C.byref(disk.io),0),0);self.assertEqual(disk.generated,0)
    def test_rng_and_atomic_key_write_failures_never_report_success(self):
        for disk in (Disk(random_failure=True),Disk(fail=BACKUP),Disk(fail=PRIMARY)):
            self.assertLess(lib.ctr_identity_prepare(C.byref(disk.io),1),0)
            self.assertIsNone(lib.ctr_identity_header(ROOT_URL))
        disk=Disk(fail=PRIMARY);self.assertLess(lib.ctr_identity_prepare(C.byref(disk.io),1),0)
        key=disk.files[BACKUP];disk.fail=None
        self.assertEqual(lib.ctr_identity_prepare(C.byref(disk.io),1),0);self.assertEqual(disk.generated,1);self.assertEqual(disk.files[BACKUP],key)
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/installation-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'groups':result.testsRun,'scope':'actual C HMAC protocol, persistent independent secrets, exact HTTP authority scope, corruption and interrupted migration'},indent=2))
    raise SystemExit(not result.wasSuccessful())
