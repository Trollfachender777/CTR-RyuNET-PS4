"""Verify physical SELF modules despite GoldHEN's automatic RETR decryption."""
from pathlib import Path
import struct,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/'outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts'))
import prepare
SELF_MAGIC=bytes.fromhex('4f153d1d')
def require_self(data):
    if data[:4]!=SELF_MAGIC:raise ValueError('A decrypted ELF is not an installable PS4 SELF module')
    prepare.parse_self(data)
    return data
def normalize_elf(data):
    if data[:4]!=b'\x7fELF':raise ValueError('ELF view expected')
    out=bytearray(data)
    struct.pack_into('<Q',out,40,0)
    struct.pack_into('<HHH',out,58,0,0,0)
    return bytes(out)
def decrypted_view(data):
    require_self(data)
    elf,*_=prepare.parse_self(data)
    return normalize_elf(elf)
def matches_readback(self_data,download):
    require_self(self_data)
    if download==self_data:return True
    if download[:4]!=b'\x7fELF':return False
    return normalize_elf(download)==decrypted_view(self_data)
def stored_size(ftp,path):
    rows=[];ftp.retrlines('LIST '+path,rows.append)
    rows=[row.split(None,8) for row in rows if len(row.split(None,8))==9 and row.startswith('-')]
    if len(rows)!=1:raise ValueError('Expected exactly one module file')
    return int(rows[0][4])
