"""Use the exact NP Toolkit friend request, including its profile-photo query."""
from pathlib import Path
import ctypes as C
import hashlib
import json
import re
import unittest
import test_core as core
from test_settings_menu import defaults

ROOT=Path(__file__).resolve().parent
lib=core.lib
lib.ctr_friends_json.argtypes=[C.c_char_p,C.c_void_p,C.c_size_t]
profile=json.loads((ROOT/'build/native-profiles.json').read_text())[1]
# Public route fixture extracted from the supported toolkit. Source-only host
# checks work without game binaries; an integration build also checks its bytes.
TOOLKIT_ROUTE=b'/v1/users/%lu/friendList?friendStatus=friend&fields=onlineId,region,avatarUrl,personalDetail,personalDetail.displayName,isOfficiallyVerified&avatarSize=l&profilePictureSizes=xl&presenceType=incontext&presenceDetail=true&limit=%d&offset=%d'
image_path=(ROOT/profile['elf']).resolve()
if image_path.is_file():
    image=image_path.read_bytes()
    assert hashlib.sha256(image).hexdigest()==profile['native_elf_sha256']
    assert TOOLKIT_ROUTE==next(value for value in re.findall(rb'[\x20-\x7e]{6,}',image)
                             if value.startswith(b'/v1/users/%lu/friendList?'))
TOOLKIT_ROUTE=TOOLKIT_ROUTE.replace(b'%lu',str(core.expected_pid('LocalTester')).encode()).replace(b'%d',b'500',1).replace(b'%d',b'0',1)

class Tests(unittest.TestCase):
    def setUp(self):
        self.api=core.Api();self.assertEqual(lib.ctr_core_init(C.byref(self.api),b'LocalTester'),0)
        s=defaults()
        for name in (b'FirstFriend',b'OtherFriend'):self.assertEqual(lib.ctr_settings_add(C.byref(s),name,b'LocalTester'),0)
        self.assertEqual(lib.ctr_settings_publish(C.byref(s)),0)
    def doc(self,route):
        out=C.create_string_buffer(32768);size=lib.ctr_friends_json(route,out,len(out))
        self.assertGreater(size,0,route);return json.loads(out.value)
    def test_exact_toolkit_request_returns_friends_with_original_presence_contract(self):
        doc=self.doc(TOOLKIT_ROUTE)
        self.assertIn('friendList',doc);self.assertNotIn('profiles',doc)
        self.assertEqual([friend['onlineId'] for friend in doc['friendList']],['FirstFriend','OtherFriend'])
        for friend in doc['friendList']:
            self.assertEqual(int(friend['accountId']),core.expected_pid(friend['onlineId']))
            self.assertEqual(friend['presence']['onlineStatus'],'online')
            self.assertEqual(friend['presence']['incontextInfoList'][0]['gameTitleInfo']['npTitleId'],'CUSA13795_00')
        # Names/presence here are the existing local NP compatibility layer.
        # Demonware still determines actual room availability; this test does
        # not claim these two synthetic contacts are connected to the server.
    def test_query_and_fragment_words_cannot_change_route(self):
        for route,key in ((b'/v1/friendList?profilePictureSizes=xl','friendList'),
                          (b'/v1/users/me/friends?fields=profile,presence','friendList'),
                          (b'/v1/profiles?fields=friends,friendOnlineIdLists,sessions','profiles'),
                          (b'/friendOnlineIdLists?profilePictureSizes=xl','friendOnlineIdLists'),
                          (b'/v1/friendList#profiles/sessions','friendList')):
            self.assertIn(key,self.doc(route),route)
        for route in (b'/v1/other?fields=profiles,friends',b'/v1/profilePictureSizes',b'/v1/friendListSuffix',b'/friends/sessions?profilePictureSizes=xl'):
            out=C.create_string_buffer(b'unchanged',80)
            self.assertEqual(lib.ctr_friends_json(route,out,len(out)),0,route)
            self.assertEqual(out.value,b'unchanged')
    def test_actual_np_webapi_delivers_complete_friend_list_in_partial_reads(self):
        create=core.function('sceNpWebApiCreateRequest',C.c_int32,C.c_int32,C.c_char_p,C.c_char_p,C.c_int32,C.c_void_p,C.POINTER(C.c_int64))
        send=core.function('sceNpWebApiSendRequest',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        read=core.function('sceNpWebApiReadData',C.c_int32,C.c_int64,C.c_void_p,C.c_uint64)
        delete=core.function('sceNpWebApiDeleteRequest',C.c_int32,C.c_int64)
        handle=C.c_int64();self.assertEqual(create(1,b'userProfile',TOOLKIT_ROUTE,0,None,C.byref(handle)),0)
        try:
            self.assertEqual(send(handle.value,None,0),0);chunks=[]
            for _ in range(1000):
                out=C.create_string_buffer(37);n=read(handle.value,out,37)
                self.assertGreaterEqual(n,0)
                if not n:break
                chunks.append(out.raw[:n])
            else:self.fail('Friend response never reached EOF')
            doc=json.loads(b''.join(chunks));self.assertIn('friendList',doc)
            self.assertEqual(doc['size'],2);self.assertEqual(len(doc['friendList']),2)
        finally:self.assertEqual(delete(handle.value),0)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/friend-routes-test-result.json').write_text(json.dumps({'groups':result.testsRun,'successful':result.wasSuccessful(),
        'failures':len(result.failures),'errors':len(result.errors),'toolkit_image_sha256':profile['native_elf_sha256'],
        'scope':'exact shipped toolkit request and actual native WebAPI implementation; no live remote presence claimed'},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
