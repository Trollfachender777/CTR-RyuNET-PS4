# Set these two folders to your own toolchain locations before building.
$env:CTR_LLVM_BIN = 'C:\PS4Dev\llvm\bin'
$env:OO_PS4_TOOLCHAIN = 'C:\PS4Dev\OpenOrbis\PS4Toolchain'
# Optional for integration/package only; use your own compatible dump.
# $env:CTR_GAME_DIR = 'D:\MyGames\CUSA13795-1.21'
