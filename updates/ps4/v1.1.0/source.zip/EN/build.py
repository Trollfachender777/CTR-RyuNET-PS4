"""Portable entry point. Builds locally; never connects to a console."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys

ROOT=Path(__file__).resolve().parent
CURRENT=ROOT/'work/crash-ryunet-vnext'
INTEGRATION=ROOT/'work/crash-ryunet-port'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('task',choices=['module','check','integration','package'])
parser.add_argument('--game',type=Path,help='Your own compatible decrypted CUSA13795 1.21 dump')
parser.add_argument('--native-tests',action='store_true',help='Also emulate the SELF; requires locally generated integration ELF files')
args=parser.parse_args()
if os.name!='nt':parser.error('These build commands target Windows; the native module itself targets PS4.')
env=os.environ.copy()

def progress(completed):
    if env.get('CTR_BUILD_PROGRESS')=='1':
        print('CTR_PROGRESS|code|'+str(completed)+'|8',flush=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(script):
    subprocess.run([sys.executable,str(script)],check=True,cwd=ROOT,env=env)
def powershell(script,*switches):
    shell=shutil.which('pwsh')
    if not shell:raise SystemExit('PowerShell 7 (pwsh) is required for the package builder')
    subprocess.run([shell,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),*switches],check=True,cwd=ROOT,env=env)
def module():
    run(CURRENT/'build_native_module.py')
def host():
    if not (CURRENT/'build/ctr_online.prx').exists():module()
    run(CURRENT/'build_host.py')
    run(CURRENT/'build_network_reference.py')
    run(CURRENT/'validate_network_host.py')
    subprocess.run([sys.executable,'-m','unittest','test_updates','test_updater'],check=True,cwd=CURRENT,env=env)
def native():
    profiles=json.loads((CURRENT/'build/native-profiles.json').read_text())
    if not all((CURRENT/p['elf']).is_file() for p in profiles):
        raise SystemExit('First run: python build.py integration --game <your own dump folder>')
    run(CURRENT/'test_native_bridge.py')
    run(CURRENT/'test_user_isolation.py')
    run(CURRENT/'test_native_updater.py')
def integration():
    game=args.game or (Path(env['CTR_GAME_DIR']) if env.get('CTR_GAME_DIR') else None)
    if game is None:parser.error('--game is required for integration and package')
    game=game.resolve()
    if not (game/'eboot.bin').is_file() or not (game/'sce_module/libSceNpToolkit2.prx').is_file():
        parser.error('--game must contain eboot.bin and sce_module/libSceNpToolkit2.prx')
    env['CTR_GAME_DIR']=str(game)
    # No build operation writes into the original dump.
    run(INTEGRATION/'prepare_images.py')
    progress(1)
    proof=json.loads((ROOT/'source-release.json').read_text())
    profiles=json.loads((INTEGRATION/'build/native-profiles.json').read_text())
    for p in profiles:
        assert p['native_elf_sha256']==proof['integrated_elf_sha256'][p['file']], 'Integration differs from the documented revision'
        p['elf']='../crash-ryunet-port/build/'+Path(p['elf']).name
    (CURRENT/'build/native-profiles.json').write_text(json.dumps(profiles,indent=2))
    # The production profile header stays exact; regenerated tables must match.
    assert sha(INTEGRATION/'src/native_profiles.h')==proof['native_sources_exact']['native_profiles.h']
    run(CURRENT/'generate_ui_profile.py')
    run(CURRENT/'generate_network_profile.py')
    for name in ('ui_profile.h','network_profile.h'):
        assert sha(CURRENT/'src'/name)==proof['native_sources_exact'][name],name
    progress(2)
    run(INTEGRATION/'wrap_native_self.py')
    run(INTEGRATION/'test_self_wrapper.py')
    run(INTEGRATION/'prepare_external_module.py')
    run(INTEGRATION/'test_bootstrap.py')
    progress(3)
    module()
    progress(4)
    native()
    progress(5)

if args.task=='module':module()
elif args.task=='check':
    host()
    if args.native_tests:module();native()
else:
    integration()
    if args.task=='package':
        host()
        progress(6)
        powershell(INTEGRATION/'test_package_crypto.ps1')
        progress(7)
        shutil.copy2(CURRENT/'build/ctr_online.prx',INTEGRATION/'build/ctr_online.prx')
        run(INTEGRATION/'stage_package.py')
        progress(8)
        powershell(INTEGRATION/'build_package.ps1')
        run_identity=[sys.executable,str(INTEGRATION/'verify_package_identity.py'),str(INTEGRATION/'build/CTR Nitro-Fueled Online - RyuNET.pkg')]
        subprocess.run(run_identity,check=True,cwd=ROOT,env=env)
print('Completed local build task:',args.task)
