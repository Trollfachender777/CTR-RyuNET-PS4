Profiles are not copied. First launch creates a new identity per local user. Choose your nickname in the game and restart it. Do not add keys, profiles, contacts or saves to the builder.
