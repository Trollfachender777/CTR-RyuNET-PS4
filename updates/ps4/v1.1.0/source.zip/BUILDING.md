# Corresponding source for RyuNET PS4 v1.1.0

ES/ and EN/ contain the exact corresponding source, license notices, bootstrap
SDK source and build scripts from the two v1.1.0 builders. No game assets,
compiled game executables, user profiles, credentials or private keys are included.

To compile the PS4 module on 64-bit Windows without game data:

1. Install the LLVM and OpenOrbis versions identified in source-release.json.
2. Set CTR_LLVM_BIN to your LLVM bin directory and OO_PS4_TOOLCHAIN to your
   OpenOrbis directory. Python 3.11+ is required for the build scripts.
3. From ES/ or EN/, run: python build.py module
4. The module is written to work/crash-ryunet-vnext/build/ctr_online.prx.

This builds only the port module. Integration tests or full game PKGs require
the player's own compatible CUSA13795 update 1.21 assets, as documented by the
builders. Check source-release.json for exact source and module hashes.

See docs/CREDITOS.md and licenses/ in each source tree for the original projects,
tools and notices. This is an independent community adaptation.
