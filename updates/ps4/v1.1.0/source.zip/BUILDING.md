# Corresponding source for RyuNET PS4 v1.1.0 (permissions-r2)

ES/ and EN/ contain the exact source, build scripts and license notices.
Set CTR_LLVM_BIN and OO_PS4_TOOLCHAIN to the dependencies in source-release.json.
From ES/ or EN/, run: python build.py module

The module is written to work/crash-ryunet-vnext/build/ctr_online.prx.
This builds the port module without game data. No game assets or identities are included.
The permission regression tests cover new and reused temporary files, umask,
fchmod failure and atomic rollback. Game integration requires your own compatible assets.
