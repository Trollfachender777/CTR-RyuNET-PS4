"""Emulate the actual PS4 module, including its native ABI and relocations."""
from pathlib import Path
import sys,struct,json,unittest,hashlib,hmac
ROOT=Path(__file__).resolve().parent;TOOLS=ROOT.parent/'ps4-online'
sys.path.insert(0,str(TOOLS/'test-libs'))
sys.path.insert(0,str(ROOT.parent.parent/'outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts'))
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_INSN,UC_HOOK_MEM_WRITE
from unicorn.x86_const import *
import prepare
P=json.loads((ROOT/'build/native-profiles.json').read_text())
for profile in P:profile['elf']=str((ROOT/profile['elf']).resolve())
UI=json.loads((ROOT/'build/ui-profile.json').read_text())
NET=json.loads((ROOT/'build/network-profile.json').read_text())
NET_HOOKS={'sceNetBind','sceNetSendto','sceNetRecvfrom','sceNetSocketClose'}
SELF_BASE=0x2000000000;STACK=0x6000000000;STUB=0x7000000000;SCRATCH=0x7100000000

class ModuleMachine:
    def __init__(self,case):
        self.uc=Uc(UC_ARCH_X86,UC_MODE_64);self.pages=set();self.allowed=[];self.case=case;self.include_toolkit=case!='late_toolkit';self.exports={};self.infos={};self.cache_writes=[]
        self.ui_writes=[];self.protect_calls=[];self.opened_dialogs=0;self.flips=[];self.rates=[];self.config_position=0
        self.dialogs_loaded=case not in ('ui_late_dialogs','ui_load_modules');self.dialog_status=0;self.loaded_modules=[];self.now_us=1000000;self.sleep_calls=[];self.gnm_calls=[]
        self.dialog_chosen=1;self.ime_state=0;self.ime_endstatus=0;self.ime_result_calls=0;self.ime_term_calls=0
        self.system_status_data=bytes(12);self.system_status_result=0;self.system_event_result=0x80a10004;self.system_event_data=struct.pack('<I',0x10000000)+b'R'*176
        self.ui_symbols={name:STUB+0x200+i*16 for i,name in enumerate(('sceMsgDialogInitialize','sceMsgDialogOpen','sceMsgDialogGetStatus','sceMsgDialogUpdateStatus','sceMsgDialogGetResult','sceMsgDialogTerminate','sceImeDialogInit','sceImeDialogGetStatus','sceImeDialogGetResult','sceImeDialogTerm','sceKernelIsNeoMode','scePadReadState','sceVideoOutSetFlipRate','sceVideoOutSubmitFlip','sceCommonDialogInitialize','sceKernelGetProcessTime','sceKernelUsleep','sceGnmSubmitAndFlipCommandBuffers','sceGnmSubmitAndFlipCommandBuffersForWorkload','sceGnmRequestFlipAndSubmitDone','sceGnmRequestFlipAndSubmitDoneForWorkload'))}
        self.ui_symbols['sceImeDialogAbort']=STUB+0x450
        self.ui_symbols['sceSystemServiceGetStatus']=STUB+0x460
        self.ui_symbols['sceSystemServiceReceiveEvent']=STUB+0x470
        self.ui_symbols['sceUserServiceGetUserName']=STUB+0x480
        self.ui_symbols['sceKernelQueryMemoryProtection']=STUB+0x490
        self.ui_symbols['sceRandomGetRandomNumber']=STUB+0x4a0
        self.ui_symbols['sceHttpAddRequestHeader']=STUB+0x4b0
        self.ui_symbols['sceHttpDeleteRequest']=STUB+0x4c0
        self.ui_symbols['sceHttpCreateRequestWithURL']=STUB+0x4d0
        self.ui_symbols['sceHttpCreateRequestWithURL2']=STUB+0x4e0
        self.random_calls=0;self.http_headers=[];self.http_deleted=[];self.http_created=[]
        self.network_symbols={name:STUB+0x600+i*16 for i,name in enumerate(('sceNetBind','sceNetSendto','sceNetRecvfrom','sceNetSocketClose','sceNetGetsockopt','sceNetErrnoLoc'))}
        self.network_sends=[];self.network_incoming=[];self.network_writes=[]
        if case.startswith('ui_network') and case!='ui_network_missing':self.ui_symbols.update(self.network_symbols)
        self.query_count=0
        self.query_result=-1 if case=='ui_render_query_fail' else 0
        self.query_first=SCRATCH;self.query_last=SCRATCH+4096;self.query_permission=1
        if case=='ui_render_range':self.query_last=SCRATCH+1024
        if case=='ui_render_permission':self.query_permission=0
        self.original_username_calls=0
        self.config=b'version=1\nfps=30\nmotion_blur=0\npro_1080=1\nfriends=PcFriend\n'
        self.files={'/data/ryunet/users/12345678/profile.ini':b'version=1\nnickname=DemoPlayerPS4001\n'}
        if case=='ui_profile_alias':self.files['/data/ryunet/users/12345678/profile.ini']=b'version=1\nnickname=AliasPrivado_123\n'
        if case=='ui_profile_missing':self.files.clear()
        if case=='ui_profile_corrupt':self.files['/data/ryunet/users/12345678/profile.ini']=b'version=1\nnickname=bad/name\n'
        if case=='ui_profile_backup':
            self.files['/data/ryunet/users/12345678/profile.ini']=b'broken'
            self.files['/data/ryunet/users/12345678/profile.ini.bak']=b'version=1\nnickname=AliasPrivado_123\n'
        if case in ('ui_graphics','ui_bad_patch'):self.files['/data/ryunet/users/12345678/settings.ini']=self.config
        if case.startswith('ui_performance'):
            self.files['/data/ryunet/users/12345678/settings.ini']=b'version=1\nfps=60\nmotion_blur=1\npro_1080=1\nperformance=1\nfriends=PcFriend,OtherFriend\n'
        if case.startswith('ui_quality'):
            self.files['/data/ryunet/users/12345678/settings.ini']=b'version=1\nfps=30\nmotion_blur=1\npro_1080=1\nperformance=1\nlight_effects=1\nlow_quality=1\nno_shadows='+ (b'1' if case in ('ui_quality_combined','ui_quality_protect_failure') else b'0')+b'\nfriends=PcFriend,OtherFriend\n'
        if case.startswith('ui_shadows'):
            self.files['/data/ryunet/users/12345678/settings.ini']=b'version=1\nfps=60\nmotion_blur=1\npro_1080=0\nperformance=0\nlight_effects=1\nlow_quality=0\nno_shadows=1\nfriends=PcFriend,OtherFriend\n'
        if case=='ui_effects_legacy':
            self.files['/data/ryunet/users/12345678/settings.ini']=b'version=1\nfps=60\nmotion_blur=1\npro_1080=0\nlight_effects=1\nfriends=PcFriend\n'
        if case=='ui_fps_unlimited':
            self.files['/data/ryunet/users/12345678/settings.ini']=b'version=1\nfps=0\nlow_quality=1\nno_shadows=1\nfriends=PcFriend,OtherFriend\n'
        if case.startswith('ui_graphics_menu'):
            self.files['/data/ryunet/users/12345678/settings.ini']=b'version=1\nfps=0\nmotion_blur=0\npro_1080=1\nperformance=1\nlight_effects=1\nlow_quality=1\nno_shadows=1\nfriends=First,Middle,Last\n'
        self.initial_user=0x12345678
        for path,data in list(self.files.items()):
            if path.endswith(('profile.ini','profile.ini.bak')) and data.startswith(b'version=1\n'):
                self.files[path]=data.replace(b'version=1\n',b'version=2\n',1)+b'identity=installation\n'
        if any(p.endswith('profile.ini') or p.endswith('profile.ini.bak') for p in self.files):
            self.files['/data/ryunet/users/12345678/identity.key']=bytes(range(32)).hex().encode()
        self.file_modes={p:0o644 for p in self.files};self.fchmod_calls=[]
        self.fds={};self.next_fd=9
        raw=(ROOT/'build/ctr_online.prx').read_bytes();elf,eh,ph,_,_=prepare.parse_self(raw)
        self.load(elf,ph,SELF_BASE)
        dp=next(p for p in ph if p['type']==2);tags=dict(prepare.unpack('<QQ',elf,pos) for pos in range(dp['offset'],dp['offset']+dp['filesz'],16));dd=next(p for p in ph if p['type']==0x61000000);blob=prepare.span(elf,dd['offset'],dd['filesz'])
        strings=prepare.span(blob,tags[0x61000035],tags[0x61000037]);symdata=prepare.span(blob,tags[0x61000039],tags[0x6100003f]);symbols=[]
        for pos in range(0,len(symdata),24):
            n,info,other,section,value,size=prepare.unpack('<IBBHQQ',symdata,pos);name=strings[n:strings.index(0,n)].decode().split('#')[0]
            symbols.append((name,section,value))
            if section:self.exports[name]=SELF_BASE+value
        self.undefined=[]
        for ot,st in ((0x61000029,0x6100002d),(0x6100002f,0x61000031)):
            table=prepare.span(blob,tags[ot],tags[st])
            for pos in range(0,len(table),24):
                target,info,addend=prepare.unpack('<QQq',table,pos);kind=info&0xffffffff;sym=info>>32
                if kind==8:value=SELF_BASE+addend
                elif kind in (1,6,7):
                    name,section,rva=symbols[sym]
                    if not section:self.undefined.append(name);continue
                    value=SELF_BASE+rva+addend
                else:raise AssertionError('Unexpected relocation '+str(kind))
                self.uc.mem_write(SELF_BASE+target,struct.pack('<Q',value))
        assert not self.undefined,self.undefined
        self.allowed.extend((SELF_BASE+p['vaddr'],SELF_BASE+p['vaddr']+p['memsz']) for p in ph if p['type'] in (1,0x61000010))
        self.map(STACK,0x20000);self.allowed.append((STACK,STACK+0x20000));self.map(STUB,0x1000);self.map(SCRATCH,0x1000)
        self.uc.mem_write(STUB,b'\xc3'*4096)
        for index,p in enumerate(P):
            base=0x900000000+index*0x4000000
            data=Path(p['elf']).read_bytes();_,_,gph,_,_=prepare.parse_elf(data)
            # The bridge never executes the game engine: map only its explicit
            # marker, import and port slots, so an unexpected read is caught too.
            self.map(base+p['marker_rva'],p['code_size'])
            self.uc.mem_write(base+p['marker_rva'],data[p['code_offset']:p['code_offset']+p['code_size']])
            self.map(base+p['cache_rva'],p['cache_size'])
            for record in p['records']:self.map(base+record['got'],8)
            if index==0:
                self.map(base+0x2aebce0,8)
                for record in UI.get('auxiliary',[]):self.map(base+record['got'],8)
            segments=[]
            for seg in gph:
                if seg['type'] in (1,0x61000010):
                    protection=(1 if seg['flags']&4 else 0)|(2 if seg['flags']&2 else 0)|(4 if seg['flags']&1 else 0)
                    if index==0 and case=='readonly_cache' and protection&2:protection&=~2
                    segments.append((base+seg['vaddr'],seg['memsz'],protection))
            assert len(segments)==3
            name=b'eboot.bin' if index==0 else b'libSceNpToolkit2.prx'
            info=struct.pack('<Q256s',352,name)+b''.join(struct.pack('<QIi',*s) for s in segments)+bytes(16)+struct.pack('<I20s',len(segments),b'\0'*20)
            assert len(info)==352
            self.infos[index]=info
            self.allowed.append((base+p['cache_rva'],base+p['cache_rva']+p['cache_size']))
            for record in p['records']:
                if record['name']=='sceUserServiceGetInitialUser':self.uc.mem_write(base+record['got'],struct.pack('<Q',STUB+0x100))
                if case=='ui_load_modules' and record['name']=='sceSysmoduleLoadModule':self.uc.mem_write(base+record['got'],struct.pack('<Q',STUB+0x400))
                if record['name'] in ('sceHttpCreateRequestWithURL','sceHttpCreateRequestWithURL2'):
                    self.uc.mem_write(base+record['got'],struct.pack('<Q',self.ui_symbols[record['name']]))
        if case=='wrong_marker':self.uc.mem_write(0x900000000+P[0]['marker_rva'],b'X')
        if case.startswith('ui_render') and case!='ui_render_null':
            object=SCRATCH+512
            self.uc.mem_write(object,struct.pack('<Q',0x900000000+(0x2797500 if case=='ui_render_derived' else 0x2796c80)))
            self.uc.mem_write(object+0x540,struct.pack('<IIf',1920,1080,480/1080))
            if case=='ui_render_wrong_vtable':self.uc.mem_write(object,b'X'*8)
            if case=='ui_render_invalid_scale':self.uc.mem_write(object+0x548,struct.pack('<I',0x7fc00000))
            if case=='ui_render_unmapped':object=0x7200000000;self.query_result=-1
            if case=='ui_render_noncanonical':object=0x800000000000
            if case=='ui_render_unaligned':object+=1
            self.uc.mem_write(0x900000000+0x2aebce0,struct.pack('<Q',object))
        if case.startswith('ui_'):
            if case.startswith('ui_network'):
                for record in NET['imports']:
                    address=0x900000000+record['got'];self.map(address,8)
                    if record['name'] not in NET_HOOKS:continue
                    value=self.network_symbols[record['name']]
                    if case=='ui_network_unresolved':value=0x900000000+record['unresolved']
                    if case=='ui_network_conflict' and record['name']=='sceNetSendto':value=0x12345678
                    self.uc.mem_write(address,struct.pack('<Q',value));self.allowed.append((address,address+8))
            if case=='ui_got_fallback':
                for record in UI.get('auxiliary',[]):
                    self.uc.mem_write(0x900000000+record['got'],struct.pack('<Q',self.ui_symbols[record['name']]))
            for record in UI['imports']:
                address=0x900000000+record['got'];self.map(address,8)
                value=0x12345678 if case=='ui_conflict' and record['name']=='scePadReadState' else self.ui_symbols[record['name']]
                self.uc.mem_write(address,struct.pack('<Q',value));self.allowed.append((address,address+8))
            for patch in UI['patches']:
                address=0x900000000+patch['rva'];self.map(address,patch['size']);self.uc.mem_write(address,bytes.fromhex(patch['bytes']))
                at=address+patch['index'];self.allowed.append((at,at+patch['length']))
            for window in UI.get('unchanged_effects',[]):
                address=0x900000000+window['rva'];self.map(address,window['size'])
                self.uc.mem_write(address,bytes.fromhex(window['bytes']))
            if case=='ui_bad_patch':self.uc.mem_write(0x900000000+UI['patches'][0]['rva'],b'X')
            if case=='ui_performance_bad_patch':self.uc.mem_write(0x900000000+UI['patches'][2]['rva']+32,b'X')
            if case in ('ui_shadows_bad_patch','ui_quality_bad_patch'):self.uc.mem_write(0x900000000+UI['patches'][4]['rva'],b'X')
        def text_at(uc,pointer):
            out=bytearray()
            while len(out)<1024:
                value=uc.mem_read(pointer+len(out),1)[0]
                if not value:return out.decode()
                out.append(value)
            raise AssertionError('Unterminated native string')
        def syscall(uc,user):
            number=uc.reg_read(UC_X86_REG_RDI);a=uc.reg_read(UC_X86_REG_RSI);b=uc.reg_read(UC_X86_REG_RDX);c=uc.reg_read(UC_X86_REG_R10);fail=False;ret=0
            if number==5:
                path=text_at(uc,a)
                if b&0x200:
                    if path not in self.files:self.file_modes[path]=c & ~getattr(self,'file_umask',0)
                    if b&0x400:self.files[path]=b''
                    else:self.files.setdefault(path,b'')
                if path in self.files:
                    ret=self.next_fd;self.next_fd+=1;self.fds[ret]=[path,len(self.files[path]) if b&8 else 0]
                else:fail=True;ret=2
            elif number==3:
                path,position=self.fds[a];block=self.files[path][position:position+c]
                uc.mem_write(b,block);self.fds[a][1]+=len(block);ret=len(block)
            elif number==4:
                path,position=self.fds[a]
                if case=='ui_profile_short_write' and path.endswith('profile.ini.tmp'):c=min(c,3)
                data=bytes(uc.mem_read(b,c))
                if getattr(self,'update_fault',None)=='corrupt' and path.endswith('.download') and data:data=bytes([data[0]^1])+data[1:]
                old=self.files[path];self.files[path]=old[:position]+data+old[position+c:];self.fds[a][1]+=c;ret=c
            elif number==6:del self.fds[a]
            elif number==124:
                path=self.fds[a][0];self.fchmod_calls.append((path,b))
                if getattr(self,'update_fault',None)=='chmod':fail=True;ret=13
                else:self.file_modes[path]=b
            elif number==95:
                if getattr(self,'update_fault',None)=='fsync':fail=True;ret=5
            elif number==116:uc.mem_write(a,struct.pack('<qq',getattr(self,'wall_seconds',1792800000),0))
            elif number==136:fail=True;ret=17
            elif number==128:
                old,new=text_at(uc,a),text_at(uc,b)
                if (case=='ui_profile_rename_failure' and new=='/data/ryunet/users/12345678/profile.ini') or (case=='ui_graphics_menu_rename_failure' and new=='/data/ryunet/users/12345678/settings.ini'):fail=True;ret=5
                elif getattr(self,'update_fault',None)=='rename' and new.endswith('/ctr_online.prx'):fail=True;ret=5
                else:
                    self.files[new]=self.files.pop(old)
                    self.file_modes[new]=self.file_modes.pop(old,0o644)
            elif number==10:
                removed=text_at(uc,a);self.files.pop(removed,None);self.file_modes.pop(removed,None)
            elif number==591:
                name=text_at(uc,b)
                aliases={prepare.nid(n):n for n in self.ui_symbols}
                resolved=aliases.get(name,name)
                available=case.startswith('ui_') and resolved in self.ui_symbols
                if not self.dialogs_loaded and ('Dialog' in resolved):available=False
                if case=='ui_nids' and name not in aliases:available=False
                if case=='ui_network_nids' and name not in aliases:available=False
                if case=='ui_got_fallback':available=False
                if case=='ui_render_missing' and resolved=='sceKernelQueryMemoryProtection':available=False
                if case=='ui_identity_no_random' and resolved=='sceRandomGetRandomNumber':available=False
                if case=='ui_identity_no_header' and resolved=='sceHttpAddRequestHeader':available=False
                if available:uc.mem_write(c,struct.pack('<Q',self.ui_symbols[resolved]))
                else:fail=True;ret=3
            elif number==74:
                self.protect_calls.append((a,b,c))
                assert a%0x4000==b%0x4000==0
                if case=='ui_protect_failure':fail=True;ret=13
                if case=='ui_second_protect_failure' and len(self.protect_calls)==2:fail=True;ret=13
                if case=='ui_network_protect_failure' and len(self.protect_calls)==1:fail=True;ret=13
                if case=='ui_performance_protect_failure' and len(self.protect_calls)==6:fail=True;ret=13
                if case in ('ui_shadows_protect_failure','ui_quality_protect_failure') and len(self.protect_calls)==6:fail=True;ret=13
            elif number==592:
                ids=(0,1) if self.include_toolkit else (0,)
                uc.mem_write(a,struct.pack('<'+'i'*len(ids),*ids));uc.mem_write(c,struct.pack('<Q',len(ids)))
            elif number==593:
                if a not in self.infos:fail=True;ret=3
                else:
                    self.assert_info_size(uc,b);uc.mem_write(b,self.infos[a])
            else:raise AssertionError('Unexpected native syscall '+str(number))
            flags=uc.reg_read(UC_X86_REG_EFLAGS);uc.reg_write(UC_X86_REG_EFLAGS,(flags|1) if fail else flags&~1);uc.reg_write(UC_X86_REG_RAX,ret)
            uc.reg_write(UC_X86_REG_RCX,0xdeadbeef);uc.reg_write(UC_X86_REG_R11,flags)
        def writes(uc,access,address,size,value,user):
            assert any(a<=address and address+size<=b for a,b in self.allowed),('Unexpected write',hex(address),size)
            for index,p in enumerate(P):
                base=0x900000000+index*0x4000000
                if base+p['cache_rva']<=address<base+p['cache_rva']+p['cache_size']:self.cache_writes.append((index,address,size))
            if any(0x900000000+r['got']<=address<0x900000000+r['got']+8 for r in UI['imports']):self.ui_writes.append((address,size))
            if any(0x900000000+r['got']<=address<0x900000000+r['got']+8 for r in NET['imports'] if r['name'] in NET_HOOKS):self.network_writes.append((address,size))
        from unicorn import UC_HOOK_CODE
        def code(uc,address,size,user):
            if address==STUB+0x100:uc.mem_write(uc.reg_read(UC_X86_REG_RDI),struct.pack('<i',self.initial_user));uc.reg_write(UC_X86_REG_RAX,0)
            if address==STUB+0x400:
                module=uc.reg_read(UC_X86_REG_RDI);self.loaded_modules.append(module)
                if module==0xa4:self.dialogs_loaded=True
                uc.reg_write(UC_X86_REG_RAX,0)
            for name,stub in self.ui_symbols.items():
                if address!=stub:continue
                result=0
                if name=='sceKernelIsNeoMode':result=int(case in ('ui_graphics','ui_bad_patch','ui_performance_pro','ui_quality_pro'))
                elif name=='sceRandomGetRandomNumber':
                    self.random_calls+=1;n=uc.reg_read(UC_X86_REG_RSI);assert n==32
                    if case=='ui_identity_random_failure':result=0xffffffff
                    else:uc.mem_write(uc.reg_read(UC_X86_REG_RDI),bytes(range(32)))
                elif name=='sceHttpAddRequestHeader':
                    self.http_headers.append((uc.reg_read(UC_X86_REG_RDI),text_at(uc,uc.reg_read(UC_X86_REG_RSI)),text_at(uc,uc.reg_read(UC_X86_REG_RDX)),uc.reg_read(UC_X86_REG_RCX)))
                    if case=='ui_identity_header_failure':result=0xffffffff
                elif name=='sceHttpDeleteRequest':self.http_deleted.append(uc.reg_read(UC_X86_REG_RDI))
                elif name in ('sceHttpCreateRequestWithURL','sceHttpCreateRequestWithURL2'):
                    self.http_created.append(name);result=571
                elif name=='sceKernelGetProcessTime':result=self.now_us
                elif name=='sceNetErrnoLoc':result=SCRATCH+0x800
                elif name=='sceNetGetsockopt':
                    uc.mem_write(uc.reg_read(UC_X86_REG_RCX),struct.pack('<I',2))
                    uc.mem_write(uc.reg_read(UC_X86_REG_R8),struct.pack('<I',4))
                elif name=='sceNetSendto':
                    n=uc.reg_read(UC_X86_REG_RDX)
                    self.network_sends.append((bytes(uc.mem_read(uc.reg_read(UC_X86_REG_RSI),n)),bytes(uc.mem_read(uc.reg_read(UC_X86_REG_R8),16))))
                    result=n
                elif name=='sceNetRecvfrom':
                    if self.network_incoming:
                        packet,source=self.network_incoming.pop(0);n=min(len(packet),uc.reg_read(UC_X86_REG_RDX))
                        uc.mem_write(uc.reg_read(UC_X86_REG_RSI),packet[:n])
                        uc.mem_write(uc.reg_read(UC_X86_REG_R8),source)
                        uc.mem_write(uc.reg_read(UC_X86_REG_R9),struct.pack('<I',16));result=n
                    else:uc.mem_write(SCRATCH+0x800,struct.pack('<I',35));result=0xffffffff
                elif name=='sceKernelUsleep':
                    amount=uc.reg_read(UC_X86_REG_RDI);self.sleep_calls.append(amount)
                    self.now_us+=((amount+999)//1000)*1000 if case=='ui_fps_quantized' else amount
                elif name=='sceKernelQueryMemoryProtection':
                    self.query_count+=1;result=self.query_result
                    if not result:
                        uc.mem_write(uc.reg_read(UC_X86_REG_RSI),struct.pack('<Q',self.query_first))
                        uc.mem_write(uc.reg_read(UC_X86_REG_RDX),struct.pack('<Q',self.query_last))
                        uc.mem_write(uc.reg_read(UC_X86_REG_RCX),struct.pack('<i',self.query_permission))
                elif name.startswith('sceGnm'):
                    registers=tuple(uc.reg_read(reg) for reg in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8,UC_X86_REG_R9))
                    stack=struct.unpack('<QQQQ',uc.mem_read(uc.reg_read(UC_X86_REG_RSP)+8,32));self.gnm_calls.append((name,registers+stack));result=0x5a
                elif name=='sceMsgDialogInitialize':self.dialog_status=1
                elif name=='sceMsgDialogTerminate':self.dialog_status=0
                elif name in ('sceMsgDialogGetStatus','sceMsgDialogUpdateStatus'):result=self.dialog_status
                elif name=='sceMsgDialogGetResult':
                    uc.mem_write(uc.reg_read(UC_X86_REG_RDI),struct.pack('<iii',1,0,self.dialog_chosen)+bytes(32))
                elif name=='sceImeDialogInit':
                    self.ime_state=1;self.ime_buffer=struct.unpack_from('<Q',uc.mem_read(uc.reg_read(UC_X86_REG_RDI),96),40)[0]
                elif name=='sceImeDialogGetStatus':result=self.ime_state
                elif name=='sceImeDialogGetResult':
                    self.ime_result_calls+=1
                    uc.mem_write(uc.reg_read(UC_X86_REG_RDI),struct.pack('<i',self.ime_endstatus)+bytes(12))
                elif name=='sceImeDialogTerm':self.ime_term_calls+=1;self.ime_state=0
                elif name=='sceImeDialogAbort':self.ime_state=2
                elif name=='sceUserServiceGetUserName':
                    self.original_username_calls+=1
                    uc.mem_write(uc.reg_read(UC_X86_REG_RSI),b'PSN_Private\0')
                elif name=='sceSystemServiceGetStatus':
                    result=self.system_status_result
                    if not result:uc.mem_write(uc.reg_read(UC_X86_REG_RDI),self.system_status_data)
                elif name=='sceSystemServiceReceiveEvent':
                    result=self.system_event_result
                    if not result:uc.mem_write(uc.reg_read(UC_X86_REG_RDI),self.system_event_data)
                elif name=='sceMsgDialogOpen':
                    pointer=uc.reg_read(UC_X86_REG_RDI);raw=uc.mem_read(pointer,136)
                    assert struct.unpack_from('<Q',raw)[0]==48
                    assert struct.unpack_from('<I',raw,44)[0]==(pointer+0xc0d1a109)&0xffffffff
                    assert struct.unpack_from('<Q',raw,48)[0]==136
                    self.opened_dialogs+=1
                    self.dialog_status=2
                elif name=='scePadReadState':
                    pointer=uc.reg_read(UC_X86_REG_RSI);data=bytearray(120);struct.pack_into('<I',data,0,6);data[76]=1;uc.mem_write(pointer,bytes(data))
                elif name=='sceVideoOutSetFlipRate':self.rates.append((uc.reg_read(UC_X86_REG_RDI),uc.reg_read(UC_X86_REG_RSI)))
                elif name=='sceVideoOutSubmitFlip':self.flips.append(tuple(uc.reg_read(reg) for reg in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX)));result=17
                uc.reg_write(UC_X86_REG_RAX,result)
        self.uc.hook_add(UC_HOOK_INSN,syscall,None,1,0,UC_X86_INS_SYSCALL);self.uc.hook_add(UC_HOOK_MEM_WRITE,writes);self.uc.hook_add(UC_HOOK_CODE,code,begin=STUB,end=STUB+4095)
    def assert_info_size(self,u,pointer):assert struct.unpack('<Q',u.mem_read(pointer,8))[0]==352
    def map(self,address,size):
        for p in range(address&-4096,(address+size+4095)&-4096,4096):
            if p not in self.pages:self.uc.mem_map(p,4096);self.pages.add(p)
    def load(self,data,ph,base):
        for p in ph:
            if p['type'] not in (1,0x61000010):continue
            self.map(base+p['vaddr'],p['memsz']);self.uc.mem_write(base+p['vaddr'],bytes(data[p['offset']:p['offset']+p['filesz']]))
    def call(self,address,*args):
        u=self.uc;top=STACK+0x1ff08;u.reg_write(UC_X86_REG_RSP,top);u.mem_write(top,struct.pack('<Q',STUB))
        for i,arg in enumerate(args[6:]):u.mem_write(top+8+i*8,struct.pack('<Q',arg))
        for reg,arg in zip((UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8,UC_X86_REG_R9),args):u.reg_write(reg,arg)
        u.emu_start(address,STUB,count=getattr(self,'instruction_budget',3000000))
        assert u.reg_read(UC_X86_REG_RIP)==STUB,'Native code failed to return'
        return u.reg_read(UC_X86_REG_RAX)&0xffffffff
    def initialize(self):return self.call(self.exports[prepare.nid('ctr_initialize')])

class Tests(unittest.TestCase):
    def test_native_toolkit_friend_query_with_profile_photo_fields_keeps_friend_schema(self):
        import re
        raw=Path(P[1]['elf']).read_bytes()
        route=next(s for s in re.findall(rb'[\x20-\x7e]{6,}',raw) if s.startswith(b'/v1/users/%lu/friendList?'))
        route=route.replace(b'%lu',b'1872708366').replace(b'%d',b'500',1).replace(b'%d',b'0',1)
        m=ModuleMachine('ui_graphics_menu');before=dict(m.files);self.assertEqual(m.initialize(),0)
        area=SCRATCH+0x10000;m.map(area,0x10000);m.allowed.append((area,area+0x10000))
        m.uc.mem_write(area,route+b'\0');m.uc.mem_write(area+0x200,b'userProfile\0')
        def hook(name):
            m.uc.mem_write(area+0x300,name.encode()+b'\0')
            m.call(m.exports[prepare.nid('ctr_find_hook')],area+0x300)
            return m.uc.reg_read(UC_X86_REG_RAX)
        create=hook('sceNpWebApiCreateRequest');send=hook('sceNpWebApiSendRequest')
        read=hook('sceNpWebApiReadData');delete=hook('sceNpWebApiDeleteRequest')
        self.assertEqual(m.call(create,1,area+0x200,area,0,0,area+0x400),0)
        handle=struct.unpack('<Q',m.uc.mem_read(area+0x400,8))[0]
        self.assertEqual(m.call(send,handle,0,0),0);pieces=[]
        for _ in range(200):
            n=m.call(read,handle,area+0x500,37);self.assertLessEqual(n,37)
            if not n:break
            pieces.append(bytes(m.uc.mem_read(area+0x500,n)))
        else:self.fail('Native friend response did not reach EOF')
        doc=json.loads(b''.join(pieces));self.assertNotIn('profiles',doc)
        self.assertEqual([f['onlineId'] for f in doc['friendList']],['First','Middle','Last'])
        self.assertEqual(doc['size'],3);self.assertEqual(m.call(delete,handle),0)
        for path,data in before.items():self.assertEqual(m.files[path],data)
    def test_original_game_friend_status_comparison_is_unchanged_and_not_forced_online(self):
        m=ModuleMachine('ui_graphics_menu');self.assertEqual(m.initialize(),0)
        gamebase=0x900000000;start=0xb89652;stop=0xb89667
        raw=Path(P[0]['elf']).read_bytes();_,_,segments,_,_=prepare.parse_elf(raw)
        segment=next(s for s in segments if s['type']==1 and s['vaddr']<=start and stop<=s['vaddr']+s['filesz'])
        offset=segment['offset']+start-segment['vaddr'];code=raw[offset:offset+stop-start]
        self.assertEqual(code.hex(),'4a8b0429488943484283bc29c8020000010f944330')
        m.map(gamebase+start,len(code));m.uc.mem_write(gamebase+start,code)
        source=SCRATCH+0x10000;friend=SCRATCH+0x11000;m.map(source,0x2000)
        m.allowed.extend(((friend+0x48,friend+0x50),(friend+0x30,friend+0x31)))
        for status in (0,1,2,0xffffffff):
            record=bytearray(0x2e0);struct.pack_into('<Q',record,0,1815854388);struct.pack_into('<I',record,0x2c8,status)
            m.uc.mem_write(source,bytes(record));m.uc.mem_write(friend,b'\xa5'*0x60)
            for register,value in ((UC_X86_REG_RCX,source),(UC_X86_REG_R13,0),(UC_X86_REG_RBX,friend)):m.uc.reg_write(register,value)
            m.uc.emu_start(gamebase+start,gamebase+stop,count=10)
            actual=bytearray(m.uc.mem_read(friend,0x60));expected=bytearray(b'\xa5'*0x60)
            struct.pack_into('<Q',expected,0x48,1815854388);expected[0x30]=int(status==1)
            self.assertEqual(actual,expected)
    def test_native_network_hooks_install_atomically_and_preserve_other_features(self):
        for case,code in (('ui_network',0),('ui_network_nids',0),('ui_network_unresolved',0),('ui_network_conflict',-5),('ui_network_missing',-3),('ui_network_protect_failure',-6)):
            m=ModuleMachine(case);before=dict(m.files)
            slots=[r for r in NET['imports'] if r['name'] in NET_HOOKS]
            values=[bytes(m.uc.mem_read(0x900000000+r['got'],8)) for r in slots]
            self.assertEqual(m.initialize(),0)
            log=m.files['/data/GoldHEN/ctr_native_port.log'].decode()
            self.assertIn(f'CTR native stage=00000096 code={code&0xffffffff:08x}',log)
            self.assertEqual(len(m.network_writes),4 if code==0 else 0)
            self.assertEqual(len(m.ui_writes),len(UI['imports']))
            if code:
                self.assertEqual(values,[bytes(m.uc.mem_read(0x900000000+r['got'],8)) for r in slots])
            for path,data in before.items():self.assertEqual(m.files[path],data)
    def test_actual_native_self_sends_v053_wire_and_unwraps_six_argument_recvfrom(self):
        m=ModuleMachine('ui_network');self.assertEqual(m.initialize(),0)
        m.allowed.append((SCRATCH+0x800,SCRATCH+0x804))
        def hook(name):
            entry=next(r for r in NET['imports'] if r['name']==name)
            return struct.unpack('<Q',m.uc.mem_read(0x900000000+entry['got'],8))[0]
        m.call(m.exports[prepare.nid('ctr_net_server')],0x7a7d01a5)
        local=bytes.fromhex('10020c02000000000000000000000000')
        peer=bytes.fromhex('1002475ec9bd1aa50000000000000000')
        server=bytes.fromhex('10020c02a5017d7a0000000000000000')
        m.uc.mem_write(SCRATCH+0x900,local)
        self.assertEqual(m.call(hook('sceNetBind'),7,SCRATCH+0x900,16),0)
        self.assertEqual(m.network_sends[-1],(b'RYUKA1\2'+bytes(293),server))
        m.uc.mem_write(SCRATCH+0x940,b'game');m.uc.mem_write(SCRATCH+0x960,peer)
        self.assertEqual(m.call(hook('sceNetSendto'),7,SCRATCH+0x940,4,0,SCRATCH+0x960,16),4)
        self.assertEqual(m.network_sends[-1],(b'RYUTN1\2'+peer[4:8]+peer[2:4]+b'game',server))
        m.network_incoming.append((b'RYUTN1\0'+peer[4:8]+peer[2:4]+b'answer',server))
        m.allowed.extend(((SCRATCH+0xa00,SCRATCH+0xa20),(SCRATCH+0xb00,SCRATCH+0xb10),(SCRATCH+0xb20,SCRATCH+0xb24)))
        m.uc.mem_write(SCRATCH+0xb20,struct.pack('<I',16))
        self.assertEqual(m.call(hook('sceNetRecvfrom'),7,SCRATCH+0xa00,32,0,SCRATCH+0xb00,SCRATCH+0xb20),6)
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH+0xa00,6)),b'answer')
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH+0xb00,16)),peer)
    def test_native_unified_resolution_and_restore_save_only_settings_preserving_profile_friends_and_fps(self):
        for restore in (False,True):
            m=ModuleMachine('ui_graphics_menu');before=dict(m.files);self.assertEqual(m.initialize(),0)
            poll=m.exports[prepare.nid('ctr_menu_poll')];self.assertEqual(m.call(poll,7,6),1)
            choices=(1,2,2,2,1) if restore else (1,2,1,2,2,1)
            for button in choices:
                m.dialog_status=3;m.dialog_chosen=button;self.assertEqual(m.call(poll,7,0),1)
            text=m.files['/data/ryunet/users/12345678/settings.ini'].decode()
            values=dict(line.split('=',1) for line in text.splitlines())
            self.assertEqual(values['fps'],'0');self.assertEqual(values['friends'],'First,Middle,Last')
            self.assertEqual(values['pro_1080'],'0');self.assertEqual(values['low_quality'],'0')
            self.assertEqual(values['performance'],'0' if restore else '1')
            self.assertEqual(values['motion_blur'],'1' if restore else '0')
            self.assertEqual(values['no_shadows'],'0' if restore else '1')
            for path,data in before.items():
                if path!='/data/ryunet/users/12345678/settings.ini':self.assertEqual(m.files[path],data)
            self.assertNotIn('/data/ryunet/users/12345678/settings.ini.tmp',m.files)
            self.assertEqual(set(m.files)-set(before),{'/data/GoldHEN/ctr_native_port.log'})
    def test_native_restore_failed_atomic_rename_preserves_previous_settings_and_profile(self):
        m=ModuleMachine('ui_graphics_menu_rename_failure');before=dict(m.files);self.assertEqual(m.initialize(),0)
        poll=m.exports[prepare.nid('ctr_menu_poll')];m.call(poll,7,6)
        for button in (1,2,2,2,1):
            m.dialog_status=3;m.dialog_chosen=button;m.call(poll,7,0)
        for path,data in before.items():self.assertEqual(m.files[path],data)
        self.assertNotIn('/data/ryunet/users/12345678/settings.ini.tmp',m.files)
    def test_renderer_diagnostics_are_read_only_and_first_flip_probe_preserves_arguments(self):
        for case in ('ui_render_ready','ui_render_derived'):
            m=ModuleMachine(case);before=bytes(m.uc.mem_read(SCRATCH,4096))
            self.assertEqual(m.initialize(),0);self.assertEqual(m.query_count,1) # renderer only
            entry=next(r for r in UI['imports'] if r['name']=='sceGnmSubmitAndFlipCommandBuffers')
            hook=struct.unpack('<Q',m.uc.mem_read(0x900000000+entry['got'],8))[0]
            args=tuple(range(11,21))
            self.assertEqual(m.call(hook,*args),0x5a);self.assertEqual(m.gnm_calls[-1][1],args)
            self.assertEqual(m.query_count,2);self.assertEqual(bytes(m.uc.mem_read(SCRATCH,4096)),before)
            self.assertEqual(m.call(hook,*args),0x5a);self.assertEqual(m.query_count,2)
            log=m.files['/data/GoldHEN/ctr_native_port.log'].decode()
            import re
            events=[(int(a,16),int(b,16)) for a,b in re.findall(r'CTR native stage=([0-9a-f]{8}) code=([0-9a-f]{8})',log)]
            snapshots=[e for e in events if 140<=e[0]<=144]
            expected=[(141,0),(142,1920),(143,1080),(144,struct.unpack('<I',struct.pack('<f',480/1080))[0])]
            self.assertEqual(snapshots,[(140,0)]+expected+[(140,1)]+expected)
    def test_renderer_diagnostics_refuse_unreadable_or_unknown_objects_without_failing_game_init(self):
        failures={'null':-2,'missing':-3,'noncanonical':-4,'unaligned':-4,'query_fail':-5,'unmapped':-5,
                  'range':-6,'permission':-6,'wrong_vtable':-7,'invalid_scale':-8}
        for case,status in failures.items():
            m=ModuleMachine('ui_render_'+case);self.assertEqual(m.initialize(),0)
            log=m.files['/data/GoldHEN/ctr_native_port.log'].decode()
            self.assertIn(f'CTR native stage=0000008d code={status&0xffffffff:08x}',log)
            self.assertNotIn('CTR native stage=0000008e',log)
            if status in (-2,-4):self.assertEqual(m.query_count,0) # no scene filter
            if status==-3:self.assertEqual(m.query_count,0) # query symbol absent
    def test_native_nickname_load_backup_and_no_psn_name_fallback(self):
        for case,expected,online in (('ui_profile_alias',b'AliasPrivado_123',True),('ui_profile_backup',b'AliasPrivado_123',True),('ui_profile_missing',b'RyuNET',False),('ui_profile_corrupt',b'RyuNET',False)):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0);m.allowed.append((SCRATCH,SCRATCH+4096))
            entry=next(r for r in UI['imports'] if r['name']=='sceUserServiceGetUserName')
            pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+entry['got'],8))[0]
            m.uc.mem_write(SCRATCH,b'\xa5'*96)
            self.assertEqual(m.call(pointer,0x12345678,SCRATCH+16,64),0)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH+16,len(expected)+1)),expected+b'\0');self.assertEqual(m.original_username_calls,0)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH,16)),b'\xa5'*16);self.assertEqual(bytes(m.uc.mem_read(SCRATCH+80,16)),b'\xa5'*16)
            m.uc.mem_write(SCRATCH+16,b'\xa5'*64);self.assertEqual(m.call(pointer,0x12345678,SCRATCH+16,4),0x8096000a)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH+16,64)),b'\xa5'*64)
            record=next(r for r in P[1]['records'] if r['name']=='sceNpGetState')
            get_state=struct.unpack('<Q',m.uc.mem_read(0x904000000+record['cache'],8))[0]
            self.assertEqual(m.call(get_state,0x12345678,SCRATCH+256),0)
            self.assertEqual(struct.unpack('<i',m.uc.mem_read(SCRATCH+256,4))[0],2 if online else 1)
    def test_native_profile_save_is_atomic_handles_short_writes_and_keeps_active_name(self):
        for case in ('ui_success','ui_profile_short_write','ui_profile_rename_failure'):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0);m.allowed.append((SCRATCH,SCRATCH+4096))
            poll=m.exports[prepare.nid('ctr_menu_poll')];self.assertEqual(m.call(poll,7,6),1)
            for button in (2,1,2,1):
                m.dialog_status=3;m.dialog_chosen=button;self.assertEqual(m.call(poll,7,0),1)
            self.assertEqual(m.ime_state,1)
            m.uc.mem_write(m.ime_buffer,('AliasPrivado_123'+'\0').encode('utf-16-le'));m.ime_state=2
            self.assertEqual(m.call(poll,7,0),1)
            wanted=b'DemoPlayerPS4001' if case=='ui_profile_rename_failure' else b'AliasPrivado_123'
            expected=b'version=2\nnickname='+wanted+b'\nidentity=installation\n'
            self.assertEqual(m.files['/data/ryunet/users/12345678/profile.ini'],expected)
            self.assertEqual(m.files['/data/ryunet/users/12345678/profile.ini.bak'],b'version=2\nnickname=DemoPlayerPS4001\nidentity=installation\n')
            self.assertNotIn('/data/ryunet/users/12345678/profile.ini.tmp',m.files)
            self.assertEqual(m.call(m.exports[prepare.nid('ctr_profile_snapshot')],SCRATCH),0)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH,17)).split(b'\0')[0],wanted)
            entry=next(r for r in UI['imports'] if r['name']=='sceUserServiceGetUserName')
            pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+entry['got'],8))[0]
            self.assertEqual(m.call(pointer,0x12345678,SCRATCH,64),0)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH,17)),b'DemoPlayerPS4001\0')
    def test_native_owned_profile_restart_reuses_key_and_recovers_backup_without_regeneration(self):
        for damaged in (False,True):
            m=ModuleMachine('ui_identity_restart');m.files={
                '/data/ryunet/users/12345678/profile.ini':b'version=2\nnickname=OwnPlayer\nidentity=installation\n',
                '/data/ryunet/users/12345678/identity.key':b'broken' if damaged else bytes(range(32)).hex().encode(),
                '/data/ryunet/users/12345678/identity.key.bak':bytes(range(32)).hex().encode()}
            before=dict(m.files);self.assertEqual(m.initialize(),0);self.assertEqual({p:v for p,v in m.files.items() if p.startswith('/data/ryunet/users/12345678/')},before);self.assertEqual(m.random_calls,0)
            m.uc.mem_write(SCRATCH,b'http://octr.ryu7w7.xyz:8080/auth\0')
            m.call(m.exports[prepare.nid('ctr_identity_header')],SCRATCH);pointer=m.uc.reg_read(UC_X86_REG_RAX)
            self.assertNotEqual(pointer,0)
            expected=hmac.new(bytes(range(32)),b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest().encode()
            self.assertEqual(bytes(m.uc.mem_read(pointer,65)),expected+b'\0')
    def test_native_first_run_creates_private_identity_and_waits_for_restart(self):
        m=ModuleMachine('ui_profile_missing');self.assertEqual(m.initialize(),0)
        poll=m.exports[prepare.nid('ctr_menu_poll')]
        for _ in range(120):m.call(poll,7,0)
        self.assertEqual(m.opened_dialogs,1);m.dialog_status=3;m.dialog_chosen=1;m.call(poll,7,0)
        self.assertEqual(m.ime_state,1);m.uc.mem_write(m.ime_buffer,('OwnPlayer'+'\0').encode('utf-16-le'));m.ime_state=2;m.call(poll,7,0)
        self.assertEqual(m.files['/data/ryunet/users/12345678/profile.ini'],b'version=2\nnickname=OwnPlayer\nidentity=installation\n')
        self.assertEqual(m.files['/data/ryunet/users/12345678/identity.key'],bytes(range(32)).hex().encode());self.assertEqual(m.random_calls,1)
        m.uc.mem_write(SCRATCH,b'http://octr.ryu7w7.xyz:8080/auth\0')
        self.assertEqual(m.call(m.exports[prepare.nid('ctr_identity_header')],SCRATCH),0)
        restarted=ModuleMachine('ui_identity_restart');restarted.files=dict(m.files);self.assertEqual(restarted.initialize(),0)
        self.assertEqual(restarted.opened_dialogs,0);self.assertEqual(restarted.random_calls,0)
    def test_native_missing_or_failed_random_source_keeps_old_profile_and_control(self):
        for case in ('ui_identity_no_random','ui_identity_random_failure'):
            m=ModuleMachine(case);m.files.clear();before=dict(m.files);self.assertEqual(m.initialize(),0)
            poll=m.exports[prepare.nid('ctr_menu_poll')];m.call(poll,7,6)
            for button in (2,1,2,1):m.dialog_status=3;m.dialog_chosen=button;m.call(poll,7,0)
            m.uc.mem_write(m.ime_buffer,('OwnPlayer'+'\0').encode('utf-16-le'));m.ime_state=2;m.call(poll,7,0)
            self.assertEqual({p:v for p,v in m.files.items() if p.startswith('/data/ryunet/users/12345678/')},before);self.assertEqual(m.ime_state,0)
            m.dialog_status=3;m.call(poll,7,0);m.call(poll,7,0)
            self.assertEqual(m.call(m.exports[prepare.nid('ctr_menu_active')]),0)
    def test_native_owned_profile_with_missing_key_stays_offline_without_legacy_fallback(self):
        m=ModuleMachine('ui_identity_lost');m.files={
            '/data/ryunet/users/12345678/profile.ini':b'version=2\nnickname=OwnPlayer\nidentity=installation\n',
            '/data/ryunet/users/12345678/profile.ini.bak':b'version=1\nnickname=OldPlayer\n'}
        before=dict(m.files);self.assertEqual(m.initialize(),0);self.assertEqual(m.random_calls,0)
        record=next(r for r in P[1]['records'] if r['name']=='sceNpGetState')
        pointer=struct.unpack('<Q',m.uc.mem_read(0x904000000+record['cache'],8))[0]
        m.allowed.append((SCRATCH,SCRATCH+4096));self.assertEqual(m.call(pointer,42,SCRATCH),0)
        self.assertEqual(struct.unpack('<i',m.uc.mem_read(SCRATCH,4))[0],1);self.assertEqual({p:v for p,v in m.files.items() if p.startswith('/data/ryunet/users/12345678/')},before)
    def test_native_both_http_request_abis_attach_header_or_fail_closed_without_leaking(self):
        for case in ('ui_identity_http','ui_nids','ui_identity_header_failure','ui_identity_no_header'):
            m=ModuleMachine(case);m.files={
                '/data/ryunet/users/12345678/profile.ini':b'version=2\nnickname=OwnPlayer\nidentity=installation\n',
                '/data/ryunet/users/12345678/identity.key':bytes(range(32)).hex().encode()}
            self.assertEqual(m.initialize(),0)
            for index,name in ((1,'sceHttpCreateRequestWithURL'),(0,'sceHttpCreateRequestWithURL2')):
                record=next(r for r in P[index]['records'] if r['name']==name)
                pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+index*0x4000000+record['cache'],8))[0]
                m.uc.mem_write(SCRATCH,b'http://octr.ryu7w7.xyz:8080/auth\0');m.uc.mem_write(SCRATCH+128,b'POST\0')
                result=m.call(pointer,12,1 if index else SCRATCH+128,SCRATCH,0)
                self.assertEqual(result,0xffffffff if case in ('ui_identity_header_failure','ui_identity_no_header') else 571)
            if case=='ui_identity_no_header':self.assertFalse(m.http_created);self.assertFalse(m.http_headers)
            else:
                self.assertEqual(len(m.http_headers),2)
                expected=hmac.new(bytes(range(32)),b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest()
                self.assertTrue(all(row==(571,'X-RyuNET-Key',expected,0) for row in m.http_headers))
                self.assertEqual(m.http_deleted,[571,571] if case=='ui_identity_header_failure' else [])
            self.assertNotIn(bytes(range(32)).hex().encode(),m.files.get('/data/GoldHEN/ctr_native_port.log',b''))
    def test_gnm_trampolines_preserve_stack_and_vector_arguments_and_limit_frames(self):
        m=ModuleMachine('ui_graphics');self.assertEqual(m.initialize(),0)
        args=tuple(0x123400000000+i for i in range(10))
        vectors=[(1<<100)+i for i in range(8)]
        names=[r for r in UI['imports'] if r['name'].startswith('sceGnm')]
        for r in names:
            for i,value in enumerate(vectors):m.uc.reg_write(UC_X86_REG_XMM0+i,value)
            pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+r['got'],8))[0]
            m.now_us+=150000
            self.assertEqual(m.call(pointer,*args),0x5a)
            self.assertEqual(m.gnm_calls[-1],(r['name'],args))
            self.assertEqual([m.uc.reg_read(UC_X86_REG_XMM0+i) for i in range(8)],vectors)
            m.now_us+=1000;self.assertEqual(m.call(pointer,*args),0x5a)
            self.assertEqual(m.sleep_calls[-1],32333)
    def test_native_sixty_and_unlimited_are_distinct_on_all_presentation_hooks(self):
        args=tuple(0x123400000000+i for i in range(10))
        for case in ('ui_fps_sixty','ui_fps_unlimited'):
            m=ModuleMachine(case);before=dict(m.files);self.assertEqual(m.initialize(),0)
            for r in (r for r in UI['imports'] if r['name'].startswith('sceGnm') or r['name']=='sceVideoOutSubmitFlip'):
                pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+r['got'],8))[0]
                m.now_us+=150000;before_sleeps=len(m.sleep_calls)
                self.assertEqual(m.call(pointer,*args),17 if r['name']=='sceVideoOutSubmitFlip' else 0x5a)
                if r['name'].startswith('sceGnm'):self.assertEqual(m.gnm_calls[-1],(r['name'],args))
                m.now_us+=1000
                self.assertEqual(m.call(pointer,*args),17 if r['name']=='sceVideoOutSubmitFlip' else 0x5a)
                if case=='ui_fps_sixty':
                    self.assertEqual(m.sleep_calls[before_sleeps:],[15667])
                else:self.assertEqual(len(m.sleep_calls),before_sleeps)
            for path,data in before.items():self.assertEqual(m.files[path],data)
    def test_native_sixty_stays_on_phase_with_millisecond_sleep_rounding(self):
        m=ModuleMachine('ui_fps_quantized');self.assertEqual(m.initialize(),0)
        r=next(r for r in UI['imports'] if r['name']=='sceGnmSubmitAndFlipCommandBuffers')
        hook=struct.unpack('<Q',m.uc.mem_read(0x900000000+r['got'],8))[0];times=[]
        for _ in range(61):
            m.now_us+=5000;self.assertEqual(m.call(hook,*range(10)),0x5a);times.append(m.now_us)
        self.assertTrue(all(16000<=b-a<=17000 for a,b in zip(times,times[1:])))
        self.assertLessEqual(abs((times[-1]-times[0])-1000000),1000)
        self.assertEqual(len(m.sleep_calls),60)
    def test_optional_dialog_system_module_is_loaded_before_menu_init(self):
        m=ModuleMachine('ui_load_modules');self.assertEqual(m.initialize(),0)
        self.assertIn(0xa4,m.loaded_modules);self.assertEqual(len(m.ui_writes),len(UI['imports']))
    def test_dialog_resolution_by_nid_and_import_slot(self):
        for case in ('ui_nids','ui_got_fallback'):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0);self.assertEqual(len(m.ui_writes),len(UI['imports']))
    def test_delayed_dialog_module_load_initializes_ui_later(self):
        m=ModuleMachine('ui_late_dialogs');self.assertEqual(m.initialize(),0);self.assertEqual(m.ui_writes,[])
        m.dialogs_loaded=True
        record=next(r for r in P[0]['records'] if r['name']=='sceNpCheckNpAvailabilityA')
        pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+record['cache'],8))[0]
        for _ in range(120):self.assertEqual(m.call(pointer),0)
        self.assertEqual(len(m.ui_writes),len(UI['imports']))
    def test_native_ui_install_pad_and_flip_preserve_game_abi(self):
        m=ModuleMachine('ui_success');self.assertEqual(m.initialize(),0);self.assertEqual(len(m.ui_writes),len(UI['imports']))
        self.assertEqual([(n,s) for _,n,s in m.protect_calls],[(0x4000,3),(0x4000,3),(0x4000,1),(0x4000,1)])
        m.allowed.append((SCRATCH,SCRATCH+4096))
        def hook(name):
            record=next(r for r in UI['imports'] if r['name']==name)
            return struct.unpack('<Q',m.uc.mem_read(0x900000000+record['got'],8))[0]
        m.uc.mem_write(SCRATCH,b'\xa5'*152)
        self.assertEqual(m.call(hook('scePadReadState'),7,SCRATCH+16),0);self.assertEqual(m.opened_dialogs,1)
        data=bytes(m.uc.mem_read(SCRATCH,152));self.assertEqual(data[:16],b'\xa5'*16);self.assertEqual(data[-16:],b'\xa5'*16)
        self.assertEqual(data[16:28],b'\x00'*4+b'\x80'*4+b'\x00'*4)
        self.assertEqual(m.call(hook('sceVideoOutSubmitFlip'),7,3,1,0x12345678),17)
        self.assertEqual(m.rates[-1],(7,0));self.assertEqual(m.flips[-1],(7,3,1,0x12345678))
    def test_native_ui_failure_preserves_original_got(self):
        for case in ('ui_conflict','ui_protect_failure','ui_second_protect_failure'):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0);self.assertEqual(m.ui_writes,[])
            if case=='ui_second_protect_failure':
                self.assertEqual(m.protect_calls[-1],(m.protect_calls[0][0],0x4000,1))
    def test_game_cannot_consume_menu_keyboard_but_original_ime_is_preserved(self):
        m=ModuleMachine('ui_success');self.assertEqual(m.initialize(),0)
        m.allowed.append((SCRATCH,SCRATCH+4096))
        poll=m.exports[prepare.nid('ctr_menu_poll')]
        owned=m.exports[prepare.nid('ctr_menu_ime_owned')]
        self.assertEqual(m.call(poll,7,6),1)
        m.dialog_status=3;m.dialog_chosen=2;self.assertEqual(m.call(poll,7,0),1)
        m.dialog_status=3;m.dialog_chosen=1;self.assertEqual(m.call(poll,7,0),1)
        m.dialog_status=3;m.dialog_chosen=1;self.assertEqual(m.call(poll,7,0),1)
        m.dialog_status=3;m.dialog_chosen=1;self.assertEqual(m.call(poll,7,0),1)
        self.assertEqual(m.call(owned),1);self.assertEqual(m.ime_state,1)
        def hook(name):
            record=next(r for r in UI['imports'] if r['name']==name)
            return struct.unpack('<Q',m.uc.mem_read(0x900000000+record['got'],8))[0]
        m.ime_state=2;m.uc.mem_write(SCRATCH,b'\xa5'*32)
        self.assertEqual(m.call(hook('sceImeDialogGetStatus')),0)
        self.assertEqual(m.call(hook('sceImeDialogGetResult'),SCRATCH),0xffffffff)
        self.assertEqual(m.call(hook('sceImeDialogTerm')),0xffffffff)
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH,32)),b'\xa5'*32)
        self.assertEqual((m.ime_result_calls,m.ime_term_calls),(0,0))
        m.ime_endstatus=1;self.assertEqual(m.call(poll,7,0),1)
        self.assertEqual(m.call(owned),0);self.assertEqual(m.call(poll,7,0),0)
        self.assertEqual((m.ime_result_calls,m.ime_term_calls),(1,1))
        m.ime_state=2;self.assertEqual(m.call(hook('sceImeDialogGetStatus')),2)
        self.assertEqual(m.call(hook('sceImeDialogGetResult'),SCRATCH),0)
        self.assertEqual(m.call(hook('sceImeDialogTerm')),0)
        self.assertEqual((m.ime_result_calls,m.ime_term_calls),(2,2))
    def test_native_join_preserves_system_events_status_flags_background_and_errors(self):
        m=ModuleMachine('ui_graphics');self.assertEqual(m.initialize(),0)
        m.allowed.append((SCRATCH,SCRATCH+4096));m.uc.mem_write(SCRATCH,b'PcFriend\0')
        self.assertEqual(m.call(m.exports[prepare.nid('ctr_session_queue')],SCRATCH),0)
        m.now_us+=300000
        def hook(name):
            record=next(r for r in UI['imports'] if r['name']==name)
            return struct.unpack('<Q',m.uc.mem_read(0x900000000+record['got'],8))[0]
        status=hook('sceSystemServiceGetStatus');event=hook('sceSystemServiceReceiveEvent')
        m.system_status_data=struct.pack('<i',2)+bytes((1,0,1,0,1,0,0,0))
        self.assertEqual(m.call(status,SCRATCH+256),0)
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH+256,12)),m.system_status_data)
        self.assertEqual(m.call(event,SCRATCH+512),0x80a10004)
        m.system_status_data=struct.pack('<i',2)+bytes((0,0,1,0,1,0,0,0))
        self.assertEqual(m.call(status,SCRATCH+256),0)
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH+256,12)),struct.pack('<i',3)+m.system_status_data[4:])
        m.system_event_result=0;self.assertEqual(m.call(event,SCRATCH+512),0)
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH+512,180)),m.system_event_data)
        m.system_event_result=0x80a10004;m.uc.mem_write(SCRATCH+496,b'\xa5'*212)
        self.assertEqual(m.call(event,SCRATCH+512),0)
        raw=bytes(m.uc.mem_read(SCRATCH+496,212));self.assertEqual(raw[:16],b'\xa5'*16);self.assertEqual(raw[-16:],b'\xa5'*16)
        self.assertEqual(struct.unpack_from('<I',raw,16)[0],0x10000002)
        self.assertEqual(struct.unpack_from('<i',raw,16+4+0x8c)[0],0x12345678)
        m.system_status_result=0x80a10003;m.uc.mem_write(SCRATCH+256,b'\xa5'*12)
        self.assertEqual(m.call(status,SCRATCH+256),0x80a10003)
        self.assertEqual(bytes(m.uc.mem_read(SCRATCH+256,12)),b'\xa5'*12)
    def test_native_stock_friend_webapi_join_does_not_need_custom_invitation(self):
        m=ModuleMachine('ui_performance_base');self.assertEqual(m.initialize(),0)
        m.allowed.append((SCRATCH,SCRATCH+4096));before=dict(m.files)
        def hook(name):
            m.uc.mem_write(SCRATCH+0x300,name.encode()+b'\0')
            m.call(m.exports[prepare.nid('ctr_find_hook')],SCRATCH+0x300)
            return m.uc.reg_read(UC_X86_REG_RAX)
        create=hook('sceNpWebApiCreateRequest');send=hook('sceNpWebApiSendRequest')
        read=hook('sceNpWebApiReadData');delete=hook('sceNpWebApiDeleteRequest')
        def request(path,method=0):
            m.uc.mem_write(SCRATCH,path.encode()+b'\0')
            self.assertEqual(m.call(create,1,0,SCRATCH,method,0,SCRATCH+256),0)
            handle=struct.unpack('<q',m.uc.mem_read(SCRATCH+256,8))[0]
            try:
                self.assertEqual(m.call(send,handle,0,0),0,path)
                chunks=[]
                for _ in range(100):
                    m.uc.mem_write(SCRATCH+512,b'\xa5'*69)
                    n=m.call(read,handle,SCRATCH+528,37)
                    self.assertLessEqual(n,37)
                    self.assertEqual(bytes(m.uc.mem_read(SCRATCH+512,16)),b'\xa5'*16)
                    self.assertEqual(bytes(m.uc.mem_read(SCRATCH+565,16)),b'\xa5'*16)
                    if not n:break
                    chunks.append(bytes(m.uc.mem_read(SCRATCH+528,n)))
                return json.loads(b''.join(chunks))
            finally:self.assertEqual(m.call(delete,handle),0)
        for friend in ('PcFriend','OtherFriend'):
            sid='cusa13795-session-'+friend;path='/v1/sessions/'+sid
            self.assertEqual([u['onlineId'] for u in request(path)['members']],[friend])
            self.assertEqual(request(path+'/members',1)['sessionId'],sid)
            doc=request(path)
            self.assertEqual(doc['sessionCreator']['onlineId'],friend)
            self.assertEqual([u['onlineId'] for u in doc['members']],[friend,'DemoPlayerPS4001'])
            self.assertEqual(m.call(m.exports[prepare.nid('ctr_session_due')]),0)
            request(path+'/members/me',3)
            self.assertEqual([u['onlineId'] for u in request(path)['members']],[friend])
        self.assertEqual(request('/v1/users/me/invitations')['size'],0)
        self.assertEqual(request('/v1/users/me/friends/sessions')['sessions'],[])
        for path,data in before.items():
            if not path.endswith('ctr_native_port.log'):self.assertEqual(m.files[path],data)
        self.assertIn(b'CTR native stage=00000073 code=00000001',m.files['/data/GoldHEN/ctr_native_port.log'])
    def test_native_session_update_returns_metadata_with_same_host(self):
        m=ModuleMachine('ui_success');self.assertEqual(m.initialize(),0)
        m.allowed.append((SCRATCH,SCRATCH+4096))
        function=m.exports[prepare.nid('ctr_sessions_json')]
        def request(path,method):
            m.uc.mem_write(SCRATCH,path.encode()+b'\0')
            n=m.call(function,SCRATCH,method,SCRATCH+512,2048)
            self.assertGreater(n,0);self.assertLess(n,2048)
            return json.loads(bytes(m.uc.mem_read(SCRATCH+512,n)))
        own='cusa13795-session-DemoPlayerPS4001'
        self.assertEqual(request('/v1/sessions',1)['sessionId'],own)
        before=request('/v1/sessions/'+own,0)
        self.assertEqual(request('/v1/sessions/'+own,2),before)
        self.assertEqual(before['sessionCreator']['onlineId'],'DemoPlayerPS4001')
        self.assertEqual([u['onlineId'] for u in before['members']],['DemoPlayerPS4001'])
    def test_native_graphics_guards_and_config_load(self):
        for case in ('ui_graphics','ui_bad_patch'):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0)
            for i,p in enumerate(UI['patches']):
                value=bytes(m.uc.mem_read(0x900000000+p['rva']+p['index'],p['length']))
                self.assertEqual(value,bytes.fromhex(p['replacement'] if case=='ui_graphics' and i<2 else p['original']))
            m.allowed.append((SCRATCH,SCRATCH+4096))
            record=next(r for r in UI['imports'] if r['name']=='sceVideoOutSubmitFlip');pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+record['got'],8))[0]
            self.assertEqual(m.call(pointer,7,0,1,9),17);self.assertEqual(m.rates[-1],(7,0))
    def test_native_performance_patches_base_and_pro_without_changing_online_or_hardware_mode(self):
        for case in ('ui_performance_base','ui_performance_pro'):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0)
            for i,p in enumerate(UI['patches']):
                actual=bytes(m.uc.mem_read(0x900000000+p['rva']+p['index'],p['length']))
                self.assertEqual(actual,bytes.fromhex(p['replacement'] if i in (0,2,3,6,7) else p['original']))
            self.assertTrue(any(n==1 for n,a,s in m.cache_writes))
            self.assertEqual(m.files['/data/ryunet/users/12345678/settings.ini'],b'version=1\nfps=60\nmotion_blur=1\npro_1080=1\nperformance=1\nfriends=PcFriend,OtherFriend\n')
            m.allowed.append((SCRATCH,SCRATCH+4096))
            # Execute the game's actual display-setup instructions with each
            # hardware flag. Both must keep 1920x1080 output and set scene scale
            # to 2/3; neither may change the hardware flag itself.
            base=0x900000000;flag=base+0x2aedea8;m.map(flag,1)
            data=Path(P[0]['elf']).read_bytes();elf,_,ph,_,_=prepare.parse_elf(data)
            seg=next(s for s in ph if s['type']==1 and s['vaddr']<=0x13aa66e<s['vaddr']+s['filesz'])
            off=seg['offset']+0x13aa66e-seg['vaddr'];m.uc.mem_write(base+0x13aa66e,bytes(elf[off:off+5]))
            for neo in (0,1):
                m.uc.mem_write(flag,bytes([neo]));display=SCRATCH+512;settings=SCRATCH+2048
                m.uc.mem_write(display+0x540,struct.pack('<IIf',1920,1080,1.0));m.uc.mem_write(settings+0x48,struct.pack('<f',4/3))
                m.uc.reg_write(UC_X86_REG_R14,display);m.uc.reg_write(UC_X86_REG_R12,settings)
                m.uc.emu_start(base+0x13a9da5,base+0x13a9dc0,count=40)
                width,height,scale=struct.unpack('<IIf',m.uc.mem_read(display+0x540,12))
                self.assertEqual((width,height),(1920,1080));self.assertAlmostEqual(scale,2/3,places=6)
                self.assertEqual(m.uc.mem_read(flag,1)[0],neo)
    def test_native_performance_signature_or_permission_failure_leaves_entire_graphics_group_untouched(self):
        for case in ('ui_performance_bad_patch','ui_performance_protect_failure'):
            m=ModuleMachine(case)
            before=[bytes(m.uc.mem_read(0x900000000+p['rva'],p['size'])) for p in UI['patches']]
            self.assertEqual(m.initialize(),0)
            after=[bytes(m.uc.mem_read(0x900000000+p['rva'],p['size'])) for p in UI['patches']]
            self.assertEqual(after,before);self.assertEqual(len(m.ui_writes),len(UI['imports']))
            if case=='ui_performance_protect_failure':self.assertEqual(len(m.protect_calls),7)
    def test_native_quality_scales_real_setup_and_preserves_all_effects_and_selected_fps(self):
        for case in ('ui_quality_base','ui_quality_pro','ui_quality_combined'):
            m=ModuleMachine(case);before=m.files['/data/ryunet/users/12345678/settings.ini'];self.assertEqual(m.initialize(),0)
            for i,p in enumerate(UI['patches']):
                active=i in (2,3,6,7) or (case=='ui_quality_combined' and i in (4,5))
                actual=bytes(m.uc.mem_read(0x900000000+p['rva']+p['index'],p['length']))
                self.assertEqual(actual,bytes.fromhex(p['alternate'] if active else p['original']))
            for w in UI['unchanged_effects']:
                self.assertEqual(bytes(m.uc.mem_read(0x900000000+w['rva'],w['size'])),bytes.fromhex(w['bytes']))
            self.assertEqual(m.files['/data/ryunet/users/12345678/settings.ini'],before)
            m.allowed.append((SCRATCH,SCRATCH+4096));base=0x900000000
            data=Path(P[0]['elf']).read_bytes();elf,_,ph,_,_=prepare.parse_elf(data)
            def raw(rva,size):
                seg=next(s for s in ph if s['type'] in (1,0x61000010) and s['vaddr']<=rva and rva+size<=s['vaddr']+s['filesz'])
                off=seg['offset']+rva-seg['vaddr'];return bytes(elf[off:off+size])
            flag=base+0x2aedea8;m.map(flag,1);m.uc.mem_write(base+0x13aa66e,raw(0x13aa66e,5))
            for neo in (0,1):
                m.uc.mem_write(flag,bytes([neo]));display=SCRATCH+512;settings=SCRATCH+2048
                m.uc.mem_write(display+0x540,struct.pack('<IIf',1920,1080,1.0));m.uc.mem_write(settings+0x48,struct.pack('<f',4/3))
                m.uc.reg_write(UC_X86_REG_R14,display);m.uc.reg_write(UC_X86_REG_R12,settings)
                m.uc.emu_start(base+0x13a9da5,base+0x13a9dc0,count=40)
                width,height,scale=struct.unpack('<IIf',m.uc.mem_read(display+0x540,12))
                self.assertEqual((width,height),(1920,1080));self.assertAlmostEqual(scale,480/1080,places=6)
                self.assertEqual(m.uc.mem_read(flag,1)[0],neo)
    def test_legacy_effects_key_does_not_remove_any_effect_or_enable_new_options(self):
        m=ModuleMachine('ui_effects_legacy');before=m.files['/data/ryunet/users/12345678/settings.ini'];self.assertEqual(m.initialize(),0)
        for w in UI['patches']+UI['unchanged_effects']:
            self.assertEqual(bytes(m.uc.mem_read(0x900000000+w['rva'],w['size'])),bytes.fromhex(w['bytes']))
        self.assertEqual(m.files['/data/ryunet/users/12345678/settings.ini'],before)
    def test_scene_scale_consumer_and_original_target_dimension_math_on_base_and_pro(self):
        data=Path(P[0]['elf']).read_bytes();elf,_,ph,_,_=prepare.parse_elf(data)
        def raw(rva,size):
            seg=next(s for s in ph if s['type'] in (1,0x61000010) and s['vaddr']<=rva and rva+size<=s['vaddr']+s['filesz'])
            off=seg['offset']+rva-seg['vaddr'];return bytes(elf[off:off+size])
        for case,scale,active in (('ui_quality_base',480/1080,True),('ui_performance_base',720/1080,True),('ui_effects_legacy',1.0,False)):
            m=ModuleMachine(case);base=0x900000000
            # Load the complete original helper BEFORE initialization patches it.
            for rva,size in ((0x13e2eb0,0x7b),(0x1cacdd4,4),(0x32fdf7,0x21)):
                m.map(base+rva,size);m.uc.mem_write(base+rva,raw(rva,size))
            m.map(base+0x2aedea0,16)
            for rva,code in ((0x1be8cc8,b'\xb8\x01\0\0\0\xc3'),(0x1be8cb8,b'\xc3'),(0x1bea208,b'\xb8\0\0\0\0\xc3')):
                m.map(base+rva,len(code));m.uc.mem_write(base+rva,code)
            self.assertEqual(m.initialize(),0)
            m.allowed.extend(((SCRATCH,SCRATCH+4096),(base+0x2aedea0,base+0x2aedea9)))
            obj=SCRATCH+512;vtable=SCRATCH+2048;target=SCRATCH+128
            m.uc.mem_write(obj,struct.pack('<Q',vtable));m.uc.mem_write(vtable+0xc0,struct.pack('<Q',STUB+0x900))
            m.uc.mem_write(obj+0x548,struct.pack('<f',scale))
            for neo in (0,1):
                for lazy in (False,True):
                    m.uc.mem_write(base+0x2aedea0,bytes([0 if lazy else 1])+bytes(7)+bytes([neo]))
                    m.uc.mem_write(base+0x1bea208,b'\xb8'+struct.pack('<I',neo)+b'\xc3')
                    m.uc.ctl_remove_cache(base+0x1bea208,base+0x1bea20e)
                    for input_scale in (1.0,0.5):
                        m.uc.reg_write(UC_X86_REG_XMM0,struct.unpack('<I',struct.pack('<f',input_scale))[0])
                        m.call(base+0x13e2eb0,obj)
                        result=struct.unpack('<f',struct.pack('<I',m.uc.reg_read(UC_X86_REG_XMM0)&0xffffffff))[0]
                        self.assertAlmostEqual(result,input_scale*scale if active or neo else 1.0,places=6)
                        self.assertEqual(m.uc.mem_read(base+0x2aedea8,1)[0],neo,(case,neo,lazy))
                    # Execute the game's own target width/height conversion.
                    m.uc.mem_write(base+0x2aedea0,b'\x01')
                    m.uc.reg_write(UC_X86_REG_XMM0,0x3f800000);m.call(base+0x13e2eb0,obj)
                    returned=m.uc.reg_read(UC_X86_REG_XMM0)&0xffffffff
                    frame=STACK+0x10000;m.uc.reg_write(UC_X86_REG_RBP,frame);m.uc.reg_write(UC_X86_REG_RBX,target)
                    m.uc.mem_write(frame-0x44,struct.pack('<I',returned));m.uc.mem_write(target+0x58,struct.pack('<II',1920,1080))
                    m.uc.emu_start(base+0x32fdf7,base+0x32fe18,count=12)
                    dims=struct.unpack('<II',m.uc.mem_read(target+0x58,8))
                    expected=(853,480) if case=='ui_quality_base' else (1280,720) if case=='ui_performance_base' else (1920,1080)
                    self.assertEqual(dims,expected)
    def test_native_shadow_controls_use_consistent_shader_flags_and_normal_camera_disable_path(self):
        m=ModuleMachine('ui_shadows_alone');self.assertEqual(m.initialize(),0);base=0x900000000
        self.assertEqual([p['name'] for p in UI['patches'][4:6]],['shadows_cascade_fade','shadows_hero_gate'])
        for i,p in enumerate(UI['patches']):
            self.assertEqual(bytes(m.uc.mem_read(base+p['rva']+p['index'],p['length'])),bytes.fromhex(p['replacement'] if i in (4,5) else p['original']))
        m.allowed.append((SCRATCH,SCRATCH+4096))
        data=Path(P[0]['elf']).read_bytes();elf,_,ph,_,_=prepare.parse_elf(data)
        def raw(rva,size):
            seg=next(s for s in ph if s['type'] in (1,0x61000010) and s['vaddr']<=rva and rva+size<=s['vaddr']+s['filesz'])
            off=seg['offset']+rva-seg['vaddr'];return bytes(elf[off:off+size])
        for rva,size in ((0x1cb1670,16),(0x1ca7448,8),(0xaf89b6,7),(0xaf883a,14),(0xaf8923,4),(0x35769b,0xb9)):
            m.map(base+rva,size);m.uc.mem_write(base+rva,raw(rva,size))
        threshold=raw(0x1ca744c,4);self.assertGreater(struct.unpack('<f',threshold)[0],0)
        for fade in (-1.0,0.0,0.5,1.0):
            m.uc.mem_write(SCRATCH,bytes([0xa5])*4096);m.uc.mem_write(SCRATCH+0x28c,struct.pack('<f',fade))
            m.uc.reg_write(UC_X86_REG_R15,SCRATCH);m.uc.reg_write(UC_X86_REG_RDX,0x7777777777777777)
            m.uc.reg_write(UC_X86_REG_R8,0x8888888888888888)
            m.uc.reg_write(UC_X86_REG_XMM2,int.from_bytes(threshold,'little'))
            m.uc.emu_start(base+0xaf87d2,base+0xaf8808,count=25)
            self.assertEqual(m.uc.reg_read(UC_X86_REG_R8)&255,0);self.assertEqual(m.uc.reg_read(UC_X86_REG_RDX)&255,0)
            self.assertEqual(m.uc.reg_read(UC_X86_REG_XMM0),0)
            m.uc.reg_write(UC_X86_REG_R14,SCRATCH+64)
            m.uc.emu_start(base+0xaf883a,base+0xaf8848,count=3)
            m.uc.reg_write(UC_X86_REG_RDI,SCRATCH+1664)
            m.uc.emu_start(base+0xaf8923,base+0xaf8927,count=1)
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH+88,8)),bytes([0,0,0xa5,0xa5,0,0,0,0]))
            self.assertEqual(m.uc.mem_read(SCRATCH+1664+0x64,1)[0],0)
            # The game's original engine consumes exactly that enable byte:
            # it disables all four split cameras and marks the splits invalid.
            obj=SCRATCH+2048;array=SCRATCH+256
            m.uc.mem_write(obj+0x3c0,struct.pack('<Q',SCRATCH+128));m.uc.mem_write(SCRATCH+160,struct.pack('<Q',array))
            cameras=[SCRATCH+512+i*0x120 for i in range(4)]
            m.uc.mem_write(array,struct.pack('<4Q',*cameras));before=bytes(m.uc.mem_read(SCRATCH,4096))
            m.uc.reg_write(UC_X86_REG_R13,SCRATCH+1664);m.uc.reg_write(UC_X86_REG_RBX,obj)
            m.uc.emu_start(base+0x35769b,base+0x357754,count=50)
            expected=bytearray(before)
            for camera in cameras:expected[camera-SCRATCH+0xf2]=0
            expected[obj-SCRATCH+0x1ec:obj-SCRATCH+0x1f0]=bytes([255])*4
            self.assertEqual(bytes(m.uc.mem_read(SCRATCH,4096)),bytes(expected))
        # All hero-handle fallback paths meet at this patched gate. Execute
        # original stack stores and branch to the original neutral-bundle path.
        for enabled in (0,1,255):
            frame=STACK+0x10000;m.uc.reg_write(UC_X86_REG_RBP,frame)
            m.uc.reg_write(UC_X86_REG_R12,0xf00dcafe12340000|enabled);m.uc.reg_write(UC_X86_REG_RBX,SCRATCH+1664)
            m.uc.emu_start(base+0xaf7dc9,base+0xaf8283,count=12)
            self.assertEqual(m.uc.reg_read(UC_X86_REG_RIP),base+0xaf8283)
            self.assertEqual(m.uc.reg_read(UC_X86_REG_R12),0xf00dcafe12340000)
            self.assertEqual(m.uc.mem_read(frame-0x82,1)[0],0)
    def test_native_new_graphics_failure_preserves_every_window_and_legacy_effects(self):
        for case in ('ui_shadows_bad_patch','ui_shadows_protect_failure','ui_quality_bad_patch','ui_quality_protect_failure'):
            m=ModuleMachine(case);before=[bytes(m.uc.mem_read(0x900000000+p['rva'],p['size'])) for p in UI['patches']]
            self.assertEqual(m.initialize(),0)
            after=[bytes(m.uc.mem_read(0x900000000+p['rva'],p['size'])) for p in UI['patches']]
            self.assertEqual(after,before);self.assertEqual(len(m.ui_writes),len(UI['imports']))
            for w in UI['unchanged_effects']:
                self.assertEqual(bytes(m.uc.mem_read(0x900000000+w['rva'],w['size'])),bytes.fromhex(w['bytes']))
            if case.endswith('protect_failure'):self.assertEqual(len(m.protect_calls),7)
    def test_success_uses_only_owned_port_slots(self):
        m=ModuleMachine('success');self.assertEqual(m.initialize(),0)
        self.assertTrue(any(n==0 for n,a,s in m.cache_writes));self.assertTrue(any(n==1 for n,a,s in m.cache_writes));self.assertTrue(all(s==8 for n,a,s in m.cache_writes))
        count=len(m.cache_writes);self.assertEqual(m.initialize(),0);self.assertEqual(len(m.cache_writes),count)
    def test_wrong_image_does_not_modify_game_memory(self):
        for case in ('wrong_marker','readonly_cache'):
            m=ModuleMachine(case);self.assertEqual(m.initialize(),0xffffffff);self.assertEqual(m.cache_writes,[])
    def test_later_toolkit_initialization_and_real_console_user(self):
        m=ModuleMachine('late_toolkit');self.assertEqual(m.initialize(),0);self.assertFalse(any(n==1 for n,a,s in m.cache_writes));m.include_toolkit=True
        record=next(r for r in P[0]['records'] if r['name']=='sceNpCheckNpAvailabilityA');pointer=struct.unpack('<Q',m.uc.mem_read(0x900000000+record['cache'],8))[0]
        m.allowed.append((SCRATCH,SCRATCH+4096))
        self.assertEqual(m.call(pointer),0);self.assertTrue(any(n==1 for n,a,s in m.cache_writes))
        record=next(r for r in P[1]['records'] if r['name']=='sceNpGetState');pointer=struct.unpack('<Q',m.uc.mem_read(0x904000000+record['cache'],8))[0]
        self.assertEqual(m.call(pointer,0x12345678,SCRATCH),0);self.assertEqual(struct.unpack('<i',m.uc.mem_read(SCRATCH,4))[0],2)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/native-bridge-test-result.json').write_text(json.dumps({'successful':result.wasSuccessful(),'test_groups':result.testsRun,'scope':'actual PS4 ABI module and relocations, with simulated module metadata and filesystem failures; every emulated memory write checked'},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
