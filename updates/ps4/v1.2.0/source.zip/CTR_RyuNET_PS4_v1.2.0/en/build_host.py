from pathlib import Path
import subprocess,json,os
ROOT=Path(__file__).resolve().parent
LLVM=Path(os.environ.get('CTR_LLVM_BIN',ROOT.parent/'ps4-online/llvm/bin'))
SRC=ROOT/'src';BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
def run(args):
    p=subprocess.run([str(x) for x in args],capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
objects=[]
for name in ('online_core','mini','identity_hash','installation','settings','profile','friends','sessions','menu','updates','updater','frame_limit','net_tunnel','runtime_net_tunnel','runtime_net_ping','social','net_transport'):
    obj=BUILD/(name+'-host.obj')
    run([LLVM/'clang.exe','--target=x86_64-pc-windows-msvc','-ffreestanding','-fno-builtin','-fno-stack-protector','-mno-stack-arg-probe','-O1','-Wall','-Wextra','-Werror','-I'+str(SRC),'-c',SRC/(name+'.c'),'-o',obj]);objects.append(obj)
run([LLVM/'lld.exe','-flavor','link','/dll','/noentry','/machine:x64','/out:'+str(BUILD/'ctr_core_test.dll'),*objects])
print(json.dumps({'built':str(BUILD/'ctr_core_test.dll')}))
