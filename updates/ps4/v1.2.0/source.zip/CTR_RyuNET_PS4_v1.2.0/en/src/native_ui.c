// SPDX-License-Identifier: GPL-2.0-only
// No workers, framebuffer access, driver replacements or automatic GoldHEN load.
#include "menu.h"
#include "frame_limit.h"
#include "sessions.h"
#include "profile.h"
#include "installation.h"
#include "updates.h"
extern int64_t ctr_syscall(int64_t,...);
typedef struct {uint64_t address;uint32_t size;int32_t protection;} Segment;
typedef struct {uint64_t size;char name[256];Segment segments[4];uint32_t count;uint8_t fingerprint[20];} Module;
typedef struct {const char *name;uint64_t got,unresolved;void *original,*replacement;} UiImport;
typedef struct {const char *name;uint64_t rva;uint32_t size,index,length;uint8_t bytes[64],replacement[64],alternate[64];} UiPatch;
typedef struct {const char *name,*nid;uint64_t got,unresolved;} UiSymbol;
#include "ui_profile.h"
static uint64_t game_base;
static Module game;
static void (*log_event)(int32_t,int32_t);
static int32_t handles[256];
static uint64_t handle_count;
static int32_t (*pad_read)(int32_t,void*);
static int32_t (*set_rate)(int32_t,int32_t);
static int32_t (*submit_flip)(int32_t,int32_t,uint32_t,int64_t);
static int32_t (*ime_status)(void),(*ime_result)(CtrImeResult*),(*ime_term)(void);
static int32_t (*system_status)(void*),(*system_event)(void*);
static int32_t (*user_name)(int32_t,char*,size_t);
static int32_t game_user=-1;
static CtrProfile disk_profile;
static int disk_profile_valid;
static int32_t (*secure_random)(void*,size_t);
static char user_directory[64];
static int foreground;
static uint32_t system_seen;
static uint32_t ime_guard_seen;
static int32_t rate_handle=-1,last_rate=-1,rate_failures;
static int32_t (*query_memory)(void*,void**,void**,int32_t*);
void *ctr_frame_original0,*ctr_frame_original1,*ctr_frame_original2,*ctr_frame_original3;
extern void ctr_frame_hook0(void),ctr_frame_hook1(void),ctr_frame_hook2(void),ctr_frame_hook3(void);
static void trace(int32_t stage,int32_t code){if(log_event)log_event(stage,code);}
static int32_t game_user_name(int32_t user,char *out,size_t capacity){
    if(user!=game_user)return user_name(user,out,capacity);
    if(!out||!capacity)return (int32_t)0x80960005;
    const char *name=ctr_player_name();size_t n=ctr_strlen(name);
    if(n+1>capacity)return (int32_t)0x8096000a;
    ctr_memcpy(out,name,n+1);return 0;
}
int ctr_native_profile_scope(int32_t user){
    ctr_memset(user_directory,0,sizeof(user_directory));if(user<0)return -1;
    static const char prefix[]="/data/ryunet/users/",digits[]="0123456789abcdef";
    size_t n=sizeof(prefix)-1;ctr_memcpy(user_directory,prefix,n);
    for(size_t i=0;i<8;i++)user_directory[n+i]=digits[((uint32_t)user>>((7-i)*4))&15];
    return 0;
}
static int user_path(const char *path,char out[128]){
    static const char prefix[]="/data/ryunet/";size_t n=sizeof(prefix)-1;
    if(!user_directory[0]||ctr_strncmp(path,prefix,n))return -1;
    const char *leaf=path+n;
    // Only fixed local basenames; a caller cannot escape into another profile.
    for(size_t i=0;leaf[i];i++)if(!((leaf[i]>='a'&&leaf[i]<='z')||leaf[i]=='.'||leaf[i]=='_'))return -1;
    size_t a=ctr_strlen(user_directory),b=ctr_strlen(leaf);if(!b||a+b+2>128||ctr_strstr(leaf,".."))return -1;
    ctr_memcpy(out,user_directory,a);out[a++]='/';ctr_memcpy(out+a,leaf,b+1);return 0;
}
static int ensure_user_directory(void){
    if(!user_directory[0])return -1;
    const char *paths[]={"/data/ryunet","/data/ryunet/users",user_directory};
    for(size_t i=0;i<3;i++){int64_t r=ctr_syscall(136,paths[i],i==2?0755:0777);if(r<0&&r!=-17)return -1;}
    return 0;
}
static int read_private(const char *path,void *out,size_t capacity){
    char scoped[128];if(user_path(path,scoped))return -1;
    int64_t fd=ctr_syscall(5,scoped,0,0);if(fd<0)return fd==-2?-2:-1;
    char *text=out;size_t size=0;int failed=0;
    while(size<capacity){int64_t n=ctr_syscall(3,fd,text+size,capacity-size);if(n<0){failed=1;break;}if(!n)break;size+=(size_t)n;}
    if(ctr_syscall(6,fd)<0)failed=1;
    return failed?-1:(int)size;
}
static int read_profile(const char *path,CtrProfile *out){
    char text[129];int size=read_private(path,text,sizeof(text));
    return size<0?-1:ctr_profile_parse_record(out,text,(size_t)size);
}
static int write_private(const char *path,const char *temporary,const void *data,size_t length,int mode){
    char scoped[128],temp[128];if(user_path(path,scoped)||user_path(temporary,temp))return -1;
    const char *text=data;int64_t fd=ctr_syscall(5,temp,0x601,mode);if(fd<0)return -1;
    size_t n=0;int result=0;
    while(n<(size_t)length){int64_t written=ctr_syscall(4,fd,text+n,(size_t)length-n);if(written<=0){result=-1;break;}n+=(size_t)written;}
    if(ctr_syscall(6,fd)<0)result=-1;
    if(!result&&ctr_syscall(128,temp,scoped)<0)result=-1;
    if(result)ctr_syscall(10,temp);return result;
}
static int generate_private(void *out,size_t n){return secure_random?secure_random(out,n):-1;}
static const CtrIdentityIo identity_io={read_private,write_private,generate_private};
int ctr_native_profile_load(CtrProfile *out){
    disk_profile_valid=0;ctr_memset(&disk_profile,0,sizeof(disk_profile));
    ctr_identity_activate(&identity_io,0);
    int r=read_profile("/data/ryunet/profile.ini",&disk_profile);
    if(r)r=read_profile("/data/ryunet/profile.ini.bak",&disk_profile);
    if(r)return -1;
    // The new user namespace never imports a legacy shared/ownerless profile.
    // Configuration from the older global directory is left untouched.
    if(!disk_profile.owned)return -3;
    disk_profile_valid=1;
    // A configured owned profile with a missing/corrupt key stays offline.
    // Never silently regenerate its key or fall back to an older legacy name.
    if(ctr_identity_activate(&identity_io,disk_profile.owned))return -2;
    *out=disk_profile;return 0;
}
static int write_profile(const char *path,const char *temporary,const CtrProfile *profile){
    char text[128];int length=ctr_profile_format_record(profile,text,sizeof(text));if(length<0)return -1;
    return write_private(path,temporary,text,(size_t)length,0600);
}
static int32_t save_profile(const char *name){
    if(!ctr_profile_name_valid(name))return -1;
    if(ensure_user_directory()){trace(113,-1);return -1;}
    CtrProfile next={{0},1};ctr_memcpy(next.nickname,name,ctr_strlen(name)+1);
    int r=next.owned?ctr_identity_prepare(&identity_io,!(disk_profile_valid&&disk_profile.owned)):0;
    if(!r&&disk_profile_valid)r=write_profile("/data/ryunet/profile.ini.bak","/data/ryunet/profile.ini.bak.tmp",&disk_profile);
    if(!r)r=write_profile("/data/ryunet/profile.ini","/data/ryunet/profile.ini.tmp",&next);
    if(!r){disk_profile=next;disk_profile_valid=1;ctr_profile_publish_record(&next);}
    trace(113,r);return r;
}
static int ime_guard(int stage,uint32_t bit){
    if(!ctr_menu_ime_owned()){__atomic_store_n(&ime_guard_seen,0,__ATOMIC_RELAXED);return 0;}
    if(!(__atomic_fetch_or(&ime_guard_seen,bit,__ATOMIC_RELAXED)&bit))trace(stage,0);
    return 1;
}
static int32_t game_ime_status(void){return ime_guard(80,1)?0:ime_status();}
static int32_t game_ime_result(CtrImeResult *result){return ime_guard(82,4)?-1:ime_result(result);}
static int32_t game_ime_term(void){return ime_guard(81,2)?-1:ime_term();}
static void system_observed(uint32_t bit,int32_t code){if(!(__atomic_fetch_or(&system_seen,bit,__ATOMIC_RELAXED)&bit))trace(bit==1?99:100,code);}
static int32_t game_system_status(void *out){
    int32_t r=system_status(out);system_observed(1,r);
    if(!r&&out){
        uint8_t *data=out;int front=!data[4]&&!data[5];
        __atomic_store_n(&foreground,front,__ATOMIC_RELEASE);
        if(front&&!ctr_menu_active()&&ctr_session_due()){
            int32_t count;ctr_memcpy(&count,data,4);
            if(count>=0&&count<0x7fffffff){count++;ctr_memcpy(data,&count,4);}
        }
    }else __atomic_store_n(&foreground,0,__ATOMIC_RELEASE);
    return r;
}
static int32_t game_system_event(void *out){
    int32_t r=system_event(out);system_observed(2,r);
    if((uint32_t)r==0x80a10004U&&out&&__atomic_load_n(&foreground,__ATOMIC_ACQUIRE)&&!ctr_menu_active()&&ctr_session_event(out,CTR_SESSION_EVENT_BYTES))return 0;
    return r;
}
static int region(uint64_t address,size_t size){
    for(uint32_t i=0;i<game.count&&i<4;i++){
        Segment *s=&game.segments[i];
        if(address>=s->address&&address-s->address<=s->size&&size<=s->size-(address-s->address))return s->protection;
    }return 0;
}
static void render_snapshot(int phase){
    // Exact-image igGraphicsDevice singleton, verified constructor vtables and
    // display fields. Never follow an unchecked heap pointer or write the object.
    trace(140,phase);
    if(!(region(game_base+0x2aebce0,8)&1)){trace(141,-1);return;}
    uint64_t object=*(volatile uint64_t*)(game_base+0x2aebce0);
    if(!object){trace(141,-2);return;}
    if(!query_memory){trace(141,-3);return;}
    if((object&7)||object>=0x800000000000ULL-0x54c){trace(141,-4);return;}
    void *first=0,*last=0;int32_t permission=0;
    if(query_memory((void*)object,&first,&last,&permission)){trace(141,-5);return;}
    if(!(permission&1)||(uint64_t)first>object||(uint64_t)last<object+0x54c){trace(141,-6);return;}
    uint64_t vtable=*(volatile uint64_t*)object;
    if(vtable!=game_base+0x2796c80&&vtable!=game_base+0x2797500){trace(141,-7);return;}
    uint32_t width=*(volatile uint32_t*)(object+0x540),height=*(volatile uint32_t*)(object+0x544);
    uint32_t scale=*(volatile uint32_t*)(object+0x548);
    if(width<320||width>7680||height<240||height>4320||scale<0x3e800000||scale>0x40000000){trace(141,-8);return;}
    if(object!=*(volatile uint64_t*)(game_base+0x2aebce0)){trace(141,-9);return;}
    // This is renderer state, not a GPU readback of all attachment dimensions.
    trace(141,0);trace(142,(int32_t)width);trace(143,(int32_t)height);trace(144,(int32_t)scale);
}
static void first_presentation_snapshot(void){render_snapshot(1);}
static void *symbol(const char *name){
    const UiSymbol *entry=0;
    static const UiSymbol random_symbol={"sceRandomGetRandomNumber","PI7jIZj4pcE",0,0};
    if(!ctr_strcmp(name,random_symbol.name))entry=&random_symbol;
    for(size_t i=0;i<sizeof(ui_symbols)/sizeof(ui_symbols[0]);i++)if(!ctr_strcmp(name,ui_symbols[i].name)){entry=&ui_symbols[i];break;}
    for(uint64_t i=0;i<handle_count;i++){
        void *result=0;
        if(ctr_syscall(591,handles[i],name,&result)==0&&result)return result;
        if(entry&&ctr_syscall(591,handles[i],entry->nid,&result)==0&&result)return result;
    }
    if(entry&&entry->got&&(region(game_base+entry->got,8)&1)){
        uint64_t pointer=*(uint64_t*)(game_base+entry->got);
        if(pointer&&pointer<0x800000000000ULL&&pointer!=game_base+entry->unresolved)return (void*)pointer;
    }
    return 0;
}
static int protect(uint64_t address,size_t size,int protection){
    uint64_t start=address&~0x3fffULL,end=(address+size+0x3fffULL)&~0x3fffULL;
    return (int)ctr_syscall(74,start,(size_t)(end-start),protection);
}
static int patch_graphics(const CtrSettings *s,int pro){
    _Static_assert(sizeof(ui_patches)/sizeof(ui_patches[0])==8,"graphics profile order");
    // Revision 13's legacy light_effects key is parsed for migration only.
    // Quality mode preserves every effect and the user's manual blur choice.
    int enabled[]={!s->motion_blur||(s->performance&&!s->low_quality),pro&&s->pro_1080&&!s->performance&&!s->low_quality,
                   s->performance||s->low_quality,s->performance||s->low_quality,s->no_shadows,s->no_shadows,
                   s->performance||s->low_quality,s->performance||s->low_quality};
    int change[8];uint64_t pages[8];int permissions[8];size_t page_count=0;
    // Validate every complete instruction window before writing any graphics
    // byte. An unexpected image or a partial patch leaves the group untouched.
    for(size_t n=0;n<8;n++){
        const UiPatch *p=&ui_patches[n];uint64_t address=game_base+p->rva;
        int permission=region(address,p->size);if(!(permission&1)||p->size>64||!p->length||p->index+p->length>p->size)return -1;
        const uint8_t *window=(const uint8_t*)address;int original=1,replaced=1,alternate=1,desired=1;
        for(uint32_t i=0;i<p->size;i++){
            uint8_t alternative=i>=p->index&&i-p->index<p->length?p->replacement[i-p->index]:p->bytes[i];
            uint8_t lower=i>=p->index&&i-p->index<p->length?p->alternate[i-p->index]:p->bytes[i];
            if(window[i]!=p->bytes[i])original=0;
            if(window[i]!=alternative)replaced=0;
            if(window[i]!=lower)alternate=0;
            if(window[i]!=(enabled[n]?(s->low_quality?lower:alternative):p->bytes[i]))desired=0;
        }
        if(!original&&!replaced&&!alternate)return -2;
        change[n]=!desired;if(desired)continue;
        uint64_t first=(address+p->index)&~0x3fffULL,last=(address+p->index+p->length-1)&~0x3fffULL;
        for(uint64_t page=first;page<=last;page+=0x4000){
            size_t j=0;while(j<page_count&&pages[j]!=page)j++;
            if(j<page_count){if(permissions[j]!=permission)return -1;}
            else {if(page_count==8)return -1;pages[page_count]=page;permissions[page_count++]=permission;}
        }
    }
    // Acquire every page first. A denied page cannot leave a half-enabled mode.
    for(size_t i=0;i<page_count;i++)if(protect(pages[i],0x4000,permissions[i]|2)){
        for(size_t j=0;j<i;j++)trace(57,protect(pages[j],0x4000,permissions[j]));
        return -3;
    }
    for(size_t n=0;n<8;n++)if(change[n]){
        const UiPatch *p=&ui_patches[n];
        ctr_memcpy((void*)(game_base+p->rva+p->index),enabled[n]?(s->low_quality?p->alternate:p->replacement):p->bytes+p->index,p->length);
    }
    int result=0;for(size_t i=0;i<page_count;i++){int r=protect(pages[i],0x4000,permissions[i]);trace(57,r);if(r)result=-4;}
    return result;
}
static int32_t save_settings(const CtrSettings *s){
    char text[1024];int length=ctr_settings_format(s,text,sizeof(text));if(length<0)return -1;
    if(ensure_user_directory())return -1;
    int result=write_private("/data/ryunet/settings.ini","/data/ryunet/settings.ini.tmp",text,(size_t)length,0600);
    if(!result&&set_rate&&rate_handle>=0){
        int32_t r=set_rate(rate_handle,0);trace(54,r);if(!r){last_rate=0;rate_failures=0;}
    }
    trace(56,result);return result;
}
static void load_settings(void){
    CtrSettings settings;ctr_settings_defaults(&settings);
    char text[4097];int size=read_private("/data/ryunet/settings.ini",text,sizeof(text));
    if(size>=0){
        if(ctr_settings_parse(&settings,text,(size_t)size)<0){ctr_settings_defaults(&settings);trace(55,-1);}
    }
    ctr_settings_publish(&settings);
}
static int32_t read_pad(int32_t handle,void *data){
    int32_t result=pad_read(handle,data);if(result<0||!data)return result;
    uint8_t *p=data;
    if(p[76]){
        uint32_t buttons;ctr_memcpy(&buttons,p,4);
        if(ctr_menu_poll(handle,buttons)){ctr_memset(p,0,12);p[4]=p[5]=p[6]=p[7]=128;p[52]=0;}
    }return result;
}
// Keep the display at native 60 Hz; the presentation scheduler caps frames at
// 30 or 60 when selected, avoiding two independent 30-Hz throttles.
static int desired_rate(void){return 0;}
static int32_t change_rate(int32_t handle,int32_t requested){
    (void)requested;int rate=desired_rate();int32_t result=set_rate(handle,rate);
    if(!result){rate_handle=handle;last_rate=rate;rate_failures=0;}trace(54,result);return result;
}
static int32_t flip(int32_t handle,int32_t index,uint32_t mode,int64_t argument){
    ctr_frame_wait(4);
    int rate=desired_rate();
    if((rate_handle!=handle||last_rate!=rate)&&rate_failures<3){
        int32_t r=set_rate(handle,rate);trace(54,r);
        if(!r){rate_handle=handle;last_rate=rate;rate_failures=0;}else rate_failures++;
    }
    return submit_flip(handle,index,mode,argument);
}
int ctr_ui_initialize(uint64_t base,const void *module,int32_t user,void(*record)(int32_t,int32_t),int32_t(*load_module)(uint16_t)){
    if(!module||!base||user<0)return -1;
    game_base=base;game=*(const Module*)module;log_event=record;
    handle_count=0;if(ctr_syscall(592,handles,(size_t)256,&handle_count)!=0||handle_count>256)return -2;
    load_settings();
    // These optional OS modules need not be loaded by CTR until an error or
    // keyboard prompt occurs. Load them normally, outside any module initializer.
    if(load_module){
        if(!symbol("sceMsgDialogInitialize"))trace(47,load_module(0x00a4));
        if(!symbol("sceImeDialogInit"))trace(46,load_module(0x0096));
        // The real PS4 CSPRNG module, resolved only after a successful load;
        // no optional import can jump through an unresolved PLT entry.
        if(!symbol("sceRandomGetRandomNumber"))trace(170,load_module(0x00ba));
        handle_count=0;if(ctr_syscall(592,handles,(size_t)256,&handle_count)!=0||handle_count>256)return -2;
    }
    secure_random=(__typeof__(secure_random))symbol("sceRandomGetRandomNumber");
    CtrMenuApi menu;ctr_memset(&menu,0,sizeof(menu));
    #define RESOLVE(field,name) menu.field=(__typeof__(menu.field))symbol(name)
    RESOLVE(message_init,"sceMsgDialogInitialize");RESOLVE(message_open,"sceMsgDialogOpen");
    RESOLVE(message_status,"sceMsgDialogGetStatus");RESOLVE(message_update,"sceMsgDialogUpdateStatus");
    RESOLVE(message_result,"sceMsgDialogGetResult");RESOLVE(message_term,"sceMsgDialogTerminate");
    RESOLVE(ime_init,"sceImeDialogInit");RESOLVE(ime_status,"sceImeDialogGetStatus");
    RESOLVE(ime_result,"sceImeDialogGetResult");RESOLVE(ime_term,"sceImeDialogTerm");
    RESOLVE(ime_abort,"sceImeDialogAbort");
    #undef RESOLVE
    if(!menu.message_status)menu.message_status=menu.message_update;
    if(menu.message_init&&menu.message_open){
        int32_t(*common_init)(void)=(int32_t(*)(void))symbol("sceCommonDialogInitialize");
        if(common_init)trace(45,common_init());
    }
    int32_t(*neo)(void)=(int32_t(*)(void))symbol("sceKernelIsNeoMode");
    menu.user=user;menu.pro=neo?neo()>0:0;menu.save=save_settings;menu.save_name=save_profile;menu.trace=record;game_user=user;
    if(ctr_menu_init(&menu)<0){
        int mask=(!menu.message_init?1:0)|(!menu.message_open?2:0)|(!menu.message_status?4:0)|(!menu.message_update?8:0)|(!menu.message_result?16:0)|(!menu.message_term?32:0);
        trace(48,mask);return -3;
    }
    ctr_updates_native_init();
    char configured[17];
    if(!ctr_profile_snapshot(configured)&&!configured[0])ctr_menu_request_setup();
    ctr_frame_init((uint64_t(*)(void))symbol("sceKernelGetProcessTime"),(int32_t(*)(uint32_t))symbol("sceKernelUsleep"),record);
    query_memory=(__typeof__(query_memory))symbol("sceKernelQueryMemoryProtection");
    render_snapshot(0);
    ctr_frame_probe(first_presentation_snapshot);
    ctr_sessions_init(user,(uint64_t(*)(void))symbol("sceKernelGetProcessTime"),record);
    for(size_t i=0;i<sizeof(ui_imports)/sizeof(ui_imports[0]);i++){
        UiImport *r=&ui_imports[i];r->original=symbol(r->name);
        uint64_t address=base+r->got;
        if(!r->original||!(region(address,8)&1))return -4;
        uint64_t old=__atomic_load_n((uint64_t*)address,__ATOMIC_ACQUIRE);
        if(old!=(uint64_t)r->original&&old!=base+r->unresolved)return -5;
        if(!ctr_strcmp(r->name,"scePadReadState")){pad_read=(__typeof__(pad_read))r->original;r->replacement=(void*)read_pad;}
        else if(!ctr_strcmp(r->name,"sceVideoOutSetFlipRate")){set_rate=(__typeof__(set_rate))r->original;r->replacement=(void*)change_rate;}
        else if(!ctr_strcmp(r->name,"sceVideoOutSubmitFlip")){submit_flip=(__typeof__(submit_flip))r->original;r->replacement=(void*)flip;}
        else if(!ctr_strcmp(r->name,"sceGnmSubmitAndFlipCommandBuffers")){ctr_frame_original0=r->original;r->replacement=(void*)ctr_frame_hook0;}
        else if(!ctr_strcmp(r->name,"sceGnmSubmitAndFlipCommandBuffersForWorkload")){ctr_frame_original1=r->original;r->replacement=(void*)ctr_frame_hook1;}
        else if(!ctr_strcmp(r->name,"sceGnmRequestFlipAndSubmitDone")){ctr_frame_original2=r->original;r->replacement=(void*)ctr_frame_hook2;}
        else if(!ctr_strcmp(r->name,"sceGnmRequestFlipAndSubmitDoneForWorkload")){ctr_frame_original3=r->original;r->replacement=(void*)ctr_frame_hook3;}
        else if(!ctr_strcmp(r->name,"sceImeDialogGetStatus")){ime_status=(__typeof__(ime_status))r->original;r->replacement=(void*)game_ime_status;}
        else if(!ctr_strcmp(r->name,"sceImeDialogGetResult")){ime_result=(__typeof__(ime_result))r->original;r->replacement=(void*)game_ime_result;}
        else if(!ctr_strcmp(r->name,"sceImeDialogTerm")){ime_term=(__typeof__(ime_term))r->original;r->replacement=(void*)game_ime_term;}
        else if(!ctr_strcmp(r->name,"sceSystemServiceGetStatus")){system_status=(__typeof__(system_status))r->original;r->replacement=(void*)game_system_status;}
        else if(!ctr_strcmp(r->name,"sceSystemServiceReceiveEvent")){system_event=(__typeof__(system_event))r->original;r->replacement=(void*)game_system_event;}
        else if(!ctr_strcmp(r->name,"sceUserServiceGetUserName")){user_name=(__typeof__(user_name))r->original;r->replacement=(void*)game_user_name;}
        if(!r->replacement)return -6;
    }
    // Preflight every known RELRO page before changing any import. A failed
    // permission change restores earlier pages without installing partial hooks.
    uint64_t pages[4];int permissions[4];size_t page_count=0;
    for(size_t i=0;i<sizeof(ui_imports)/sizeof(ui_imports[0]);i++){
        uint64_t address=base+ui_imports[i].got,page=address&~0x3fffULL;
        int permission=region(address,8);size_t j=0;
        while(j<page_count&&pages[j]!=page)j++;
        if(j<page_count){if(permissions[j]!=permission)return -7;}
        else {if(page_count==4)return -7;pages[j]=page;permissions[j]=permission;page_count++;}
    }
    for(size_t i=0;i<page_count;i++)if(protect(pages[i],0x4000,permissions[i]|2)){
        for(size_t j=0;j<i;j++)trace(53,protect(pages[j],0x4000,permissions[j]));
        return -8;
    }
    for(size_t i=0;i<sizeof(ui_imports)/sizeof(ui_imports[0]);i++)__atomic_store_n((uint64_t*)(base+ui_imports[i].got),(uint64_t)ui_imports[i].replacement,__ATOMIC_RELEASE);
    for(size_t i=0;i<page_count;i++)trace(53,protect(pages[i],0x4000,permissions[i]));
    ctr_sessions_ready(1);
    CtrSettings s;if(!ctr_settings_snapshot(&s)){
        int r=patch_graphics(&s,menu.pro);trace(121,r);
        trace(120,r? -1:s.performance);trace(122,menu.pro);
        trace(123,0); // Legacy DOF-removal mode retired.
        trace(124,r? -1:s.low_quality);trace(125,r? -1:s.no_shadows);
    }
    trace(50,(int32_t)(sizeof(ui_imports)/sizeof(ui_imports[0])));return 0;
}
