// SPDX-License-Identifier: GPL-2.0-only
// Native PS4 adapter for OCTR 0.5.3's UDP tunnel. No workers or spin waits.
// Only the game's IPv4 datagram socket bound to 3074 is intercepted.
#include "net_transport.h"
#include "net_tunnel.h"
#include "runtime_net_tunnel.h"
#include "runtime_net_ping.h"
static CtrNetApi api;
static int lock,receive_lock,enabled;
static int32_t game_fd=-1;
static uint32_t server_ip,generation,trace_sent,trace_received;
// Preserve ordinary datagrams, including a long direct packet. Only relay
// envelopes are restricted to the upstream protocol's 2048-byte payload.
static uint8_t received[65536];
static struct {int valid;uint32_t generation;size_t length;CtrNetAddress from;uint8_t data[65536];} peeked;
static int take(void){int zero=0;return __atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void give(void){__atomic_store_n(&lock,0,__ATOMIC_RELEASE);}
static int take_receive(void){int zero=0;return __atomic_compare_exchange_n(&receive_lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void give_receive(void){__atomic_store_n(&receive_lock,0,__ATOMIC_RELEASE);}
static uint16_t swap(uint16_t n){return (uint16_t)((n>>8)|(n<<8));}
static int32_t *error_ptr(void){return api.errno_location?api.errno_location():0;}
static int32_t error_get(void){int32_t *p=error_ptr();return p?*p:0;}
static void error_set(int32_t n){int32_t *p=error_ptr();if(p)*p=n;}
static void trace(int stage,int value){if(api.trace)api.trace(stage,value);}
static uint64_t now(void){return api.clock_us()/1000;}
static int ipv4(const void *addr,uint32_t n){return addr&&n>=16&&((const CtrNetAddress*)addr)->family==2&&((const CtrNetAddress*)addr)->length==16;}
static CtrNetAddress server(void){CtrNetAddress a={16,2,swap(3074),__atomic_load_n(&server_ip,__ATOMIC_ACQUIRE),{0}};return a;}
// Caller holds the transport try-lock. No loop waits for a packet or another thread.
static void keepalive(int32_t fd,const CtrNetAddress *to){
    uint64_t t=now();uint8_t request[TUN_REQUEST_LEN];
    if(tun_keepalive_due(t)){size_t n=tun_pass_request(request,sizeof(request),t);if(n)api.sendto(fd,request,n,0x40,to,16);}
    int count=tun_relay_count();
    for(int i=0;i<count;i++){
        uint32_t ip;uint16_t port;size_t n=tun_relay_register(i,t,request,sizeof(request),&ip,&port);
        if(n){CtrNetAddress relay={16,2,swap(port),ip,{0}};api.sendto(fd,request,n,0x40,&relay,16);}
    }
}
static void relay_copy(int32_t fd,const void *data,size_t length,const CtrNetAddress *peer,const CtrNetAddress *to){
    if(!tun_candidate(peer->ip,to->ip)||tun_relay_index(peer->ip,swap(peer->port))>=0)return;
    uint8_t bits=0,wrapped[CTR_TUN_PAYLOAD+CTR_TUN_HEADER];int relay=-1;
    int routes=tun_on_send(peer->ip,swap(peer->port),now(),&bits,&relay);
    size_t n=ctr_tun_wrap(wrapped,sizeof(wrapped),bits|TUN_FLAG_PING,peer->ip,swap(peer->port),data,length);
    if(!n)return;
    if(routes&TUN_VIA_SERVER){int r=api.sendto(fd,wrapped,n,0x40,to,16);if(trace_sent++<4)trace(r<0?156:154,r<0?r:0);}
    uint32_t ip;uint16_t port;
    if((routes&TUN_VIA_RELAY)&&tun_relay_addr(relay,&ip,&port)){
        CtrNetAddress dest={16,2,swap(port),ip,{0}};api.sendto(fd,wrapped,n,0x40,&dest,16);
    }
}
static void ping_send(int32_t fd,const uint8_t *data,size_t length,const CtrNetAddress *peer,const CtrNetAddress *to){
    api.sendto(fd,data,length,0x40,peer,16);relay_copy(fd,data,length,peer,to);
}
CTR_EXPORT int ctr_net_init(const CtrNetApi *platform){
    if(!platform||!platform->bind||!platform->sendto||!platform->recvfrom||!platform->close||!platform->getsockopt||!platform->errno_location||!platform->clock_us)return -1;
    api=*platform;game_fd=-1;peeked.valid=0;server_ip=0;generation=0;trace_sent=trace_received=0;lock=receive_lock=0;ctr_tun_reset();tun_reset();ping_reset();ping_set_name(ctr_player_name());enabled=1;return 0;
}
CTR_EXPORT void ctr_net_server(uint32_t ip){
    if(!ip)return;
    uint32_t previous=__atomic_exchange_n(&server_ip,ip,__ATOMIC_ACQ_REL);
    if(previous!=ip)trace(152,1); // Do not log public or private IP addresses.
}
CTR_EXPORT int32_t ctr_net_bind(int32_t fd,const void *addr,uint32_t length){
    int32_t result=api.bind(fd,addr,length),saved=error_get();
    if(result||!enabled||!ipv4(addr,length)||swap(((const CtrNetAddress*)addr)->port)!=3074)return result;
    int32_t type=0;uint32_t size=4;
    if(api.getsockopt(fd,0xffff,0x1008,&type,&size)||size!=4||type!=2){error_set(saved);return result;}
    if(take()){
        if(game_fd<0||game_fd==fd){
            __atomic_fetch_add(&generation,1,__ATOMIC_ACQ_REL);
            __atomic_store_n(&game_fd,fd,__ATOMIC_RELEASE);ctr_tun_reset();tun_reset();ping_reset();ping_set_name(ctr_player_name());
            CtrNetAddress to=server();if(to.ip)keepalive(fd,&to);trace(153,0);
        }
        give();
    }
    error_set(saved);return result;
}
CTR_EXPORT int32_t ctr_net_sendto(int32_t fd,const void *data,size_t length,int32_t flags,const void *addr,uint32_t addrlen){
    int32_t result=api.sendto(fd,data,length,flags,addr,addrlen),saved=error_get();
    if(result<0||!enabled||fd!=__atomic_load_n(&game_fd,__ATOMIC_ACQUIRE)||!ipv4(addr,addrlen)||length>CTR_TUN_PAYLOAD||(!data&&length)||!take())return result;
    CtrNetAddress to=server();
    if(to.ip){
        keepalive(fd,&to);const CtrNetAddress *peer=addr;
        relay_copy(fd,data,length,peer,&to);
        if(tun_candidate(peer->ip,to.ip)&&tun_relay_index(peer->ip,swap(peer->port))<0){
            ping_on_game_send(peer->ip,swap(peer->port),now());
            for(unsigned i=0;i<PING_MAX_PEERS;i++){
                uint8_t packet[PING_PACKET_MAX];uint32_t ip;uint16_t port;
                size_t n=ping_next(now(),packet,sizeof(packet),&ip,&port);if(!n)break;
                CtrNetAddress dest={16,2,swap(port),ip,{0}};ping_send(fd,packet,n,&dest,&to);
            }
        }
    }
    give();error_set(saved);return result;
}
static int32_t copy_result(void *out,size_t capacity,void *from,uint32_t *fromlen,const uint8_t *data,size_t length,const CtrNetAddress *address){
    if(from&&fromlen){size_t n=*fromlen<16?*fromlen:16;if(n)ctr_memcpy(from,address,n);*fromlen=16;}
    size_t n=length<capacity?length:capacity;if(n)ctr_memcpy(out,data,n);return (int32_t)n;
}
CTR_EXPORT int32_t ctr_net_recvfrom(int32_t fd,void *out,size_t capacity,int32_t flags,void *from,uint32_t *fromlen){
    if(!enabled||fd!=__atomic_load_n(&game_fd,__ATOMIC_ACQUIRE)||(!out&&capacity))return api.recvfrom(fd,out,capacity,flags,from,fromlen);
    if(!take_receive()){error_set(35);return -1;}
    uint32_t epoch=__atomic_load_n(&generation,__ATOMIC_ACQUIRE);
    if(peeked.valid&&peeked.generation!=epoch)peeked.valid=0;
    if(peeked.valid){
        int32_t r=copy_result(out,capacity,from,fromlen,peeked.data,peeked.length,&peeked.from);
        if(!(flags&2))peeked.valid=0;give_receive();return r;
    }
    CtrNetAddress to=server();
    if(!to.ip){give_receive();return api.recvfrom(fd,out,capacity,flags,from,fromlen);}
    int32_t prior=error_get();if(take()){keepalive(fd,&to);give();}error_set(prior);
    // Never hold the peer bookkeeping lock across a potentially blocking
    // socket read: a sender on another game thread must still use the relay.
    uint8_t *wrapped=received;CtrNetAddress address;uint32_t size=16;
    int32_t r=api.recvfrom(fd,wrapped,sizeof(received),flags&~2,&address,&size),saved=error_get();
    if(r<0){give_receive();error_set(saved);return r;}
    if((size_t)r>sizeof(received)||size!=16||address.family!=2){give_receive();error_set(35);return -1;}
    size_t length=(size_t)r;const uint8_t *data=wrapped;
    int held=take();int relay=held?tun_relay_index(address.ip,swap(address.port)):-1;
    int server_packet=address.ip==to.ip&&address.port==to.port;
    if(server_packet||relay>=0){
        uint8_t bits;uint32_t ip;uint16_t port;
        if(server_packet&&length>=6&&!ctr_strncmp((const char*)wrapped,"RYUPS1",6)){
            if(held){tun_on_offer(wrapped,length,now());give();}give_receive();error_set(35);return -1;
        }
        if(ctr_tun_unwrap(wrapped,length,&bits,&ip,&port)){
            if(!tun_candidate(ip,to.ip)){if(held)give();give_receive();error_set(35);return -1;}
            if(held){tun_on_tunnelled(ip,port,bits,relay>=0,now());if(bits&TUN_FLAG_PING)ping_on_capable(ip,port,now());}
            address.ip=ip;address.port=swap(port);data+=CTR_TUN_HEADER;length-=CTR_TUN_HEADER;
            if(trace_received++<4)trace(155,0);
        }else if(relay>=0||(length>=6&&!ctr_strncmp((const char*)wrapped,"RYUTN1",6))){
            if(held){if(relay>=0)tun_on_register_reply(relay,wrapped,length,now());give();}
            give_receive();error_set(35);return -1;
        }
    }else if(held)tun_on_direct(address.ip,swap(address.port),now());
    if(length>=6&&!ctr_strncmp((const char*)data,PING_MAGIC,6)){
        if(held){
            uint8_t reply[PING_PACKET_MAX];size_t n=0;
            if(tun_candidate(address.ip,to.ip))ping_on_packet(data,length,address.ip,swap(address.port),now(),reply,sizeof(reply),&n);
            if(n)ping_send(fd,reply,n,&address,&to);give();
        }
        give_receive();error_set(35);return -1; // control packets never enter CTR or its peek cache
    }
    if(held)give();
    if((flags&2)&&epoch==__atomic_load_n(&generation,__ATOMIC_ACQUIRE)){
        peeked.valid=1;peeked.generation=epoch;peeked.length=length;peeked.from=address;if(length)ctr_memcpy(peeked.data,data,length);
    }
    r=copy_result(out,capacity,from,fromlen,data,length,&address);give_receive();error_set(saved);return r;
}
CTR_EXPORT int32_t ctr_net_close(int32_t fd){
    int32_t r=api.close(fd),saved=error_get();
    if(!r&&fd==__atomic_load_n(&game_fd,__ATOMIC_ACQUIRE)){
        __atomic_store_n(&game_fd,-1,__ATOMIC_RELEASE);
        __atomic_fetch_add(&generation,1,__ATOMIC_ACQ_REL);
        if(take()){ctr_tun_reset();tun_reset();ping_reset();ping_set_name(ctr_player_name());give();}trace(157,0);
    }
    error_set(saved);return r;
}

CTR_EXPORT int ctr_net_ping_view(PingPeer *out,int max){
    if(!out||max<0||max>PING_MAX_PEERS||!enabled||!take())return 0;
    int n=ping_view(now(),out,max);give();return n;
}
