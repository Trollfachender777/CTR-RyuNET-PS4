// SPDX-License-Identifier: GPL-2.0-only
#include "menu.h"
#include "profile.h"
#include "updates.h"
#include "updater.h"
#include "social.h"
#include "season.h"
#include "sessions.h"
#include "runtime_net_ping.h"
extern int ctr_net_ping_view(PingPeer*,int);
enum {MAIN=1,PERFORMANCE,FPS,GRAPHICS,BLUR,RESOLUTION,FRIENDS,LIST=9,ADD,REMOVE,NOTICE,FRIENDS_LIST,ONLINE=15,PROFILE,NAME_EDIT,GRAPHICS_MORE,LIGHT_MODE,MANUAL_GRAPHICS,LIGHT_EFFECTS,QUALITY_SHADOWS,SHADOWS,FPS_CAPPED,RESET_GRAPHICS,SETUP,EXTRAS,UPDATES,SOCIAL_HUB,SERVER_LIST,SOCIAL_PENDING,REQUESTS,REQUEST_ACTION,INVITES,SOCIAL_MORE,NET_INFO};
static CtrMenuApi api;
static CtrDialogParam param;
static CtrDialogMessage message;
static CtrDialogButtons choices;
static CtrImeParam ime;
static uint16_t input[17],title[64];
static char body[2048];
static int available,state,dialog,lock,owned_handle=-1,combo_held,cooldown,owns_message_init;
static int ime_owned,ime_last_status;
static int capturing;
static int setup_pending;
static uint32_t resolution_choice;
static int update_shown;
static unsigned friend_choice,request_choice,invite_choice;
static char social_target[17];
static const char *resolution_names[]={"Nativa","720p","480p"};
static const char *notice;
static void trace(int32_t stage,int32_t result){if(api.trace)api.trace(stage,result);}
static void append(const char *text){size_t a=ctr_strlen(body),b=ctr_strlen(text);if(a+b<sizeof(body))ctr_memcpy(body+a,text,b+1);}
static void utf16(uint16_t *out,size_t cap,const char *text){size_t i=0;while(i+1<cap&&text[i]){out[i]=(uint8_t)text[i];i++;}out[i]=0;}
static void release_message(void){api.message_term();if(!owns_message_init)api.message_init();}
static int open_message(const char *text,const char *first,const char *second){
    int status=api.message_status();if(status!=0&&status!=1)return -1;
    owns_message_init=status==0;int r=0;
    if(owns_message_init){r=api.message_init();if(r<0){trace(61,r);return r;}}
    ctr_memset(&param,0,sizeof(param));ctr_memset(&message,0,sizeof(message));ctr_memset(&choices,0,sizeof(choices));
    body[0]=0;append(text);message.message=body;
    message.buttons=second?9:0;choices.first=first;choices.second=second;message.custom=second?&choices:0;
    param.base.size=sizeof(param.base);param.base.magic=(uint32_t)((uintptr_t)&param.base+0xC0D1A109U);
    param.size=sizeof(param);param.mode=1;param.message=&message;param.user=api.user;
    r=api.message_open(&param);trace(62,r);
    if(r<0){release_message();return r;}dialog=1;return 0;
}
static int open_ime(int mode){
    if(!api.ime_init||!api.ime_status||!api.ime_result||!api.ime_term)return -1;
    if(api.ime_status()!=0)return -1;
    ctr_memset(input,0,sizeof(input));ctr_memset(&ime,0,sizeof(ime));
    utf16(title,64,mode==REMOVE?"Apodo RyuNET del amigo a eliminar":mode==NAME_EDIT?"Tu apodo solo para RyuNET":"Apodo RyuNET del amigo de PC o PS4");
    if(mode==NAME_EDIT){char saved[17];if(!ctr_profile_snapshot(saved)&&saved[0])utf16(input,17,saved);}
    ime.user=api.user;ime.type=1;ime.max_length=16;ime.buffer=input;ime.title=title;
    __atomic_store_n(&ime_owned,1,__ATOMIC_RELEASE);ime_last_status=-1;
    int r=api.ime_init(&ime,0);trace(60,r);
    if(r<0){__atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);return r;}
    dialog=2;return 0;
}
CTR_EXPORT int ctr_menu_ime_owned(void){return __atomic_load_n(&ime_owned,__ATOMIC_ACQUIRE);}
CTR_EXPORT int ctr_menu_active(void){return __atomic_load_n(&capturing,__ATOMIC_ACQUIRE);}
static int release_ime(void){
    int r=api.ime_term();trace(65,r);
    __atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);dialog=0;return r;
}
static void show(int next){
    if(next==MAIN&&ctr_updater_auto_prompt())next=UPDATES;
    state=next;dialog=0;CtrSettings s;
    if(ctr_settings_snapshot(&s)){state=0;return;}
    const char *text="",*one="",*two=0;char list[1600];
    switch(next){
    case SETUP:text="Bienvenido a RyuNET\n\nElige tu propio apodo para jugar online (3 a 16 caracteres). No uses el de otra persona.\n\nEsta PS4 creara y guardara su identidad privada. No se usa tu nombre de PSN.\n\nSi lo omites, puedes jugar offline y configurarlo con L3 + R3 -> Online -> Mi apodo.";one="Elegir apodo";two="Ahora no";break;
    case MAIN:text="RyuNET - Ajustes PS4 v1.2.1\n\nL3 + R3 para abrir. Circulo para volver al juego.";one="Rendimiento";two="Online y extras";break;
    case EXTRAS:text="Online y extras";one="Online";two="Actualizaciones PS4";break;
    case UPDATES:{
        CtrUpdaterResult u;if(ctr_updater_snapshot(&u)){state=0;return;}update_shown=u.state;
        char percent[5];unsigned value=u.percent>100?100:u.percent;int digits=0;
        if(value>=100)percent[digits++]='1';if(value>=10)percent[digits++]=(char)('0'+value/10%10);percent[digits++]=(char)('0'+value%10);percent[digits++]='%';percent[digits]=0;
        const char *status=u.state==CTR_UPDATER_CHECKING?"Buscando actualizaciones de PS4...\nPulsa Ver resultado en unos segundos.":
            u.state==CTR_UPDATER_CURRENT?"Tu version de PS4 esta actualizada.":
            u.state==CTR_UPDATER_AVAILABLE?"Hay una actualizacion disponible.\n\nQuieres actualizar ahora?\nSe descargara solo el modulo de RyuNET. Se aplica al cerrar y volver a abrir el juego.":
            u.state==CTR_UPDATER_DOWNLOADING?"Descargando y verificando la actualizacion...":
            u.state==CTR_UPDATER_READY?"Actualizacion preparada.\n\nCierra el juego normalmente desde PS -> Cerrar aplicacion y vuelve a abrirlo para aplicarla. No desconectes la consola durante la descarga.":
            u.state==CTR_UPDATER_FAILED?"La actualizacion no se completo. Tu version anterior se conserva. Vuelve a buscar para intentarlo otra vez.":
            u.state==CTR_UPDATER_NEEDS_SETUP?"Esta instalacion necesita el constructor v1.1.0 o una instalacion del actualizador por una sola vez. Despues podras actualizar el modulo desde PS4.":
            u.state==CTR_UPDATER_RATE_LIMIT?"GitHub limito las consultas. Espera y vuelve a intentarlo.":
            u.state==CTR_UPDATER_INVALID?"La actualizacion no es compatible con este port o su informacion no es valida.":
            u.state==CTR_UPDATER_UNAVAILABLE?"El actualizador no esta disponible en este inicio. Vuelve a intentarlo despues de reiniciar.":
            u.state==CTR_UPDATER_NO_RELEASE?"Todavia no hay una actualizacion PS4 publicada en el canal.":
            u.state==CTR_UPDATER_NETWORK?"No se pudo comprobar. Revisa Internet y la fecha de la consola o intentalo mas tarde.":"Busca actualizaciones del port de PS4.";
        const char *parts[]={"Actualizaciones de PS4\n\n",status,
            u.version[0]?"\n\nVersion disponible: ":"",u.version,
            u.state==CTR_UPDATER_DOWNLOADING?"\nProgreso: ":"",u.state==CTR_UPDATER_DOWNLOADING?percent:"",
            "\n\nVersion instalada: " CTR_PS4_RELEASE_TAG,
            "\nConserva tu partida, identidad, apodo, amigos y ajustes."};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t l=ctr_strlen(parts[i]);if(n+l+1>sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],l);n+=l;}list[n]=0;
        text=list;one=u.state==CTR_UPDATER_AVAILABLE?"Actualizar ahora":u.state==CTR_UPDATER_CHECKING||u.state==CTR_UPDATER_DOWNLOADING?"Ver resultado":u.state==CTR_UPDATER_READY?"Aceptar":"Buscar actualizaciones";
        two=u.state==CTR_UPDATER_AVAILABLE?"Ahora no":"Volver";break;
    }
    case ONLINE:text="RyuNET Online";one="Amigos";two="Mi apodo";break;
    case PROFILE:{
        char saved[17];if(ctr_profile_snapshot(saved))saved[0]=0;
        const char *parts[]={"Mi apodo de RyuNET\n\nEn uso: ",ctr_profile_name_valid(ctr_player_name())?ctr_player_name():"Sin configurar",
            "\nGuardado: ",saved[0]?saved:"Sin configurar",
            "\n\nUsa de 3 a 16 letras, numeros, guion o guion bajo.\nSe aplica al reiniciar el juego. Un apodo distinto puede ser otro perfil del servidor; tus amigos deberan anadirlo. Tu partida local se conserva."};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t l=ctr_strlen(parts[i]);if(n+l+1>sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],l);n+=l;}list[n]=0;
        text=list;one="Cambiar apodo";two="Volver";break;
    }
    case PERFORMANCE:text="Rendimiento\n\nElige el limite de FPS o los ajustes graficos.";one="Limite de FPS";two="Graficos";break;
    case FPS:
        text=s.fps==60?"Limite actual: 60 FPS\n\nElige un limite de 30/60 FPS o permite que el juego renderice sin este limitador.":s.fps==30?"Limite actual: 30 FPS\n\nElige un limite de 30/60 FPS o permite que el juego renderice sin este limitador.":"Limite actual: sin limite\n\nPuede aumentar la carga y el consumo. El resultado depende del juego, la consola y la sincronizacion de pantalla.";
        one="30 / 60 FPS";two="Sin limite";break;
    case FPS_CAPPED:
        text="Limite de FPS\n\n30 y 60 aplican un limite real mediante esperas. Se aplica al volver al juego; no requiere reiniciar.";
        one="30 FPS";two="60 FPS";break;
    case GRAPHICS:text="Graficos\n\nElige una sola resolucion interna: Nativa, 720p o 480p.\nLos cambios graficos requieren cerrar y volver a abrir el juego.";one="Resolucion interna";two="Mas opciones";break;
    case GRAPHICS_MORE:text="Mas opciones graficas";one="Efectos y sombras";two="Restaurar graficos";break;
    case MANUAL_GRAPHICS:text="Efectos y sombras";one="Desenfoque";two="Sombras dinamicas";break;
    case SHADOWS:
        text=s.no_shadows?"Sombras dinamicas: desactivadas (guardado)\n\nRetira las sombras en cascada y de los corredores mediante sus controles del motor. La iluminacion permanece. Las sombras pintadas en texturas pueden seguir visibles.\n\nRequiere reiniciar.":"Sombras dinamicas: activadas (guardado)\n\nPuedes quitarlas para reducir trabajo grafico. Cambia la apariencia; no garantiza una mejora concreta de FPS.\n\nLas sombras pintadas en texturas no se modifican. Requiere reiniciar.";
        one="Quitar sombras";two="Restaurar sombras";break;
    case BLUR:text=s.performance&&!s.low_quality?"Desenfoque de movimiento\n\nEl perfil de 720p lo mantiene desactivado. Tu preferencia manual se usara al elegir Nativa o 480p.":s.motion_blur?"Desenfoque de movimiento: activado\n\nReinicia el juego despues de guardar.":"Desenfoque de movimiento: desactivado\n\nReinicia el juego despues de guardar.";one="Activar";two="Desactivar";break;
    case RESOLUTION:{
        int current=ctr_settings_resolution(&s);if(current<0||resolution_choice>CTR_RES_480P){state=0;return;}
        const char *saved=api.pro&&s.pro_1080&&current==CTR_RES_NATIVE?"1080p Pro (heredado)":resolution_names[current];
        const char *parts[]={"Resolucion interna\n\nGuardada: ",saved,"\nElegida: ",resolution_names[resolution_choice],
            "\n\nOpciones: Nativa / 720p / 480p.\nSiguiente recorre las opciones; Aplicar guarda la elegida.\n",
            resolution_choice==CTR_RES_720P?"720p usa el perfil existente sin desenfoque.\n":"",
            "\nConserva FPS y sombras. La TV puede seguir indicando 1080p: es la salida HDMI.\nReinicia el juego para aplicar. Circulo cancela."};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t length=ctr_strlen(parts[i]);if(n+length+1>sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],length);n+=length;}list[n]=0;
        text=list;one="Aplicar";two="Siguiente";break;
    }
    case RESET_GRAPHICS:
        text="Restaurar ajustes graficos\n\nVolvera a resolucion Nativa, desenfoque activado y sombras dinamicas activadas.\n\nConserva el limite de FPS, tu partida, apodo y amigos.\nRequiere cerrar y volver a abrir el juego.";
        one="Restaurar";two="Cancelar";break;
    case FRIENDS:text="Amigos RyuNET - protocolo OCTR 0.6.4\n\nAnadir envia una solicitud al servidor. La otra persona debe aceptarla. Para unirte a una partida, usa Online -> Amigos del CTR.\nVer / eliminar incluye solicitudes e invitaciones.";one="Anadir amigo";two="Ver / eliminar";break;
    case FRIENDS_LIST:text="Gestionar amigos RyuNET";one="Ver lista";two="Eliminar amigo";break;
    case LIST:
        list[0]=0;
        if(!s.count){const char *empty="Todavia no has anadido amigos.";ctr_memcpy(list,empty,ctr_strlen(empty)+1);}
        else {size_t n=0;for(uint32_t i=0;i<s.count;i++){size_t l=ctr_strlen(s.friends[i]);ctr_memcpy(list+n,s.friends[i],l);n+=l;list[n++]='\n';}list[n]=0;}
        text=list;one="Amigos del servidor";two="Volver";break;
    case SOCIAL_HUB:text="Amigos del servidor\n\nSe actualiza cada 8 segundos. Las solicitudes necesitan aceptacion mutua; eliminar retira la amistad del servidor para ambos.\nLos contactos locales anteriores se conservan y envian una solicitud si hace falta.";one="Lista / invitar";two="Solicitudes y extras";break;
    case SERVER_LIST:case REQUESTS:case INVITES:{
        CtrSocialView v;social_target[0]=0;if(ctr_social_snapshot(&v)){state=0;return;}
        if(v.state!=CTR_SOCIAL_READY){text=v.state==CTR_SOCIAL_REFUSED?"El servidor no acepto la consulta de amigos. Entra primero a Online y vuelve a intentarlo.":"Consultando amigos del servidor. Entra primero a Online y espera unos segundos.";one="Ver resultado";two="Volver";break;}
        unsigned total=next==SERVER_LIST?v.count:next==REQUESTS?v.incoming_count:v.invite_count;
        if(!total){text=next==SERVER_LIST?"Todavia no hay amistades aceptadas en el servidor.":next==REQUESTS?"No hay solicitudes de amistad pendientes.":"No hay invitaciones pendientes.";one="Actualizar";two="Volver";break;}
        unsigned *choice=next==SERVER_LIST?&friend_choice:next==REQUESTS?&request_choice:&invite_choice;*choice%=total;
        const char *name=next==SERVER_LIST?v.friends[*choice].name:next==REQUESTS?v.incoming[*choice]:v.invites[*choice].from;
        ctr_memcpy(social_target,name,ctr_strlen(name)+1);list[0]=0;
        const char *parts[]={next==SERVER_LIST?"Amigo: ":next==REQUESTS?"Solicitud de amistad de: ":"Tu amigo te invita a su partida: ",name,
            next==SERVER_LIST?(v.friends[*choice].online?"\nConectado":"\nDesconectado"):"",
            next==INVITES?"\n\nAceptar intentara entrar en su sala. Debe tener plazas y no estar en carrera.":"",
            "\n\nSiguiente recorre los contactos. Circulo vuelve al juego.",v.result[0]?"\nUltima respuesta: ":"",v.result};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t len=ctr_strlen(parts[i]);if(n+len>=sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],len);n+=len;}list[n]=0;
        text=list;one=next==SERVER_LIST?"Invitar":next==REQUESTS?"Aceptar / rechazar":"Aceptar invitacion";two="Siguiente";break;
    }
    case REQUEST_ACTION:list[0]=0;ctr_memcpy(list,"Solicitud de: ",15);ctr_memcpy(list+14,social_target,ctr_strlen(social_target)+1);text=list;one="Aceptar";two="Rechazar";break;
    case SOCIAL_PENDING:text="Solicitudes y extras";one="Solicitudes recibidas";two="Invitaciones / red";break;
    case SOCIAL_MORE:text="Invitaciones y red";one="Invitaciones recibidas";two="Ping de la sala";break;
    case NET_INFO:{
        PingPeer peers[PING_MAX_PEERS];int n=ctr_net_ping_view(peers,PING_MAX_PEERS);list[0]=0;
        const char *intro="Ping de jugadores (OCTR 0.6.4)\n\n";ctr_memcpy(list,intro,ctr_strlen(intro)+1);size_t at=ctr_strlen(list);
        for(int i=0;i<n;i++){
            const char *name=peers[i].name[0]?peers[i].name:"Jugador";size_t len=ctr_strlen(name);ctr_memcpy(list+at,name,len);at+=len;list[at++]=' ';list[at]=0;
            if(peers[i].ms>=0){unsigned value=(unsigned)peers[i].ms;char rev[12];unsigned k=0;do{rev[k++]=(char)('0'+value%10);value/=10;}while(value);while(k)list[at++]=rev[--k];ctr_memcpy(list+at," ms\n",5);at+=4;}
            else {const char *status=peers[i].ms==PING_OLDER_PORT?"(sin soporte de ping)\n":"(esperando respuesta)\n";len=ctr_strlen(status);ctr_memcpy(list+at,status,len+1);at+=len;}
        }
        if(!n){const char *empty="Entra en una sala con otros jugadores para ver el ping.";ctr_memcpy(list+at,empty,ctr_strlen(empty)+1);}text=list;one="Actualizar";two="Volver";break;
    }
    case ADD:case REMOVE:case NAME_EDIT:if(!open_ime(next))return;notice="No se pudo abrir el teclado. Vuelve a intentarlo desde el menu principal.";state=NOTICE;next=NOTICE;/* fall through */
    case NOTICE:text=notice?notice:"Ajustes guardados.";one="Aceptar";break;
    default:state=0;return;
    }
    if(open_message(text,one,two)<0){state=0;trace(61,-1);}
}
static void commit(CtrSettings *s,const char *success){
    if(!api.save||api.save(s)<0){notice="No se pudo guardar. Se conserva la configuracion anterior.";show(NOTICE);return;}
    if(ctr_settings_publish(s)<0){notice="Archivo guardado. Reinicia el juego para cargarlo.";show(NOTICE);return;}
    notice=success;show(NOTICE);
}
static void selected(int button){
    CtrSettings s;if(ctr_settings_snapshot(&s)){state=0;return;}
    switch(state){
    case SETUP:if(button==1)show(NAME_EDIT);else state=0;return;
    case MAIN:show(button==1?PERFORMANCE:EXTRAS);return;
    case EXTRAS:show(button==1?ONLINE:UPDATES);return;
    case UPDATES:if(button==2){show(EXTRAS);return;}if(update_shown==CTR_UPDATER_AVAILABLE)ctr_updater_install();else if(update_shown!=CTR_UPDATER_CHECKING&&update_shown!=CTR_UPDATER_DOWNLOADING&&update_shown!=CTR_UPDATER_READY)ctr_updater_check();show(UPDATES);return;
    case ONLINE:show(button==1?FRIENDS:PROFILE);return;
    case PROFILE:show(button==1?NAME_EDIT:ONLINE);return;
    case PERFORMANCE:show(button==1?FPS:GRAPHICS);return;
    case FPS:
        if(button==1){show(FPS_CAPPED);return;}
        s.fps=CTR_FPS_UNLIMITED;commit(&s,"Sin limite guardado. Se aplica al volver al juego.");return;
    case FPS_CAPPED:s.fps=button==1?30:60;commit(&s,"Limite guardado. Se aplica al volver al juego.");return;
    case GRAPHICS:
        if(button==1){int current=ctr_settings_resolution(&s);if(current<0){state=0;return;}resolution_choice=(uint32_t)current;show(RESOLUTION);}
        else show(GRAPHICS_MORE);return;
    case GRAPHICS_MORE:show(button==1?MANUAL_GRAPHICS:RESET_GRAPHICS);return;
    case MANUAL_GRAPHICS:show(button==1?BLUR:SHADOWS);return;
    case SHADOWS:
        s.no_shadows=button==1;
        commit(&s,s.no_shadows?"Sombras dinamicas desactivadas. Cierra el juego normalmente y vuelve a abrirlo para aplicarlo.":"Sombras dinamicas restauradas. Cierra y vuelve a abrir el juego para aplicarlo.");return;
    case BLUR:s.motion_blur=button==1;commit(&s,"Desenfoque guardado. Reinicia el juego para aplicarlo.");return;
    case RESOLUTION:
        if(button==2){resolution_choice=(resolution_choice+1)%3;show(RESOLUTION);return;}
        if(ctr_settings_set_resolution(&s,(int)resolution_choice)<0){state=0;return;}
        commit(&s,"Resolucion guardada. Cierra el juego normalmente y vuelve a abrirlo para aplicarla. El limite de FPS se conserva.");return;
    case RESET_GRAPHICS:
        if(button==2){show(GRAPHICS_MORE);return;}
        if(ctr_settings_reset_graphics(&s)<0){state=0;return;}
        commit(&s,"Graficos restaurados. Cierra el juego normalmente y vuelve a abrirlo. FPS, partida, apodo y amigos conservados.");return;
    case LIST:show(button==1?SOCIAL_HUB:FRIENDS_LIST);return;
    case SOCIAL_HUB:show(button==1?SERVER_LIST:SOCIAL_PENDING);return;
    case SOCIAL_PENDING:show(button==1?REQUESTS:SOCIAL_MORE);return;
    case SOCIAL_MORE:show(button==1?INVITES:NET_INFO);return;
    case NET_INFO:show(button==1?NET_INFO:SOCIAL_MORE);return;
    case SERVER_LIST:case REQUESTS:case INVITES:{
        int previous=state;
        if(!social_target[0]){show(button==1?state:SOCIAL_HUB);return;}
        if(button==2){if(state==SERVER_LIST)friend_choice++;else if(state==REQUESTS)request_choice++;else invite_choice++;show(previous);return;}
        if(state==REQUESTS){show(REQUEST_ACTION);return;}
        if(state==INVITES){int r=ctr_session_queue(social_target);notice=r?"No se pudo preparar la invitacion. Entra primero a Online y vuelve a intentarlo.":"Invitacion aceptada. Vuelve al juego para entrar en la sala.";}
        else {int r=ctr_social_action("invite",social_target);notice=r?"No se pudo enviar. Espera y vuelve a intentarlo.":"Invitacion en cola. El servidor confirmara el envio en la lista de amigos.";}
        show(NOTICE);return;
    }
    case REQUEST_ACTION:{int r=ctr_social_action(button==1?"accept":"decline",social_target);notice=r?"No se pudo enviar. Espera y vuelve a intentarlo.":"Respuesta en cola. La lista se actualizara cuando responda el servidor.";show(NOTICE);return;}
    case FRIENDS:show(button==1?ADD:FRIENDS_LIST);return;
    case FRIENDS_LIST:show(button==1?LIST:REMOVE);return;
    default:break;
    }state=0;
}
CTR_EXPORT int ctr_menu_init(const CtrMenuApi *native){
    if(!native||!native->message_init||!native->message_open||!native->message_status||!native->message_update||!native->message_result||!native->message_term||native->user<0)return -1;
    api=*native;state=dialog=combo_held=cooldown=setup_pending=0;owned_handle=-1;
    __atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);__atomic_store_n(&capturing,0,__ATOMIC_RELEASE);available=1;return 0;
}
CTR_EXPORT void ctr_menu_request_setup(void){setup_pending=120;}
CTR_EXPORT int ctr_menu_poll(int32_t handle,uint32_t buttons){
    if(!available)return 0;int zero=0;
    if(!__atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return state!=0;
    int capture=state!=0;int combo=(buttons&6)==6;
    if(owned_handle<0)owned_handle=handle;
    if(handle!=owned_handle)goto done;
    ctr_updater_tick();
    ctr_social_tick();
    ctr_season_tick();
    if(!state&&setup_pending&&!--setup_pending){
        // Respect dialogs already owned by CTR or the OS; retry later without
        // stealing their input or assuming a particular loading-screen length.
        int status=api.message_status();
        if((status==0||status==1)&&(!api.ime_status||api.ime_status()==0)){show(SETUP);capture=state!=0;}
        if(!state)setup_pending=120;combo_held=combo;goto done;
    }
    if(cooldown>0)cooldown--;
    if(!state){if(combo&&!combo_held&&!cooldown){show(MAIN);capture=state!=0;trace(59,state);}combo_held=combo;goto done;}
    int escape=combo&&!combo_held&&!cooldown;combo_held=combo;
    if(dialog==2&&escape){
        if(api.ime_abort)trace(67,api.ime_abort());
        release_ime();state=0;cooldown=20;goto done;
    }
    if(dialog==1&&api.message_update()==3){
        CtrDialogResult result;ctr_memset(&result,0,sizeof(result));int r=api.message_result(&result);
        release_message();dialog=0;
        if(r<0||result.result!=0||result.button<1||result.button>2)state=0;
        else selected(result.button);
        cooldown=20;
    }else if(dialog==2){
        int status=api.ime_status();
        if(status!=ime_last_status){trace(63,status);ime_last_status=status;}
        if(status==1)goto done;
        if(status!=2){
            // The OS dialog disappeared, or its status call failed. Never keep
            // capturing game input while waiting for a result that cannot arrive.
            if(status!=0&&api.ime_abort)trace(67,api.ime_abort());
            if(status!=0)release_ime();
            else {__atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);dialog=0;}
            trace(66,status);state=0;cooldown=20;goto done;
        }
        CtrImeResult result;ctr_memset(&result,0,sizeof(result));int r=api.ime_result(&result);trace(64,r);
        int terminated=release_ime();
        if(terminated<0){state=0;cooldown=20;goto done;}
        if(r<0||result.result!=0){state=0;goto done;}
        char name[17];size_t n=0;while(n<16&&input[n]&&input[n]<128){name[n]=(char)input[n];n++;}name[n]=0;
        if(input[n]){notice="Apodo no valido. Usa letras, numeros, guion o guion bajo.";show(NOTICE);goto done;}
        CtrSettings s;if(ctr_settings_snapshot(&s)){state=0;goto done;}
        if(state==NAME_EDIT){
            if(!ctr_profile_name_valid(name)){notice="Elige un apodo propio de 3 a 16 letras, numeros, guion o guion bajo. No uses nombres genericos como Player o RyuNET.";show(NOTICE);goto done;}
            uint32_t i=0;while(i<s.count&&!ctr_name_equal(name,s.friends[i]))i++;
            if(i<s.count){notice="Ese apodo pertenece a un contacto de tu lista. Elige tu propio apodo.";show(NOTICE);goto done;}
            if(!api.save_name||api.save_name(name)<0){notice="No se pudo guardar el apodo. Se conserva el anterior.";show(NOTICE);goto done;}
            ctr_profile_publish(name);trace(112,0);
            setup_pending=0;notice="Apodo guardado. Cierra el juego normalmente y vuelve a abrirlo para usarlo en RyuNET. Si el servidor rechaza el nombre, elige otro que no este ocupado. No compartas tus archivos de identidad.";show(NOTICE);cooldown=20;goto done;
        }
        r=state==ADD?ctr_settings_add(&s,name,ctr_player_name()):ctr_settings_remove(&s,name);
        if(state==REMOVE&&ctr_social_contact(name))r=0;
        if(r<0){notice=r==-3?"Ese amigo ya esta en la lista.":"No se pudo cambiar la lista. Comprueba el apodo (1 a 16 caracteres), que no sea el tuyo y que haya espacio.";show(NOTICE);}
        else {
            int social_result=ctr_social_action(state==ADD?"request":"remove",name);
            commit(&s,social_result?"Contacto local guardado. No se pudo poner en cola la solicitud del servidor; entra a Online y vuelve a intentarlo.":"Solicitud en cola. Revisa Amigos del servidor para confirmar la respuesta. La otra persona debe aceptar las nuevas amistades.");
        }
        cooldown=20;
    }
done:
    __atomic_store_n(&capturing,state!=0,__ATOMIC_RELEASE);
    __atomic_store_n(&lock,0,__ATOMIC_RELEASE);return capture;
}
