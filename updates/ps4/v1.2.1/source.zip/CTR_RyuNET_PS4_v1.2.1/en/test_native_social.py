"""Actual PS4 SELF: signed social HTTP worker and read-only per-user data."""
import ctypes as C,hashlib,hmac,struct,unittest
from test_native_updates import UpdateMachine
from test_native_bridge import prepare,SCRATCH,STUB
from test_v064 import View
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RAX
class Tests(unittest.TestCase):
    def machine(self):
        m=UpdateMachine(response=b'friend 1 1 8 PcFriend\nincoming NewFriend\ninvite 2 PcFriend\n');m.social_http=True
        m.files['/data/ryunet/users/12345678/profile.ini']=b'version=2\nnickname=OwnPlayer\nidentity=installation\n'
        m.files['/data/ryunet/users/12345678/identity.key']=bytes(range(32)).hex().encode()
        m.map(SCRATCH,16384);m.allowed.append((SCRATCH,SCRATCH+16384));self.assertEqual(m.initialize(),0);return m
    def invoke(self,m,name,*args):return m.call(m.exports[prepare.nid(name)],*args)
    def test_self_social_poll_is_deferred_signed_bounded_and_keeps_profile_bytes(self):
        m=self.machine();before=dict(m.files);self.invoke(m,'ctr_social_tick')
        self.assertEqual(len(m.tasks),1);self.assertFalse(m.requested);m.finish()
        self.assertEqual(m.requested,['http://octr.ryu7w7.xyz:8080/ryunet/friends?name=OwnPlayer&format=text']*2)
        proof=next(v for _,k,v,_ in m.http_headers if k=='X-RyuNET-Proof')
        _,ts,nonce,mac=proof.split('.')
        key=hmac.new(bytes(range(32)),b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest().encode()
        message=(ts+'\n'+nonce+'\nGET\n/ryunet/friends?name=OwnPlayer&format=text').encode()
        self.assertEqual(mac,hmac.new(key,message,hashlib.sha256).hexdigest())
        self.assertEqual(self.invoke(m,'ctr_social_snapshot',SCRATCH),0)
        out=View.from_buffer_copy(bytes(m.uc.mem_read(SCRATCH,C.sizeof(View))))
        self.assertEqual((out.state,out.count,out.incoming_count,out.invite_count),(2,1,1,1))
        for p,data in before.items():self.assertEqual(m.files[p],data)
        self.assertFalse(m.fds);self.assertEqual(len(m.cleanup),6)
        self.assertEqual(m.policy['sceHttpSetAutoRedirect'],(604,0))
    def test_self_accept_request_uses_post_and_preserves_nonce_uniqueness(self):
        m=self.machine();self.invoke(m,'ctr_social_tick');m.finish()
        m.uc.mem_write(SCRATCH,b'accept\0');m.uc.mem_write(SCRATCH+64,b'NewFriend\0')
        self.assertEqual(self.invoke(m,'ctr_social_action',SCRATCH,SCRATCH+64),0)
        self.invoke(m,'ctr_social_tick');m.responses=[b'status sent\n',m.response];m.finish()
        self.assertTrue(any('/friends/accept?name=OwnPlayer&from=NewFriend&format=text' in x for x in m.requested))
        proofs=[v for _,k,v,_ in m.http_headers if k=='X-RyuNET-Proof'];self.assertEqual(len(set(proofs)),len(proofs))
        self.assertFalse(m.fds)
if __name__=='__main__':unittest.main(verbosity=2)
