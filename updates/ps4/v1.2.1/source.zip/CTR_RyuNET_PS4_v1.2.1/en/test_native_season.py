"""Run the actual PS4 SELF event hook, original game signature and HTTP worker."""
import struct,unittest
from pathlib import Path
from test_native_updates import UpdateMachine
from test_native_bridge import ModuleMachine,prepare,SCRATCH,STACK,STUB,P
from unicorn.x86_const import *
BASE=0x900000000;SITE=BASE+0xfb601b
ORIGINAL=bytes.fromhex('498b87300100004c89ef8b7018e8e3160000')
def invoke(m,name,*args):return m.call(m.exports[prepare.nid(name)],*args)
class Tests(unittest.TestCase):
    def test_hook_site_matches_the_users_actual_supported_game_image(self):
        raw=Path(P[0]['elf']).read_bytes();_,_,ph,_,_=prepare.parse_elf(raw)
        seg=next(p for p in ph if p['type']==1 and p['vaddr']<=0xfb601b and 0xfb601b+18<=p['vaddr']+p['filesz'])
        off=seg['offset']+0xfb601b-seg['vaddr'];self.assertEqual(raw[off:off+18],ORIGINAL)
    def test_real_self_installs_only_the_thirteen_byte_site_and_restores_rx(self):
        m=ModuleMachine('ui_success');self.assertEqual(m.initialize(),0)
        data=bytes(m.uc.mem_read(SITE,18));self.assertEqual(data[:2],b'\x48\xb8');self.assertEqual(data[10:13],b'\xff\xe0\x90');self.assertEqual(data[13:],ORIGINAL[13:])
        page=SITE&~0x3fff;self.assertEqual([x for x in m.protect_calls if x[0]==page],[(page,0x4000,7),(page,0x4000,5)])
    def test_unknown_bytes_or_denied_permissions_leave_original_event_code_intact(self):
        for case in ('ui_season_bad_signature','ui_season_protect_failure'):
            m=ModuleMachine(case);before=bytes(m.uc.mem_read(SITE,18));self.assertEqual(m.initialize(),0);self.assertEqual(bytes(m.uc.mem_read(SITE,18)),before)
    def machine(self,body=b'{"theme":"halloween","value":1}',status=200,fail=None):
        m=UpdateMachine(response=body,status=status,fail=fail);m.map(SCRATCH,0x4000);m.allowed.append((SCRATCH,SCRATCH+0x4000));self.assertEqual(m.initialize(),0);return m
    def test_public_theme_get_needs_no_identity_headers_is_deferred_and_cleans_up(self):
        m=self.machine();before=dict(m.files);invoke(m,'ctr_season_tick')
        self.assertEqual(len(m.tasks),1);self.assertFalse(m.requested);self.assertNotIn('sceHttpSendRequest',m.calls);m.finish()
        self.assertEqual(invoke(m,'ctr_season_current'),1);self.assertEqual(m.requested,['http://octr.ryu7w7.xyz:8080/ryunet/theme']*2)
        self.assertEqual([k for _,k,v,_ in m.http_headers],['Accept','Accept-Encoding']);self.assertFalse(m.fds);self.assertEqual({k:v for k,v in m.files.items() if k!='/data/GoldHEN/ctr_native_port.log'},{k:v for k,v in before.items() if k!='/data/GoldHEN/ctr_native_port.log'})
        self.assertEqual(len(m.cleanup),6);self.assertEqual(m.policy['sceHttpSetAutoRedirect'],(604,0))
    def test_real_hook_preserves_every_unrelated_register_flag_and_stack_value(self):
        regs=(UC_X86_REG_RAX,UC_X86_REG_RBX,UC_X86_REG_RCX,UC_X86_REG_RDX,UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_R8,UC_X86_REG_R9,UC_X86_REG_R10,UC_X86_REG_R11,UC_X86_REG_R12,UC_X86_REG_R13,UC_X86_REG_R14,UC_X86_REG_R15)
        for theme,value in [(None,2),('default',0),('halloween',1),('golden',2)]:
            m=self.machine(body=(b'' if theme is None else ('{"theme":"'+theme+'"}').encode()))
            if theme is not None:invoke(m,'ctr_season_tick');m.finish()
            for i,reg in enumerate(regs):m.uc.reg_write(reg,0xa000+i)
            outer=SCRATCH;config=SCRATCH+0x400;manager=SCRATCH+0x800
            m.uc.mem_write(outer+0x130,struct.pack('<Q',config));m.uc.mem_write(config+0x18,struct.pack('<I',2))
            m.uc.reg_write(UC_X86_REG_R15,outer);m.uc.reg_write(UC_X86_REG_R13,manager);m.uc.reg_write(UC_X86_REG_RSP,STACK+0x1f000);m.uc.reg_write(UC_X86_REG_EFLAGS,0x246)
            before={r:m.uc.reg_read(r) for r in regs};rsp=m.uc.reg_read(UC_X86_REG_RSP)
            m.uc.emu_start(SITE,SITE+13,count=100)
            self.assertEqual(m.uc.reg_read(UC_X86_REG_RIP),SITE+13);self.assertEqual(m.uc.reg_read(UC_X86_REG_RAX),config);self.assertEqual(m.uc.reg_read(UC_X86_REG_RDI),manager);self.assertEqual(m.uc.reg_read(UC_X86_REG_RSI),value)
            for r,v in before.items():
                if r not in (UC_X86_REG_RAX,UC_X86_REG_RDI,UC_X86_REG_RSI):self.assertEqual(m.uc.reg_read(r),v)
            self.assertEqual(m.uc.reg_read(UC_X86_REG_RSP),rsp);self.assertEqual(m.uc.reg_read(UC_X86_REG_EFLAGS),0x246)
    def test_bad_reply_and_http_failures_never_invent_an_event(self):
        for fail,status,body in [(None,200,b'{"theme":"bad"}'),(None,503,b''),('sceHttpSendRequest',200,b'')]:
            m=self.machine(body,status,fail);invoke(m,'ctr_season_tick');m.finish();self.assertEqual(invoke(m,'ctr_season_current'),0xffffffff)
if __name__=='__main__':unittest.main(verbosity=2)
