"""Execute the native season parser and deferred worker, including hostile input."""
import ctypes as C,json,unittest
from test_core import lib

class Api(C.Structure):
    _fields_=[('spawn',C.c_void_p),('request',C.c_void_p),('time',C.c_void_p),('trace',C.c_void_p)]
lib.ctr_season_init.argtypes=[C.POINTER(Api)]
lib.ctr_season_parse.argtypes=[C.c_char_p,C.c_size_t,C.POINTER(C.c_int32)]
lib.ctr_season_current.restype=C.c_int32
class Service:
    def __init__(self,body=b'{"theme":"halloween","value":1}',status=200,fail_spawn=False):
        self.now=1000000;self.tasks=[];self.requests=[];self.body=body;self.status=status;self.traces=[]
        def spawn(fn,arg):
            if fail_spawn:return -1
            self.tasks.append((fn,arg));return 0
        def request(method,target,out,cap):
            self.requests.append((method,target,cap));assert cap==4096
            C.memmove(out,self.body+b'\0',min(len(self.body)+1,cap));return self.status
        self.callbacks=[C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_void_p)(spawn),C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_char_p,C.c_void_p,C.c_size_t)(request),C.CFUNCTYPE(C.c_uint64)(lambda:self.now),C.CFUNCTYPE(None,C.c_int32,C.c_int32)(lambda a,b:self.traces.append((a,b)))]
        self.api=Api(*(C.cast(f,C.c_void_p).value for f in self.callbacks))
        assert lib.ctr_season_init(C.byref(self.api))==0
    def finish(self):
        fn,arg=self.tasks.pop(0);C.CFUNCTYPE(C.c_void_p,C.c_void_p)(fn)(arg)
class Tests(unittest.TestCase):
    def tearDown(self):self.assertEqual(lib.ctr_season_init(None),0)
    def test_official_server_reply_and_all_three_modes(self):
        for theme,value in [('default',0),('halloween',1),('golden',2)]:
            raw=json.dumps(dict(theme=theme,value=value,season='Spooky',source='calendar',end_race_timeout=30)).encode();out=C.c_int32(-123)
            self.assertEqual(lib.ctr_season_parse(raw,len(raw),C.byref(out)),0);self.assertEqual(out.value,value)
    def test_theme_is_required_numbers_duplicates_truncation_and_oversize_rejected(self):
        for raw in [b'{}',b'{"value":1}',b'{"theme":"other"}',b'{"theme":"halloween","value":2}',b'{"theme":"halloween","value":-1}',b'{"theme":"halloween","value":01}',b'{"theme":"halloween","value":1.0}',b'{"theme":"halloween","theme":"default"}',b'{"theme":"halloween","value":1,"value":1}',b'{"theme":"halloween"}junk',b'{"theme":"halloween"}\0',b'{"theme":"halloween","nested":'+b'['*18+b'0'+b']'*18+b'}',b'x'*4096]:
            out=C.c_int32(-123);self.assertLess(lib.ctr_season_parse(raw,len(raw),C.byref(out)),0,raw[:80]);self.assertEqual(out.value,-123)
    def test_only_one_deferred_public_request_and_fifteen_minute_refresh(self):
        s=Service();self.assertEqual(lib.ctr_season_current(),-1)
        for _ in range(100):lib.ctr_season_tick()
        self.assertEqual(len(s.tasks),1);self.assertFalse(s.requests)
        self.assertEqual(lib.ctr_season_init(None),-1);s.finish()
        self.assertEqual(s.requests,[(b'GET',b'/ryunet/theme',4096)]);self.assertEqual(lib.ctr_season_current(),1)
        for _ in range(100):lib.ctr_season_tick()
        self.assertFalse(s.tasks);s.now+=900000000;lib.ctr_season_tick();s.body=b'{"theme":"default","value":0}';s.finish();self.assertEqual(lib.ctr_season_current(),0)
    def test_failed_request_keeps_last_mode_and_retries_after_one_minute(self):
        s=Service();lib.ctr_season_tick();s.finish()
        for status,body in [(403,b''),(200,b'bad json'),(0,b'')]:
            s.now+=900000000;s.status=status;s.body=body;lib.ctr_season_tick();s.finish();self.assertEqual(lib.ctr_season_current(),1)
            s.now+=59999999;lib.ctr_season_tick();self.assertFalse(s.tasks)
            s.now+=1;lib.ctr_season_tick();self.assertEqual(len(s.tasks),1);s.finish()
    def test_spawn_failure_does_not_block_the_game_or_change_mode(self):
        s=Service(fail_spawn=True)
        for _ in range(100):lib.ctr_season_tick()
        self.assertFalse(s.tasks);self.assertFalse(s.requests);self.assertEqual(lib.ctr_season_current(),-1)
if __name__=='__main__':unittest.main(verbosity=2)
