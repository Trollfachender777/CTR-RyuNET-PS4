"""PS4-only releases, hostile input, deferred I/O, rate limits and menu flow."""
import ctypes as C, json, unittest
from test_core import lib
from test_settings_menu import Menu, defaults, snapshot

class Release(C.Structure):
    _fields_=[('id',C.c_uint64),('tag',C.c_char*81),('published',C.c_char*21),('url',C.c_char*257)]
class Result(C.Structure):
    _fields_=[('state',C.c_int32),('error',C.c_int32),('release',Release)]
class Api(C.Structure):
    _fields_=[('spawn',C.c_void_p),('fetch',C.c_void_p),('time',C.c_void_p)]
lib.ctr_release_parse.argtypes=[C.c_char_p,C.c_size_t,C.POINTER(Release)]
lib.ctr_updates_init.argtypes=[C.POINTER(Api)]
lib.ctr_updates_snapshot.argtypes=[C.POINTER(Result)]
ENDPOINT='https://api.github.com/repos/Trollfachender777/CTR-RyuNET-PS4/releases/latest'
def payload(**kwargs):
    p=dict(id=419889396,tag_name='constructores',published_at='2026-10-21T22:35:17Z',html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/constructores',draft=False,prerelease=False)
    p.update(kwargs)
    return json.dumps(p).encode()
def new_payload():
    return payload(id=419889397,tag_name='v1.3.0',published_at='2026-10-25T12:00:00Z',html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/v1.3.0')
def state():
    out=Result();assert lib.ctr_updates_snapshot(C.byref(out))==0;return out
class Transport:
    def __init__(self,body=None,status=200,error=0,spawn_error=0):
        self.body=payload() if body is None else body;self.status=status;self.error=error;self.spawn_error=spawn_error
        self.now=1000000;self.requests=[];self.entry=None
        def spawn(entry,arg):self.entry=entry;self.arg=arg;return self.spawn_error
        def fetch(url,out,cap,length,status_out):
            self.requests.append(url.decode());status_out[0]=self.status
            data=self.body[:cap];C.memmove(out,data,len(data));length[0]=len(self.body);return self.error
        self.callbacks=[C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_void_p)(spawn),C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t),C.POINTER(C.c_int32))(fetch),C.CFUNCTYPE(C.c_uint64)(lambda:self.now)]
        self.api=Api(*(C.cast(cb,C.c_void_p).value for cb in self.callbacks))
        assert lib.ctr_updates_init(C.byref(self.api))==0
    def finish(self):C.CFUNCTYPE(C.c_void_p,C.c_void_p)(self.entry)(self.arg)
class Tests(unittest.TestCase):
    def tearDown(self):lib.ctr_updates_init(None)
    def parse(self,data):
        out=Release();C.memset(C.byref(out),0x55,C.sizeof(out));before=bytes(out)
        r=lib.ctr_release_parse(data,len(data),C.byref(out))
        if r:self.assertEqual(bytes(out),before)
        return r,out
    def test_real_release_shape_and_nested_fields_cannot_replace_top_level(self):
        raw=payload(assets=[{'id':99,'tag_name':'PC_FAKE','html_url':'http://fake'}],body='"tag_name": "v999"; prueba \\n \U0001f3c1')
        r,out=self.parse(raw);self.assertEqual(r,0);self.assertEqual(out.tag,b'constructores');self.assertEqual(out.id,419889396)
    def test_rejects_pc_repository_http_cross_origin_and_mismatching_tag(self):
        for url in ['https://github.com/Ryu7w7/OCTR-NitroFueled-PC/releases/tag/constructores','http://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/constructores','https://evil.test/releases/tag/constructores','https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/other']:
            with self.subTest(url=url):self.assertNotEqual(self.parse(payload(html_url=url))[0],0)
    def test_rejects_drafts_prereleases_missing_fields_and_unsafe_tags(self):
        for patch in [{'draft':True},{'prerelease':True},{'id':0},{'id':-1},{'id':2**64},{'id':1.5},{'published_at':None},{'tag_name':'foo/bar'},{'tag_name':'a\x00b'},{'tag_name':'x'*81}]:
            with self.subTest(patch=patch):self.assertNotEqual(self.parse(payload(**patch))[0],0)
        self.assertNotEqual(self.parse(b'{}')[0],0)
    def test_rejects_malformed_trailing_and_duplicate_metadata(self):
        raw=payload()
        for bad in [raw[:-1],raw+b'garbage',raw[:-1]+b',"id":2}',raw.replace(b'419889396',b'0419889396'),b'{"body":[[[[[[[[[[[[[[[[[[0]]]]]]]]]]]]]]]]]]}',raw.replace(b'false',b'falseX',1),raw.replace(b'constructores',b'bad\\u0000tag',1)]:
            with self.subTest(bad=bad[:80]):self.assertNotEqual(self.parse(bad)[0],0)
    def test_rejects_invalid_calendar_and_oversized_response(self):
        for d in ['2026-02-30T12:00:00Z','2026-13-01T12:00:00Z','2026-10-25T25:00:00Z','2026-10-25T12:60:00Z']:
            self.assertNotEqual(self.parse(payload(published_at=d))[0],0)
        self.assertNotEqual(self.parse(b' '*65537)[0],0)
    def test_start_defers_all_network_io_and_prevents_duplicate_workers(self):
        t=Transport();self.assertEqual(lib.ctr_updates_start(),1);self.assertEqual(state().state,1)
        self.assertEqual(t.requests,[]);self.assertEqual(lib.ctr_updates_start(),0)
        self.assertEqual(lib.ctr_updates_init(None),-1);t.finish()
        self.assertEqual(state().state,2);self.assertEqual(t.requests,[ENDPOINT])
    def test_only_a_later_stable_ps4_release_is_an_update(self):
        for raw,expected in [(new_payload(),3),(payload(),2),(payload(id=419889397,published_at='2026-10-20T12:00:00Z'),2),(payload(tag_name='v1.2.0',html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/v1.2.0',published_at='2026-10-25T12:00:00Z'),2)]:
            t=Transport(raw);lib.ctr_updates_start();t.finish();self.assertEqual(state().state,expected)
    def test_network_rate_limit_not_found_and_bad_json_are_not_current(self):
        for status,error,raw,expected in [(200,-1,b'',4),(403,0,b'',5),(429,0,b'',5),(404,0,b'',8),(500,0,b'',4),(200,0,b'broken',6),(200,0,b'x'*65537,6)]:
            t=Transport(raw,status,error);lib.ctr_updates_start();t.finish();self.assertEqual(state().state,expected)
    def test_retry_interval_and_worker_failure(self):
        t=Transport();lib.ctr_updates_start();t.finish();self.assertEqual(lib.ctr_updates_start(),0)
        t.now+=60000000;self.assertEqual(lib.ctr_updates_start(),1);t.finish();self.assertEqual(len(t.requests),2)
        t=Transport(spawn_error=9);self.assertEqual(lib.ctr_updates_start(),-1);self.assertEqual(state().state,7);self.assertEqual(t.requests,[])
    def test_missing_platform_is_explicitly_unavailable(self):
        lib.ctr_updates_init(None);self.assertEqual(lib.ctr_updates_start(),0);self.assertEqual(state().state,7)
if __name__=='__main__':unittest.main(verbosity=2)
