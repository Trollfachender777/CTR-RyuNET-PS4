// SPDX-License-Identifier: GPL-2.0-only
// Metadata and code have fixed GitHub origins. No credentials or user data leave
// the console. Installing requires an explicit confirmation, a complete SELF,
// its declared length and SHA-256, and a loader with the same update ABI.
#include "updater.h"
#include "installation.h"
// Bounded JSON scanner shared with the release parser, including duplicate-key
// checks at the schema boundary. Nested unknown values cannot replace metadata.
#include "update_json.h"
static int version(const char *s,uint32_t *out){
    if(!s||*s++!='v')return -1;uint32_t v=0;
    for(int part=0;part<3;part++){
        uint32_t n=0;int digits=0;const char *start=s;
        while(*s>='0'&&*s<='9'){if(++digits>3)return -1;n=n*10+(unsigned)(*s++-'0');}
        if(!digits||(digits>1&&*start=='0'))return -1;v=v*1000+n;
        if(part<2){if(*s++!='.')return -1;}else if(*s)return -1;
    }*out=v;return 0;
}
static int digest(const char *s,uint8_t out[32]){
    if(ctr_strlen(s)!=64)return -1;for(int i=0;i<32;i++){int a=hex(s[i*2]),b=hex(s[i*2+1]);if(a<0||b<0)return -1;out[i]=(uint8_t)(a*16+b);}return 0;
}
CTR_EXPORT int ctr_update_manifest_parse(const char *data,size_t length,CtrUpdatePackage *out){
    if(!out)return -1;CtrUpdatePackage p;ctr_memset(&p,0,sizeof(p));
    if(ctr_release_parse(data,length,&p.release))return -1;
    uint32_t semver;if(version(p.release.tag,&semver))return -1;
    Json j={data,data+length};if(take(&j,'{'))return -1;unsigned seen=0;
    for(;;){
        char key[128],value[128];uint64_t integer=0;unsigned bit=0;int r=0;
        if(string(&j,key,sizeof(key))||take(&j,':'))return -1;
        if(!ctr_strcmp(key,"schema")){bit=1;r=unsigned_id(&j,&integer);if(integer!=1)r=-1;}
        else if(!ctr_strcmp(key,"module_abi")){bit=2;r=unsigned_id(&j,&integer);if(integer!=1)r=-1;}
        else if(!ctr_strcmp(key,"title_id")){bit=4;r=string(&j,value,sizeof(value));if(!r&&ctr_strcmp(value,"RYUN00001"))r=-1;}
        else if(!ctr_strcmp(key,"cusa")){bit=8;r=string(&j,value,sizeof(value));if(!r&&ctr_strcmp(value,"CUSA13795"))r=-1;}
        else if(!ctr_strcmp(key,"game_version")){bit=16;r=string(&j,value,sizeof(value));if(!r&&ctr_strcmp(value,"01.21"))r=-1;}
        else if(!ctr_strcmp(key,CTR_UPDATER_LANGUAGE "_size")){bit=32;r=unsigned_id(&j,&integer);if(integer<4096||integer>CTR_UPDATER_MAX)r=-1;p.size=(uint32_t)integer;}
        else if(!ctr_strcmp(key,CTR_UPDATER_LANGUAGE "_sha256")){bit=64;r=string(&j,value,sizeof(value));if(!r)r=digest(value,p.digest);}
        else r=skip(&j,0);
        if(r||(bit&&(seen&bit)))return -1;seen|=bit;ws(&j);
        if(j.p<j.end&&*j.p=='}'){j.p++;break;}if(take(&j,','))return -1;
    }
    ws(&j);if(j.p!=j.end||seen!=127)return -1;*out=p;return 0;
}
CTR_EXPORT int ctr_updater_url_allowed(const char *url){
    if(!url)return 0;if(!ctr_strcmp(url,CTR_UPDATER_CHANNEL))return 1;
    const char prefix[]=CTR_UPDATER_FILES;size_t n=sizeof(prefix)-1;
    if(ctr_strncmp(url,prefix,n))return 0;char tag[81];size_t i=0;
    while(url[n+i]&&url[n+i]!='/'){if(i+1>=sizeof(tag))return 0;tag[i]=url[n+i];i++;}tag[i]=0;
    uint32_t v;if(version(tag,&v)||ctr_strcmp(url+n+i,"/ctr_online_" CTR_UPDATER_LANGUAGE ".prx"))return 0;return 1;
}
static uint16_t u16(const uint8_t *p){return (uint16_t)(p[0]|p[1]<<8);}
static uint32_t u32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint64_t u64(const uint8_t *p){return (uint64_t)u32(p)|(uint64_t)u32(p+4)<<32;}
CTR_EXPORT int ctr_update_self_valid(const uint8_t *p,size_t n){
    if(!p||n<4096||n>CTR_UPDATER_MAX||u32(p)!=0x1d3d154f)return 0;
    unsigned count=u16(p+24);size_t base=32+(size_t)count*32;
    if(!count||count>64||base+64>n)return 0;const uint8_t *elf=p+base;
    if(u32(elf)!=0x464c457f||elf[4]!=2||elf[5]!=1||elf[6]!=1||u16(elf+18)!=62)return 0;
    uint64_t phoff=u64(elf+32);unsigned phnum=u16(elf+56);
    if(u16(elf+54)!=56||!phnum||phnum>64||phoff>n-base||phnum*56>n-base-phoff)return 0;
    unsigned mapped=0;
    for(unsigned i=0;i<count;i++){
        const uint8_t *s=p+32+i*32;uint64_t flags=u64(s),off=u64(s+8),size=u64(s+16),memory=u64(s+24);
        if(off>n||size>n-off)return 0;if(!(flags&0x800))continue;
        unsigned index=(unsigned)(flags>>20)&4095;
        if((flags&10)||index>=phnum||size!=memory||u64(elf+phoff+index*56+32)!=size)return 0;mapped++;
    }return mapped!=0;
}
static CtrUpdaterApi platform;
static CtrUpdaterResult result;
static CtrUpdatePackage package;
static int guard,attempted;
static uint64_t last_attempt,boot_time;
static unsigned auto_ticks;
static int auto_check,auto_prompted;
static char metadata[CTR_UPDATE_BODY_MAX];
static uint8_t payload[CTR_UPDATER_MAX];
static int acquire(void){int zero=0;return __atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void release(void){__atomic_store_n(&guard,0,__ATOMIC_RELEASE);}
static void publish(const CtrUpdaterResult *next){while(!acquire())__asm__ volatile("pause");result=*next;release();}
void ctr_updater_progress(size_t done,size_t total){if(!total||done>total||!acquire())return;if(result.state==CTR_UPDATER_DOWNLOADING&&package.size&&done<=package.size)result.percent=(uint32_t)(done*90/package.size);release();}
static void *check_worker(void *unused){
    (void)unused;CtrUpdaterResult next;CtrUpdatePackage p;ctr_memset(&next,0,sizeof(next));size_t length=0;int32_t status=0;
    int r=platform.fetch(CTR_UPDATER_CHANNEL,metadata,sizeof(metadata),&length,&status);next.error=r?r:status;
    if(r)next.state=CTR_UPDATER_NETWORK;
    else if(status==403||status==429)next.state=CTR_UPDATER_RATE_LIMIT;
    else if(status==404)next.state=CTR_UPDATER_NO_RELEASE;
    else if(status!=200)next.state=CTR_UPDATER_NETWORK;
    else if(ctr_update_manifest_parse(metadata,length,&p))next.state=CTR_UPDATER_INVALID;
    else {
        uint32_t candidate,current;version(p.release.tag,&candidate);version(CTR_PS4_RELEASE_TAG,&current);
        next.error=0;ctr_memcpy(next.version,p.release.tag,sizeof(next.version));next.state=candidate>current?CTR_UPDATER_AVAILABLE:CTR_UPDATER_CURRENT;
        while(!acquire())__asm__ volatile("pause");package=p;result=next;release();return 0;
    }publish(&next);return 0;
}
static void *install_worker(void *unused){
    (void)unused;CtrUpdaterResult next;ctr_memset(&next,0,sizeof(next));next.state=CTR_UPDATER_FAILED;
    ctr_memcpy(next.version,package.release.tag,sizeof(next.version));char url[256];size_t a=ctr_strlen(CTR_UPDATER_FILES),b=ctr_strlen(package.release.tag);
    ctr_memcpy(url,CTR_UPDATER_FILES,a);ctr_memcpy(url+a,package.release.tag,b);
    const char suffix[]="/ctr_online_" CTR_UPDATER_LANGUAGE ".prx";ctr_memcpy(url+a+b,suffix,sizeof(suffix));
    size_t length=0;int32_t status=0;int r=platform.fetch(url,(char*)payload,sizeof(payload),&length,&status);next.error=r?r:status;
    uint8_t hash[32];
    if(!r&&status==200&&length==package.size&&ctr_update_self_valid(payload,length)){
        ctr_sha256(payload,length,hash);int matches=1;for(int i=0;i<32;i++)if(hash[i]!=package.digest[i])matches=0;
        if(matches){r=platform.stage(payload,length,hash);next.error=r;next.state=r==-100?CTR_UPDATER_NEEDS_SETUP:r?CTR_UPDATER_FAILED:CTR_UPDATER_READY;}
        else next.error=-20;
    }else if(!r&&status==200)next.error=-21;
    if(next.state==CTR_UPDATER_READY)next.percent=100;publish(&next);return 0;
}
CTR_EXPORT int ctr_updater_init(const CtrUpdaterApi *api){
    if(!acquire())return -1;if(result.state==CTR_UPDATER_CHECKING||result.state==CTR_UPDATER_DOWNLOADING){release();return -1;}
    ctr_memset(&platform,0,sizeof(platform));ctr_memset(&result,0,sizeof(result));ctr_memset(&package,0,sizeof(package));attempted=0;last_attempt=0;
    if(api)platform=*api;auto_ticks=0;auto_check=auto_prompted=0;boot_time=platform.time_us?platform.time_us():0;result.state=platform.spawn&&platform.fetch&&platform.time_us?CTR_UPDATER_IDLE:CTR_UPDATER_UNAVAILABLE;release();return 0;
}
CTR_EXPORT int ctr_updater_snapshot(CtrUpdaterResult *out){if(!out||!acquire())return -1;*out=result;release();return 0;}
CTR_EXPORT int ctr_updater_check(void){
    if(!acquire())return 0;
    if(result.state==CTR_UPDATER_CHECKING||result.state==CTR_UPDATER_DOWNLOADING||result.state==CTR_UPDATER_READY||!platform.spawn||!platform.fetch||!platform.time_us){release();return 0;}
    uint64_t now=platform.time_us();if(attempted&&now>=last_attempt&&now-last_attempt<60000000ULL){release();return 0;}
    attempted=1;last_attempt=now;ctr_memset(&result,0,sizeof(result));result.state=CTR_UPDATER_CHECKING;release();
    int r=platform.spawn(check_worker,0);if(r){CtrUpdaterResult failed={0};failed.state=CTR_UPDATER_UNAVAILABLE;failed.error=r;publish(&failed);return -1;}return 1;
}
CTR_EXPORT int ctr_updater_install(void){
    if(!acquire())return 0;if(result.state!=CTR_UPDATER_AVAILABLE||!platform.stage){release();return 0;}
    result.state=CTR_UPDATER_DOWNLOADING;result.percent=0;release();
    int r=platform.spawn(install_worker,0);if(r){while(!acquire())__asm__ volatile("pause");result.state=CTR_UPDATER_FAILED;result.error=r;release();return -1;}return 1;
}

CTR_EXPORT uint32_t ctr_updater_version(void){uint32_t current=0;version(CTR_PS4_RELEASE_TAG,&current);return current;}

// Delay one automatic metadata check until after startup. This never downloads
// code or opens a dialog. The next explicit L3+R3 opening can show the offer.
CTR_EXPORT void ctr_updater_tick(void){
    if(++auto_ticks<120)return;auto_ticks=0;if(!acquire())return;
    int start=0;
    if(!attempted&&result.state==CTR_UPDATER_IDLE&&platform.time_us){
        uint64_t now=platform.time_us();if(now>=boot_time&&now-boot_time>=30000000ULL){auto_check=1;start=1;}
    }release();if(start)ctr_updater_check();
}
CTR_EXPORT int ctr_updater_auto_prompt(void){
    if(!acquire())return 0;int yes=auto_check&&!auto_prompted&&result.state==CTR_UPDATER_AVAILABLE;
    if(yes)auto_prompted=1;release();return yes;
}
