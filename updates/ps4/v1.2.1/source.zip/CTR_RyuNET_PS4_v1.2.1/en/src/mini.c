// SPDX-License-Identifier: GPL-2.0-only
#include "online_core.h"
void *ctr_memcpy(void *d,const void *s,size_t n){unsigned char *a=d;const unsigned char *b=s;for(size_t i=0;i<n;i++)a[i]=b[i];return d;}
void *ctr_memset(void *d,int c,size_t n){unsigned char *a=d;for(size_t i=0;i<n;i++)a[i]=(unsigned char)c;return d;}
size_t ctr_strlen(const char *s){size_t n=0;while(s[n])n++;return n;}
int ctr_strcmp(const char *a,const char *b){while(*a && *a==*b){a++;b++;}return (unsigned char)*a-(unsigned char)*b;}
int ctr_strncmp(const char *a,const char *b,size_t n){for(size_t i=0;i<n;i++){if(a[i]!=b[i])return (unsigned char)a[i]-(unsigned char)b[i];if(!a[i])return 0;}return 0;}
const char *ctr_strstr(const char *a,const char *b){size_t n=ctr_strlen(b);if(!n)return a;for(;*a;a++)if(!ctr_strncmp(a,b,n))return a;return 0;}
// Compiler-generated aggregate copies are also freestanding.
void *memcpy(void *d,const void *s,size_t n){return ctr_memcpy(d,s,n);}
void *memset(void *d,int c,size_t n){return ctr_memset(d,c,n);}
