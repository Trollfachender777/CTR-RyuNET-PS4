// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
typedef struct {
    int (*spawn)(void *(*entry)(void*),void *arg);
    int (*request)(const char *method,const char *target,char *out,size_t capacity);
    uint64_t (*time_us)(void);
    void (*trace)(int32_t,int32_t);
} CtrSeasonApi;
CTR_EXPORT int ctr_season_parse(const char *body,size_t size,int32_t *mode);
CTR_EXPORT int ctr_season_init(const CtrSeasonApi *api);
CTR_EXPORT void ctr_season_tick(void);
CTR_EXPORT int32_t ctr_season_current(void);
int ctr_season_install(uint64_t base,const void *module);
