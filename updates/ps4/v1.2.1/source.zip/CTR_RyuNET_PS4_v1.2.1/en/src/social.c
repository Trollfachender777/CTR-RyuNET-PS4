// SPDX-License-Identifier: GPL-2.0-only
// PS4 adaptation of OCTR v0.6.4 runtime_friends.c / runtime_http.c.
// Bounded storage, one short-lived worker, never blocking HTTP on game threads.
#include "social.h"
#include "installation.h"
static CtrSocialApi api;
static CtrSocialView view;
static struct {char action[12],who[17];} jobs[64];
static unsigned head,count;static int lock,busy,migrated,have_view;static uint64_t next_refresh;
static char response[32768]; // only the single worker owns this buffer
static int take(void){int zero=0;return __atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void give(void){__atomic_store_n(&lock,0,__ATOMIC_RELEASE);}
static void copy(char *out,const char *in){ctr_memcpy(out,in,ctr_strlen(in)+1);}
static int valid(const char *s){return ctr_name_valid(s)&&ctr_strlen(s)>=3;}
static void add(char *out,const char *in){copy(out+ctr_strlen(out),in);}
static void decimal(char *out,uint64_t n){char r[24];unsigned i=0;do{r[i++]=(char)('0'+n%10);n/=10;}while(n);unsigned j=0;while(i)out[j++]=r[--i];out[j]=0;}
static int token(const char **p,const char *end,char *out,size_t cap){
    while(*p<end&&**p==' ')(*p)++;size_t n=0;
    while(*p<end&&**p!=' '&&**p!='\r'&&**p!='\n'){if(n+1>=cap){out[0]=0;return 0;}out[n++]=*(*p)++;}out[n]=0;return n>0;
}
static int number(const char **p,const char *end,uint32_t *out){
    char text[12];if(!token(p,end,text,sizeof(text)))return 0;uint32_t n=0;
    for(unsigned i=0;text[i];i++){if(text[i]<'0'||text[i]>'9'||n>100000000)return 0;n=n*10+(unsigned)(text[i]-'0');}
    *out=n;return 1;
}
static int trailing(const char *p,const char *end){while(p<end&&(*p==' '||*p=='\r'))p++;return p==end;}
CTR_EXPORT int ctr_social_parse(const char *body,size_t size,CtrSocialView *out){
    if(!body||!out||size>=sizeof(response))return -1;CtrSocialView next;ctr_memset(&next,0,sizeof(next));
    const char *p=body,*end=body+size;
    while(p<end){
        const char *e=p;while(e<end&&*e!='\n'){if(!*e)return -1;e++;}
        const char *q=p;char kind[16],name[17];uint32_t a,b,c;
        if(q==e){p=e<end?e+1:e;continue;}
        if(!token(&q,e,kind,sizeof(kind)))return -1;
        if(!ctr_strcmp(kind,"friend")){
            if(!number(&q,e,&a)||!number(&q,e,&b)||!number(&q,e,&c)||!token(&q,e,name,sizeof(name))||!valid(name)||!trailing(q,e)||a>1||b>8||c>8||b>c||next.count>=CTR_SOCIAL_MAX)return -1;
            for(unsigned i=0;i<next.count;i++)if(ctr_name_equal(next.friends[i].name,name))return -1;
            CtrSocialFriend *f=&next.friends[next.count++];copy(f->name,name);f->online=(int)a;f->players=(int)b;f->max=(int)c;
        }else if(!ctr_strcmp(kind,"incoming")||!ctr_strcmp(kind,"outgoing")){
            if(!token(&q,e,name,sizeof(name))||!valid(name)||!trailing(q,e))return -1;
            uint32_t *n=!ctr_strcmp(kind,"incoming")?&next.incoming_count:&next.outgoing_count;
            char (*list)[17]=!ctr_strcmp(kind,"incoming")?next.incoming:next.outgoing;
            if(*n>=CTR_SOCIAL_PENDING)return -1;copy(list[(*n)++],name);
        }else if(!ctr_strcmp(kind,"invite")){
            if(!number(&q,e,&a)||!token(&q,e,name,sizeof(name))||!valid(name)||!trailing(q,e)||next.invite_count>=CTR_SOCIAL_INVITES)return -1;
            CtrSocialInvite *inv=&next.invites[next.invite_count++];copy(inv->from,name);inv->ago=a;
        } // newer server message / announcement records do not replace friends
        p=e<end?e+1:e;
    }
    next.state=CTR_SOCIAL_READY;next.status=200;*out=next;return 0;
}
CTR_EXPORT int ctr_social_snapshot(CtrSocialView *out){if(!out||!take())return -1;*out=view;give();return 0;}
CTR_EXPORT int ctr_social_contacts(CtrSettings *s){
    if(!s||!take())return -1;
    if(!have_view){give();return 0;}
    s->count=view.count>CTR_MAX_FRIENDS?CTR_MAX_FRIENDS:view.count;for(unsigned i=0;i<s->count;i++)copy(s->friends[i],view.friends[i].name);give();return 1;
}
CTR_EXPORT int ctr_social_contact(const char *name){
    if(!name||!take())return 0;int found=0;
    for(unsigned i=0;i<view.count;i++)if(ctr_name_equal(name,view.friends[i].name))found=1;give();return found;
}
CTR_EXPORT int ctr_social_action(const char *action,const char *who){
    if(!action||!valid(who)||ctr_name_equal(who,ctr_player_name()))return -1;
    if(ctr_strcmp(action,"request")&&ctr_strcmp(action,"accept")&&ctr_strcmp(action,"decline")&&ctr_strcmp(action,"remove")&&ctr_strcmp(action,"invite"))return -1;
    if(!api.request||!take())return -1;if(count==64){give();return -1;}
    unsigned at=(head+count)%64;copy(jobs[at].action,action);copy(jobs[at].who,who);count++;
    view.result[0]=0;view.serial++;next_refresh=0;give();return 0;
}
static void *worker(void *unused){
    (void)unused;char me[17],action[12]={0},who[17]={0};copy(me,ctr_player_name());
    if(take()){if(count){copy(action,jobs[head].action);copy(who,jobs[head].who);head=(head+1)%64;count--;}give();}
    char target[192];int status=0;
    if(action[0]){
        copy(target,"/ryunet/friends/");add(target,action);add(target,"?name=");add(target,me);
        add(target,!ctr_strcmp(action,"accept")||!ctr_strcmp(action,"decline")?"&from=":!ctr_strcmp(action,"remove")?"&who=":"&to=");add(target,who);add(target,"&format=text");
        status=api.request("POST",target,response,sizeof(response));
        const char *p=response,*end=response+ctr_strlen(response);char kind[16],result[24];copy(result,status==403?"refused":"error");
        if(status==200&&token(&p,end,kind,sizeof(kind))&&!ctr_strcmp(kind,"status"))token(&p,end,result,sizeof(result));
        if(take()){copy(view.result,result);copy(view.who,who);view.serial++;give();}
    }
    copy(target,"/ryunet/friends?name=");add(target,me);add(target,"&format=text");
    status=api.request("GET",target,response,sizeof(response));CtrSocialView next;
    int parsed=status==200?ctr_social_parse(response,ctr_strlen(response),&next):-1;
    if(take()){
        if(!parsed){next.serial=view.serial+1;copy(next.result,view.result);copy(next.who,view.who);view=next;have_view=1;}
        else {view.state=status==200?CTR_SOCIAL_REFUSED:status?CTR_SOCIAL_REFUSED:CTR_SOCIAL_NETWORK;view.status=status;view.serial++;}
        next_refresh=api.time_us()+8000000ULL;give();
    }
    // The upstream client migrates its old local list on the first good view.
    // Do the same without replacing settings.ini or saving another user's ID.
    if(!parsed&&!migrated){
        CtrSettings s;if(!ctr_settings_snapshot(&s)){
            migrated=1;
            for(unsigned i=0;i<s.count;i++){
                int known=ctr_name_equal(s.friends[i],me),incoming=0;
                for(unsigned j=0;j<next.count;j++)if(ctr_name_equal(s.friends[i],next.friends[j].name))known=1;
                for(unsigned j=0;j<next.outgoing_count;j++)if(ctr_name_equal(s.friends[i],next.outgoing[j]))known=1;
                for(unsigned j=0;j<next.incoming_count;j++)if(ctr_name_equal(s.friends[i],next.incoming[j]))incoming=1;
                if(!known)ctr_social_action(incoming?"accept":"request",s.friends[i]);
            }
        }
    }
    __atomic_store_n(&busy,0,__ATOMIC_RELEASE);return 0;
}
CTR_EXPORT int ctr_social_init(const CtrSocialApi *native){
    if(__atomic_load_n(&busy,__ATOMIC_ACQUIRE))return -1;
    if(!native){ctr_memset(&api,0,sizeof(api));ctr_memset(&view,0,sizeof(view));head=count=migrated=have_view=0;return 0;}
    if(!native->spawn||!native->request||!native->time_us)return -1;
    api=*native;ctr_memset(&view,0,sizeof(view));view.state=CTR_SOCIAL_WAITING;
    head=count=0;lock=busy=migrated=have_view=0;next_refresh=0;return 0;
}
CTR_EXPORT void ctr_social_tick(void){
    if(!api.time_us||!valid(ctr_player_name())||!ctr_identity_header("http://octr.ryu7w7.xyz:8080/"))return;
    if(!take())return;int due=count||api.time_us()>=next_refresh;give();if(!due)return;
    int zero=0;if(!__atomic_compare_exchange_n(&busy,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return;
    if(api.spawn(worker,0)){if(take()){next_refresh=api.time_us()+8000000ULL;give();}__atomic_store_n(&busy,0,__ATOMIC_RELEASE);}
}
CTR_EXPORT int ctr_social_proof(const char *method,const char *target,uint64_t seconds,const char *nonce,char *out,size_t cap){
    const char *key=ctr_identity_header("http://octr.ryu7w7.xyz:8080/");
    if(!key||!method||!target||!nonce||!out||cap<150||ctr_strlen(nonce)!=32||seconds<946684800||seconds>7258118400ULL)return 0;
    if(ctr_strcmp(method,"GET")&&ctr_strcmp(method,"POST")&&ctr_strcmp(method,"PUT")&&ctr_strcmp(method,"DELETE"))return 0;
    for(unsigned i=0;i<32;i++)if(!((nonce[i]>='0'&&nonce[i]<='9')||(nonce[i]>='a'&&nonce[i]<='f')))return 0;
    size_t n=ctr_strlen(target);if(!n||n>1023||target[0]!='/')return 0;
    for(size_t i=0;i<n;i++)if((uint8_t)target[i]<33||(uint8_t)target[i]>126)return 0;
    char msg[1200],ts[24];decimal(ts,seconds);copy(msg,ts);add(msg,"\n");add(msg,nonce);add(msg,"\n");add(msg,method);add(msg,"\n");add(msg,target);
    uint8_t inner[64+1200],outer[96],digest[32];
    for(unsigned i=0;i<64;i++){inner[i]=(uint8_t)key[i]^0x36;outer[i]=(uint8_t)key[i]^0x5c;}
    size_t len=ctr_strlen(msg);ctr_memcpy(inner+64,msg,len);ctr_sha256(inner,64+len,digest);ctr_memcpy(outer+64,digest,32);ctr_sha256(outer,sizeof(outer),digest);
    char hex[65];const char digits[]="0123456789abcdef";
    for(unsigned i=0;i<32;i++){hex[2*i]=digits[digest[i]>>4];hex[2*i+1]=digits[digest[i]&15];}hex[64]=0;
    copy(out,"1.");add(out,ts);add(out,".");add(out,nonce);add(out,".");add(out,hex);
    volatile uint8_t *wipe=inner;for(size_t i=0;i<sizeof(inner);i++)wipe[i]=0;wipe=outer;for(size_t i=0;i<sizeof(outer);i++)wipe[i]=0;
    return 1;
}
CTR_EXPORT int64_t ctr_social_http_date(const char *text,size_t size){
    // Fixed RFC 7231 IMF-fixdate, no locale, timezone, or OS clock writes.
    if(!text||size<29||text[3]!=','||text[4]!=' '||text[7]!=' '||text[11]!=' '||text[16]!=' '||text[19]!=':'||text[22]!=':'||ctr_strncmp(text+25," GMT",4))return -1;
    const unsigned pos[]={5,6,12,13,14,15,17,18,20,21,23,24};for(unsigned i=0;i<12;i++)if(text[pos[i]]<'0'||text[pos[i]]>'9')return -1;
    int day=(text[5]-'0')*10+text[6]-'0',year=(text[12]-'0')*1000+(text[13]-'0')*100+(text[14]-'0')*10+text[15]-'0';
    int hour=(text[17]-'0')*10+text[18]-'0',minute=(text[20]-'0')*10+text[21]-'0',second=(text[23]-'0')*10+text[24]-'0',month=0;
    const char months[]="JanFebMarAprMayJunJulAugSepOctNovDec";for(int m=0;m<12;m++)if(!ctr_strncmp(text+8,months+3*m,3))month=m+1;
    if(!month||year<2000||year>2200||day<1||day>31||hour>23||minute>59||second>59)return -1;
    const unsigned days[]={31,28,31,30,31,30,31,31,30,31,30,31};unsigned limit=days[month-1];if(month==2&&year%4==0&&(year%100!=0||year%400==0))limit++;
    if((unsigned)day>limit)return -1;int64_t y=year-(month<=2),era=y/400,yoe=y-era*400,doy=(153*(month+(month>2?-3:9))+2)/5+day-1;
    return (era*146097+yoe*365+yoe/4-yoe/100+doy-719468)*86400+hour*3600+minute*60+second;
}
