// Generated from the sealed RYUN00001 images; fixed import addresses.
static NetImport net_imports[] = {
{0,"sceNetBind",0x28082a8,0x1be9e7e},
{0,"sceNetRecvfrom",0x28082d8,0x1be9ede},
{0,"sceNetSendto",0x2808300,0x1be9f2e},
{0,"sceNetSocketClose",0x2808318,0x1be9f5e},
};
static NetSymbol net_symbols[] = {
{"sceKernelGetProcessTime","4J2sUJmuHZQ"},
{"sceNetBind","bErx49PgxyY"},
{"sceNetErrnoLoc","HQOwnfMGipQ"},
{"sceNetGetsockopt","xphrZusl78E"},
{"sceNetRecvfrom","304ooNZxWDY"},
{"sceNetSendto","gvD1greCu0A"},
{"sceNetSocketClose","45ggEzakPJQ"},
};
