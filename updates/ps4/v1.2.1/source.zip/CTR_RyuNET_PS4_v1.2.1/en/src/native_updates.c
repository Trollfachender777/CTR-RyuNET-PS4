// SPDX-License-Identifier: GPL-2.0-only
// One short-lived worker on explicit request. No game HTTP contexts or keys.
#include "updates.h"
#include "updater.h"
#include "installation.h"
extern int64_t ctr_syscall(int64_t,...);
#include "update_symbols.h"
static uint64_t (*clock_us)(void);
static void *resolve(const char *name){
    const char *nid=0;for(size_t i=0;i<sizeof(update_symbols)/sizeof(update_symbols[0]);i++)if(!ctr_strcmp(name,update_symbols[i].name)){nid=update_symbols[i].nid;break;}
    int32_t handles[256];uint64_t count=0;
    if(ctr_syscall(592,handles,(size_t)256,&count)||count>256)return 0;
    for(uint64_t i=0;i<count;i++){void *value=0;if(!ctr_syscall(591,handles[i],name,&value)&&value)return value;if(nid&&!ctr_syscall(591,handles[i],nid,&value)&&value)return value;}return 0;
}
static uint64_t now(void){return clock_us?clock_us():0;}
static int spawn(void *(*entry)(void*),void *arg){
    // PS4 scePthread handles and attributes are opaque pointers, not host
    // pthread_attr_t. This intentionally uses the native pointer-to-handle ABI.
    int32_t(*init)(void**)=(__typeof__(init))resolve("scePthreadAttrInit");
    int32_t(*detach)(void**,int32_t)=(__typeof__(detach))resolve("scePthreadAttrSetdetachstate");
    int32_t(*destroy)(void**)=(__typeof__(destroy))resolve("scePthreadAttrDestroy");
    int32_t(*create)(void**,const void*,void*(*)(void*),void*,const char*)=(__typeof__(create))resolve("scePthreadCreate");
    if(!init||!detach||!destroy||!create)return -1;
    void *attr=0,*thread=0;int r=init(&attr);if(r)return r;
    r=detach(&attr,1);if(!r)r=create(&thread,&attr,entry,arg,"RyuNET-update");destroy(&attr);return r;
}
static int fetch(const char *url,char *out,size_t cap,size_t *length,int32_t *status){
    if(!url||(ctr_strcmp(url,CTR_UPDATE_ENDPOINT)&&!ctr_updater_url_allowed(url))||!out||!length||!status||(cap!=CTR_UPDATE_BODY_MAX&&cap!=CTR_UPDATER_MAX)||!clock_us)return -1;
    int32_t(*load)(uint32_t)=(__typeof__(load))resolve("sceSysmoduleLoadModuleInternal");
    if(!resolve("sceSslInit")&&load)load(0x8000000b);
    if(!resolve("sceHttpInit")&&load)load(0x8000000a);
    int32_t(*net_create)(const char*,int32_t,int32_t)=(__typeof__(net_create))resolve("sceNetPoolCreate");
    void(*net_destroy)(int32_t)=(__typeof__(net_destroy))resolve("sceNetPoolDestroy");
    int32_t(*ssl_init)(size_t)=(__typeof__(ssl_init))resolve("sceSslInit");
    int32_t(*ssl_term)(int32_t)=(__typeof__(ssl_term))resolve("sceSslTerm");
    int32_t(*http_init)(int32_t,int32_t,size_t)=(__typeof__(http_init))resolve("sceHttpInit");
    int32_t(*http_term)(int32_t)=(__typeof__(http_term))resolve("sceHttpTerm");
    int32_t(*tmpl_create)(int32_t,const char*,int32_t,int32_t)=(__typeof__(tmpl_create))resolve("sceHttpCreateTemplate");
    int32_t(*tmpl_delete)(int32_t)=(__typeof__(tmpl_delete))resolve("sceHttpDeleteTemplate");
    int32_t(*resolve_timeout)(int32_t,uint32_t)=(__typeof__(resolve_timeout))resolve("sceHttpSetResolveTimeOut");
    int32_t(*connect_timeout)(int32_t,uint32_t)=(__typeof__(connect_timeout))resolve("sceHttpSetConnectTimeOut");
    int32_t(*send_timeout)(int32_t,uint32_t)=(__typeof__(send_timeout))resolve("sceHttpSetSendTimeOut");
    int32_t(*recv_timeout)(int32_t,uint32_t)=(__typeof__(recv_timeout))resolve("sceHttpSetRecvTimeOut");
    int32_t(*redirect)(int32_t,int32_t)=(__typeof__(redirect))resolve("sceHttpSetAutoRedirect");
    int32_t(*verify)(int32_t,uint32_t)=(__typeof__(verify))resolve("sceHttpsEnableOption");
    int32_t(*conn_create)(int32_t,const char*,int32_t)=(__typeof__(conn_create))resolve("sceHttpCreateConnectionWithURL");
    int32_t(*conn_delete)(int32_t)=(__typeof__(conn_delete))resolve("sceHttpDeleteConnection");
    int32_t(*req_create)(int32_t,int32_t,const char*,uint64_t)=(__typeof__(req_create))resolve("sceHttpCreateRequestWithURL");
    int32_t(*req_delete)(int32_t)=(__typeof__(req_delete))resolve("sceHttpDeleteRequest");
    int32_t(*header)(int32_t,const char*,const char*,int32_t)=(__typeof__(header))resolve("sceHttpAddRequestHeader");
    int32_t(*send)(int32_t,const void*,size_t)=(__typeof__(send))resolve("sceHttpSendRequest");
    int32_t(*get_status)(int32_t,int32_t*)=(__typeof__(get_status))resolve("sceHttpGetStatusCode");
    int32_t(*read)(int32_t,void*,uint32_t)=(__typeof__(read))resolve("sceHttpReadData");
    if(!net_create||!net_destroy||!ssl_init||!ssl_term||!http_init||!http_term||!tmpl_create||!tmpl_delete||!resolve_timeout||!connect_timeout||!send_timeout||!recv_timeout||!redirect||!verify||!conn_create||!conn_delete||!req_create||!req_delete||!header||!send||!get_status||!read)return -2;
    int32_t pool=-1,ssl=-1,http=-1,tmpl=-1,conn=-1,req=-1;int r=-3;*length=0;*status=0;
    uint64_t begin=now();
    pool=net_create("RyuNET-updates",128*1024,0);if(pool<0)goto cleanup;
    ssl=ssl_init(256*1024);if(ssl<0)goto cleanup;
    http=http_init(pool,ssl,128*1024);if(http<0)goto cleanup;
    tmpl=tmpl_create(http,"CTR-RyuNET-PS4-update-check",2,0);if(tmpl<0)goto cleanup;
    // 5-second operation deadlines, 20-second total read window. Redirects
    // cannot escape the fixed HTTPS endpoint. Keep all certificate checks.
    if(resolve_timeout(tmpl,5000000)<0||connect_timeout(tmpl,5000000)<0||send_timeout(tmpl,5000000)<0||recv_timeout(tmpl,5000000)<0||redirect(tmpl,0)<0||verify(tmpl,0xbd)<0)goto cleanup;
    conn=conn_create(tmpl,url,0);if(conn<0)goto cleanup;
    req=req_create(conn,0,url,0);if(req<0)goto cleanup;
    if(header(req,"Accept","application/vnd.github+json",0)<0||header(req,"X-GitHub-Api-Version","2022-11-28",0)<0||header(req,"Accept-Encoding","identity",0)<0)goto cleanup;
    if(send(req,0,0)<0||get_status(req,status)<0)goto cleanup;
    if(*status!=200){r=0;goto cleanup;}
    for(;;){
        if(now()-begin>(cap==CTR_UPDATER_MAX?60000000ULL:20000000ULL)){r=-4;goto cleanup;}
        char chunk[1024];int n=read(req,chunk,sizeof(chunk));if(n<0)goto cleanup;if(!n){r=0;break;}
        if(n>(int)sizeof(chunk)||(size_t)n>cap-*length){r=-5;goto cleanup;}
        ctr_memcpy(out+*length,chunk,(size_t)n);*length+=(size_t)n;
        if(cap==CTR_UPDATER_MAX)ctr_updater_progress(*length,cap);
    }
cleanup:
    if(req>=0)req_delete(req);if(conn>=0)conn_delete(conn);if(tmpl>=0)tmpl_delete(tmpl);if(http>=0)http_term(http);if(ssl>=0)ssl_term(ssl);if(pool>=0)net_destroy(pool);return r;
}
#include "social.h"
#include "season.h"
static int64_t social_clock_offset;
static int social_fetch(const char *method,const char *url,char *out,size_t cap,size_t *length,int32_t *status){
    static const char root[]="http://octr.ryu7w7.xyz:8080/ryunet/friends";
    int season=url&&method&&!ctr_strcmp(method,"GET")&&!ctr_strcmp(url,"http://octr.ryu7w7.xyz:8080/ryunet/theme");
    int friends=url&&!ctr_strncmp(url,root,sizeof(root)-1)&&(url[sizeof(root)-1]=='?'||url[sizeof(root)-1]=='/');
    if((!season&&!friends)||!method||!out||!length||!status||!cap||cap>32767||!clock_us)return -1;
    char proof[160],nonce[33];const char digits[]="0123456789abcdef";static uint64_t counter;
    struct {int64_t seconds,microseconds;} tv={0,0};
    if(!season&&(ctr_syscall(116,&tv,0)||tv.seconds<946684800))return -1;
    uint64_t unique=__atomic_add_fetch(&counter,1,__ATOMIC_RELAXED),stamp=now();
    for(unsigned i=0;i<16;i++){nonce[i]=digits[(stamp>>((15-i)*4))&15];nonce[16+i]=digits[(unique>>((15-i)*4))&15];}nonce[32]=0;
    if(!season&&!ctr_social_proof(method,url+sizeof("http://octr.ryu7w7.xyz:8080")-1,(uint64_t)(tv.seconds+social_clock_offset),nonce,proof,sizeof(proof)))return -1;
    int32_t(*load)(uint32_t)=(__typeof__(load))resolve("sceSysmoduleLoadModuleInternal");
    if(!resolve("sceSslInit")&&load)load(0x8000000b);
    if(!resolve("sceHttpInit")&&load)load(0x8000000a);
    int32_t(*net_create)(const char*,int32_t,int32_t)=(__typeof__(net_create))resolve("sceNetPoolCreate");
    void(*net_destroy)(int32_t)=(__typeof__(net_destroy))resolve("sceNetPoolDestroy");
    int32_t(*ssl_init)(size_t)=(__typeof__(ssl_init))resolve("sceSslInit");
    int32_t(*ssl_term)(int32_t)=(__typeof__(ssl_term))resolve("sceSslTerm");
    int32_t(*http_init)(int32_t,int32_t,size_t)=(__typeof__(http_init))resolve("sceHttpInit");
    int32_t(*http_term)(int32_t)=(__typeof__(http_term))resolve("sceHttpTerm");
    int32_t(*tmpl_create)(int32_t,const char*,int32_t,int32_t)=(__typeof__(tmpl_create))resolve("sceHttpCreateTemplate");
    int32_t(*tmpl_delete)(int32_t)=(__typeof__(tmpl_delete))resolve("sceHttpDeleteTemplate");
    int32_t(*resolve_timeout)(int32_t,uint32_t)=(__typeof__(resolve_timeout))resolve("sceHttpSetResolveTimeOut");
    int32_t(*connect_timeout)(int32_t,uint32_t)=(__typeof__(connect_timeout))resolve("sceHttpSetConnectTimeOut");
    int32_t(*send_timeout)(int32_t,uint32_t)=(__typeof__(send_timeout))resolve("sceHttpSetSendTimeOut");
    int32_t(*recv_timeout)(int32_t,uint32_t)=(__typeof__(recv_timeout))resolve("sceHttpSetRecvTimeOut");
    int32_t(*redirect)(int32_t,int32_t)=(__typeof__(redirect))resolve("sceHttpSetAutoRedirect");
    int32_t(*verify)(int32_t,uint32_t)=(__typeof__(verify))resolve("sceHttpsEnableOption");
    int32_t(*conn_create)(int32_t,const char*,int32_t)=(__typeof__(conn_create))resolve("sceHttpCreateConnectionWithURL");
    int32_t(*conn_delete)(int32_t)=(__typeof__(conn_delete))resolve("sceHttpDeleteConnection");
    int32_t(*req_create)(int32_t,int32_t,const char*,uint64_t)=(__typeof__(req_create))resolve("sceHttpCreateRequestWithURL");
    int32_t(*req_delete)(int32_t)=(__typeof__(req_delete))resolve("sceHttpDeleteRequest");
    int32_t(*header)(int32_t,const char*,const char*,int32_t)=(__typeof__(header))resolve("sceHttpAddRequestHeader");
    int32_t(*send)(int32_t,const void*,size_t)=(__typeof__(send))resolve("sceHttpSendRequest");
    int32_t(*get_status)(int32_t,int32_t*)=(__typeof__(get_status))resolve("sceHttpGetStatusCode");
    int32_t(*read)(int32_t,void*,uint32_t)=(__typeof__(read))resolve("sceHttpReadData");
    if(!net_create||!net_destroy||!ssl_init||!ssl_term||!http_init||!http_term||!tmpl_create||!tmpl_delete||!resolve_timeout||!connect_timeout||!send_timeout||!recv_timeout||!redirect||!verify||!conn_create||!conn_delete||!req_create||!req_delete||!header||!send||!get_status||!read)return -2;
    int32_t pool=-1,ssl=-1,http=-1,tmpl=-1,conn=-1,req=-1;int r=-3;*length=0;*status=0;
    uint64_t begin=now();
    pool=net_create("RyuNET-friends",128*1024,0);if(pool<0)goto cleanup;
    ssl=ssl_init(256*1024);if(ssl<0)goto cleanup;
    http=http_init(pool,ssl,128*1024);if(http<0)goto cleanup;
    tmpl=tmpl_create(http,"CTR-RyuNET-PS4-v1.2",2,0);if(tmpl<0)goto cleanup;
    // 5-second operation deadlines, 20-second total read window. Redirects
    // cannot escape the fixed HTTPS endpoint. Keep all certificate checks.
    if(resolve_timeout(tmpl,5000000)<0||connect_timeout(tmpl,5000000)<0||send_timeout(tmpl,5000000)<0||recv_timeout(tmpl,5000000)<0||redirect(tmpl,0)<0||verify(tmpl,0xbd)<0)goto cleanup;
    conn=conn_create(tmpl,url,0);if(conn<0)goto cleanup;
    req=req_create(conn,!ctr_strcmp(method,"POST")?1:0,url,0);if(req<0)goto cleanup;
    if(header(req,"Accept",season?"application/json":"text/plain",0)<0||(!season&&header(req,"X-RyuNET-Proof",proof,0)<0)||header(req,"Accept-Encoding","identity",0)<0)goto cleanup;
    if(send(req,0,0)<0||get_status(req,status)<0)goto cleanup;
    int32_t(*headers)(int32_t,char**,size_t*)=(__typeof__(headers))resolve("sceHttpGetAllResponseHeaders");
    char *raw=0;size_t raw_size=0;
    if(!season&&headers&&headers(req,&raw,&raw_size)>=0&&raw&&raw_size<16384){
        for(size_t i=0;i+35<=raw_size;i++)if((i==0||raw[i-1]=='\n')&&!ctr_strncmp(raw+i,"Date: ",6)){
            int64_t server=ctr_social_http_date(raw+i+6,raw_size-i-6);
            if(server>=0)__atomic_store_n(&social_clock_offset,server-tv.seconds,__ATOMIC_RELEASE);break;
        }
    }
    if(*status!=200){r=0;goto cleanup;}
    for(;;){
        if(now()-begin>20000000ULL){r=-4;goto cleanup;}
        char chunk[1024];int n=read(req,chunk,sizeof(chunk));if(n<0)goto cleanup;if(!n){r=0;break;}
        if(n>(int)sizeof(chunk)||(size_t)n>cap-*length){r=-5;goto cleanup;}
        ctr_memcpy(out+*length,chunk,(size_t)n);*length+=(size_t)n;
    }
cleanup:
    if(req>=0)req_delete(req);if(conn>=0)conn_delete(conn);if(tmpl>=0)tmpl_delete(tmpl);if(http>=0)http_term(http);if(ssl>=0)ssl_term(ssl);if(pool>=0)net_destroy(pool);return r;
}

static int social_request(const char *method,const char *target,char *out,size_t cap){
    int season=method&&target&&!ctr_strcmp(method,"GET")&&!ctr_strcmp(target,"/ryunet/theme");
    if(!target||(!season&&ctr_strncmp(target,"/ryunet/friends",14))||ctr_strlen(target)>192||cap<2)return 0;
    char url[256]; // canonical authority, no redirects
    const char *root="http://octr.ryu7w7.xyz:8080";size_t n=ctr_strlen(root);ctr_memcpy(url,root,n);ctr_memcpy(url+n,target,ctr_strlen(target)+1);
    int32_t status=0;size_t length=0;int64_t previous=__atomic_load_n(&social_clock_offset,__ATOMIC_ACQUIRE);
    out[0]=0;int r=social_fetch(method,url,out,cap-1,&length,&status);if(length<cap)out[length]=0;
    // A refused signature with an updated server clock is safe to retry once.
    if(!r&&status==403&&previous!=__atomic_load_n(&social_clock_offset,__ATOMIC_ACQUIRE)){
        length=0;r=social_fetch(method,url,out,cap-1,&length,&status);if(length<cap)out[length]=0;
    }
    return r?0:status;
}

#include "native_update_files.h"
void ctr_updates_native_init(void(*trace)(int32_t,int32_t)){clock_us=(__typeof__(clock_us))resolve("sceKernelGetProcessTime");CtrUpdateApi api={spawn,fetch,clock_us?now:0};ctr_updates_init(&api);CtrUpdaterApi updater={spawn,fetch,clock_us?now:0,stage_update};ctr_updater_init(&updater);CtrSocialApi social_api={spawn,social_request,clock_us?now:0};ctr_social_init(&social_api);CtrSeasonApi season_api={spawn,social_request,clock_us?now:0,trace};ctr_season_init(&season_api);}
