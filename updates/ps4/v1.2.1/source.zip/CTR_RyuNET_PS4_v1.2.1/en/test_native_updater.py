"""Execute the actual SELF updater, including PS4 file syscalls and rollback."""
import struct,unittest
from test_native_updates import UpdateMachine
from test_native_bridge import prepare,SCRATCH
from test_updater import manifest,LANG,CHANNEL,PREFIX
def small_self():
    out=bytearray(4096);out[:4]=bytes.fromhex('4f153d1d');struct.pack_into('<H',out,24,1)
    struct.pack_into('<QQQQ',out,32,0x800,1024,256,256)
    base=64;out[base:base+7]=b'\x7fELF\x02\x01\x01';struct.pack_into('<H',out,base+18,62)
    struct.pack_into('<Q',out,base+32,64);struct.pack_into('<HH',out,base+54,56,1)
    struct.pack_into('<Q',out,base+64+32,256);return bytes(out)
class Machine(UpdateMachine):
    def __init__(self,marker=True,fault=None):
        super().__init__();self.update_fault=fault;self.data=small_self();self.responses=[manifest(self.data),self.data]
        self.target='/data/ryunet/'+LANG+'/ctr_online.prx'
        self.original=bytearray(self.data);self.original[-1]=42;self.original=bytes(self.original)
        self.files[self.target]=self.original
        if marker:self.files['/app0/sce_module/ryunet-updater.txt']=('RYUNET-PS4-UPDATER-ABI1:'+LANG+'\n').encode()
    def invoke(self,name):return self.call(self.exports[prepare.nid(name)])
    def result(self):
        self.call(self.exports[prepare.nid('ctr_updater_snapshot')],SCRATCH)
        return struct.unpack('<iiI',self.uc.mem_read(SCRATCH,12))
    def run_check(self):assert self.invoke('ctr_updater_check')==1;self.finish();assert self.result()[0]==3
    def install(self):assert self.invoke('ctr_updater_install')==1;self.finish()
class Tests(unittest.TestCase):
    def test_actual_self_stages_atomically_keeps_previous_and_preserves_every_user_profile(self):
        m=Machine();self.assertEqual(m.initialize(),0);before={p:v for p,v in m.files.items() if '/users/' in p}
        m.run_check();self.assertEqual(m.files[m.target],m.original);self.assertEqual(m.invoke('ctr_updater_install'),1);self.assertEqual(m.result()[0],9)
        self.assertEqual(m.files[m.target],m.original);m.finish();self.assertEqual(m.result(),(10,0,100))
        self.assertEqual(m.files[m.target],m.data);self.assertEqual(m.files[m.target+'.previous'],m.original)
        self.assertFalse(any(p.endswith(('.download','.previous.tmp')) for p in m.files))
        for p,v in before.items():self.assertEqual(m.files[p],v)
        url=PREFIX+'v1.3.0/ctr_online_'+LANG+'.prx';self.assertEqual(m.requested,[CHANNEL,CHANNEL,url,url])
        self.assertFalse(m.fds);self.assertEqual(m.policy['sceHttpsEnableOption'],(604,0xbd))
    def test_executable_modes_survive_umask_and_reused_non_executable_temporaries(self):
        for reuse in (False,True):
            with self.subTest(reuse=reuse):
                m=Machine();m.file_umask=0o777
                m.file_modes[m.target]=0o755
                if reuse:
                    for suffix in ('.download','.previous.tmp'):
                        m.files[m.target+suffix]=b'stale';m.file_modes[m.target+suffix]=0o644
                self.assertEqual(m.initialize(),0);m.run_check();m.install()
                self.assertEqual(m.result(),(10,0,100))
                self.assertEqual(m.file_modes[m.target],0o755)
                self.assertEqual(m.file_modes[m.target+'.previous'],0o755)
                self.assertEqual(m.fchmod_calls,[(m.target+'.download',0o755),(m.target+'.previous.tmp',0o755)])
    def test_failed_permission_change_never_replaces_current_executable(self):
        m=Machine(fault='chmod');m.file_modes[m.target]=0o755
        self.assertEqual(m.initialize(),0);m.run_check();m.install()
        self.assertEqual(m.result()[0],11)
        self.assertEqual(m.files[m.target],m.original)
        self.assertEqual(m.file_modes[m.target],0o755)
        self.assertFalse(any(p.endswith(('.download','.previous.tmp')) for p in m.files))
    def test_disk_readback_fsync_and_commit_failures_leave_current_code_and_identity_intact(self):
        for fault in ('corrupt','fsync','chmod','rename'):
            with self.subTest(fault=fault):
                m=Machine(fault=fault);self.assertEqual(m.initialize(),0);before={p:v for p,v in m.files.items() if '/users/' in p}
                m.run_check();m.install();self.assertEqual(m.result()[0],11);self.assertEqual(m.files[m.target],m.original)
                self.assertFalse(any(p.endswith(('.download','.previous.tmp')) for p in m.files));self.assertFalse(m.fds)
                for p,v in before.items():self.assertEqual(m.files[p],v)
    def test_legacy_installation_needs_setup_and_does_not_claim_an_update_was_applied(self):
        m=Machine(marker=False);self.assertEqual(m.initialize(),0);m.run_check();m.install()
        self.assertEqual(m.result()[0],12);self.assertEqual(m.files[m.target],m.original);self.assertNotIn(m.target+'.previous',m.files)
    def test_digest_failure_never_opens_a_destination_file(self):
        m=Machine();self.assertEqual(m.initialize(),0);m.responses[1]=m.responses[1][:-1]+b'X';m.run_check();before=dict(m.files);m.install()
        self.assertEqual(m.result()[0],11);self.assertEqual(m.files,before)
if __name__=='__main__':unittest.main(verbosity=2)
