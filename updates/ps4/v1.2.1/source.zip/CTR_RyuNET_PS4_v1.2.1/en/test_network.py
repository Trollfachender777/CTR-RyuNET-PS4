"""Execute the PS4 transport against v0.5.3 wire packets and native API mocks."""
from pathlib import Path
import ctypes as C
import json
import socket
import struct
import unittest

ROOT=Path(__file__).resolve().parent
lib=C.CDLL(str(ROOT/'build/ctr_core_test.dll'))
class Address(C.Structure):
    _fields_=[('length',C.c_uint8),('family',C.c_uint8),('port',C.c_uint16),('ip',C.c_uint32),('zero',C.c_uint8*8)]
class Api(C.Structure):
    _fields_=[(name,C.c_void_p) for name in ('bind','sendto','recvfrom','close','getsockopt','errno_location','clock_us','trace')]
def address(ip,port=3074):
    return Address(16,2,socket.htons(port),int.from_bytes(socket.inet_aton(ip),'little'))
SERVER=address('165.1.125.122')
PEER=address('201.189.26.165',18270)
def wire(peer,payload,flags=0):
    return b'RYUTN1'+bytes([flags])+bytes(peer)[4:8]+struct.pack('>H',socket.ntohs(peer.port))+payload

lib.ctr_net_init.argtypes=[C.POINTER(Api)]
lib.ctr_net_server.argtypes=[C.c_uint32]
lib.ctr_net_bind.argtypes=[C.c_int32,C.c_void_p,C.c_uint32]
lib.ctr_net_sendto.argtypes=[C.c_int32,C.c_void_p,C.c_size_t,C.c_int32,C.c_void_p,C.c_uint32]
lib.ctr_net_recvfrom.argtypes=[C.c_int32,C.c_void_p,C.c_size_t,C.c_int32,C.c_void_p,C.POINTER(C.c_uint32)]
lib.ctr_net_close.argtypes=[C.c_int32]
lib.ctr_tun_candidate.argtypes=[C.c_uint32,C.c_uint32]
lib.ctr_tun_send.argtypes=[C.c_uint32,C.c_uint16,C.c_uint64,C.POINTER(C.c_uint8)]
lib.ctr_tun_direct.argtypes=[C.c_uint32,C.c_uint16,C.c_uint64]
lib.ctr_tun_received.argtypes=[C.c_uint32,C.c_uint16,C.c_uint8,C.c_uint64]
lib.ctr_tun_keepalive.argtypes=[C.c_uint64]
lib.ctr_tun_wrap.argtypes=[C.c_void_p,C.c_size_t,C.c_uint8,C.c_uint32,C.c_uint16,C.c_void_p,C.c_size_t]
lib.ctr_tun_wrap.restype=C.c_size_t

class Tests(unittest.TestCase):
    def setUp(self):
        self.now=1000000;self.errno=C.c_int32(71);self.sent=[];self.queue=[];self.traces=[];self.recvs=0
        self.type=2;self.bind_result=0;self.close_result=0;self.send_result=None
        self.on_send=None;self.on_recv=None
        self.callbacks=[]
        def cb(result,args,fn):
            value=C.CFUNCTYPE(result,*args)(fn);self.callbacks.append(value);return C.cast(value,C.c_void_p).value
        def send(fd,data,n,flags,to,length):
            self.sent.append((fd,C.string_at(data,n),flags,C.string_at(to,length) if to else None))
            self.errno.value=99
            if self.on_send:self.on_send(self.sent[-1])
            return n if self.send_result is None else self.send_result
        def recv(fd,out,n,flags,source,source_length):
            self.recvs+=1
            if self.on_recv:self.on_recv()
            if not self.queue:self.errno.value=35;return -1
            data,peer=self.queue[0]
            if not flags&2:self.queue.pop(0)
            count=min(n,len(data));C.memmove(out,data,count)
            if source and source_length:
                C.memmove(source,C.byref(peer),min(source_length[0],16));source_length[0]=16
            return count
        def getsockopt(fd,level,opt,out,size):
            self.assertEqual((level,opt),(0xffff,0x1008));C.cast(out,C.POINTER(C.c_int32))[0]=self.type;size[0]=4;return 0
        self.api=Api(
            cb(C.c_int32,[C.c_int32,C.c_void_p,C.c_uint32],lambda *args:self.bind_result),
            cb(C.c_int32,[C.c_int32,C.c_void_p,C.c_size_t,C.c_int32,C.c_void_p,C.c_uint32],send),
            cb(C.c_int32,[C.c_int32,C.c_void_p,C.c_size_t,C.c_int32,C.c_void_p,C.POINTER(C.c_uint32)],recv),
            cb(C.c_int32,[C.c_int32],lambda fd:self.close_result),
            cb(C.c_int32,[C.c_int32,C.c_int32,C.c_int32,C.c_void_p,C.POINTER(C.c_uint32)],getsockopt),
            cb(C.c_void_p,[],lambda:C.addressof(self.errno)),
            cb(C.c_uint64,[],lambda:self.now),
            cb(None,[C.c_int32,C.c_int32],lambda a,b:self.traces.append((a,b))),
        )
        self.assertEqual(lib.ctr_net_init(C.byref(self.api)),0)
    def bind(self,fd=7,endpoint=None):
        lib.ctr_net_server(SERVER.ip)
        endpoint=endpoint or address('0.0.0.0')
        self.assertEqual(lib.ctr_net_bind(fd,C.byref(endpoint),16),self.bind_result)
    def send(self,payload=b'game',peer=PEER,fd=7):
        return lib.ctr_net_sendto(fd,payload,len(payload),0,C.byref(peer),16)
    def recv(self,capacity=2048,flags=0,fd=7,source_capacity=16):
        out=(C.c_uint8*(capacity+32))(*([0xa5]*(capacity+32)))
        source=(C.c_uint8*48)(*([0xa5]*48));size=C.c_uint32(source_capacity)
        result=lib.ctr_net_recvfrom(fd,C.byref(out,16),capacity,flags,C.byref(source,16),C.byref(size))
        self.assertEqual(bytes(out[:16])+bytes(out[-16:]),b'\xa5'*32)
        self.assertEqual(bytes(source[:16])+bytes(source[16+source_capacity:]),b'\xa5'*(48-source_capacity))
        return result,bytes(out[16:16+max(result,0)]),bytes(source[16:32]),size.value
    def test_upstream_wire_format_and_private_destinations(self):
        buffer=C.create_string_buffer(100)
        n=lib.ctr_tun_wrap(buffer,len(buffer),1,PEER.ip,18270,b'\x0c\x02\x00\xab',4)
        self.assertEqual(buffer.raw[:n],wire(PEER,b'\x0c\x02\x00\xab',1))
        self.assertEqual(lib.ctr_tun_wrap(buffer,10,0,PEER.ip,3074,b'x',1),0)
        self.assertEqual(lib.ctr_tun_wrap(buffer,100,0,PEER.ip,3074,b'x',2**64-1),0)
        for ip in ('192.168.1.2','10.1.2.3','172.20.1.1','127.0.0.1','100.64.3.4','169.254.1.2','0.255.0.255','239.1.1.1'):
            self.assertFalse(lib.ctr_tun_candidate(address(ip).ip,SERVER.ip),ip)
        self.assertTrue(lib.ctr_tun_candidate(PEER.ip,SERVER.ip))
        self.assertFalse(lib.ctr_tun_candidate(SERVER.ip,SERVER.ip))
    def test_only_bound_game_datagram_socket_tunnels(self):
        for endpoint,kind,result in ((address('0.0.0.0',4000),2,0),(address('0.0.0.0'),1,0),(address('0.0.0.0'),2,-1)):
            self.setUp();self.type=kind;self.bind_result=result;self.bind(endpoint=endpoint)
            self.send();self.assertEqual(len(self.sent),1)
        self.setUp();self.bind();self.assertEqual(self.sent[0][1],(b'RYUKA1\2'+bytes(293)))
        self.sent.clear();self.send(fd=8);self.assertEqual(len(self.sent),1)
        self.sent.clear();self.send();self.assertEqual(len(self.sent),2)
        self.assertEqual(self.sent[1][1],wire(PEER,b'game',2))
    def test_direct_send_result_and_errno_survive_relay_failure(self):
        self.bind();self.send_result=-1;self.sent.clear()
        self.assertEqual(self.send(),-1);self.assertEqual(len(self.sent),1)
        self.assertEqual(self.errno.value,99)
        self.send_result=None;self.sent.clear();self.assertEqual(self.send(),4)
        self.assertEqual(self.errno.value,99)
    def test_relay_strips_envelope_and_restores_peer_address(self):
        self.bind();self.queue.append((wire(PEER,b'\x01\x00payload'),SERVER))
        n,data,source,size=self.recv()
        self.assertEqual((n,data,size),(9,b'\x01\x00payload',16));self.assertEqual(source,bytes(PEER))
        self.assertIn((155,0),self.traces)
    def test_nat_packets_and_untrusted_magic_are_passed_unchanged(self):
        self.bind()
        for data,source in ((b'\x15\x02\x00\x01',SERVER),(wire(PEER,b'abc'),PEER)):
            self.queue.append((data,source));n,out,addr,size=self.recv();self.assertEqual(out,data);self.assertEqual(addr,bytes(source))
    def test_peek_repeats_full_datagram_then_consumes_once(self):
        self.bind();payload=bytes(range(200));self.queue.append((wire(PEER,payload),SERVER))
        for _ in range(3):self.assertEqual(self.recv(8,2)[1],payload[:8])
        self.assertEqual(self.recvs,1);self.assertEqual(self.recv(2048)[1],payload)
        self.assertEqual(self.recvs,1);self.assertEqual(self.recv()[0],-1);self.assertEqual(self.errno.value,35)
    def test_long_direct_datagram_is_preserved_across_peek(self):
        self.bind();data=b'long'*12000;self.queue.append((data,PEER))
        self.assertEqual(self.recv(3,2)[1],data[:3]);self.assertEqual(self.recv(50000)[1],data)
    def test_source_address_short_buffer_and_truncation(self):
        self.bind();self.queue.append((wire(PEER,b'abcdef'),SERVER))
        n,data,source,size=self.recv(2,source_capacity=4)
        self.assertEqual((n,data,size),(2,b'ab',16));self.assertEqual(source[:4],bytes(PEER)[:4])
    def test_invalid_server_envelopes_never_enter_engine(self):
        self.bind()
        for packet in (b'RYUTN1',wire(address('127.0.0.1'),b'bad'),wire(PEER,b'x'*2049),b'RYUTN1'+b'\0'*7):
            self.queue.append((packet,SERVER));self.assertEqual(self.recv()[0],-1);self.assertEqual(self.errno.value,35)
    def test_same_lan_and_server_destinations_are_not_relayed(self):
        self.bind();self.sent.clear()
        for peer in (address('192.168.1.10'),SERVER):self.send(peer=peer)
        self.assertEqual(len(self.sent),2)
    def test_bidirectional_direct_confirmation_and_one_way_fallback(self):
        self.bind();self.send();self.sent.clear()
        self.queue.append((b'direct',PEER));self.recv()
        self.send();self.assertEqual(self.sent[-1][1],wire(PEER,b'game',3))
        self.queue.append((wire(PEER,b'answer',1),SERVER));self.recv();self.sent.clear()
        self.send();self.assertEqual(len(self.sent),1)
        self.now+=3100000;self.sent.clear();self.send();self.assertEqual(len(self.sent),2)
        self.queue.append((wire(PEER,b'one-way',0),SERVER));self.recv()
        self.queue.append((b'direct',PEER));self.recv();self.sent.clear()
        self.send();self.assertEqual(self.sent[-1][1],wire(PEER,b'game',3))
    def test_keepalive_timeout_reopen_and_many_peers(self):
        self.bind();self.sent.clear();self.send();self.sent.clear();self.now+=21000000
        self.send();self.assertEqual([p[1] for p in self.sent],[b'game',(b'RYUKA1\2'+bytes(293))])
        self.queue.append((wire(PEER,b'answer'),SERVER));self.recv();self.sent.clear()
        self.send();self.assertEqual(len(self.sent),2)
        self.assertEqual(lib.ctr_net_close(7),0);self.sent.clear();self.send();self.assertEqual(len(self.sent),1)
        self.bind();self.sent.clear()
        for i in range(200):self.send(peer=address(f'80.1.{i//256}.{i%256}'))
        self.assertEqual(len(self.sent),400)
    def test_receive_during_send_does_not_spin_or_leak_envelope(self):
        self.bind();self.queue.append((wire(PEER,b'pending'),SERVER));seen=[]
        self.on_send=lambda packet:seen.append(self.recv()[1]) if packet[1].startswith(b'RYUTN1') else None
        self.send();self.assertEqual(seen,[b'pending']);self.assertEqual(len(self.queue),0)
    def test_send_can_relay_while_another_thread_is_in_socket_receive(self):
        self.bind();self.sent.clear();self.queue.append((wire(PEER,b'answer'),SERVER))
        self.on_recv=lambda:self.send()
        self.assertEqual(self.recv()[1],b'answer')
        self.assertEqual([packet[1] for packet in self.sent],[b'game',wire(PEER,b'game',2)])
    def test_differential_compatibility_with_unmodified_v053_peer_bookkeeping(self):
        upstream=C.CDLL(str(ROOT/'build/upstream-network-v053/upstream.dll'))
        for name,fn in (('tun_on_send',lib.ctr_tun_send),('tun_on_direct',lib.ctr_tun_direct),('tun_on_tunnelled',lib.ctr_tun_received)):
            getattr(upstream,name).argtypes=fn.argtypes
        # Two independent peer states, receiving the same sequence of direct
        # and relayed packets, must make the same route/flag decisions.
        import random
        randomizer=random.Random(53);upstream.tun_reset();lib.ctr_tun_reset()
        now=1000
        for i in range(5000):
            peer=address(f'80.1.{i%8}.{i%250+1}',3000+i%70)
            now+=randomizer.randrange(1,100)
            action=randomizer.randrange(3)
            if action==0:
                lib.ctr_tun_direct(peer.ip,socket.ntohs(peer.port),now)
                upstream.tun_on_direct(peer.ip,socket.ntohs(peer.port),now)
            elif action==1:
                flags=randomizer.randrange(2)
                lib.ctr_tun_received(peer.ip,socket.ntohs(peer.port),flags,now)
                upstream.tun_on_tunnelled(peer.ip,socket.ntohs(peer.port),flags,now)
            a=C.c_uint8();b=C.c_uint8()
            ra=lib.ctr_tun_send(peer.ip,socket.ntohs(peer.port),now,C.byref(a))
            rb=upstream.tun_on_send(peer.ip,socket.ntohs(peer.port),now,C.byref(b))
            self.assertEqual((ra,a.value),(rb,b.value),i)

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (ROOT/'build/network-test-result.json').write_text(json.dumps({'groups':result.testsRun,'successful':result.wasSuccessful(),
        'failures':len(result.failures),'errors':len(result.errors),
        'scope':'actual C transport with mocked PS4 socket APIs and OCTR v0.5.3 wire vectors; not proof of PS4 WAN connectivity'},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
