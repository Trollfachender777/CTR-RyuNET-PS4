"""Confirmed PS4 update flow: metadata, compatibility, integrity and restart."""
from pathlib import Path
import ctypes as C,hashlib,json,unittest
from test_core import lib
from test_updates import Release,payload
from test_settings_menu import Menu,defaults,snapshot
ROOT=Path(__file__).resolve().parent
LANG='en'
CHANNEL='https://raw.githubusercontent.com/Trollfachender777/CTR-RyuNET-PS4/main/updates/ps4/stable.json'
PREFIX='https://raw.githubusercontent.com/Trollfachender777/CTR-RyuNET-PS4/main/updates/ps4/'
class Package(C.Structure):_fields_=[('release',Release),('size',C.c_uint32),('digest',C.c_uint8*32)]
class Result(C.Structure):_fields_=[('state',C.c_int32),('error',C.c_int32),('percent',C.c_uint32),('version',C.c_char*81)]
class Api(C.Structure):_fields_=[(n,C.c_void_p) for n in ('spawn','fetch','time','stage')]
lib.ctr_update_manifest_parse.argtypes=[C.c_char_p,C.c_size_t,C.POINTER(Package)]
lib.ctr_updater_init.argtypes=[C.POINTER(Api)]
lib.ctr_updater_snapshot.argtypes=[C.POINTER(Result)]
lib.ctr_updater_url_allowed.argtypes=[C.c_char_p]
lib.ctr_update_self_valid.argtypes=[C.c_void_p,C.c_size_t]
def module():return (ROOT/'build/ctr_online.prx').read_bytes()
def manifest(data=None,**patch):
    data=module() if data is None else data
    p=json.loads(payload(id=1100001,tag_name='v1.3.0',published_at='2026-10-25T12:00:00Z',html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/v1.3.0'))
    p.update(schema=1,module_abi=1,title_id='RYUN00001',cusa='CUSA13795',game_version='01.21',es_size=len(data),en_size=len(data),es_sha256=hashlib.sha256(data).hexdigest(),en_sha256=hashlib.sha256(data).hexdigest())
    p.update(patch);return json.dumps(p).encode()
def state():
    out=Result();assert lib.ctr_updater_snapshot(C.byref(out))==0;return out
class Transport:
    def __init__(self,metadata=None,data=None,fetch_error=0,status=200,stage_error=0,spawn_error=0):
        self.data=module() if data is None else data;self.metadata=manifest(self.data) if metadata is None else metadata
        self.now=1000000;self.requests=[];self.tasks=[];self.staged=[]
        def spawn(entry,arg):
            if not spawn_error:self.tasks.append((entry,arg))
            return spawn_error
        def fetch(url,out,cap,length,response_status):
            url=url.decode();self.requests.append(url);data=self.metadata if url==CHANNEL else self.data
            response_status[0]=status;length[0]=len(data);C.memmove(out,data,min(len(data),cap));return fetch_error
        def stage(data,size,expected):self.staged.append((C.string_at(data,size),C.string_at(expected,32)));return stage_error
        self.callbacks=[C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_void_p)(spawn),C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t),C.POINTER(C.c_int32))(fetch),C.CFUNCTYPE(C.c_uint64)(lambda:self.now),C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_size_t,C.c_void_p)(stage)]
        self.api=Api(*(C.cast(cb,C.c_void_p).value for cb in self.callbacks));assert lib.ctr_updater_init(C.byref(self.api))==0
    def finish(self):entry,arg=self.tasks.pop(0);C.CFUNCTYPE(C.c_void_p,C.c_void_p)(entry)(arg)
    def check(self):assert lib.ctr_updater_check()==1;self.finish();return state()
class Tests(unittest.TestCase):
    def tearDown(self):lib.ctr_updater_init(None)
    def parse(self,raw):
        out=Package();C.memset(C.byref(out),0x55,C.sizeof(out));before=bytes(out)
        r=lib.ctr_update_manifest_parse(raw,len(raw),C.byref(out))
        if r:self.assertEqual(bytes(out),before)
        return r,out
    def test_one_delayed_automatic_check_offers_the_update_on_l3_r3_without_installing(self):
        t=Transport();m=Menu()
        for _ in range(120):lib.ctr_updater_tick()
        self.assertFalse(t.tasks);t.now+=30000000
        for _ in range(120):lib.ctr_updater_tick()
        self.assertEqual(len(t.tasks),1);self.assertEqual(t.requests,[]);t.finish()
        m.open();self.assertEqual(m.shown[-1][1],'Update now');self.assertFalse(t.staged)
        m.choose(2);m.choose(cancel=True)
        for _ in range(25):m.poll()
        m.open();self.assertEqual(m.shown[-1][1],'Performance');self.assertEqual(len(t.requests),1)
    def test_manifest_requires_exact_compatible_ps4_schema(self):
        r,p=self.parse(manifest());self.assertEqual(r,0);self.assertEqual(p.size,len(module()));self.assertEqual(bytes(p.digest),hashlib.sha256(module()).digest())
        for patch in [dict(schema=2),dict(module_abi=2),dict(title_id='CUSA13795'),dict(cusa='OTHER'),dict(game_version='01.20'),dict(tag_name='v1.02.0',html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/v1.02.0'),{LANG+'_size':1048577},{LANG+'_size':4095},{LANG+'_sha256':'0'*63},{LANG+'_sha256':'x'*64},dict(draft=True),dict(prerelease=True)]:
            with self.subTest(patch=patch):self.assertNotEqual(self.parse(manifest(**patch))[0],0)
        raw=manifest();self.assertNotEqual(self.parse(raw[:-1]+b',"module_abi":1}')[0],0)
    def test_download_url_cannot_escape_fixed_owner_channel_version_or_language(self):
        self.assertEqual(lib.ctr_updater_url_allowed(CHANNEL.encode()),1)
        self.assertEqual(lib.ctr_updater_url_allowed((PREFIX+'v1.3.0/ctr_online_'+LANG+'.prx').encode()),1)
        for url in [CHANNEL+'?x=1',PREFIX+'../ctr_online_'+LANG+'.prx',PREFIX+'v1.3.0/ctr_online_'+LANG+'.prx?redirect=x',PREFIX+'v1.3.0/other.prx',PREFIX.replace('Trollfachender777','other')+'v1.3.0/ctr_online_'+LANG+'.prx','http'+CHANNEL[5:]]:
            with self.subTest(url=url):self.assertEqual(lib.ctr_updater_url_allowed(url.encode()),0)
    def test_only_semantically_newer_ps4_versions_are_offered(self):
        for v,expected in [('v1.3.0',3),('v1.1.0',2),('v1.0.9',2),('v2.0.0',3)]:
            raw=manifest(tag_name=v,html_url='https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases/tag/'+v)
            t=Transport(raw);self.assertEqual(t.check().state,expected);self.assertEqual(t.requests,[CHANNEL]);self.assertFalse(t.staged)
    def test_download_requires_confirmation_and_runs_on_a_separate_worker(self):
        t=Transport();self.assertEqual(lib.ctr_updater_install(),0);self.assertEqual(t.check().state,3)
        self.assertEqual(lib.ctr_updater_install(),1);self.assertEqual(state().state,9);self.assertFalse(t.staged);self.assertEqual(len(t.requests),1)
        self.assertEqual(lib.ctr_updater_install(),0);self.assertEqual(lib.ctr_updater_check(),0);self.assertEqual(lib.ctr_updater_init(None),-1)
        t.finish();self.assertEqual(state().state,10);self.assertEqual(state().percent,100)
        self.assertEqual(t.staged,[(module(),hashlib.sha256(module()).digest())]);self.assertEqual(t.requests[-1],PREFIX+'v1.3.0/ctr_online_'+LANG+'.prx')
        self.assertEqual(lib.ctr_updater_check(),0)
    def test_corrupt_truncated_or_wrong_kind_code_never_reaches_installer(self):
        good=module();broken=good[:-1]+bytes([good[-1]^1])
        for data,metadata in [(broken,manifest(good)),(good[:-1],manifest(good)),(b'\x7fELF'+good[4:],manifest(b'\x7fELF'+good[4:])),(b'<html>'+good[6:],manifest(b'<html>'+good[6:]))]:
            t=Transport(metadata,data);self.assertEqual(t.check().state,3);lib.ctr_updater_install();t.finish();self.assertEqual(state().state,11);self.assertFalse(t.staged)
    def test_self_header_segment_ranges_and_architecture_are_validated(self):
        data=module();self.assertEqual(lib.ctr_update_self_valid(data,len(data)),1)
        import struct
        count=struct.unpack_from('<H',data,24)[0];base=32+count*32
        for off,value in [(24,b'\xff\xff'),(base,b'FAIL'),(base+18,b'\xb7\x00'),(40,struct.pack('<Q',len(data)+1))]:
            bad=bytearray(data);bad[off:off+len(value)]=value;self.assertEqual(lib.ctr_update_self_valid(bytes(bad),len(bad)),0)
    def test_installer_error_and_legacy_loader_are_reported_without_success(self):
        for error,expected in [(-32,11),(-100,12)]:
            t=Transport(stage_error=error);t.check();lib.ctr_updater_install();t.finish();self.assertEqual(state().state,expected);self.assertNotEqual(state().percent,100)
    def test_network_invalid_channel_and_rate_limit_do_not_offer_an_update(self):
        for metadata,status,error,expected in [(b'',404,0,8),(b'broken',200,0,6),(b'',200,-1,4),(b'',403,0,5)]:
            t=Transport(metadata,status=status,fetch_error=error);self.assertEqual(t.check().state,expected);self.assertEqual(lib.ctr_updater_install(),0)
    def test_menu_confirms_updates_and_does_not_change_game_preferences(self):
        s=defaults();lib.ctr_settings_publish(C.byref(s));before=bytes(snapshot());t=Transport()
        m=Menu();m.open();m.choose(2);m.choose(2);m.choose(1)
        self.assertIn('Checking',m.shown[-1][0]);before_term=m.terminated;t.finish();m.poll();self.assertEqual(m.terminated,before_term)
        m.choose(1);self.assertIn('Update now?',m.shown[-1][0]);self.assertEqual(m.shown[-1][1:3],('Update now','Not now'))
        self.assertFalse(t.staged);m.choose(1);self.assertIn('Downloading',m.shown[-1][0]);self.assertFalse(t.staged)
        t.finish();m.choose(1);self.assertIn('Update ready',m.shown[-1][0]);self.assertIn('Close Application',m.shown[-1][0]);self.assertEqual(bytes(snapshot()),before);self.assertFalse(m.saved);self.assertFalse(m.saved_names)
    def test_declining_or_leaving_during_download_restores_game_controls(self):
        t=Transport();t.check();m=Menu();m.open();m.choose(2);m.choose(2);m.choose(2);m.choose(cancel=True);m.poll()
        self.assertFalse(lib.ctr_menu_active());self.assertEqual(t.requests,[CHANNEL]);self.assertFalse(t.staged)
        lib.ctr_updater_install();m.open();m.choose(cancel=True);m.poll();self.assertFalse(lib.ctr_menu_active());t.finish();self.assertEqual(state().state,10)
if __name__=='__main__':unittest.main(verbosity=2)
