/* Guest file system: PS4 mount points mapped onto host directories.
 *   /app0, /hostapp  -> game package root (read-only by convention)
 *   /temp0, /download0, /data, and mounts added by SaveData -> user directory
 * Guest descriptors are small integers in our own table; stdio 0-2 pass through.
 * Paths containing ".." components are rejected rather than normalized. */
#define _GNU_SOURCE
#include "runtime.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <windows.h>
/* 64-bit sizes and times; directories are never opened as CRT descriptors. */
typedef struct _stat64 HostStat;
#define host_stat(path,s) _stat64(path,s)
#define host_fstat(fd,s) _fstat64(fd,s)
#define host_lseek _lseeki64
#define O_DIRECTORY 0x40000000 /* bbport marker, removed before _open */
#else
typedef struct stat HostStat;
#define host_stat(path,s) stat(path,s)
#define host_fstat(fd,s) fstat(fd,s)
#define host_lseek lseek
#endif
#ifndef O_BINARY
#define O_BINARY 0
#endif
#define ERR(n) ((int32_t)(UINT32_C(0x80020000)|(n)))
#define MAX_FILES 1024
#define MAX_MOUNTS 16
#include "runtime_mod_files.h"

typedef struct { int64_t sec, nsec; } GuestTimespec;
typedef struct {
    uint32_t dev, ino;
    uint16_t mode, nlink;
    uint32_t uid, gid, rdev;
    GuestTimespec atime, mtime, ctime;
    int64_t size, blocks;
    uint32_t blksize, flags, gen;
    int32_t lspare;
    GuestTimespec birthtime;
} GuestStat;
_Static_assert(sizeof(GuestStat)==120,"FreeBSD stat layout");

typedef struct { char *names; size_t count, *offsets; unsigned char *types; } Listing;
/* commit: a save file opened for writing is written to a temporary copy (temp), which replaces
 * the file (commit) in one rename when closed: a crash or a kill mid-save leaves the old file. */
/* The game's full-screen videos (Bink .bk2 files in archives): the logos and intro at start, the credits and
 * the endings. */
static int fullscreen_video(const char *guest) {
    static const char *const names[] = {"openinglogo.bk2", "octane_intro_logo_atvi.bk2", "ctr_game_intro.bk2",
                                        "octanecredits.bk2", "oxide_outro_first.bk2", "oxide_outro_second.bk2"};
    const char *name = strrchr(guest, '/');
    name = name ? name + 1 : guest;
    for (size_t i = 0; i < sizeof(names) / sizeof(*names); ++i)
        if (!strcasecmp(name, names[i])) return 1;
    return 0;
}

/* Archive patches (scripts/archive_patch.py; BB_ARCHIVE_PATCHES lists their files, separated by
 * '|'): a game archive as the game should read it, the archive itself unchanged. Ranges below the
 * archive's size replace those bytes; ranges past it are added after its end (zeros between), and
 * the game sees the archive that much longer. A patch applies only to an archive of the size it was
 * made for. scripts/online_playlist.py makes one (every track in the online race playlist), and
 * scripts/widescreen.py one per archive of a 21:9 or 32:9 layout; one archive has one patch. */
typedef struct { uint64_t offset; uint32_t length; const uint8_t *data; } PatchRange;
typedef struct ArchivePatch {
    char guest[256]; uint64_t size, virtual_size;
    int count, slot;
    PatchRange *ranges;
    const struct ArchivePatch *private_view;
} ArchivePatch;
extern int runtime_private_room_active(void); /* runtime_services.c */
typedef struct { int used, host, dirty, save_logged, video; Listing *dir; size_t position; char path[512]; char *commit, *temp; const ArchivePatch *patch; } File;
typedef struct { char guest[64]; char host[512]; } Mount;
static File files[MAX_FILES];
static Mount mounts[MAX_MOUNTS];
static size_t mount_count, opens, reads, writes, missing;
static uint64_t bytes_read;
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;

static int save_path(const char *p) { return p && !strncmp(p,"/savedata",9); }
static int temp_name(const char *name) {
    size_t n=strlen(name);
    return n>6 && !strcmp(name+n-6,".bbtmp");
}
/* Copies left by a crash (none of them open): removed when their directory is mounted. */
static void remove_stale_temps(const char *dir,int depth) {
    DIR *d=opendir(dir);
    if (!d) return;
    for (struct dirent *e; (e=readdir(d));) {
        if (e->d_name[0]=='.') continue;
        char path[1024];
        if ((size_t)snprintf(path,sizeof(path),"%s/%s",dir,e->d_name)>=sizeof(path)) continue;
        if (temp_name(e->d_name)) {
            int open_now=0;
            for (int i=3;i<MAX_FILES;++i) if (files[i].used && files[i].temp && !strcmp(files[i].temp,path)) open_now=1;
            if (!open_now && !unlink(path)) printf("Runtime: removed %s (a save interrupted earlier; the file it would have replaced is intact)\n",path);
        } else if (depth<4) {
#ifdef _WIN32
            HostStat st; /* MinGW's dirent has no d_type */
            if (!host_stat(path,&st) && S_ISDIR(st.st_mode)) remove_stale_temps(path,depth+1);
#else
            if (e->d_type==DT_DIR) remove_stale_temps(path,depth+1);
#endif
        }
    }
    closedir(d);
}

int runtime_file_mount(const char *guest,const char *host) {
    pthread_mutex_lock(&lock);
    for (size_t i=0;i<mount_count;++i) if (!strcmp(mounts[i].guest,guest)) {
        snprintf(mounts[i].host,sizeof(mounts[i].host),"%s",host);
        pthread_mutex_unlock(&lock); return 0;
    }
    if (mount_count==MAX_MOUNTS || strlen(guest)>=64 || strlen(host)>=512) { pthread_mutex_unlock(&lock); return -1; }
    snprintf(mounts[mount_count].guest,64,"%s",guest);
    snprintf(mounts[mount_count].host,512,"%s",host);
    ++mount_count;
    if (save_path(guest)) remove_stale_temps(host,0);
    pthread_mutex_unlock(&lock);
    return 0;
}
void runtime_file_unmount(const char *guest) {
    pthread_mutex_lock(&lock);
    for (size_t i=0;i<mount_count;++i) if (!strcmp(mounts[i].guest,guest)) {
        mounts[i]=mounts[--mount_count]; break;
    }
    pthread_mutex_unlock(&lock);
}
static char user_root[512]="user";
const char *runtime_file_user_dir(void) { return user_root; }
void runtime_file_configure(const char *app0,const char *user) {
    char path[600];
    snprintf(user_root,sizeof(user_root),"%s",user);
    runtime_file_mount("/app0",app0);
    runtime_file_mount("/hostapp",app0);
    const char *writable[]={"temp0","download0","data"};
    mkdir(user,0755);
    for (int i=0;i<3;++i) {
        snprintf(path,sizeof(path),"%s/%s",user,writable[i]);
        mkdir(path,0755);
        char guest[32]; snprintf(guest,sizeof(guest),"/%s",writable[i]);
        runtime_file_mount(guest,path);
    }
}
/* Resolve a guest path to a host path; returns 0 or a host errno. */
/* The Options menu's Graphics tab and the main menu's Quit Game (PR #117): their relabelled menu
 * files are an extra archive, archives/update3.pak (scripts/graphics_tab.py, path in
 * BB_GRAPHICS_TAB_ARCHIVE), which the game loads after update2.pak. Served here instead of a copy
 * of the game folder, and only when the engine hooks are in (gpu/shim/bbport_graphics_tab.cpp
 * sets the flag) and the game has no update3.pak of its own. */
int runtime_graphics_tab_ready;
static void graphics_tab_archive(const char *guest,char *out,size_t size) {
    if (!__atomic_load_n(&runtime_graphics_tab_ready,__ATOMIC_ACQUIRE) ||
        strcasecmp(guest,"/app0/archives/update3.pak")) return;
    const char *archive=getenv("BB_GRAPHICS_TAB_ARCHIVE");
    struct stat s;
    if (!archive || !*archive || !stat(out,&s) || stat(archive,&s)) return;
    if ((size_t)snprintf(out,size,"%s",archive)>=size) return;
    static int logged;
    if (!__atomic_exchange_n(&logged,1,__ATOMIC_ACQ_REL)) printf("Runtime: Graphics tab menus from %s\n",archive);
}
static int translate(const char *guest,char *out,size_t size) {
    if (!guest || !*guest) return ENOENT;
    char buffer[1024];
    if (guest[0]!='/') snprintf(buffer,sizeof(buffer),"/app0/%s",guest);
    else snprintf(buffer,sizeof(buffer),"%s",guest);
    for (const char *p=buffer;(p=strstr(p,".."));p+=2)
        if ((p==buffer || p[-1]=='/') && (p[2]==0 || p[2]=='/')) return EACCES;
    pthread_mutex_lock(&lock);
    size_t best=0; const Mount *m=NULL;
    for (size_t i=0;i<mount_count;++i) {
        size_t n=strlen(mounts[i].guest);
        if (!strncmp(buffer,mounts[i].guest,n) && (buffer[n]=='/' || !buffer[n]) && n>best) { best=n; m=&mounts[i]; }
    }
    int result=0;
    if (!m) result=ENOENT;
    else if ((size_t)snprintf(out,size,"%s%s",m->host,buffer+best)>=size) result=ENAMETOOLONG;
    pthread_mutex_unlock(&lock);
    if (!result) {
        int redirected=mod_file_translate(buffer,out,size);
        if (redirected<0) result=-redirected;
    }
    if (!result) graphics_tab_archive(buffer,out,size);
    if (result==ENOENT) fprintf(stderr,"Runtime: no mount for guest path %s\n",guest);
    /* BB_FILE_TRACE=1: every guest path the game opens, stats or checks (mods, missing files). */
    static int trace=-1;
    if (trace<0) { const char *t=getenv("BB_FILE_TRACE"); trace=t && t[0]=='1'; }
    if (trace) printf("File trace: %s -> %s\n",guest,result ? "(no mount)" : out);
    return result;
}
/* The PS4's file system ignores case, and the game asks for lower-case names
 * (adhoc/font/dbgfont14h.ccm): files from mods or dumps made elsewhere keep their own case.
 * After a miss, the host path is matched component by component ignoring case; true when it was
 * corrected (same length: only case differs). Only on misses: no cost for found files. */
static int fix_case(char *path) {
#ifdef _WIN32
    (void)path; return 0; /* the Windows file system ignores case already */
#endif
    if (path[0]!='/') return 0;
    char out[1024]="", trial[1024], part[256];
    const char *p=path;
    while (*p) {
        while (*p=='/') ++p;
        if (!*p) break;
        const char *end=strchr(p,'/');
        size_t len=end ? (size_t)(end-p) : strlen(p);
        if (len>=sizeof(part)) return 0;
        memcpy(part,p,len); part[len]=0;
        if ((size_t)snprintf(trial,sizeof(trial),"%s/%s",out,part)>=sizeof(trial)) return 0;
        if (access(trial,F_OK)) {
            DIR *d=opendir(out[0] ? out : "/");
            if (!d) return 0;
            int found=0;
            for (struct dirent *e;(e=readdir(d));)
                if (!strcasecmp(e->d_name,part)) { snprintf(trial,sizeof(trial),"%s/%s",out,e->d_name); found=1; break; }
            closedir(d);
            if (!found) return 0;
        }
        memcpy(out,trial,strlen(trial)+1);
        p+=len;
    }
    if (!strcmp(out,path) || strlen(out)!=strlen(path)) return 0;
    memcpy(path,out,strlen(out)+1);
    return 1;
}
static int host_flags(int flags) {
    int r;
    switch (flags&3) { case 0: r=O_RDONLY; break; case 1: r=O_WRONLY; break; default: r=O_RDWR; }
    if (flags&0x4) r|=O_NONBLOCK;
    if (flags&0x8) r|=O_APPEND;
    if (flags&0x80) r|=O_SYNC;
    if (flags&0x200) r|=O_CREAT;
    if (flags&0x400) r|=O_TRUNC;
    if (flags&0x800) r|=O_EXCL;
    if (flags&0x20000) r|=O_DIRECTORY;
#ifdef _WIN32
    r|=O_BINARY;
#endif
    return r|O_CLOEXEC;
}
static void free_listing(Listing *l) { if (l) { free(l->names); free(l->offsets); free(l->types); free(l); } }
static Listing *list_directory(const char *path,const char *guest) {
    DIR *d=opendir(path);
    if (!d) return NULL;
    Listing *l=calloc(1,sizeof(*l));
    size_t capacity=0,bytes=0,cap_names=0;
    struct dirent *e;
    while (l && (e=readdir(d))) {
        if (temp_name(e->d_name)) continue;
        size_t n=strlen(e->d_name)+1;
        if (l->count==capacity) {
            capacity=capacity ? capacity*2 : 64;
            l->offsets=realloc(l->offsets,capacity*sizeof(size_t));
            l->types=realloc(l->types,capacity);
        }
        if (bytes+n>cap_names) { cap_names=(bytes+n)*2; l->names=realloc(l->names,cap_names); }
        if (!l->offsets || !l->types || !l->names) { fputs("Out of memory listing directory\n",stderr); exit(1); }
        memcpy(l->names+bytes,e->d_name,n);
        l->offsets[l->count]=bytes;
#ifdef _WIN32
        /* MinGW's dirent has no d_type. */
        char child[1100]; HostStat entry;
        snprintf(child,sizeof(child),"%s/%s",path,e->d_name);
        l->types[l->count]=host_stat(child,&entry) ? 0 : S_ISDIR(entry.st_mode) ? 4 : S_ISREG(entry.st_mode) ? 8 : 0;
#else
        unsigned char type=e->d_type;
        if (type==DT_LNK || type==DT_UNKNOWN) {
            struct stat entry;
            if (!fstatat(dirfd(d),e->d_name,&entry,0))
                type=S_ISDIR(entry.st_mode) ? DT_DIR : S_ISREG(entry.st_mode) ? DT_REG : type;
        }
        l->types[l->count]=type==DT_DIR ? 4 : type==DT_REG ? 8 : type==DT_LNK ? 10 : 0;
#endif
        ++l->count; bytes+=n;
    }
    closedir(d);
    const char *relative=mod_relative(guest);
    if (l && relative) {
        pthread_once(&mod_files_once,load_mod_files);
        size_t prefix=strlen(relative);
        for (uint32_t i=0;i<mod_file_count;++i) {
            const char *p=mod_files[i].guest;
            if (prefix) {
                if (strncasecmp(p,relative,prefix) || p[prefix]!='/') continue;
                p+=prefix+1;
            }
            const char *slash=strchr(p,'/');size_t n=slash ? (size_t)(slash-p) : strlen(p);
            int found=0;
            for (size_t j=0;j<l->count;++j) if (strlen(l->names+l->offsets[j])==n && !strncasecmp(p,l->names+l->offsets[j],n)) {
                l->types[j]=slash ? 4 : 8;found=1;break;
            }
            if (found) continue;
            l->offsets=realloc(l->offsets,(l->count+1)*sizeof(size_t));
            l->types=realloc(l->types,l->count+1);l->names=realloc(l->names,bytes+n+1);
            if (!l->offsets || !l->types || !l->names) { fputs("Out of memory listing mod files\n",stderr);exit(1); }
            l->offsets[l->count]=bytes;l->types[l->count]=slash ? 4 : 8;
            memcpy(l->names+bytes,p,n);l->names[bytes+n]=0;bytes+=n+1;++l->count;
        }
    }
    return l;
}
static void convert_stat(const HostStat *s,GuestStat *g) {
    memset(g,0,sizeof(*g));
    g->dev=(uint32_t)s->st_dev; g->ino=(uint32_t)s->st_ino;
    g->nlink=(uint16_t)s->st_nlink;
    g->size=s->st_size;
#ifdef _WIN32
    /* FreeBSD mode bits: directories rwxr-xr-x, files rw-r--r--. */
    g->mode=(uint16_t)(S_ISDIR(s->st_mode) ? 0040755 : 0100644);
    g->blocks=(s->st_size+511)/512; g->blksize=4096;
    g->atime=(GuestTimespec){s->st_atime,0};
    g->mtime=(GuestTimespec){s->st_mtime,0};
    g->ctime=(GuestTimespec){s->st_ctime,0};
#else
    g->mode=(uint16_t)s->st_mode;
    g->blocks=s->st_blocks; g->blksize=(uint32_t)s->st_blksize;
    g->atime=(GuestTimespec){s->st_atim.tv_sec,s->st_atim.tv_nsec};
    g->mtime=(GuestTimespec){s->st_mtim.tv_sec,s->st_mtim.tv_nsec};
    g->ctime=(GuestTimespec){s->st_ctim.tv_sec,s->st_ctim.tv_nsec};
#endif
    g->birthtime=g->ctime;
}
static File *get(int fd) {
    if (fd<3 || fd>=MAX_FILES || !files[fd].used) return NULL;
    return &files[fd];
}

/* --- archive patches (see ArchivePatch) ----------------------------------------------------- */
#define MAX_ARCHIVE_PATCHES 32 /* the widescreen layouts patch 13 archives (scripts/widescreen.py) */
static ArchivePatch archive_patches[MAX_ARCHIVE_PATCHES];
static int archive_patch_count;
static ArchivePatch private_archive_patches[MAX_ARCHIVE_PATCHES];
static int private_archive_patch_count;
static pthread_once_t archive_patches_once=PTHREAD_ONCE_INIT;

static uint64_t le64(const uint8_t *p) { uint64_t v=0; for (int i=7;i>=0;--i) v=v<<8|p[i]; return v; }
static uint32_t le32(const uint8_t *p) { return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24; }

/* "BBPAK001" u64 size, u32 n, path[n], u32 count, count x {u64 offset, u32 length, bytes}. */
static int parse_archive_patch(const uint8_t *b,size_t len,ArchivePatch *out) {
    if (len<24 || memcmp(b,"BBPAK001",8)) return 0;
    size_t at=8;
    out->size=le64(b+at); at+=8;
    uint32_t n=le32(b+at); at+=4;
    if (n==0 || n>=sizeof(out->guest) || at+n+4>len) return 0;
    memcpy(out->guest,b+at,n); out->guest[n]=0; at+=n;
    uint32_t count=le32(b+at); at+=4;
    if (count==0 || count>4096) return 0; /* a layout replaces up to 152 entries of an archive: 2 ranges each */
    out->ranges=calloc(count,sizeof(PatchRange));
    if (!out->ranges) return 0;
    out->virtual_size=out->size;
    for (uint32_t i=0;i<count;++i) {
        if (at+12>len) return 0;
        PatchRange *r=&out->ranges[i];
        r->offset=le64(b+at); r->length=le32(b+at+8); at+=12;
        if (r->length>len-at) return 0;
        r->data=b+at; at+=r->length;
        if (r->offset+r->length>out->virtual_size) out->virtual_size=r->offset+r->length;
    }
    out->count=(int)count;
    return 1;
}

static void load_archive_patch_list(const char *key,ArchivePatch *patches,int *count,int slot_base) {
    const char *list=getenv(key);
    if (!list || !*list) return;
    char *copy=strdup(list), *save=NULL;
    for (char *item=strtok_r(copy,"|",&save); item && *count<MAX_ARCHIVE_PATCHES; item=strtok_r(NULL,"|",&save)) {
        FILE *fp=fopen(item,"rb");
        if (!fp) { printf("Runtime: archive patch %s not readable\n",item); continue; }
        uint8_t *blob=NULL; size_t len=0;
        if (!fseek(fp,0,SEEK_END)) {
            long size=ftell(fp);
            if (size>0 && size<(64L<<20) && !fseek(fp,0,SEEK_SET) && (blob=malloc((size_t)size)))
                len=fread(blob,1,(size_t)size,fp);
        }
        fclose(fp);
        ArchivePatch *p=&patches[*count];
        if (blob && parse_archive_patch(blob,len,p)) {
            p->slot=slot_base+(*count)++;
            /* The blob stays: the ranges point into it. */
            printf("Runtime: archive patch for %s (%d ranges, the game sees %llu bytes)\n",p->guest,p->count,
                   (unsigned long long)p->virtual_size);
        } else {
            printf("Runtime: archive patch %s is damaged: not used\n",item);
            free(p->ranges); memset(p,0,sizeof(*p)); free(blob);
        }
    }
    free(copy);
}

static void load_archive_patches(void) {
    load_archive_patch_list("BB_ARCHIVE_PATCHES",archive_patches,&archive_patch_count,0);
    load_archive_patch_list("BB_PRIVATE_ARCHIVE_PATCHES",private_archive_patches,
                            &private_archive_patch_count,MAX_ARCHIVE_PATCHES);
    for (int i=0;i<archive_patch_count;++i) {
        ArchivePatch *normal=&archive_patches[i];
        for (int j=0;j<private_archive_patch_count;++j) {
            const ArchivePatch *speed=&private_archive_patches[j];
            if (strcasecmp(normal->guest,speed->guest) || normal->size!=speed->size) continue;
            if (normal->virtual_size!=speed->virtual_size) {
                printf("Runtime: Speed archive size differs for %s: private view disabled\n",normal->guest);
            } else {
                normal->private_view=speed;
            }
            break;
        }
    }
}

static int speed_mode_enabled;

void runtime_speed_mode_set(int enabled) {
    __atomic_store_n(&speed_mode_enabled, !!enabled, __ATOMIC_RELEASE);
}

static int runtime_speed_mode_enabled(void) {
    return __atomic_load_n(&speed_mode_enabled, __ATOMIC_ACQUIRE);
}

int runtime_speed_race_active(void) {
    /* PUBLIC_SPEED_STEP_3: after implementing server-confirmed room state, replace
     * only the room predicate below with:
     *   (runtime_private_room_active() || runtime_public_speed_confirmed())
     * Proposed API: true only for the current authenticated Speed lobby with a
     * compatible content version. A UI selection or advertised capability alone
     * is insufficient. Clear confirmation on leave, disconnect, failed join,
     * migration or replacement of the lobby; re-confirm before loading assets.
     * This predicate gates both archive assets and seasonal pickup spawning.
     * Keep runtime_speed_mode_enabled() so remembered private selection alone
     * cannot enable Speed outside an active eligible room.
     * v0.7.5: the game's own private-match flag too. The session flag outlived a private
     * menu (no DELETE), so a remembered Itemless choice reached public races (no items,
     * Tiger Temple's door open).
     */
    return runtime_speed_mode_enabled() && runtime_private_room_active() &&
           runtime_online_mode_in_private();
}

static const ArchivePatch *active_archive_patch(const ArchivePatch *normal) {
    return normal && normal->private_view && runtime_speed_race_active()
               ? normal->private_view : normal;
}

/* The patch for this guest file, when there is one made for an archive of this size. */
static const ArchivePatch *archive_patch_for(const char *guest,uint64_t size) {
    pthread_once(&archive_patches_once,load_archive_patches);
    for (int i=0;i<archive_patch_count;++i) {
        const ArchivePatch *p=&archive_patches[i];
        if (strcasecmp(p->guest,guest)) continue;
        if (p->size==size) return p;
        static int warned;
        if (!warned) { warned=1; printf("Runtime: archive patch for %s not used: the archive changed (%llu bytes, made for %llu)\n",
                                        guest,(unsigned long long)size,(unsigned long long)p->size); }
    }
    return NULL;
}
/* BB_AUDIO_TRACE=1: sound file opens and failed reads (missing game sounds). */
static int audio_trace(void) { static int v=-1; if (v<0) { const char *e=getenv("BB_AUDIO_TRACE"); v=e && e[0]=='1'; } return v; }
/* BB_SAVE_TRACE=1: every operation on save files (/savedataN). */
static int save_trace(void) { static int v=-1; if (v<0) { const char *e=getenv("BB_SAVE_TRACE"); v=e && e[0]=='1'; } return v; }
/* Game mounts (including linked mod overlays) are read-only. Saves use other mounts. */
static int game_path(const char *p) {
    if (!p || !*p) return 0;
    if (*p!='/') return 1;
    return (!strncmp(p,"/app0",5) && (!p[5] || p[5]=='/')) ||
           (!strncmp(p,"/hostapp",8) && (!p[8] || p[8]=='/'));
}
/* Saves (/savedataN): see File. The copy starts as the old file unless the open truncates. */
static unsigned temp_serial;
static int copy_contents(int from,int to) {
    char buffer[65536];
    for (;;) {
        ssize_t n=read(from,buffer,sizeof(buffer));
        if (n<0 && errno==EINTR) continue;
        if (n<=0) return n<0 ? -1 : 0;
        for (ssize_t done=0; done<n;) {
            ssize_t w=write(to,buffer+done,(size_t)(n-done));
            if (w<0 && errno==EINTR) continue;
            if (w<0) return -1;
            done+=w;
        }
    }
}
/* A save file open for writing is its copy to the operations by path too (the game stats the
 * file it is writing, which may not exist yet: it renames the old one to its backup first). */
static void current_copy(char *path,size_t size,int write) {
    pthread_mutex_lock(&lock);
    for (int i=3;i<MAX_FILES;++i)
        if (files[i].used && files[i].commit && !strcmp(files[i].commit,path)) { snprintf(path,size,"%s",files[i].temp); files[i].dirty|=write; break; }
    pthread_mutex_unlock(&lock);
}
/* Returns the descriptor of the copy, or -(errno). */
static int open_for_commit(const char *path,const char *source,int flags,int mode,char **commit,char **temp) {
    int hf=host_flags(flags);
    struct stat s;
    int exists=!stat(source,&s);
    if (exists && !S_ISREG(s.st_mode)) { int h=open(path,hf,mode ? mode : 0644); return h<0 ? -errno : h; }
    if (exists && (hf&O_CREAT) && (hf&O_EXCL)) return -EEXIST;
    if (!exists && !(hf&O_CREAT)) return -ENOENT;
    size_t n=strlen(path)+32;
    char *t=malloc(n), *c=strdup(path);
    if (!t || !c) { free(t); free(c); return -ENOMEM; }
    snprintf(t,n,"%s.%u.bbtmp",path,__atomic_add_fetch(&temp_serial,1,__ATOMIC_RELAXED));
    int out=open(t,O_WRONLY|O_CREAT|O_TRUNC|O_CLOEXEC|O_BINARY,exists ? (int)(s.st_mode&07777) : mode ? mode : 0644);
    int e=out<0 ? errno : 0;
    if (!e && exists && !(hf&O_TRUNC)) {
        int in=open(source,O_RDONLY|O_CLOEXEC|O_BINARY);
        if (in<0 || copy_contents(in,out)) e=errno ? errno : EIO;
        if (in>=0) close(in);
    }
    if (out>=0) close(out);
    int host=e ? -1 : open(t,hf&~(O_CREAT|O_EXCL|O_TRUNC));
    if (host<0) {
        if (!e) e=errno;
        unlink(t); free(t); free(c);
        return -e;
    }
    *commit=c; *temp=t;
    return host;
}
static void sync_directory(const char *file) {
#ifdef _WIN32
    (void)file; return; /* NTFS: the rename is journaled; directories cannot be opened by the CRT */
#endif
    char dir[1024];
    snprintf(dir,sizeof(dir),"%s",file);
    char *slash=strrchr(dir,'/');
    if (!slash) return;
    *slash=0;
    int d=open(dir,O_RDONLY|O_DIRECTORY|O_CLOEXEC);
    if (d>=0) { fsync(d); close(d); }
}
static int commit_file(const File *f) {
    if (!f->dirty) { close(f->host); unlink(f->temp); return 0; } /* opened for writing, not written */
    int e=fsync(f->host) ? errno : 0;
    close(f->host);
#ifdef _WIN32
    /* POSIX rename replaces the old save; the CRT's would fail. */
    if (!e && !MoveFileExA(f->temp,f->commit,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)) e=compat_errno_from_win32(GetLastError());
#else
    if (!e && rename(f->temp,f->commit)) e=errno;
#endif
    if (e) {
        fprintf(stderr,"Runtime: save file %s not replaced (%s); the old one is kept\n",f->path,strerror(e));
        unlink(f->temp);
        return -e;
    }
    sync_directory(f->commit);
    return 0;
}
/* All operations return >=0 or -(host errno); wrappers adapt the convention. */
/* bbport.ini skip_intro=1 (the launcher's "Skip intro videos"): the two logo videos at start,
 * Activision's (octane_intro_logo_atvi.bk2) and Beenox's (openinglogo.bk2), are reported missing
 * and the game goes on without them. Read once from BB_CONFIG. */
static int skip_intro(void) {
    static int v=-1;
    if (v>=0) return v;
    v=0;
    const char *config=getenv("BB_CONFIG");
    FILE *f=config && *config ? fopen(config,"r") : NULL;
    char line[256];
    while (f && fgets(line,sizeof(line),f)) {
        const char *p=line;
        while (*p==' '||*p=='\t') ++p;
        if (!strncmp(p,"skip_intro",10)) {
            p+=10;
            while (*p==' '||*p=='\t') ++p;
            if (*p=='=') { ++p; while (*p==' '||*p=='\t') ++p; v=*p=='1'; }
        }
    }
    if (f) fclose(f);
    return v;
}

static int intro_video(const char *guest) {
    static const char *const names[]={"octane_intro_logo_atvi.bk2","openinglogo.bk2"};
    size_t n=strlen(guest);
    for (size_t i=0;i<sizeof(names)/sizeof(*names);++i) {
        size_t k=strlen(names[i]);
        if (n>=k && !strcasecmp(guest+n-k,names[i]) && (n==k || guest[n-k-1]=='/')) return 1;
    }
    return 0;
}

static int64_t do_open(const char *guest,int flags,int mode) {
    if (intro_video(guest) && skip_intro()) {
        printf("Runtime: open(%s) -> skipped (skip_intro)\n",guest);
        return -ENOENT;
    }
    if (game_path(guest) && (flags & (3|0x8|0x200|0x400|0x800))) return -EROFS;
    char path[1024];
    int e=translate(guest,path,sizeof(path));
    if (e) return -e;
    char *commit=NULL, *temp=NULL, current[1024];
    snprintf(current,sizeof(current),"%s",path);
    if (save_path(guest)) current_copy(current,sizeof(current),0);
#ifdef _WIN32
    /* Windows cannot open a directory as a CRT descriptor: directories are listings only.
     * The file system ignores case, so fix_case is not needed. */
    HostStat s;
    Listing *dir=NULL;
    int host=-1;
    if (!host_stat(current,&s) && S_ISDIR(s.st_mode)) {
        if (flags&3) return -EISDIR;
        if (!(dir=list_directory(current,guest))) return -EACCES;
    } else if (flags&0x20000) {
        e=errno==ENOENT ? ENOENT : ENOTDIR;
        if (e==ENOENT) { ++missing; printf("Runtime: open(%s) -> not found\n",guest); }
        return -e;
    } else {
        if (save_path(guest) && (flags&3)) {
            host=open_for_commit(path,current,flags,mode,&commit,&temp);
            if (host<0) { errno=-host; host=-1; }
        } else {
            host=open(current,host_flags(flags)&~O_DIRECTORY,_S_IREAD|_S_IWRITE);
        }
        if (save_trace() && save_path(guest))
            printf("Save trace: open(%s, flags 0x%x) -> host %d%s%s\n",guest,flags,host,temp ? ", copy " : "",temp ? temp : "");
        if (host<0) {
            e=errno;
            if (e==ENOENT) { ++missing; printf("Runtime: open(%s) -> not found\n",guest); }
            return -e;
        }
        if (host_fstat(host,&s)) memset(&s,0,sizeof(s));
    }
#else
    int host;
    if (save_path(guest) && (flags&3)) {
        host=open_for_commit(path,current,flags,mode,&commit,&temp);
        if (host<0) { errno=-host; host=-1; }
    } else {
        host=open(current,host_flags(flags),mode ? mode : 0644);
        if (host<0 && errno==ENOENT && !(flags&0x200) && !save_path(guest) && fix_case(current)) {
            host=open(current,host_flags(flags),mode ? mode : 0644);
            snprintf(path,sizeof(path),"%s",current); // the directory listing below uses it
        }
    }
    if (save_trace() && save_path(guest))
        printf("Save trace: open(%s, flags 0x%x) -> host %d%s%s\n",guest,flags,host,temp ? ", copy " : "",temp ? temp : "");
    if (host<0) {
        e=errno;
        if (e==ENOENT) { ++missing; printf("Runtime: open(%s) -> not found\n",guest); }
        return -e;
    }
    struct stat s;
    Listing *dir=NULL;
    if (!fstat(host,&s) && S_ISDIR(s.st_mode)) dir=list_directory(path,guest);
#endif
    pthread_mutex_lock(&lock);
    int fd=-1;
    for (int i=3;i<MAX_FILES;++i) if (!files[i].used) { fd=i; break; }
    if (fd<0) {
        pthread_mutex_unlock(&lock); if (host>=0) close(host); free_listing(dir);
        if (temp) unlink(temp);
        free(commit); free(temp); return -EMFILE;
    }
    files[fd]=(File){.used=1,.host=host,.dir=dir,.commit=commit,.temp=temp};
    snprintf(files[fd].path,sizeof(files[fd].path),"%s",guest);
    if (host>=0 && !dir && !(flags&3)) files[fd].patch=archive_patch_for(guest,(uint64_t)s.st_size);
    /* A full-screen Bink video (ultrawide: shown at 16:9 while one is open, runtime_cinematic.c).
     * The menus' videos (track previews, hints, CTR TV, the tutorial) play inside the ultrawide
     * menu and are left alone. */
    if (fullscreen_video(guest)) { files[fd].video=1; runtime_cinematic_video(1); }
    ++opens;
    pthread_mutex_unlock(&lock);
    if (audio_trace() && strstr(guest,"sound/")) printf("Audio trace: open(%s) -> fd %d, %lld bytes\n",guest,fd,(long long)s.st_size);
    const char *mod_trace=getenv("BB_MOD_TRACE"), *mod_root=getenv("BB_MODS_DIR");
    if (mod_trace && mod_trace[0]=='1' && mod_root) {
        char actual[PATH_MAX],root[PATH_MAX];
        static unsigned traced;
        if (realpath(path,actual) && realpath(mod_root,root)) {
            size_t n=strlen(root);
            if (!strncmp(actual,root,n) && (actual[n]=='/' || actual[n]=='\\') &&
                __atomic_fetch_add(&traced,1,__ATOMIC_RELAXED)<32)
                printf("Mods: open %s -> %s\n",guest,actual);
        }
    }
    if (save_trace() && save_path(guest)) printf("Save trace: open(%s) -> fd %d\n",guest,fd);
    return fd;
}
static int64_t do_close(int fd) {
    if (fd>=0 && fd<3) return 0;
    pthread_mutex_lock(&lock);
    File *f=get(fd);
    if (!f) { pthread_mutex_unlock(&lock); return -EBADF; }
    File closed=*f;
    *f=(File){0};
    pthread_mutex_unlock(&lock);
    if (closed.video) runtime_cinematic_video(-1);
    free_listing(closed.dir);
    int result=0;
    if (closed.temp) result=commit_file(&closed);
    else if (closed.host>=0) close(closed.host);
    if (save_trace() && save_path(closed.path))
        printf("Save trace: close(fd %d, %s)%s -> %d\n",fd,closed.path,closed.temp ? closed.dirty ? " commit" : " unwritten" : "",result);
    free(closed.commit); free(closed.temp);
    return result;
}
static int host_fd(int fd) {
    if (fd>=0 && fd<3) return fd;
    File *f=get(fd);
    return f ? f->host : -1;
}
static int host_fd_written(int fd) {
    if (fd>=0 && fd<3) return fd;
    File *f=get(fd);
    if (!f) return -1;
    if (!f->dirty && save_trace() && save_path(f->path)) printf("Save trace: first write to fd %d (%s)\n",fd,f->path);
    f->dirty=1;
    return f->host;
}
/* The GPU side is told of the write first (runtime_memory_note_write: its tracking unprotects the
 * range). Pages protected again meanwhile would make the kernel's copy fail with EFAULT instead
 * of faulting to our handler: a user-mode write to each page first goes through the handler. */
#ifdef _WIN32
/* The CRT reads and writes at most INT_MAX bytes per call. */
static ssize_t host_read(int h,void *buffer,uint64_t size) { return read(h,buffer,(unsigned)(size>0x7ffff000 ? 0x7ffff000 : size)); }
static ssize_t host_write(int h,const void *buffer,uint64_t size) { return write(h,buffer,(unsigned)(size>0x7ffff000 ? 0x7ffff000 : size)); }
#else
#define host_read read
#define host_write write
#endif
static void touch_for_write(void *buffer,uint64_t size) {
    if (!size) return;
    uintptr_t p=(uintptr_t)buffer & ~(uintptr_t)4095, end=(uintptr_t)buffer+size;
    for (; p<end; p+=4096) {
        volatile unsigned char *b=(volatile unsigned char *)(p<(uintptr_t)buffer ? (uintptr_t)buffer : p);
        *b=*b;
    }
}
/* A page protected again between the touch and the kernel's copy (the GPU side re-arms its write
 * traps): EFAULT with nothing read. Touched again, the read is tried again a few times. */
static ssize_t read_retrying(int h,void *buffer,uint64_t size,int64_t offset,int positional) {
    ssize_t n=-1;
    for (int attempt=0; attempt<8; ++attempt) {
        n=positional ? pread(h,buffer,size,offset) : host_read(h,buffer,size);
        if (n>=0 || errno!=EFAULT) break;
        touch_for_write(buffer,size);
    }
    return n;
}
/* A read of a patched archive at offset: the archive's bytes, then the patch's ranges over them. */
static int64_t patched_read(const ArchivePatch *p,int h,void *buffer,uint64_t size,int64_t offset) {
    if (offset<0) return -EINVAL;
    uint64_t off=(uint64_t)offset;
    if (off>=p->virtual_size || !size) return 0;
    uint64_t total=size<p->virtual_size-off ? size : p->virtual_size-off;
    uint64_t from_archive=off<p->size ? (total<p->size-off ? total : p->size-off) : 0;
    if (from_archive) {
        ssize_t n=read_retrying(h,buffer,from_archive,offset,1);
        if (n<0) return -errno;
        if ((uint64_t)n<from_archive) total=from_archive=(uint64_t)n;
    }
    if (total>from_archive) memset((char *)buffer+from_archive,0,total-from_archive);
    for (int i=0;i<p->count;++i) {
        const PatchRange *r=&p->ranges[i];
        uint64_t lo=r->offset>off ? r->offset : off, hi=r->offset+r->length<off+total ? r->offset+r->length : off+total;
        if (lo<hi) {
            memcpy((char *)buffer+(lo-off),r->data+(lo-r->offset),hi-lo);
            /* The log says once that the game read each range (the patch is in use). */
            static unsigned char seen[MAX_ARCHIVE_PATCHES*2][64];
            const int k=p->slot;
            if (k>=0 && k<MAX_ARCHIVE_PATCHES*2 && i<64 && !seen[k][i]) {
                seen[k][i]=1;
                printf("Runtime: archive patch %s: the game read range %d (%u bytes at %llu)\n",p->guest,i,r->length,(unsigned long long)r->offset);
            }
        }
    }
    return (int64_t)total;
}
static int64_t do_read(int fd,void *buffer,uint64_t size) {
    int h=host_fd(fd);
    if (h<0) return -EBADF;
    runtime_memory_note_write((uintptr_t)buffer,size);
    touch_for_write(buffer,size);
    File *pf=get(fd);
    if (pf && pf->patch) {
        int64_t at=host_lseek(h,0,SEEK_CUR);
        int64_t got=at<0 ? -errno : patched_read(active_archive_patch(pf->patch),h,buffer,size,at);
        if (got>0) { host_lseek(h,at+got,SEEK_SET); runtime_memory_note_write((uintptr_t)buffer,(uint64_t)got); }
        if (got>0) { __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,(uint64_t)got,__ATOMIC_RELAXED); }
        return got;
    }
    ssize_t n=read_retrying(h,buffer,size,0,0);
    if (n<0) { if (audio_trace()) printf("Audio trace: read(fd %d, %llu) failed, errno %d\n",fd,(unsigned long long)size,errno); return -errno; }
    if (n>0) runtime_memory_note_write((uintptr_t)buffer,(uint64_t)n); /* and once the data is there */
    __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,(uint64_t)n,__ATOMIC_RELAXED);
    return n;
}
static int64_t do_pread(int fd,void *buffer,uint64_t size,int64_t offset) {
    int h=host_fd(fd);
    if (h<0) return -EBADF;
    runtime_memory_note_write((uintptr_t)buffer,size);
    touch_for_write(buffer,size);
    File *pf=get(fd);
    if (pf && pf->patch) {
        int64_t got=patched_read(active_archive_patch(pf->patch),h,buffer,size,offset);
        if (got>0) { runtime_memory_note_write((uintptr_t)buffer,(uint64_t)got); __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,(uint64_t)got,__ATOMIC_RELAXED); }
        return got;
    }
    ssize_t n=read_retrying(h,buffer,size,offset,1);
    if (n<0) { if (audio_trace()) printf("Audio trace: pread(fd %d, %llu @%lld) failed, errno %d\n",fd,(unsigned long long)size,(long long)offset,errno); return -errno; }
    if (n>0) runtime_memory_note_write((uintptr_t)buffer,(uint64_t)n); /* and once the data is there */
    __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,(uint64_t)n,__ATOMIC_RELAXED);
    return n;
}
/* Pages the GPU side keeps without access (data newer in VRAM, runtime_memory_trap reasons from
 * 16 up) would make the kernel's copy fail with EFAULT: a user-mode read of each page first goes
 * through the handler, which copies the data back. */
static void touch_for_read(const void *buffer,uint64_t size) {
    if (!size) return;
    uintptr_t p=(uintptr_t)buffer & ~(uintptr_t)4095, end=(uintptr_t)buffer+size;
    for (; p<end; p+=4096)
        (void)*(volatile const unsigned char *)(p<(uintptr_t)buffer ? (uintptr_t)buffer : p);
}
static int64_t do_write(int fd,const void *buffer,uint64_t size) {
    /* SacredFire: the first write into each opened save file is logged (plan milestone d). */
    { File *sf=get(fd); if (sf && !sf->save_logged && !strncmp(sf->path,"/savedata",9)) { sf->save_logged=1; printf("Runtime: save write: %s (%llu bytes)\n",sf->path,(unsigned long long)size); } }
    int h=host_fd_written(fd);
    if (h<0) return -EBADF;
    touch_for_read(buffer,size);
    ssize_t n=host_write(h,buffer,size);
    if (n<0) return -errno;
    __atomic_add_fetch(&writes,1,__ATOMIC_RELAXED);
    return n;
}
static int64_t do_pwrite(int fd,const void *buffer,uint64_t size,int64_t offset) {
    int h=host_fd_written(fd);
    if (h<0) return -EBADF;
    touch_for_read(buffer,size);
    ssize_t n=pwrite(h,buffer,size,offset);
    return n<0 ? -errno : n;
}
static int64_t do_lseek(int fd,int64_t offset,int whence) {
    if (save_trace()) { File *t=get(fd); if (t && save_path(t->path)) printf("Save trace: lseek(fd %d, %lld, %d)\n",fd,(long long)offset,whence); }
    File *f=get(fd);
    if (!f) return -EBADF;
    if (whence<0 || whence>2) return -EINVAL;
    if (f->dir) {
        /* Directory offsets are entry indices for getdirentries. */
        if (whence==0 && offset>=0) { f->position=(size_t)offset; return offset; }
        return -EINVAL;
    }
    /* A patched archive ends where the game sees it end. */
    int64_t r=f->patch && whence==2 ? host_lseek(f->host,(int64_t)f->patch->virtual_size+offset,SEEK_SET)
                                    : host_lseek(f->host,offset,whence);
    return r<0 ? -errno : r;
}
static int64_t do_fstat(int fd,GuestStat *out) {
    if (save_trace()) { File *t=get(fd); if (t && save_path(t->path)) printf("Save trace: fstat(fd %d)\n",fd); }
    int h=host_fd(fd);
    HostStat s;
#ifdef _WIN32
    if (h<0) { /* directory: a listing only, stat the path it was opened with */
        File *f=get(fd); char path[1024];
        if (!f || !f->dir) return -EBADF;
        if (!out) return -EFAULT;
        if (translate(f->path,path,sizeof(path)) || host_stat(path,&s)) return -EBADF;
        convert_stat(&s,out); return 0;
    }
#else
    if (h<0) return -EBADF;
#endif
    if (!out) return -EFAULT;
    if (host_fstat(h,&s)) return -errno;
    convert_stat(&s,out);
    File *pf=get(fd);
    if (pf && pf->patch) { out->size=(int64_t)pf->patch->virtual_size; out->blocks=(out->size+511)/512; }
    return 0;
}
static int64_t do_stat(const char *guest,GuestStat *out) {
    char path[1024]; HostStat s;
    int e=translate(guest,path,sizeof(path));
    if (e) return -e;
    if (save_path(guest)) current_copy(path,sizeof(path),0);
    if (!out) return -EFAULT;
    int r=host_stat(path,&s) ? -errno : 0;
    if (r==-ENOENT && !save_path(guest) && fix_case(path)) r=host_stat(path,&s) ? -errno : 0;
    if (save_trace() && save_path(guest)) printf("Save trace: stat(%s) -> %d, %lld bytes\n",guest,r,r ? -1LL : (long long)s.st_size);
    if (r) return r;
    convert_stat(&s,out);
    const ArchivePatch *patch=S_ISREG(s.st_mode) ? archive_patch_for(guest,(uint64_t)s.st_size) : NULL;
    if (patch) { out->size=(int64_t)patch->virtual_size; out->blocks=(out->size+511)/512; }
    return 0;
}
static int64_t do_getdents(int fd,char *buffer,uint64_t size,int64_t *basep) {
    pthread_mutex_lock(&lock);
    File *f=get(fd);
    int64_t result=0;
    if (!f) result=-EBADF;
    else if (!f->dir) result=-EINVAL;
    else if (!buffer) result=-EFAULT;
    else if (size<512) result=-EINVAL;
    else {
        if (basep) *basep=(int64_t)f->position;
        uint64_t written=0;
        while (f->position<f->dir->count) {
            const char *name=f->dir->names+f->dir->offsets[f->position];
            size_t n=strlen(name); if (n>255) n=255;
            uint16_t reclen=(uint16_t)((8+n+1+7)&~(size_t)7);
            if (written+reclen>size) break;
            char *p=buffer+written;
            memset(p,0,reclen);
            uint32_t ino=(uint32_t)f->position+1;
            memcpy(p,&ino,4); memcpy(p+4,&reclen,2);
            p[6]=(char)f->dir->types[f->position]; p[7]=(char)n;
            memcpy(p+8,name,n);
            written+=reclen; ++f->position;
        }
        result=(int64_t)written;
    }
    pthread_mutex_unlock(&lock);
    return result;
}
static int64_t path_op(const char *guest,int op,int mode) {
    if (game_path(guest)) return -EROFS;
    char path[1024];
    int e=translate(guest,path,sizeof(path));
    if (e) return -e;
    int r= op==0 ? mkdir(path,mode ? mode : 0755) : op==1 ? rmdir(path) : unlink(path);
    r=r ? -errno : 0;
    if (save_trace() && save_path(guest)) printf("Save trace: %s(%s) -> %d\n",op==0 ? "mkdir" : op==1 ? "rmdir" : "unlink",guest,r);
    return r;
}
static int64_t do_rename(const char *from,const char *to) {
    if (game_path(from) || game_path(to)) return -EROFS;
    char a[1024],b[1024];
    int e=translate(from,a,sizeof(a));
    if (!e) e=translate(to,b,sizeof(b));
    if (e) return -e;
#ifdef _WIN32
    /* POSIX rename replaces an existing target; the CRT's fails. */
    int r=MoveFileExA(a,b,MOVEFILE_REPLACE_EXISTING) ? 0 : -compat_errno_from_win32(GetLastError());
#else
    int r=rename(a,b) ? -errno : 0;
#endif
    if (save_trace() && (save_path(from) || save_path(to))) printf("Save trace: rename(%s, %s) -> %d\n",from,to,r);
    return r;
}
static int64_t do_ftruncate(int fd,int64_t length) {
    int h=host_fd_written(fd);
    if (h<0) return -EBADF;
#ifdef _WIN32
    return _chsize_s(h,length) ? -errno : 0;
#else
    return ftruncate(h,length) ? -errno : 0;
#endif
}
static int64_t do_truncate(const char *guest,int64_t length) {
    if (game_path(guest)) return -EROFS;
    char path[1024];
    int e=translate(guest,path,sizeof(path));
    if (e) return -e;
    if (save_path(guest)) current_copy(path,sizeof(path),1);
    if (save_trace() && save_path(guest)) printf("Save trace: truncate(%s, %lld)\n",guest,(long long)length);
#ifdef _WIN32
    int h=open(path,O_RDWR|O_BINARY);
    if (h<0) return -errno;
    int r=_chsize_s(h,length) ? -errno : 0;
    close(h);
    return r;
#else
    return truncate(path,length) ? -errno : 0;
#endif
}
static int64_t do_fsync(int fd) { int h=host_fd(fd); if (h<0) return -EBADF; return fsync(h) ? -errno : 0; }
static int64_t do_access(const char *guest,int mode) {
    char path[1024];
    int e=translate(guest,path,sizeof(path));
    if (e) return -e;
    if (save_path(guest)) current_copy(path,sizeof(path),0);
#ifdef _WIN32
    return access(path,mode&6) ? -errno : 0; /* X_OK is invalid for the CRT */
#else
    int r=access(path,mode&7) ? -errno : 0;
    if (r==-ENOENT && !save_path(guest) && fix_case(path)) r=access(path,mode&7) ? -errno : 0;
    return r;
#endif
}

/* Convention adapters: sceKernel* -> Orbis error codes, POSIX -> -1 + errno. */
static int64_t sce(int64_t r) { return r<0 ? ERR(runtime_guest_errno((int)-r)) : r; }
static int64_t posix(int64_t r) { if (r<0) { *runtime_errno()=runtime_guest_errno((int)-r); return -1; } return r; }
#define PAIR(name,params,args) \
    static ABI int64_t sce_##name params { return sce(do_##name args); } \
    static ABI int64_t posix_##name params { return posix(do_##name args); }
PAIR(open,(const char *p,int f,int m),(p,f,m))
PAIR(close,(int fd),(fd))
PAIR(read,(int fd,void *b,uint64_t n),(fd,b,n))
PAIR(pread,(int fd,void *b,uint64_t n,int64_t o),(fd,b,n,o))
PAIR(write,(int fd,const void *b,uint64_t n),(fd,b,n))
PAIR(pwrite,(int fd,const void *b,uint64_t n,int64_t o),(fd,b,n,o))
PAIR(lseek,(int fd,int64_t o,int w),(fd,o,w))
PAIR(fstat,(int fd,GuestStat *s),(fd,s))
PAIR(stat,(const char *p,GuestStat *s),(p,s))
PAIR(getdents,(int fd,char *b,uint64_t n,int64_t *base),(fd,b,n,base))
PAIR(rename,(const char *a,const char *b),(a,b))
PAIR(ftruncate,(int fd,int64_t l),(fd,l))
PAIR(truncate,(const char *p,int64_t l),(p,l))
PAIR(fsync,(int fd),(fd))
static ABI int64_t posix_access(const char *p,int m) { return posix(do_access(p,m)); }
static ABI int64_t sce_mkdir(const char *p,int m) { return sce(path_op(p,0,m)); }
static ABI int64_t posix_mkdir(const char *p,int m) { return posix(path_op(p,0,m)); }
static ABI int64_t sce_rmdir(const char *p) { return sce(path_op(p,1,0)); }
static ABI int64_t posix_rmdir(const char *p) { return posix(path_op(p,1,0)); }
static ABI int64_t sce_unlink(const char *p) { return sce(path_op(p,2,0)); }
static ABI int64_t posix_unlink(const char *p) { return posix(path_op(p,2,0)); }
/* SacredFire: sceKernelGetdents is getdirentries without the base pointer. */
static ABI int64_t sce_getdents_nobase(int fd,char *b,uint64_t n) { int64_t base=0; return sce(do_getdents(fd,b,n,&base)); }
static ABI int32_t sce_check_reachability(const char *p) {
    GuestStat s; return (int32_t)sce(do_stat(p,&s));
}

static const RuntimeExport exports[]={
    {"sceKernelOpen",sce_open}, {"open",posix_open}, {"_open",posix_open},
    {"sceKernelClose",sce_close}, {"close",posix_close}, {"_close",posix_close},
    {"sceKernelRead",sce_read}, {"read",posix_read}, {"_read",posix_read},
    {"sceKernelPread",sce_pread}, {"pread",posix_pread},
    {"sceKernelWrite",sce_write}, {"write",posix_write}, {"_write",posix_write},
    {"sceKernelPwrite",sce_pwrite}, {"pwrite",posix_pwrite},
    {"sceKernelLseek",sce_lseek}, {"lseek",posix_lseek},
    {"sceKernelFstat",sce_fstat}, {"fstat",posix_fstat},
    {"sceKernelStat",sce_stat}, {"stat",posix_stat},
    {"sceKernelGetdirentries",sce_getdents}, {"getdirentries",posix_getdents},
    {"sceKernelGetdents",sce_getdents_nobase},
    {"sceKernelRename",sce_rename}, {"rename",posix_rename},
    {"sceKernelFtruncate",sce_ftruncate}, {"ftruncate",posix_ftruncate},
    {"sceKernelTruncate",sce_truncate}, {"truncate",posix_truncate},
    {"sceKernelFsync",sce_fsync}, {"fsync",posix_fsync},
    {"access",posix_access}, {"sceKernelCheckReachability",sce_check_reachability},
    {"sceKernelMkdir",sce_mkdir}, {"mkdir",posix_mkdir},
    {"sceKernelRmdir",sce_rmdir}, {"rmdir",posix_rmdir},
    {"sceKernelUnlink",sce_unlink}, {"unlink",posix_unlink},
};
uintptr_t runtime_file_resolve(const char *name) { return RUNTIME_LOOKUP(exports,name); }
/* Host-side helpers for other modules (e.g. SaveData, Fios). */
int64_t runtime_file_open(const char *p,int f,int m) { return do_open(p,f,m); }
int64_t runtime_file_close(int fd) { return do_close(fd); }
int64_t runtime_file_read(int fd,void *b,uint64_t n) { return do_read(fd,b,n); }
int64_t runtime_file_pread(int fd,void *b,uint64_t n,int64_t o) { return do_pread(fd,b,n,o); }
int64_t runtime_file_write(int fd,const void *b,uint64_t n) { return do_write(fd,b,n); }
int64_t runtime_file_lseek(int fd,int64_t o,int w) { return do_lseek(fd,o,w); }
int64_t runtime_file_stat(const char *p,void *s) { return do_stat(p,s); }
int64_t runtime_file_fstat(int fd,void *s) { return do_fstat(fd,s); }
int64_t runtime_file_getdents(int fd,char *b,uint64_t n,int64_t *base) { return do_getdents(fd,b,n,base); }
int runtime_file_translate(const char *guest,char *out,size_t size) { return translate(guest,out,size); }
void runtime_file_report(void) {
    printf("Runtime: files opened=%zu, reads=%zu (%llu bytes), writes=%zu, not found=%zu\n",
           opens,reads,(unsigned long long)bytes_read,writes,missing);
}

