# Corresponding source: CTR RyuNET PS4 v1.5.2

Private validation candidate, pinned to OCTR v0.7.5. Module sources match the ES/EN SELF files. This archive excludes game executables, game archives, profiles, keys and saves. Update PKGs separately contain the required executable and UI patch resources.

Build dependencies: Python 3, LLVM clang/ld.lld, OpenOrbis create-fself and GoldHEN SDK crtprx.c. CTR_LLVM_BIN and OO_PS4_TOOLCHAIN select tool locations. The scripts preserve the development workspace layout, with ps4-online toolchains alongside ctr-v152-es/en. Native emulation tests require the supported, separately supplied game image and fixtures; this is corresponding source, not a standalone constructor. Platform test shims are test-only and are not linked into shipping modules.

The updater preserves the fixed GitHub origin and validates complete SELF files and the hash-pinned UI archive. Missing-resource migration restores an older valid module before initialization, downloads resources on a detached worker, verifies disk readback and activates the pending module only after success. External routing is limited to read-only access to the one verified UI archive. No general mod redirection is enabled.

Console validation is required before activating the public feed. Local tests include actual SELF execution, failed transfers, disk errors, rollback, exact-path routing, identity isolation and native menus. The reported PC-host Itemless crate behavior is not claimed fixed.

Credits: Ryu7w7 and OCTR/RyuNET contributors, original PC-port authors, n0buholic, Vo1dTear, immaculatevibes2025 and contributors, PS4 contributors and AI assistance. Original GPL notices and tool licenses apply.
