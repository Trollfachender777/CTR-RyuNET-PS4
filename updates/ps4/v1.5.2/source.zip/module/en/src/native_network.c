// SPDX-License-Identifier: GPL-2.0-only
// Install four explicit network GOT hooks in the verified game, never OS code.
#include "net_transport.h"
extern int64_t ctr_syscall(int64_t,...);
typedef struct {uint64_t address;uint32_t size;int32_t protection;} NetSegment;
typedef struct {uint64_t size;char name[256];NetSegment segments[4];uint32_t count;uint8_t fingerprint[20];} NetModule;
typedef struct {int module;const char *name;uint64_t got,unresolved;} NetImport;
typedef struct {const char *name,*nid;} NetSymbol;
#include "network_profile.h"
static int installed;
static int permission(const NetModule *m,uint64_t address,size_t size){
    if(m->count>4)return 0;
    for(uint32_t i=0;i<m->count;i++){
        const NetSegment *s=&m->segments[i];
        if(address>=s->address&&address-s->address<=s->size&&size<=s->size-(address-s->address))return s->protection;
    }
    return 0;
}
int ctr_network_install(uint64_t base,const void *module,void(*trace)(int32_t,int32_t)){
    if(installed)return 0;
    if(!module||!base)return -1;
    const NetModule *game=module;
    int32_t handles[256];uint64_t count=0;
    if(ctr_syscall(592,handles,(size_t)256,&count)||count>256)return -2;
    void *symbols[sizeof(net_symbols)/sizeof(net_symbols[0])];ctr_memset(symbols,0,sizeof(symbols));
    for(size_t n=0;n<sizeof(symbols)/sizeof(symbols[0]);n++){
        for(uint64_t i=0;i<count;i++){
            void *value=0;
            if((ctr_syscall(591,handles[i],net_symbols[n].name,&value)==0||
                ctr_syscall(591,handles[i],net_symbols[n].nid,&value)==0)&&value&&(uint64_t)value<0x800000000000ULL){symbols[n]=value;break;}
        }
        if(!symbols[n])return -3;
    }
    CtrNetApi api;ctr_memset(&api,0,sizeof(api));api.trace=trace;
    for(size_t n=0;n<sizeof(symbols)/sizeof(symbols[0]);n++){
        const char *name=net_symbols[n].name;void *value=symbols[n];
        if(!ctr_strcmp(name,"sceNetBind"))api.bind=(__typeof__(api.bind))value;
        else if(!ctr_strcmp(name,"sceNetSendto"))api.sendto=(__typeof__(api.sendto))value;
        else if(!ctr_strcmp(name,"sceNetRecvfrom"))api.recvfrom=(__typeof__(api.recvfrom))value;
        else if(!ctr_strcmp(name,"sceNetSocketClose"))api.close=(__typeof__(api.close))value;
        else if(!ctr_strcmp(name,"sceNetGetsockopt"))api.getsockopt=(__typeof__(api.getsockopt))value;
        else if(!ctr_strcmp(name,"sceNetErrnoLoc"))api.errno_location=(__typeof__(api.errno_location))value;
        else if(!ctr_strcmp(name,"sceKernelGetProcessTime"))api.clock_us=(__typeof__(api.clock_us))value;
    }
    uint64_t pages[4],before[4];int permissions[4];size_t page_count=0;
    void *replacement[4];
    _Static_assert(sizeof(net_imports)/sizeof(net_imports[0])==4,"exact game network imports");
    for(size_t n=0;n<4;n++){
        const NetImport *entry=&net_imports[n];
        if(entry->module!=0||entry->got&7||!(permission(game,base+entry->got,8)&1))return -4;
        uint64_t current=*(volatile uint64_t*)(base+entry->got),expected=0;
        for(size_t i=0;i<sizeof(symbols)/sizeof(symbols[0]);i++)if(!ctr_strcmp(entry->name,net_symbols[i].name))expected=(uint64_t)symbols[i];
        if(!current||current>=0x800000000000ULL||(current!=expected&&current!=base+entry->unresolved))return -5;
        before[n]=current;
        if(!ctr_strcmp(entry->name,"sceNetBind"))replacement[n]=(void*)ctr_net_bind;
        else if(!ctr_strcmp(entry->name,"sceNetSendto"))replacement[n]=(void*)ctr_net_sendto;
        else if(!ctr_strcmp(entry->name,"sceNetRecvfrom"))replacement[n]=(void*)ctr_net_recvfrom;
        else if(!ctr_strcmp(entry->name,"sceNetSocketClose"))replacement[n]=(void*)ctr_net_close;
        else return -4;
        uint64_t page=(base+entry->got)&~0x3fffULL;size_t i=0;
        while(i<page_count&&pages[i]!=page)i++;
        if(i==page_count){pages[page_count]=page;permissions[page_count++]=permission(game,base+entry->got,8);}
    }
    for(size_t i=0;i<page_count;i++)if(ctr_syscall(74,pages[i],(size_t)0x4000,permissions[i]|2)){
        for(size_t j=0;j<i;j++)ctr_syscall(74,pages[j],(size_t)0x4000,permissions[j]);return -6;
    }
    // Recheck after acquiring all pages. Another hook must not be overwritten.
    for(size_t n=0;n<4;n++)if(*(volatile uint64_t*)(base+net_imports[n].got)!=before[n]){
        for(size_t i=0;i<page_count;i++)ctr_syscall(74,pages[i],(size_t)0x4000,permissions[i]);return -5;
    }
    if(ctr_net_init(&api)){
        for(size_t i=0;i<page_count;i++)ctr_syscall(74,pages[i],(size_t)0x4000,permissions[i]);return -7;
    }
    for(size_t n=0;n<4;n++)__atomic_store_n((uint64_t*)(base+net_imports[n].got),(uint64_t)replacement[n],__ATOMIC_RELEASE);
    installed=1;
    for(size_t i=0;i<page_count;i++){int r=(int)ctr_syscall(74,pages[i],(size_t)0x4000,permissions[i]);if(r&&trace)trace(151,r);}
    return 0;
}
