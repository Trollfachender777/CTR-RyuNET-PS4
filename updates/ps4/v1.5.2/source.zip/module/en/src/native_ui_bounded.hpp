// SPDX-License-Identifier: GPL-2.0-only
// Bounded native UI containers: no host CRT, heap, exceptions or static constructors.
#pragma once
#include <stddef.h>
#include <stdint.h>
extern "C" {
void *ctr_memcpy(void*,const void*,size_t);
void *ctr_memset(void*,int,size_t);
size_t ctr_strlen(const char*);
int ctr_strcmp(const char*,const char*);
int ctr_strncmp(const char*,const char*,size_t);
const char *ctr_strstr(const char*,const char*);
int ctr_native_memcmp(const void*,const void*,size_t);
int ctr_native_snprintf(char*,size_t,const char*,...);
int ctr_native_mutex_create(void**);
void ctr_native_mutex_lock(void**);
void ctr_native_mutex_unlock(void**);
int ctr_native_safe_read(const void*,void*,size_t);
void *ctr_native_code_allocate(size_t);
int ctr_native_code_write(void*,const void*,size_t);
const char *ctr_native_graphics_row(size_t,int);
const char *ctr_native_graphics_description(size_t);
int ctr_native_graphics_changed(void);
void ctr_native_graphics_save(void);
void ctr_native_graphics_restart(void);
void ctr_native_quit(void);
int ctr_native_language(void);
}
using u8=uint8_t;using u32=uint32_t;using s32=int32_t;using u64=uint64_t;
#define PS4_SYSV_ABI
namespace std {
using size_t=::size_t;using uint8_t=::uint8_t;using uint64_t=::uint64_t;
using ::ctr_memcpy;using ::ctr_strlen;
inline void *memcpy(void*d,const void*s,size_t n){return ::ctr_memcpy(d,s,n);}
inline int memcmp(const void*a,const void*b,size_t n){return ::ctr_native_memcmp(a,b,n);}
inline size_t strlen(const char*s){return ::ctr_strlen(s);}
inline int strncmp(const char*a,const char*b,size_t n){return ::ctr_strncmp(a,b,n);}
inline const char *strstr(const char*a,const char*b){return ::ctr_strstr(a,b);}
inline const char*getenv(const char*){return nullptr;}
inline int atoi(const char*s){int n=0;if(s)while(*s>='0'&&*s<='9')n=n*10+*s++-'0';return n;}
template<class...A>int printf(const char*,A...){return 0;}
inline int fflush(void*){return 0;}
using ::ctr_native_snprintf;
template<class...A> int snprintf(char*out,size_t n,const char*fmt,A...args){return ::ctr_native_snprintf(out,n,fmt,args...);}
inline int isalnum(unsigned char c){return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9');}
template<class T>constexpr const T&min(const T&a,const T&b){return a<b?a:b;}
template<class T>constexpr const T&clamp(const T&v,const T&lo,const T&hi){return v<lo?lo:v>hi?hi:v;}
template<class T,size_t N>constexpr size_t size(const T(&)[N]){return N;}
template<class It,class T>It find(It a,It b,const T&v){while(a!=b&&*a!=v)++a;return a;}
template<class T>class initializer_list {
 const T *first_;size_t count_;
 constexpr initializer_list(const T*p,size_t n):first_(p),count_(n){}
 public:constexpr initializer_list():first_(nullptr),count_(0){}
 constexpr const T*begin()const{return first_;}constexpr const T*end()const{return first_+count_;}
 constexpr size_t size()const{return count_;}
};
template<class T>class atomic {
 T value_;
 public:constexpr atomic(T v={}):value_(v){}
 T load()const{return __atomic_load_n(&value_,__ATOMIC_ACQUIRE);}
 void store(T v){__atomic_store_n(&value_,v,__ATOMIC_RELEASE);}
 T fetch_add(T v){return __atomic_fetch_add(&value_,v,__ATOMIC_ACQ_REL);}
 atomic&operator=(T v){store(v);return *this;}operator T()const{return load();}
};
class mutex {
 void *handle_;
 public:constexpr mutex():handle_(nullptr){}
 bool initialize(){return ::ctr_native_mutex_create(&handle_)==0;}
 void lock(){::ctr_native_mutex_lock(&handle_);}void unlock(){::ctr_native_mutex_unlock(&handle_);}
};
template<class M>class scoped_lock {
 M&mutex_;
 public:explicit scoped_lock(M&m):mutex_(m){mutex_.lock();}~scoped_lock(){mutex_.unlock();}
};
template<class T>class vector {
 T data_[64];size_t count_;
 public:constexpr vector():data_{},count_(0){}
 size_t size()const{return count_;}bool empty()const{return !count_;}
 void clear(){count_=0;}void push_back(const T&v){if(count_<64)data_[count_++]=v;}
 T*begin(){return data_;}T*end(){return data_+count_;}
 const T*begin()const{return data_;}const T*end()const{return data_+count_;}
 T&operator[](size_t i){return data_[i<64?i:63];}const T&operator[](size_t i)const{return data_[i<64?i:63];}
};
class string {
 char data_[1024];
 public:constexpr string():data_{}{}
 string(const char*s):data_{}{*this=s;}
 string&operator=(const char*s){size_t i=0;if(s)for(;s[i]&&i<sizeof(data_)-1;i++)data_[i]=s[i];data_[i]=0;return *this;}
 const char*c_str()const{return data_;}bool empty()const{return !data_[0];}
 size_t size()const{return ::ctr_strlen(data_);}void clear(){data_[0]=0;}
 bool operator==(const char*s)const{return !::ctr_strcmp(data_,s);}
 bool operator!=(const char*s)const{return !!::ctr_strcmp(data_,s);}
 bool operator==(const string&s)const{return !::ctr_strcmp(data_,s.data_);}
};
}
#define stdout ((void*)0)
