// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
typedef struct {uint64_t address;uint32_t size;int32_t protection;} CtrMenuSegment;
typedef struct {uint64_t size;char name[256];CtrMenuSegment segments[4];uint32_t count;uint8_t fingerprint[20];} CtrMenuModule;
int ctr_native_menu_install(uint64_t,const void*,int32_t(*)(void*,void**,void**,int32_t*),void(*)(int32_t,int32_t));
int ctr_native_services_init(int32_t(*)(void*,void**,void**,int32_t*),void(*)(int32_t,int32_t));
int ctr_native_graphics_install(unsigned char*,uint64_t);
int ctr_native_graphics_commit(const void*);
void ctr_native_menu_notice(const char*);
void ctr_native_room_chosen(int,int);
int ctr_native_menu_ready(void);
