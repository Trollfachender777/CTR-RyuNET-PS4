// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
typedef struct {
    int (*read)(uint64_t,void*,size_t);
    int (*compare_byte)(uint64_t,uint8_t,uint8_t);
    void (*trace)(int32_t,int32_t);
} CtrCharactersIo;
CTR_EXPORT int ctr_characters_init(uint64_t,const CtrCharactersIo*);
CTR_EXPORT int ctr_characters_status(void);
CTR_EXPORT int ctr_characters_enable(void);
