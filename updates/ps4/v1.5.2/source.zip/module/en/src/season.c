// SPDX-License-Identifier: GPL-2.0-only
// Adaptation of OCTR v0.6.4 run.py server_settings and patches.py theme_patches.
// No game assets, profile changes, blocking network calls or frame-time writes.
#include "season.h"
#include "items.h"
#include "update_json.h"
static CtrSeasonApi platform;
static int busy;
static uint64_t next_refresh;
static char response[CTR_ITEM_BODY_MAX];
// The startup-installed assembly hook only reads this aligned value. -1 keeps
// the game's original NetConfig mode until a valid server reply is available.
int32_t ctr_season_mode = -1;
CTR_EXPORT int32_t ctr_season_current(void){return __atomic_load_n(&ctr_season_mode,__ATOMIC_ACQUIRE);}
CTR_EXPORT int ctr_season_parse(const char *body,size_t size,int32_t *mode){
    if(!body||!mode||!size||size>=sizeof(response))return -1;
    for(size_t i=0;i<size;i++)if(!body[i])return -1;
    Json j={body,body+size};unsigned seen=0;int32_t selected=-1,value=-1;
    if(take(&j,'{'))return -1;
    for(;;){
        char key[64];if(string(&j,key,sizeof(key))||take(&j,':'))return -1;
        unsigned bit=0;
        if(!ctr_strcmp(key,"theme")){
            char theme[16];bit=1;if(string(&j,theme,sizeof(theme)))return -1;
            if(!ctr_strcmp(theme,"default"))selected=0;
            else if(!ctr_strcmp(theme,"halloween"))selected=1;
            else if(!ctr_strcmp(theme,"golden"))selected=2;
            else return -1;
        }else if(!ctr_strcmp(key,"value")){
            bit=2;ws(&j);if(j.p==j.end||*j.p<'0'||*j.p>'2')return -1;
            value=*j.p++-'0';
        }else if(!ctr_strcmp(key,"end_race_timeout")){
            // Validated and deliberately left unchanged in this event-only fix.
            uint64_t ignored;if(unsigned_id(&j,&ignored))return -1;
        }else if(skip(&j,0))return -1;
        if(bit&&(seen&bit))return -1;seen|=bit;ws(&j);
        if(j.p<j.end&&*j.p=='}'){j.p++;break;}
        if(take(&j,','))return -1;
    }
    ws(&j);if(j.p!=j.end||!(seen&1)||((seen&2)&&value!=selected))return -1;
    *mode=selected;return 0;
}
static void *worker(void *unused){
    (void)unused;response[0]=0;response[sizeof(response)-1]=0;
    int status=platform.request("GET","/ryunet/theme",response,sizeof(response));
    size_t length=0;while(length<sizeof(response)&&response[length])length++;
    int32_t mode=-1;int valid=status==200&&!ctr_season_parse(response,length,&mode);
    if(valid){
        int items=ctr_items_accept(response,length);
        if(items&&platform.trace)platform.trace(191,items);
        int32_t before=__atomic_exchange_n(&ctr_season_mode,mode,__ATOMIC_RELEASE);
        if(before!=mode&&platform.trace)platform.trace(181,mode);
    }else if(platform.trace)platform.trace(182,status);
    // Only the worker writes the deadline; the caller sees it after busy clears.
    next_refresh=platform.time_us()+(valid?900000000ULL:60000000ULL);
    __atomic_store_n(&busy,0,__ATOMIC_RELEASE);return 0;
}
CTR_EXPORT int ctr_season_init(const CtrSeasonApi *api){
    if(__atomic_load_n(&busy,__ATOMIC_ACQUIRE))return -1;
    ctr_memset(&platform,0,sizeof(platform));next_refresh=0;ctr_items_reset();
    __atomic_store_n(&ctr_season_mode,-1,__ATOMIC_RELEASE);
    if(api){if(!api->spawn||!api->request||!api->time_us)return -1;platform=*api;}
    return 0;
}
CTR_EXPORT void ctr_season_tick(void){
    if(!platform.time_us)return;
    int zero=0;if(!__atomic_compare_exchange_n(&busy,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return;
    if(platform.time_us()<next_refresh){__atomic_store_n(&busy,0,__ATOMIC_RELEASE);return;}
    if(platform.spawn(worker,0)){
        next_refresh=platform.time_us()+60000000ULL;
        __atomic_store_n(&busy,0,__ATOMIC_RELEASE);
    }
}
