// SPDX-License-Identifier: GPL-2.0-only
// Read the already-loaded CPowerUpData on the game's input path, never a worker.
// No new executable hook, engine call, heap allocation, file or save mutation.
#include "items.h"
typedef struct {uint64_t address;uint32_t size;int32_t protection;} ItemSegment;
typedef struct {uint64_t size;char name[256];ItemSegment segments[4];uint32_t count;uint8_t fingerprint[20];} ItemModule;
static uint64_t image;
static ItemModule game;
static int32_t(*query_memory)(void*,void**,void**,int32_t*);
static void(*record)(int32_t,int32_t);
static uint32_t item_poll_count;
static int region(uint64_t address,size_t size){
    for(unsigned i=0;i<game.count&&i<4;i++){
        ItemSegment *s=&game.segments[i];
        if(address>=s->address&&address-s->address<=s->size&&size<=s->size-(address-s->address))return s->protection;
    }return 0;
}
static int check(uint64_t address,size_t bytes,int write){
    if(!address||(address&3)||address>=0x800000000000ULL||bytes>0x800000000000ULL-address)return 0;
    int needed=write?3:1;
    int native=region(address,bytes);if((native&needed)==needed)return 1;
    void *first=0,*last=0;int32_t protection=0;
    return query_memory&&!query_memory((void*)address,&first,&last,&protection)&&
        (protection&needed)==needed&&(uint64_t)first<=address&&(uint64_t)last>=address+bytes;
}
static uint64_t pointer(uint64_t at){uint64_t value;ctr_memcpy(&value,(void*)at,8);return value;}
void ctr_items_native_init(uint64_t base,const void *module,
    int32_t(*query)(void*,void**,void**,int32_t*),void(*trace)(int32_t,int32_t)){
    image=0;item_poll_count=0;query_memory=query;record=trace;
    if(!base||!module||!query)return;game=*(const ItemModule*)module;
    static const uint8_t getter[]={0x48,0x8b,0x05,0x71,0xfd,0x11,0x02,0x48,0x85,0xc0,0x74,0x01,0xc3};
    static const uint8_t meta[]={0x48,0x8b,0x05,0xa1,0x3a,0x95,0x01,0xc3};
    if((region(base+0x9b9ec0,sizeof(getter))&5)!=5||(region(base+0x117e140,sizeof(meta))&5)!=5||
       !(region(base+0x2ad9c38,8)&1))return;
    for(unsigned i=0;i<sizeof(getter);i++)if(((const uint8_t*)(base+0x9b9ec0))[i]!=getter[i])return;
    for(unsigned i=0;i<sizeof(meta);i++)if(((const uint8_t*)(base+0x117e140))[i]!=meta[i])return;
    image=base;
}
void ctr_items_native_tick(void){
    if(!image||!ctr_items_pending()||(++item_poll_count%60)!=1)return;
    uint64_t root=pointer(image+0x2ad9c38);
    if(!check(root,0x100,0))return;
    uint64_t object=pointer(root+0xf8);
    if(!check(object,144,0)||pointer(object)!=image+0x26bc7a0)return;
    // Confirm the owner still refers to this object immediately before walking it.
    if(root!=pointer(image+0x2ad9c38)||object!=pointer(root+0xf8))return;
    int result=ctr_items_apply(object,check);if(record){record(190,result);if(ctr_items_skipped())record(192,(int32_t)ctr_items_skipped());}
}
