// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
void ctr_roommode_native_map(int);
int runtime_online_mode_in_private(void);
#define ABI
typedef struct {int selector,podium_count;void *podium_order[8],*contact;} CtrNativeThreadContext;
CtrNativeThreadContext *ctr_native_mode_context(void);
int ctr_native_memcmp(const void*,const void*,size_t);
int ctr_native_strcasecmp(const char*,const char*);
const char *ctr_native_strchr(const char*,int);
int runtime_file_stat(const char*,void*);
int ctr_native_snprintf(char*,size_t,const char*,...);
int ctr_native_log(const char*,...);
int ctr_native_flush(void*);
char *ctr_native_strdup(const char*);
void ctr_native_free(void*);
const char *ctr_native_mode_setting(const char*);
void *ctr_native_code_allocate(size_t);
int ctr_native_code_write(void*,const void*,size_t);
int runtime_online_mode_start(unsigned char*,size_t);
int runtime_itemless_start(unsigned char*,size_t);
void runtime_online_mode_adopt(int);
void runtime_online_mode_leave_cup(void);
int runtime_online_mode_private_speed(void);
int runtime_online_mode_private_cup(void);
int runtime_online_mode_in_private(void);
int runtime_speed_race_active(void);
void runtime_speed_mode_set(int);
#define memcpy ctr_memcpy
#define memset ctr_memset
#define memcmp ctr_native_memcmp
#define strcmp ctr_strcmp
#define strncmp ctr_strncmp
#define strlen ctr_strlen
#define strcasecmp ctr_native_strcasecmp
#define strchr ctr_native_strchr
#define snprintf ctr_native_snprintf
#define getenv ctr_native_mode_setting
#define printf ctr_native_log
#define puts ctr_native_log
#define fputs ctr_native_log
#define fflush ctr_native_flush
#define strdup ctr_native_strdup
#define free ctr_native_free
#define stdout ((void*)0)
#define stderr ((void*)0)
