// SPDX-License-Identifier: GPL-2.0-only
// The original PAK size, names, descriptors, offsets and compression tables stay intact.
#include "speed_view.h"
static int equal(const void *a,const void *b,size_t n){const uint8_t *x=a,*y=b;for(size_t i=0;i<n;i++)if(x[i]!=y[i])return 0;return 1;}
static uint32_t u32(const uint8_t *p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint64_t u64(const uint8_t *p){return u32(p)|(uint64_t)u32(p+4)<<32;}
typedef struct {uint64_t bytes;uint32_t count;char guest[128];size_t at;} Header;
static int header(const uint8_t *data,size_t size,Header *out){
    if(!data||size<24||!equal(data,"BBPAK001",8))return -1;
    uint64_t bytes=u64(data+8);uint32_t n=u32(data+16);
    if(!bytes||bytes>8ULL*1024*1024*1024||n<20||n>=128||n>size-24)return -1;
    Header h;ctr_memset(&h,0,sizeof(h));h.bytes=bytes;ctr_memcpy(h.guest,data+20,n);h.at=24+n;h.count=u32(data+20+n);
    if(ctr_strlen(h.guest)!=n)return -1;
    if(!h.count||h.count>CTR_SPEED_RANGES||ctr_strncmp(h.guest,"/app0/archives/",15))return -1;
    const char *p=h.guest+15;size_t len=ctr_strlen(p);
    if(len<5||ctr_strcmp(p+len-4,".pak"))return -1;
    for(size_t i=0;i<len;i++)if(!((p[i]>='a'&&p[i]<='z')||(p[i]>='0'&&p[i]<='9')||p[i]=='_'||p[i]=='.'))return -1;
    if(ctr_strstr(p,".."))return -1;*out=h;return 0;
}
CTR_EXPORT int ctr_speed_view_parse(const uint8_t *normal,size_t a,const uint8_t *speed,size_t b,CtrSpeedView *out){
    if(!out)return -1;Header x,y;
    if(header(normal,a,&x)||header(speed,b,&y)||x.bytes!=y.bytes||x.count!=y.count||ctr_strcmp(x.guest,y.guest))return -1;
    CtrSpeedView next;ctr_memset(&next,0,sizeof(next));next.source_bytes=x.bytes;next.count=x.count;ctr_memcpy(next.guest,x.guest,sizeof(next.guest));
    uint64_t previous=0;
    for(uint32_t i=0;i<x.count;i++){
        if(x.at>a||a-x.at<12||y.at>b||b-y.at<12)return -1;
        uint64_t at=u64(normal+x.at),other=u64(speed+y.at);uint32_t n=u32(normal+x.at+8),m=u32(speed+y.at+8);x.at+=12;y.at+=12;
        if(at!=other||n!=m||!n||n>a-x.at||n>b-y.at||at<previous||at>x.bytes||n>x.bytes-at)return -1;
        next.ranges[i]=(CtrSpeedRange){at,n,normal+x.at,speed+y.at};previous=at+n;x.at+=n;y.at+=n;
    }
    if(x.at!=a||y.at!=b)return -1;*out=next;return 0;
}
CTR_EXPORT int ctr_speed_view_apply(const CtrSpeedView *view,uint64_t at,void *buffer,size_t size){
    if(!view||(!buffer&&size)||view->count>CTR_SPEED_RANGES||at>view->source_bytes||size>view->source_bytes-at)return -1;
    uint8_t *data=buffer;uint64_t end=at+size;
    for(unsigned pass=0;pass<2;pass++)for(uint32_t i=0;i<view->count;i++){
        const CtrSpeedRange *r=&view->ranges[i];
        if(!r->before||!r->after||!r->bytes||r->offset>view->source_bytes||r->bytes>view->source_bytes-r->offset)return -1;
        uint64_t lo=at>r->offset?at:r->offset,stop=r->offset+r->bytes;if(stop>end)stop=end;
        if(lo>=stop)continue;size_t n=(size_t)(stop-lo),dst=(size_t)(lo-at),src=(size_t)(lo-r->offset);
        if(!pass){if(!equal(data+dst,r->before+src,n))return -2;}
        else ctr_memcpy(data+dst,r->after+src,n);
    }
    return 0;
}
