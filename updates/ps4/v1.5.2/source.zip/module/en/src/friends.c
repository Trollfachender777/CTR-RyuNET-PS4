// SPDX-License-Identifier: GPL-2.0-only
// Adapted from OCTR v0.4 runtime_services.c. Identity hashes match PC.
#include "settings.h"
#include "social.h"
typedef struct {char *out;size_t n,cap;int failed;} Json;
static void add(Json *j,const char *text){size_t n=ctr_strlen(text);if(j->n+n>=j->cap){j->failed=1;return;}ctr_memcpy(j->out+j->n,text,n);j->n+=n;j->out[j->n]=0;}
static void number(Json *j,uint64_t n){char rev[24],text[24];size_t c=0;do{rev[c++]=(char)('0'+n%10);n/=10;}while(n);for(size_t i=0;i<c;i++)text[i]=rev[c-i-1];text[c]=0;add(j,text);}
static void user(Json *j,const char *name){add(j,"{\"accountId\":\"");number(j,ctr_pid_for_name(name));add(j,"\",\"onlineId\":\"");add(j,name);add(j,"\"}");}
static void profile(Json *j,const char *name,int self,int presence){
    add(j,"{\"accountId\":\"");number(j,ctr_pid_for_name(name));add(j,"\",\"onlineId\":\"");add(j,name);
    add(j,"\",\"region\":\"US\",\"isOfficiallyVerified\":false,\"user\":");user(j,name);
    add(j,self?",\"relation\":\"me\"":",\"relation\":\"friend\"");
    add(j,",\"aboutMe\":\"Crash Team Racing Nitro-Fueled\",\"languagesUsed\":[\"es\"],\"avatarUrl\":\"\",\"profilePictureUrl\":\"\",\"personalDetail\":{\"displayName\":\"");add(j,name);
    add(j,"\",\"firstName\":\"");add(j,name);add(j,"\",\"middleName\":\"\",\"lastName\":\"\",\"profilePictureUrl\":\"\"}");
    // This is v0.4's local NP compatibility contract, not a server presence query.
    if(presence)add(j,",\"presence\":{\"onlineStatus\":\"online\",\"platform\":\"PS4\",\"incontextInfoList\":[{\"platform\":\"PS4\",\"onlineStatus\":\"online\",\"gameStatus\":\"In Game\",\"gameData\":\"\",\"gameTitleInfo\":{\"npTitleId\":\"CUSA13795_00\",\"titleName\":\"Crash Team Racing Nitro-Fueled\"}}]}");
    add(j,"}");
}
static int route_is(const char *path,const char *name){
    // Query fields such as profilePictureSizes do not identify the endpoint.
    // NP Toolkit asks for them when requesting friendList with presence.
    const char *last=path,*end=path;
    while(*end&&*end!='?'&&*end!='#'){if(*end=='/')last=end+1;end++;}
    size_t n=(size_t)(end-last);return n==ctr_strlen(name)&&!ctr_strncmp(last,name,n);
}
CTR_EXPORT int ctr_friends_json(const char *path,char *out,size_t capacity){
    if(!path||!out||!capacity)return -1;
    int profiles=route_is(path,"profile")||route_is(path,"profiles");
    int ids=route_is(path,"friendOnlineIdLists");
    int friends=route_is(path,"friendList")||route_is(path,"friends");
    if(!profiles&&!ids&&!friends)return 0;
    // Session discovery needs the transport; never invent a friend's session.
    if(route_is(path,"sessions"))return 0;
    CtrSettings s;if(ctr_settings_snapshot(&s))return -1;ctr_social_contacts(&s);Json j={out,0,capacity,0};out[0]=0;
    if(ids){
        add(&j,"{\"friendOnlineIdLists\":[{\"user\":");user(&j,ctr_player_name());add(&j,",\"friendOnlineIdList\":[");
        for(uint32_t i=0;i<s.count;i++){if(i)add(&j,",");add(&j,"\"");add(&j,s.friends[i]);add(&j,"\"");}
        add(&j,"]}]}");
    }else{
        add(&j,profiles?"{\"profiles\":[":"{\"friendList\":[");
        if(profiles)profile(&j,ctr_player_name(),1,0);
        for(uint32_t i=0;i<s.count;i++){if(i||profiles)add(&j,",");profile(&j,s.friends[i],0,!profiles);}
        uint32_t count=s.count+(profiles?1:0);
        add(&j,"],\"size\":");number(&j,count);add(&j,",\"totalResults\":");number(&j,count);add(&j,",\"offset\":0,\"limit\":500,\"start\":0}");
    }
    if(j.failed){out[0]=0;return -1;}return (int)j.n;
}
