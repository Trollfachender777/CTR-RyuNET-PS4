// SPDX-License-Identifier: GPL-2.0-only
#pragma once
typedef struct {const char *p,*end;} Json;
static void ws(Json *j){while(j->p<j->end&&(*j->p==' '||*j->p=='\t'||*j->p=='\r'||*j->p=='\n'))j->p++;}
static int take(Json *j,char c){ws(j);if(j->p==j->end||*j->p!=c)return -1;j->p++;return 0;}
static int hex(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;}
static int string(Json *j,char *out,size_t cap){
    if(take(j,'"'))return -1;size_t n=0;
    while(j->p<j->end){
        unsigned c=(uint8_t)*j->p++;
        if(c=='"'){if(out){if(n>=cap)return -1;out[n]=0;}return 0;}
        if(c<32)return -1;
        if(c=='\\'){
            if(j->p==j->end)return -1;c=(uint8_t)*j->p++;
            if(c=='u'){
                unsigned u=0;for(int i=0;i<4;i++){if(j->p==j->end)return -1;int h=hex(*j->p++);if(h<0)return -1;u=u*16+(unsigned)h;}
                if(u>=0xd800&&u<=0xdbff){
                    if(j->end-j->p<6||j->p[0]!='\\'||j->p[1]!='u')return -1;j->p+=2;
                    unsigned low=0;for(int i=0;i<4;i++){int h=hex(*j->p++);if(h<0)return -1;low=low*16+(unsigned)h;}
                    if(low<0xdc00||low>0xdfff)return -1;u=0x10000+(u-0xd800)*1024+low-0xdc00;
                }else if(u>=0xdc00&&u<=0xdfff)return -1;
                // Only ASCII metadata is displayed. Other text is safely skipped.
                c=u<128?u:'?';
            }else if(c=='n')c='\n';else if(c=='r')c='\r';else if(c=='t')c='\t';else if(c=='b')c='\b';else if(c=='f')c='\f';
            else if(c!='"'&&c!='\\'&&c!='/')return -1;
        }
        if(out){if(!c||n+1>=cap)return -1;out[n++]=(char)c;}
    }return -1;
}
static int literal(Json *j,const char *word){ws(j);size_t n=ctr_strlen(word);if((size_t)(j->end-j->p)<n||ctr_strncmp(j->p,word,n))return -1;j->p+=n;return 0;}
static int number(Json *j){
    ws(j);if(j->p<j->end&&*j->p=='-')j->p++;
    if(j->p==j->end)return -1;
    if(*j->p=='0')j->p++;
    else {if(*j->p<'1'||*j->p>'9')return -1;do{j->p++;}while(j->p<j->end&&*j->p>='0'&&*j->p<='9');}
    if(j->p<j->end&&*j->p=='.'){j->p++;const char *start=j->p;while(j->p<j->end&&*j->p>='0'&&*j->p<='9')j->p++;if(start==j->p)return -1;}
    if(j->p<j->end&&(*j->p=='e'||*j->p=='E')){j->p++;if(j->p<j->end&&(*j->p=='+'||*j->p=='-'))j->p++;const char *start=j->p;while(j->p<j->end&&*j->p>='0'&&*j->p<='9')j->p++;if(start==j->p)return -1;}
    return 0;
}
static int skip(Json *j,int depth){
    if(depth>16)return -1;ws(j);if(j->p==j->end)return -1;
    if(*j->p=='"')return string(j,0,0);
    if(*j->p=='{'||*j->p=='['){
        int object=*j->p=='{';char end=object?'}':']';j->p++;ws(j);
        if(j->p<j->end&&*j->p==end){j->p++;return 0;}
        for(;;){if(object&&(string(j,0,0)||take(j,':')))return -1;if(skip(j,depth+1))return -1;ws(j);if(j->p<j->end&&*j->p==end){j->p++;return 0;}if(take(j,','))return -1;}
    }
    if(*j->p=='t')return literal(j,"true");if(*j->p=='f')return literal(j,"false");if(*j->p=='n')return literal(j,"null");return number(j);
}
static inline int unsigned_id(Json *j,uint64_t *out){
    ws(j);uint64_t v=0;const char *start=j->p;
    while(j->p<j->end&&*j->p>='0'&&*j->p<='9'){unsigned d=(unsigned)(*j->p++-'0');if(v>(UINT64_MAX-d)/10)return -1;v=v*10+d;}
    if(start==j->p||!v||(j->p-start>1&&*start=='0'))return -1;*out=v;return 0;
}
