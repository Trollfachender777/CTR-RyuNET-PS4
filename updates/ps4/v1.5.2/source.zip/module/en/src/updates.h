// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
#define CTR_UPDATE_ENDPOINT "https://api.github.com/repos/Trollfachender777/CTR-RyuNET-PS4/releases/latest"
#define CTR_UPDATE_RELEASES "https://github.com/Trollfachender777/CTR-RyuNET-PS4/releases"
#define CTR_UPDATE_BODY_MAX 65536
#ifndef CTR_PS4_RELEASE_ID
#define CTR_PS4_RELEASE_ID 0ULL
#define CTR_PS4_RELEASE_TAG "v1.5.2"
#define CTR_PS4_RELEASE_DATE "2026-11-01T00:00:00Z"
#endif
enum {CTR_UPDATE_IDLE=0,CTR_UPDATE_BUSY,CTR_UPDATE_CURRENT,CTR_UPDATE_AVAILABLE,CTR_UPDATE_NETWORK,CTR_UPDATE_RATE_LIMIT,CTR_UPDATE_INVALID,CTR_UPDATE_UNAVAILABLE,CTR_UPDATE_NO_RELEASE};
typedef struct {uint64_t id;char tag[81],published[21],url[257];} CtrRelease;
typedef struct {int32_t state,error;CtrRelease release;} CtrUpdateResult;
typedef struct {
    int (*spawn)(void *(*entry)(void*),void *arg);
    int (*fetch)(const char *url,char *out,size_t capacity,size_t *length,int32_t *status);
    uint64_t (*time_us)(void);
} CtrUpdateApi;
CTR_EXPORT int ctr_release_parse(const char *json,size_t length,CtrRelease *out);
CTR_EXPORT int ctr_updates_init(const CtrUpdateApi *api);
CTR_EXPORT int ctr_updates_start(void);
CTR_EXPORT int ctr_updates_snapshot(CtrUpdateResult *out);
void ctr_updates_native_init(void(*trace)(int32_t,int32_t));
