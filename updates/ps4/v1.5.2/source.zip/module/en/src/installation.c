// SPDX-License-Identifier: GPL-2.0-only
#include "installation.h"
static const char key_path[]="/data/ryunet/identity.key";
static const char key_backup[]="/data/ryunet/identity.key.bak";
static char active_header[65];
static void erase(void *data,size_t n){volatile uint8_t *p=data;while(n--)*p++=0;}
static int nibble(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;}
static void hex(const uint8_t in[32],char out[65]){
    const char digits[]="0123456789abcdef";
    for(size_t i=0;i<32;i++){out[i*2]=digits[in[i]>>4];out[i*2+1]=digits[in[i]&15];}out[64]=0;
}
CTR_EXPORT int ctr_identity_parse(uint8_t out[32],const char *text,size_t n){
    if(!out||!text||(n!=64&&n!=65)||(n==65&&text[64]!='\n'))return -1;
    uint8_t key[32];int any=0;
    for(size_t i=0;i<32;i++){int a=nibble(text[i*2]),b=nibble(text[i*2+1]);if(a<0||b<0){erase(key,32);return -1;}key[i]=(uint8_t)((a<<4)|b);any|=key[i];}
    if(!any){erase(key,32);return -1;}
    ctr_memcpy(out,key,32);erase(key,32);return 0;
}
CTR_EXPORT int ctr_identity_derive(const uint8_t key[32],char out[65]){
    if(!key||!out)return -1;
    // Match official OCTR run.py: HMAC-SHA256(raw installation key, lower host).
    static const char host[]="octr.ryu7w7.xyz";
    uint8_t inner[64+sizeof(host)-1],outer[96],digest[32];
    for(size_t i=0;i<64;i++){uint8_t b=i<32?key[i]:0;inner[i]=b^0x36;outer[i]=b^0x5c;}
    ctr_memcpy(inner+64,host,sizeof(host)-1);ctr_sha256(inner,sizeof(inner),digest);
    ctr_memcpy(outer+64,digest,32);ctr_sha256(outer,sizeof(outer),digest);hex(digest,out);
    erase(inner,sizeof(inner));erase(outer,sizeof(outer));erase(digest,32);return 0;
}
static int read_key(const CtrIdentityIo *io,uint8_t key[32]){
    if(!io||!io->read)return -1;
    char text[66];int a=io->read(key_path,text,sizeof(text));
    if(a>=0&&!ctr_identity_parse(key,text,(size_t)a)){erase(text,sizeof(text));return 0;}
    int b=io->read(key_backup,text,sizeof(text));
    int ok=b>=0&&!ctr_identity_parse(key,text,(size_t)b);erase(text,sizeof(text));
    return ok?0:a==-2&&b==-2?-2:-1;
}
CTR_EXPORT int ctr_identity_prepare(const CtrIdentityIo *io,int allow_create){
    uint8_t key[32];int r=read_key(io,key);
    if(r==0){erase(key,32);return 0;}
    if(r!=-2||!allow_create||!io||!io->random||!io->write)return -1;
    if(io->random(key,32)!=0){erase(key,32);return -1;}
    char text[65];hex(key,text);uint8_t checked[32];
    if(ctr_identity_parse(checked,text,64)<0){erase(key,32);erase(text,65);return -1;}
    // Both copies precede profile commit. An interrupted first run has no
    // active owned profile; retries reuse its key instead of changing identity.
    r=io->write(key_backup,"/data/ryunet/identity.key.bak.tmp",text,64,0600);
    if(!r)r=io->write(key_path,"/data/ryunet/identity.key.tmp",text,64,0600);
    erase(key,32);erase(checked,32);erase(text,65);return r;
}
CTR_EXPORT int ctr_identity_activate(const CtrIdentityIo *io,int owned){
    erase(active_header,sizeof(active_header));if(!owned)return 0;
    uint8_t key[32];int r=read_key(io,key);
    if(!r)r=ctr_identity_derive(key,active_header);
    erase(key,32);return r;
}
CTR_EXPORT const char *ctr_identity_header(const char *url){
    if(!url||!active_header[0])return 0;
    static const char root[]="http://octr.ryu7w7.xyz:8080";size_t n=sizeof(root)-1;
    // Exact authority boundary: never send ownership to Sony, lookalike hosts,
    // user-info URLs, HTTPS or another port. The core supplies canonical URLs.
    if(ctr_strncmp(url,root,n)||(url[n]&&url[n]!='/'&&url[n]!='?'))return 0;
    return active_header;
}
