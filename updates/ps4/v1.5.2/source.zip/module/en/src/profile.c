// SPDX-License-Identifier: GPL-2.0-only
#include "profile.h"
static CtrProfile saved;
static int guard;
CTR_EXPORT int ctr_profile_name_valid(const char *name){
    if(!ctr_name_valid(name)||ctr_strlen(name)<3)return 0;
    const char *reserved[]={"ryupc","ryunet","player","jugador","guest"};
    for(size_t i=0;i<sizeof(reserved)/sizeof(reserved[0]);i++)if(ctr_name_equal(name,reserved[i]))return 0;
    return 1;
}
CTR_EXPORT int ctr_profile_parse_record(CtrProfile *out,const char *text,size_t size){
    if(!out||!text||size>128)return -1;
    CtrProfile parsed={{0},0};char *name=parsed.nickname;int version=0,found=0,identity=0;size_t p=0;
    for(size_t i=0;i<size;i++)if(!text[i])return -1;
    while(p<size){
        size_t start=p;while(p<size&&text[p]!='\n')p++;size_t n=p-start;if(p<size)p++;
        if(n&&text[start+n-1]=='\r')n--;
        if(!n||text[start]=='#')continue;
        if(n>63)return -1;char line[64];ctr_memcpy(line,text+start,n);line[n]=0;
        if(!ctr_strcmp(line,"version=1")){if(version)return -1;version=1;}
        else if(!ctr_strcmp(line,"version=2")){if(version)return -1;version=2;}
        else if(!ctr_strcmp(line,"identity=installation")){if(identity)return -1;identity=1;}
        else if(!ctr_strncmp(line,"nickname=",9)){
            if(found||!ctr_profile_name_valid(line+9))return -1;
            ctr_memcpy(name,line+9,ctr_strlen(line+9)+1);found=1;
        }else return -1;
    }
    if(!version||!found||(version==2)!=identity)return -1;parsed.owned=(uint8_t)identity;*out=parsed;return 0;
}
CTR_EXPORT int ctr_profile_parse(char out[17],const char *text,size_t size){
    CtrProfile p;if(!out||ctr_profile_parse_record(&p,text,size))return -1;ctr_memcpy(out,p.nickname,17);return 0;
}
CTR_EXPORT int ctr_profile_format_record(const CtrProfile *p,char *out,size_t capacity){
    if(!p||!ctr_profile_name_valid(p->nickname)||!out||p->owned>1)return -1;
    const char *prefix=p->owned?"version=2\nnickname=":"version=1\nnickname=";
    const char *suffix=p->owned?"\nidentity=installation\n":"\n";
    size_t a=ctr_strlen(prefix),b=ctr_strlen(p->nickname),c=ctr_strlen(suffix);
    if(a+b+c+1>capacity)return -1;ctr_memcpy(out,prefix,a);ctr_memcpy(out+a,p->nickname,b);ctr_memcpy(out+a+b,suffix,c+1);return (int)(a+b+c);
}
CTR_EXPORT int ctr_profile_format(const char *name,char *out,size_t capacity){
    if(!ctr_profile_name_valid(name))return -1;CtrProfile p={{0},0};ctr_memcpy(p.nickname,name,ctr_strlen(name)+1);return ctr_profile_format_record(&p,out,capacity);
}
CTR_EXPORT void ctr_profile_reset(void){ctr_memset(&saved,0,sizeof(saved));__atomic_store_n(&guard,0,__ATOMIC_RELEASE);}
CTR_EXPORT int ctr_profile_publish_record(const CtrProfile *p){
    if(!p||p->owned>1||!ctr_profile_name_valid(p->nickname))return -1;int zero=0;
    if(!__atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return -1;
    saved=*p;__atomic_store_n(&guard,0,__ATOMIC_RELEASE);return 0;
}
CTR_EXPORT int ctr_profile_snapshot_record(CtrProfile *out){
    if(!out)return -1;
    for(int i=0;i<32;i++){int zero=0;if(__atomic_compare_exchange_n(&guard,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED)){
        *out=saved;__atomic_store_n(&guard,0,__ATOMIC_RELEASE);return 0;
    }}return -1;
}
CTR_EXPORT int ctr_profile_publish(const char *name){
    if(!ctr_profile_name_valid(name))return -1;CtrProfile p;
    if(ctr_profile_snapshot_record(&p))return -1;
    ctr_memset(p.nickname,0,17);ctr_memcpy(p.nickname,name,ctr_strlen(name));return ctr_profile_publish_record(&p);
}
CTR_EXPORT int ctr_profile_snapshot(char out[17]){
    CtrProfile p;if(!out||ctr_profile_snapshot_record(&p))return -1;ctr_memcpy(out,p.nickname,17);return 0;
}
