// SPDX-License-Identifier: GPL-2.0-only
static const char *native_menu_nids[]={"aI+OeCz8xrQ","cmo1RIYva9o","9UK1vLZQft4","tn3VlD0hG60","Q2V+iqvjgC0","fZo48un7LK4","JoBqSQt1yyA"};
