// SPDX-License-Identifier: GPL-2.0-only
// OCTR v0.6.5 item_rules.py semantics, applied to checked loaded PS4 tables.
// No local odds setting, bundled game data, filesystem writes or network here.
#include "items.h"
#include "update_json.h"
#include "item_profile.h"
#if defined(_WIN32)
int _fltused=0;
#endif
static const char *names[CTR_ITEM_COUNT]={"Bomb","Missile","Explosive Crate","Beaker",
    "Invincibility Mask","N'Tropy Clock","Turbo Boost","Warp Orb","Power Shield",
    "Triple Bomb","Triple Missile","Super Engine","Invisibility"};
static CtrItemRules accepted;
static int lock,ready,done;
static uint32_t skipped_writes;
static int item(const char *name){for(int i=0;i<CTR_ITEM_COUNT;i++)if(!ctr_strcmp(name,names[i]))return i;return -1;}
static int real(Json *j,float *out){
    ws(j);const char *start=j->p;char quoted[64];Json text;
    if(j->p<j->end&&*j->p=='"'){
        if(string(j,quoted,sizeof(quoted)))return -1;
        text=(Json){quoted,quoted+ctr_strlen(quoted)};ws(&text);start=text.p;
        if(number(&text))return -1;ws(&text);if(text.p!=text.end)return -1;
    }else{
        if(number(j))return -1;text=(Json){start,j->p};
    }
    const char *p=start,*end=text.end;int negative=p<end&&*p=='-';if(negative)p++;
    double value=0.0,scale=1.0;int fraction=0,exponent=0,expnegative=0;
    while(p<end&&*p!='e'&&*p!='E'){
        if(*p=='.'){fraction=1;p++;continue;}
        if(*p<'0'||*p>'9')break;
        value=value*10.0+(*p++-'0');if(fraction)scale*=10.0;
        if(value>1e60||scale>1e60)return -1;
    }
    if(p<end&&(*p=='e'||*p=='E')){
        p++;if(p<end&&(*p=='+'||*p=='-'))expnegative=*p++=='-';
        while(p<end&&*p>='0'&&*p<='9'){exponent=exponent*10+(*p++-'0');if(exponent>60)return -1;}
    }
    value/=scale;while(exponent--)value=expnegative?value/10.0:value*10.0;
    if(negative)value=-value;if(!(value>=-1000000.0&&value<=1000000.0))return -1;
    *out=(float)value;return 0;
}
static int unsigned_number(Json *j,uint64_t *out){
    ws(j);const char *start=j->p;uint64_t n=0;
    while(j->p<j->end&&*j->p>='0'&&*j->p<='9'){
        unsigned d=*j->p++-'0';if(n>(UINT64_MAX-d)/10)return -1;n=n*10+d;
    }
    if(start==j->p||(j->p-start>1&&*start=='0'))return -1;*out=n;return 0;
}
static int table(Json *j,CtrItemRules *r,unsigned at){
    ws(j);if(j->p<j->end&&*j->p=='n')return literal(j,"null");
    if(take(j,'{'))return -1;ws(j);if(j->p<j->end&&*j->p=='}'){j->p++;return 0;}
    unsigned members=0;
    for(;;){
        char name[96];float value;if(++members>128||string(j,name,sizeof(name))||take(j,':')||real(j,&value)||value<0)return -1;
        int key=item(name);
        if(key>=0){uint32_t bit=1U<<key;if(r->masks[at]&bit)return -1;r->masks[at]|=bit;r->values[at][key]=value;r->order[at][r->counts[at]++]=(uint8_t)key;}
        ws(j);if(j->p<j->end&&*j->p=='}'){j->p++;return 0;}if(take(j,','))return -1;
    }
}
static int writes(Json *j,CtrItemRules *r){
    ws(j);if(j->p<j->end&&*j->p=='n')return literal(j,"null");
    if(take(j,'['))return -1;ws(j);if(j->p<j->end&&*j->p==']'){j->p++;return 0;}
    for(;;){
        if(r->write_count==CTR_ITEM_WRITES||take(j,'{'))return -1;
        CtrItemWrite *w=&r->writes[r->write_count];unsigned seen=0;
        for(;;){
            char key[32];unsigned bit=0;if(string(j,key,sizeof(key))||take(j,':'))return -1;
            if(!ctr_strcmp(key,"sha256")){
                bit=1;if(string(j,w->sha256,sizeof(w->sha256))||ctr_strlen(w->sha256)!=64)return -1;
                for(int k=0;k<64;k++)if(hex(w->sha256[k])<0)return -1;
            }else if(!ctr_strcmp(key,"offset")){
                uint64_t n;bit=2;if(unsigned_number(j,&n)||n>UINT32_MAX)return -1;w->offset=(uint32_t)n;
            }else if(!ctr_strcmp(key,"f32")){
                float value;bit=4;if(real(j,&value))return -1;ctr_memcpy(&w->bits,&value,4);
            }else if(!ctr_strcmp(key,"u32")){
                uint64_t n;bit=8;if(unsigned_number(j,&n))return -1;w->bits=(uint32_t)n;
            }else if(skip(j,0))return -1;
            if(bit&&(seen&bit))return -1;seen|=bit;ws(j);
            if(j->p<j->end&&*j->p=='}'){j->p++;break;}if(take(j,','))return -1;
        }
        if((seen!=7&&seen!=11))return -1;r->write_count++;
        ws(j);if(j->p<j->end&&*j->p==']'){j->p++;return 0;}if(take(j,','))return -1;
    }
}
static int rules(Json *j,CtrItemRules *r){
    ws(j);if(j->p<j->end&&*j->p=='n')return literal(j,"null");
    if(take(j,'{'))return -1;ws(j);if(j->p<j->end&&*j->p=='}'){j->p++;return 0;}
    unsigned seen=0;
    for(;;){
        char key[32];unsigned bit=0;if(string(j,key,sizeof(key))||take(j,':'))return -1;
        if(!ctr_strcmp(key,"race")){
            bit=1;ws(j);
            if(j->p<j->end&&*j->p=='n'){if(literal(j,"null"))return -1;}
            else{
                if(take(j,'['))return -1;ws(j);unsigned position=0;
                if(j->p<j->end&&*j->p==']')j->p++;
                else for(;;){
                    if(position==8||table(j,r,position++))return -1;ws(j);
                    if(j->p<j->end&&*j->p==']'){j->p++;break;}if(take(j,','))return -1;
                }
            }
        }else if(!ctr_strcmp(key,"battle")){bit=2;if(table(j,r,8))return -1;}
        else if(!ctr_strcmp(key,"bacon")){bit=4;if(table(j,r,9))return -1;}
        else if(!ctr_strcmp(key,"cooldowns")){bit=8;if(table(j,r,10))return -1;}
        else if(!ctr_strcmp(key,"writes")){bit=16;if(writes(j,r))return -1;}
        else if(skip(j,0))return -1;
        if(bit&&(seen&bit))return -1;seen|=bit;ws(j);
        if(j->p<j->end&&*j->p=='}'){j->p++;return 0;}if(take(j,','))return -1;
    }
}
CTR_EXPORT int ctr_items_parse(const char *body,size_t size,CtrItemRules *out){
    if(!body||!out||!size||size>=CTR_ITEM_BODY_MAX)return -1;
    for(size_t i=0;i<size;i++)if(!body[i])return -1;
    CtrItemRules next;ctr_memset(&next,0,sizeof(next));Json j={body,body+size};int seen=0;
    if(take(&j,'{'))return -1;ws(&j);
    if(j.p<j.end&&*j.p=='}')j.p++;
    else for(;;){
        char key[64];if(string(&j,key,sizeof(key))||take(&j,':'))return -1;
        if(!ctr_strcmp(key,"items")){if(seen++||rules(&j,&next))return -1;}
        else if(skip(&j,0))return -1;
        ws(&j);if(j.p<j.end&&*j.p=='}'){j.p++;break;}if(take(&j,','))return -1;
    }
    ws(&j);if(j.p!=j.end)return -1;*out=next;return 0;
}
CTR_EXPORT void ctr_items_reset(void){ready=done=0;skipped_writes=0;ctr_memset(&accepted,0,sizeof(accepted));__atomic_store_n(&lock,0,__ATOMIC_RELEASE);}
CTR_EXPORT uint32_t ctr_items_skipped(void){return __atomic_load_n(&skipped_writes,__ATOMIC_ACQUIRE);}
CTR_EXPORT int ctr_items_accept(const char *body,size_t size){
    // Like the PC launcher: one rules snapshot per launch, not changing during a race.
    if(__atomic_load_n(&ready,__ATOMIC_ACQUIRE))return 0;
    CtrItemRules next;if(ctr_items_parse(body,size,&next))return -1;
    int zero=0;if(!__atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return -1;
    if(!ready){accepted=next;__atomic_store_n(&ready,1,__ATOMIC_RELEASE);}
    __atomic_store_n(&lock,0,__ATOMIC_RELEASE);return 0;
}
CTR_EXPORT int ctr_items_pending(void){
    if(!__atomic_load_n(&ready,__ATOMIC_ACQUIRE)||__atomic_load_n(&done,__ATOMIC_ACQUIRE))return 0;
    if(accepted.write_count)return 1;for(unsigned i=0;i<CTR_ITEM_TABLES;i++)if(accepted.masks[i])return 1;return 0;
}
typedef struct {uint64_t table,keys,values;uint32_t slots,count;uint32_t key[64],value[64];} Table;
typedef struct {uint64_t address;uint32_t before,after;} Write;
static uint32_t u32(uint64_t p){uint32_t v;ctr_memcpy(&v,(void*)p,4);return v;}
static uint64_t u64(uint64_t p){uint64_t v;ctr_memcpy(&v,(void*)p,8);return v;}
static int load_table(uint64_t address,unsigned step,Table *t,CtrItemCheck check){
    if(!check(address,64,0))return -1;
    uint32_t bytes=u32(address+0x20),values=u32(address+0x10);
    if(!bytes||bytes%4||bytes>256||values!=bytes/4*step)return -1;
    uint64_t k=u64(address+0x28),v=u64(address+0x18);unsigned slots=bytes/4;
    if(!check(k,bytes,step==4)||!check(v,values,step==4)||!check(address+0x30,4,step==4))return -1;
    t->table=address;t->keys=k;t->values=v;t->slots=slots;t->count=u32(address+0x30);if(t->count>slots)return -1;
    for(unsigned i=0;i<slots;i++){t->key[i]=u32(k+i*4);if(step==4)t->value[i]=u32(v+i*4);}
    return 0;
}
static uint64_t lookup(const Table *t,uint32_t key,unsigned step){for(unsigned i=0;i<t->slots;i++)if(t->key[i]==key)return t->values+(uint64_t)i*step;return 0;}
static int load_list(uint64_t root,uint32_t mode,uint64_t *out,unsigned count,CtrItemCheck check){
    Table modes;if(load_table(root,8,&modes,check))return -1;
    uint64_t at=lookup(&modes,mode,8);if(!at)return -1;
    uint64_t list=u64(at);if(!check(list,40,0)||u32(list+0x10)<count||u32(list+0x10)>64)return -1;
    uint64_t refs=u64(list+0x20);if(!check(refs,count*8,0))return -1;
    for(unsigned i=0;i<count;i++)out[i]=u64(refs+i*8);return 0;
}
static int queue(Write *out,unsigned *n,uint64_t address,uint32_t value,CtrItemCheck check){
    if(!check(address,4,1)||*n>=1600)return -1;
    for(unsigned i=0;i<*n;i++)if(out[i].address==address){out[i].after=value;return 0;}
    if(u32(address)!=value){out[*n]=(Write){address,u32(address),value};(*n)++;}return 0;
}
CTR_EXPORT int ctr_items_apply(uint64_t object,CtrItemCheck check){
    if(!check||!ctr_items_pending())return 0;
    int zero=0;if(!__atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return -1;
    Table tables[CTR_ITEM_TABLES];uint64_t addresses[CTR_ITEM_TABLES];Write plan[1600];unsigned count=0;int result=-2;
    if(!check(object,144,0))goto finish;
    uint64_t root=u64(object+0x18);
    if(load_list(root,1,addresses,8,check)||load_list(root,9,addresses+8,1,check)||load_list(root,12,addresses+9,1,check))goto finish;
    addresses[10]=u64(object+0x20);
    int contiguous=object>=CTR_ITEM_ROOT_OFFSET;uint64_t data=object-CTR_ITEM_ROOT_OFFSET;
    for(unsigned t=0;t<CTR_ITEM_TABLES;t++){
        if(load_table(addresses[t],4,&tables[t],check))goto finish;
        Table *table=&tables[t];if(table->table!=data+ctr_item_layout[t].table||table->keys!=data+ctr_item_layout[t].keys||table->values!=data+ctr_item_layout[t].values)contiguous=0;
        uint32_t keys[64],values[64];ctr_memcpy(keys,table->key,sizeof(keys));ctr_memcpy(values,table->value,sizeof(values));unsigned added=0;
        for(unsigned next=0;next<accepted.counts[t];next++){
            unsigned k=accepted.order[t][next];
            unsigned slot=0;while(slot<table->slots&&keys[slot]!=k)slot++;
            if(slot==table->slots){
                if(t==10||accepted.values[t][k]==0)continue;
                slot=0;while(slot<table->slots&&keys[slot]!=UINT32_MAX)slot++;if(slot==table->slots)continue;
                keys[slot]=k;added++;
            }
            ctr_memcpy(values+slot,&accepted.values[t][k],4);
        }
        for(unsigned i=0;i<table->slots;i++){
            if(queue(plan,&count,table->keys+i*4,keys[i],check)||queue(plan,&count,table->values+i*4,values[i],check))goto finish;
        }
        if(queue(plan,&count,table->table+0x30,table->count+added,check))goto finish;
    }
    unsigned skipped=0;
    for(unsigned i=0;i<accepted.write_count;i++){
        CtrItemWrite *w=&accepted.writes[i];uint32_t o=w->offset;
        if(ctr_strcmp(w->sha256,CTR_ITEM_ENTRY_SHA256)||!contiguous||o%4||o>CTR_ITEM_DATA_SIZE-4||
           !(ctr_item_scalar_allowed[o/32]&(1U<<((o/4)%8)))){skipped++;continue;}
        if(queue(plan,&count,data+o,w->bits,check))goto finish;
    }
    // All reads and destinations are checked before the first four-byte write.
    for(unsigned i=0;i<count;i++)if(!check(plan[i].address,4,1)||u32(plan[i].address)!=plan[i].before)goto finish;
    for(unsigned i=0;i<count;i++)__atomic_store_n((uint32_t*)plan[i].address,plan[i].after,__ATOMIC_RELEASE);
    __atomic_store_n(&skipped_writes,skipped,__ATOMIC_RELEASE);
    __atomic_store_n(&done,1,__ATOMIC_RELEASE);result=(int)count;
finish:
    __atomic_store_n(&lock,0,__ATOMIC_RELEASE);return result;
}
