// SPDX-License-Identifier: GPL-2.0-only
// RyuNET v0.5.3 wire protocol, adapted from runtime_net_tunnel.{c,h} at
// d5be87dc0b9be6d947bc27654c0ee596e0eb93d3. Caller serializes state access.
#pragma once
#include "online_core.h"
#define CTR_TUN_HEADER 13u
#define CTR_TUN_PAYLOAD 2048u
CTR_EXPORT void ctr_tun_reset(void);
CTR_EXPORT int ctr_tun_candidate(uint32_t,uint32_t);
CTR_EXPORT int ctr_tun_send(uint32_t,uint16_t,uint64_t,uint8_t*);
CTR_EXPORT void ctr_tun_direct(uint32_t,uint16_t,uint64_t);
CTR_EXPORT void ctr_tun_received(uint32_t,uint16_t,uint8_t,uint64_t);
CTR_EXPORT int ctr_tun_keepalive(uint64_t);
CTR_EXPORT size_t ctr_tun_wrap(uint8_t*,size_t,uint8_t,uint32_t,uint16_t,const void*,size_t);
CTR_EXPORT int ctr_tun_unwrap(const uint8_t*,size_t,uint8_t*,uint32_t*,uint16_t*);

