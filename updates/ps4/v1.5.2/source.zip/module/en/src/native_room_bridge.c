// SPDX-License-Identifier: GPL-2.0-only
#include "native_menu.h"
#include "room_mode.h"
#include "speed_view.h"
void ctr_native_room_chosen(int speed,int private){ctr_roommode_native_choose(speed,private);}
void runtime_speed_mode_set(int enabled){ctr_roommode_native_requested(enabled);}
int runtime_speed_race_active(void){return __atomic_load_n(&ctr_speed_active,__ATOMIC_ACQUIRE)!=0;}
int ctr_itemless_assets_ready(void){return ctr_native_menu_ready()&&ctr_speed_assets_ready();}
