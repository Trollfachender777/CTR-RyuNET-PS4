// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
enum {CTR_ROOM_NONE,CTR_ROOM_HOST,CTR_ROOM_GUEST};
typedef struct {
    int (*spawn)(void*(*)(void*),void*);
    int (*request)(const char*,const char*,char*,size_t);
    uint64_t (*time_us)(void);
    int (*private_now)(void);
    int (*assets_ready)(void);
    int (*peer_recent)(void);
} CtrRoomApi;
typedef struct {
    int32_t role,selected,following,confirmed,available,active,status;
    uint32_t generation;
    char host[17];
} CtrRoomView;
CTR_EXPORT int ctr_roommode_init(const CtrRoomApi*);
CTR_EXPORT void ctr_roommode_hosting(void);
CTR_EXPORT void ctr_roommode_joined(const char*);
CTR_EXPORT void ctr_roommode_left(void);
CTR_EXPORT int ctr_roommode_choose(int);
CTR_EXPORT void ctr_roommode_tick(void);
CTR_EXPORT int ctr_roommode_snapshot(CtrRoomView*);
CTR_EXPORT int ctr_roommode_parse(const char*,size_t,int*);
CTR_EXPORT void ctr_roommode_native_choose(int,int);
CTR_EXPORT void ctr_roommode_native_requested(int);
CTR_EXPORT void ctr_roommode_on_leave(void(*)(void));
CTR_EXPORT void ctr_roommode_set_trace(void(*)(int32_t,int32_t));
CTR_EXPORT void ctr_roommode_native_map(int);
// Updated on the game input path; archive reads and the seasonal hook agree.
extern int32_t ctr_speed_active;
