// SPDX-License-Identifier: GPL-2.0-only
#include "net_tunnel.h"
typedef struct {
    uint32_t ip;uint16_t port;int used,peer_ok,answered;
    uint64_t first_send,last_use,last_direct;
} Peer;
static Peer peers[64];
static uint64_t keepalive_at;
static int keepalive_started;
CTR_EXPORT void ctr_tun_reset(void){ctr_memset(peers,0,sizeof(peers));keepalive_at=0;keepalive_started=0;}
static uint64_t elapsed(uint64_t now,uint64_t before){return now>=before?now-before:UINT64_MAX;}
CTR_EXPORT int ctr_tun_candidate(uint32_t ip,uint32_t server){
    const uint8_t *b=(const uint8_t*)&ip;
    if(ip==server||!ip||ip==UINT32_MAX||b[0]==10||b[0]==127||!b[0]||b[0]>=224)return 0;
    if(b[0]==172&&(b[1]&0xf0)==16)return 0;
    if(b[0]==192&&b[1]==168)return 0;
    if(b[0]==169&&b[1]==254)return 0;
    if(b[0]==100&&(b[1]&0xc0)==64)return 0;
    return 1;
}
static Peer *find(uint32_t ip,uint16_t port,uint64_t now,int create){
    Peer *free_slot=0,*oldest=0;
    for(size_t i=0;i<64;i++){
        Peer *p=&peers[i];
        if(p->used&&p->ip==ip&&p->port==port)return p;
        if(!p->used||elapsed(now,p->last_use)>60000){if(!free_slot)free_slot=p;}
        else if(!oldest||p->last_use<oldest->last_use)oldest=p;
    }
    if(!create)return 0;
    Peer *p=free_slot?free_slot:oldest;
    ctr_memset(p,0,sizeof(*p));p->ip=ip;p->port=port;p->used=1;p->first_send=p->last_use=now;return p;
}
CTR_EXPORT int ctr_tun_send(uint32_t ip,uint16_t port,uint64_t now,uint8_t *flags){
    if(!flags||!port)return 0;
    Peer *p=find(ip,port,now,1);p->last_use=now;
    int fresh=p->last_direct&&elapsed(now,p->last_direct)<3000;
    *flags=fresh?1:0;
    return !(fresh&&p->peer_ok)&& (p->answered||elapsed(now,p->first_send)<=20000);
}
CTR_EXPORT void ctr_tun_direct(uint32_t ip,uint16_t port,uint64_t now){
    Peer *p=find(ip,port,now,0);if(p){p->last_direct=now;p->last_use=now;}
}
CTR_EXPORT void ctr_tun_received(uint32_t ip,uint16_t port,uint8_t flags,uint64_t now){
    Peer *p=find(ip,port,now,1);p->peer_ok=flags&1;p->answered=1;p->last_use=now;
}
CTR_EXPORT int ctr_tun_keepalive(uint64_t now){
    if(keepalive_started&&elapsed(now,keepalive_at)<15000)return 0;
    keepalive_at=now;keepalive_started=1;return 1;
}
CTR_EXPORT size_t ctr_tun_wrap(uint8_t *out,size_t cap,uint8_t flags,uint32_t ip,uint16_t port,const void *data,size_t n){
    if(!out||(!data&&n)||n>CTR_TUN_PAYLOAD||cap<CTR_TUN_HEADER||n>cap-CTR_TUN_HEADER||!port)return 0;
    ctr_memcpy(out,"RYUTN1",6);out[6]=flags;ctr_memcpy(out+7,&ip,4);
    out[11]=(uint8_t)(port>>8);out[12]=(uint8_t)port;
    if(n)ctr_memcpy(out+CTR_TUN_HEADER,data,n);return n+CTR_TUN_HEADER;
}
CTR_EXPORT int ctr_tun_unwrap(const uint8_t *in,size_t n,uint8_t *flags,uint32_t *ip,uint16_t *port){
    if(!in||!flags||!ip||!port||n<CTR_TUN_HEADER||n>CTR_TUN_HEADER+CTR_TUN_PAYLOAD)return 0;
    for(size_t i=0;i<6;i++)if(in[i]!=(uint8_t)"RYUTN1"[i])return 0;
    *flags=in[6];ctr_memcpy(ip,in+7,4);*port=(uint16_t)((uint16_t)in[11]<<8|in[12]);return *port!=0;
}

