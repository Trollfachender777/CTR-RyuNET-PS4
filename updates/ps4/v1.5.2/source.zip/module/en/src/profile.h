// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "settings.h"
typedef struct {char nickname[17];uint8_t owned;} CtrProfile;
CTR_EXPORT int ctr_profile_parse_record(CtrProfile*,const char*,size_t);
CTR_EXPORT int ctr_profile_format_record(const CtrProfile*,char*,size_t);
CTR_EXPORT int ctr_profile_publish_record(const CtrProfile*);
CTR_EXPORT int ctr_profile_snapshot_record(CtrProfile*);
CTR_EXPORT int ctr_profile_name_valid(const char *name);
CTR_EXPORT int ctr_profile_parse(char out[17],const char *text,size_t size);
CTR_EXPORT int ctr_profile_format(const char *name,char *out,size_t capacity);
CTR_EXPORT void ctr_profile_reset(void);
CTR_EXPORT int ctr_profile_publish(const char *name);
CTR_EXPORT int ctr_profile_snapshot(char out[17]);
int ctr_native_profile_load(CtrProfile*);
int ctr_native_profile_scope(int32_t user);
