// SPDX-License-Identifier: GPL-2.0-only
// Loaded explicitly by the integrated game after its original NetCtlInit.
// No automatic plugin startup, CRT dependency, workers, joins or memory scanning.
#include "online_core.h"
#include "native_assets.h"
#include "profile.h"
#include "installation.h"
#define COUNT(a) (sizeof(a)/sizeof((a)[0]))
extern int64_t ctr_syscall(int64_t,...);
extern int ctr_ui_initialize(uint64_t,const void*,int32_t,void(*)(int32_t,int32_t),int32_t(*)(uint16_t));
extern int ctr_network_install(uint64_t,const void*,void(*)(int32_t,int32_t));
typedef struct {uint64_t address;uint32_t size;int32_t protection;} NativeSegment;
typedef struct {uint64_t size;char name[256];NativeSegment segments[4];uint32_t segment_count;uint8_t fingerprint[20];} NativeModule;
_Static_assert(sizeof(NativeModule)==352,"PS4 module-info ABI");
typedef struct {uint64_t marker_rva,cache_rva;uint32_t slot_count;uint8_t marker[64];uint64_t base;int ready;} PortProfile;
typedef struct {int module;uint64_t original_got,cache,original_plt;const char *name;} PortImport;
#include "native_profiles.h"
static int active,refreshing,initializing;
static int ui_pending,ui_busy;
static uint32_t ui_poll;
static int32_t native_user=-1;
static void refresh_ui(void);
static NativeModule modules[2];
static uint32_t log_count;

static void write_log(const char *text){
    if(log_count++>2048)return;
    int64_t fd=ctr_syscall(5,"/data/GoldHEN/ctr_native_port.log",0x209,0666);
    if(fd<0)fd=ctr_syscall(5,"/temp0/ctr_native_port.log",0x209,0666);
    if(fd>=0){ctr_syscall(4,fd,text,ctr_strlen(text));ctr_syscall(6,fd);}
}
static void record(int32_t stage,int32_t code){
    char line[]="CTR native stage=00000000 code=00000000\n";
    const char hex[]="0123456789abcdef";
    for(int i=0;i<8;i++){line[17+i]=hex[((uint32_t)stage>>((7-i)*4))&15];line[31+i]=hex[((uint32_t)code>>((7-i)*4))&15];}
    write_log(line);
}
static int contains(const NativeModule *module,uint64_t address,size_t length,int writing){
    if(!address||address>=0x800000000000ULL||length>0x10000000)return 0;
    if(module->segment_count>4)return 0;
    for(uint32_t i=0;i<module->segment_count;i++){
        const NativeSegment *s=&module->segments[i];
        if(writing && !(s->protection&2))continue;
        if(address>=s->address && address-s->address<=s->size && length<=s->size-(address-s->address))return 1;
    }return 0;
}
static int matches(int index,const NativeModule *module){
    if(!module->segment_count||module->segment_count>4)return 0;
    uint64_t base=module->segments[0].address;PortProfile *p=&profiles[index];
    if(!contains(module,base+p->marker_rva,64,0)||!contains(module,base+p->cache_rva,(size_t)p->slot_count*8,1))return 0;
    const uint8_t *actual=(const uint8_t*)(base+p->marker_rva);
    for(size_t i=0;i<64;i++)if(actual[i]!=p->marker[i])return 0;
    return 1;
}
static void fill_profile(int index,const NativeModule *module){
    PortProfile *p=&profiles[index];if(p->ready || !matches(index,module))return;
    modules[index]=*module;p->base=module->segments[0].address;
    int filled=0;
    // All writes target the explicit, zero-filled port slots in this package.
    for(size_t i=0;i<COUNT(imports);i++){
        const PortImport *r=&imports[i];if(r->module!=index)continue;
        void *fn=ctr_find_hook(r->name);if(!fn)continue;
        if(!contains(module,p->base+r->cache,8,1))continue;
        uint64_t *slot=(uint64_t*)(p->base+r->cache);
        if(*slot && *slot!=(uint64_t)fn)continue;
        __atomic_store_n(slot,(uint64_t)fn,__ATOMIC_RELEASE);filled++;
    }
    p->ready=1;record(10+index,filled);
}
static void refresh_modules(void){
    if(profiles[0].ready && profiles[1].ready){refresh_ui();return;}
    int zero=0;if(!__atomic_compare_exchange_n(&refreshing,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return;
    int32_t handles[256];uint64_t count=0;
    int64_t r=ctr_syscall(592,handles,COUNT(handles),&count);
    if(r==0 && count<=COUNT(handles)){
        for(uint64_t i=0;i<count;i++){
            NativeModule info;ctr_memset(&info,0,sizeof(info));info.size=sizeof(info);
            if(ctr_syscall(593,handles[i],&info)!=0)continue;
            if(!profiles[0].ready)fill_profile(0,&info);
            if(profiles[0].ready && !profiles[1].ready)fill_profile(1,&info);
        }
    }
    __atomic_store_n(&refreshing,0,__ATOMIC_RELEASE);
    refresh_ui();
}
static void *original(const char *name){
    for(size_t i=0;i<COUNT(imports);i++){
        const PortImport *r=&imports[i];PortProfile *p=&profiles[r->module];
        if(!p->base || ctr_strcmp(name,r->name))continue;
        uint64_t address=p->base+r->original_got;
        if(!contains(&modules[r->module],address,8,0))continue;
        uint64_t ptr=*(volatile uint64_t*)address;
        if(ptr>=p->base+r->original_plt && ptr<p->base+r->original_plt+6)continue;
        if(ptr && ptr<0x800000000000ULL)return (void*)ptr;
    }return 0;
}
static int32_t native_resolve(int32_t id,const char *host,void *out,int32_t timeout,int32_t retry,int32_t flags){void *p=original("sceNetResolverStartNtoa");return p?((int32_t(*)(int32_t,const char*,void*,int32_t,int32_t,int32_t))p)(id,host,out,timeout,retry,flags):-1;}
static int32_t native_conn(int32_t id,const char *url,int32_t keep){void *p=original("sceHttpCreateConnectionWithURL");return p?((int32_t(*)(int32_t,const char*,int32_t))p)(id,url,keep):-1;}
static int32_t (*add_header)(int32_t,const char*,const char*,int32_t);
static int32_t (*delete_request)(int32_t);
static void *optional_symbol(const char *name,const char *nid){
    int32_t handles[256];uint64_t count=0;
    if(ctr_syscall(592,handles,COUNT(handles),&count)||count>COUNT(handles))return 0;
    for(uint64_t i=0;i<count;i++){
        void *result=0;
        if(!ctr_syscall(591,handles[i],name,&result)&&result)return result;
        if(!ctr_syscall(591,handles[i],nid,&result)&&result)return result;
    }return 0;
}
static int ownership_ready(const char *url){
    if(!ctr_identity_header(url))return 1;
    if(!add_header)add_header=(__typeof__(add_header))optional_symbol("sceHttpAddRequestHeader","EY28T2bkN7k");
    if(!delete_request)delete_request=(__typeof__(delete_request))optional_symbol("sceHttpDeleteRequest","qe7oZ+v4PWA");
    if(!add_header||!delete_request){record(173,-1);return 0;}return 1;
}
static int32_t own_request(int32_t id,const char *url){
    const char *key=ctr_identity_header(url);if(id<0||!key)return id;
    int32_t r=add_header(id,"X-RyuNET-Key",key,0);record(173,r);
    if(r<0){delete_request(id);return r;}return id;
}
static int32_t native_req(int32_t id,int32_t method,const char *url,uint64_t size){
    void *p=original("sceHttpCreateRequestWithURL");
    if(!p||!ownership_ready(url))return -1;
    return own_request(((int32_t(*)(int32_t,int32_t,const char*,uint64_t))p)(id,method,url,size),url);
}
static int32_t native_req2(int32_t id,const char *method,const char *url,uint64_t size){
    void *p=original("sceHttpCreateRequestWithURL2");
    if(!p||!ownership_ready(url))return -1;
    return own_request(((int32_t(*)(int32_t,const char*,const char*,uint64_t))p)(id,method,url,size),url);
}
static int32_t native_status(int32_t id,int32_t *status){void *p=original("sceHttpGetStatusCode");return p?((int32_t(*)(int32_t,int32_t*))p)(id,status):-1;}
static int32_t native_sysmodule(uint16_t id){void *p=original("sceSysmoduleLoadModule");int32_t r=p?((int32_t(*)(uint16_t))p)(id):-1;__atomic_store_n(&ui_poll,119,__ATOMIC_RELAXED);return r;}
static void refresh_ui(void){
    if(!active||!__atomic_load_n(&ui_pending,__ATOMIC_ACQUIRE))return;
    if(__atomic_fetch_add(&ui_poll,1,__ATOMIC_RELAXED)%120!=119)return;
    int zero=0;if(!__atomic_compare_exchange_n(&ui_busy,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return;
    int r=ctr_ui_initialize(profiles[0].base,&modules[0],native_user,record,native_sysmodule);record(49,r);
    if(r==0||(r!=-3&&r!=-4))__atomic_store_n(&ui_pending,0,__ATOMIC_RELEASE);
    __atomic_store_n(&ui_busy,0,__ATOMIC_RELEASE);
}
CTR_EXPORT int32_t ctr_initialize(void){
    if(active)return 0;
    int zero=0;if(!__atomic_compare_exchange_n(&initializing,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return 0;
    if(!ctr_assets_boot_source()){
        int32_t previous=0;
        if(ctr_assets_migration(&previous)){__atomic_store_n(&initializing,0,__ATOMIC_RELEASE);return previous;}
        write_log("RyuNET native UI assets missing; complete update PKG required. New routing not installed.\n");
        __atomic_store_n(&initializing,0,__ATOMIC_RELEASE);return -100;
    }
    write_log("CTR RyuNET native port: explicit initialization after NetCtlInit\n");
    write_log("CTR native settings revision=PS4-v1.5.2-native-r1-update-bundle\n");
    CtrNativeApi api={native_resolve,native_conn,native_req,native_req2,native_status,native_sysmodule,refresh_modules,record};
    // Start offline while resolving the real local user. No shared nickname
    // can authenticate during discovery, and no PSN account ID is used as name.
    if(ctr_core_init(&api,"RyuNET")!=0){__atomic_store_n(&initializing,0,__ATOMIC_RELEASE);return -1;}
    ctr_core_set_online(0);
    refresh_modules();
    if(!profiles[0].ready){write_log("Native image marker unavailable; routing remains inactive\n");__atomic_store_n(&initializing,0,__ATOMIC_RELEASE);return -1;}
    void *get_user=original("sceUserServiceGetInitialUser");
    int32_t user=-1;
    if(get_user){if(((int32_t(*)(int32_t*))get_user)(&user)==0)ctr_core_set_user(user);}
    CtrProfile identity;int profile=user<0?-1:ctr_native_profile_scope(user);
    if(!profile)profile=ctr_native_profile_load(&identity);record(110,profile);
    if(!profile){
        if(ctr_core_init(&api,identity.nickname)!=0){__atomic_store_n(&initializing,0,__ATOMIC_RELEASE);return -1;}
        ctr_profile_publish_record(&identity);ctr_core_set_user(user);
    }
    record(150,ctr_network_install(profiles[0].base,&modules[0],record));
    native_user=user;active=1;ui_pending=1;ui_poll=119;refresh_ui();
    __atomic_store_n(&initializing,0,__ATOMIC_RELEASE);write_log("Native routing ready; online session still requires game verification\n");return 0;
}
__attribute__((visibility("hidden"))) int module_start(size_t args,const void *data){(void)args;(void)data;return 0;}
__attribute__((visibility("hidden"))) int module_stop(size_t args,const void *data){(void)args;(void)data;return 0;}
