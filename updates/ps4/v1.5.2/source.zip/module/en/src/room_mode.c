// SPDX-License-Identifier: GPL-2.0-only
// OCTR 0.7.2 room-mode HTTP contract, adapted to bounded Orbis workers.
// No files, identities, saves, blocking UI waits or public Speed matchmaking.
#include "room_mode.h"
#include "settings.h"
static CtrRoomApi api;
static CtrRoomView view;
static int gate,busy,ready,last_private,publish;
static uint64_t next_request;
static int native_choice,native_known,native_private,native_requested;
// 0: no map boundary yet; 1: non-private map; 2: private map loading/running.
// The native loader supplies this before archive reads, not a UDP-port guess.
static int map_context;
static void(*leave_callback)(void);
static int leave_pending;
static void(*room_trace)(int32_t,int32_t);
static unsigned trace_count,last_trace_state;
static void diagnostic(int stage,int value){if(room_trace&&__atomic_fetch_add(&trace_count,1,__ATOMIC_RELAXED)<64)room_trace(stage,value);}
CTR_EXPORT void ctr_roommode_set_trace(void(*record)(int32_t,int32_t)){room_trace=record;trace_count=0;last_trace_state=~0U;diagnostic(223,ready);}
int32_t ctr_speed_active;
typedef struct {uint32_t generation;int role,mode;char host[17];} Task;
static Task task;
static int enter(void){int zero=0;return __atomic_compare_exchange_n(&gate,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED);}
static void leave(void){__atomic_store_n(&gate,0,__ATOMIC_RELEASE);}
static int name_ok(const char *name){return name&&ctr_strlen(name)>=3&&ctr_name_valid(name);}
static void inactive(void){__atomic_store_n(&ctr_speed_active,0,__ATOMIC_RELEASE);view.active=0;}
static void invalidate(void){view.generation++;view.confirmed=0;view.status=0;next_request=0;inactive();}
CTR_EXPORT int ctr_roommode_parse(const char *data,size_t size,int *mode){
    if(!data||!mode||!size||size>127)return -1;
    for(size_t i=0;i<size;i++)if(!data[i])return -1;
    size_t a=0,b=size;
    while(a<b&&(data[a]==' '||data[a]=='\r'||data[a]=='\n'||data[a]=='\t'))a++;
    while(b>a&&(data[b-1]==' '||data[b-1]=='\r'||data[b-1]=='\n'||data[b-1]=='\t'))b--;
    if(b-a==10&&!ctr_strncmp(data+a,"mode speed",10)){*mode=1;return 0;}
    if(b-a==11&&!ctr_strncmp(data+a,"mode normal",11)){*mode=0;return 0;}
    return -1;
}
static void *worker(void *unused){
    (void)unused;Task current=task;char target[128],body[128];size_t n=0;
    const char *prefix=current.role==CTR_ROOM_HOST?"/ryunet/room-mode?name=":"/ryunet/room-mode?host=";
    ctr_memcpy(target,prefix,ctr_strlen(prefix)+1);n=ctr_strlen(prefix);
    ctr_memcpy(target+n,current.host,ctr_strlen(current.host)+1);n+=ctr_strlen(current.host);
    if(current.role==CTR_ROOM_HOST){const char *mode=current.mode?"&mode=speed":"&mode=normal";ctr_memcpy(target+n,mode,ctr_strlen(mode)+1);n+=ctr_strlen(mode);}
    ctr_memcpy(target+n,"&format=text",13);body[0]=0;body[127]=0;
    int status=api.request(current.role==CTR_ROOM_HOST?"POST":"GET",target,body,sizeof(body));
    size_t length=0;while(length<sizeof(body)&&body[length])length++;
    int mode=current.mode,valid=status==200&&(current.role==CTR_ROOM_HOST||!ctr_roommode_parse(body,length,&mode));
    diagnostic(224,(current.role<<16)|(status&0xffff)|(valid?0x1000000:0));
    // A stale response never changes a newer room, mode choice or public visit.
    if(enter()){
        if(current.generation==view.generation&&current.role==view.role&&!ctr_strcmp(current.host,view.host)){
            view.status=status;
            if(valid){view.confirmed=mode;view.following=current.role==CTR_ROOM_GUEST;publish=0;}
            next_request=api.time_us()+2000000ULL;
        }
        leave();
    }
    __atomic_store_n(&busy,0,__ATOMIC_RELEASE);return 0;
}
CTR_EXPORT int ctr_roommode_init(const CtrRoomApi *platform){
    if(__atomic_load_n(&busy,__ATOMIC_ACQUIRE))return -1;
    ready=0;room_trace=0;ctr_memset(&api,0,sizeof(api));ctr_memset(&view,0,sizeof(view));next_request=0;publish=0;last_private=0;ctr_speed_active=0;native_choice=native_known=native_private=native_requested=leave_pending=map_context=0;
    if(!platform){leave_callback=0;return 0;}
    if(!platform->spawn||!platform->request||!platform->time_us||!platform->private_now||!platform->assets_ready||!platform->peer_recent)return -1;
    api=*platform;ready=1;return 0;
}
CTR_EXPORT void ctr_roommode_hosting(void){
    if(!enter())return;invalidate();__atomic_store_n(&map_context,0,__ATOMIC_RELEASE);view.role=CTR_ROOM_HOST;view.following=0;
    const char *me=ctr_player_name();ctr_memset(view.host,0,sizeof(view.host));
    if(name_ok(me))ctr_memcpy(view.host,me,ctr_strlen(me)+1);else view.role=CTR_ROOM_NONE;
    publish=1;leave();
}
CTR_EXPORT void ctr_roommode_joined(const char *id){
    const char prefix[]="cusa13795-session-";
    if(!id||ctr_strncmp(id,prefix,sizeof(prefix)-1))return;
    const char *host=id+sizeof(prefix)-1;
    if(!name_ok(host)||ctr_name_equal(host,ctr_player_name()))return;
    if(!enter())return;invalidate();__atomic_store_n(&map_context,0,__ATOMIC_RELEASE);
    // The completed join supersedes choices queued by the previous local menu.
    // A delayed pad tick must not turn this new guest back into a host.
    __atomic_store_n(&native_choice,0,__ATOMIC_RELEASE);native_known=0;
    view.role=CTR_ROOM_GUEST;view.following=0;
    ctr_memcpy(view.host,host,ctr_strlen(host)+1);publish=0;leave();
}
CTR_EXPORT void ctr_roommode_left(void){
    if(!enter())return;invalidate();__atomic_store_n(&map_context,0,__ATOMIC_RELEASE);view.role=CTR_ROOM_NONE;view.host[0]=0;view.following=0;publish=0;native_known=0;__atomic_store_n(&native_choice,0,__ATOMIC_RELEASE);if(leave_callback)__atomic_store_n(&leave_pending,1,__ATOMIC_RELEASE);leave();
}
CTR_EXPORT void ctr_roommode_on_leave(void(*callback)(void)){leave_callback=callback;}
CTR_EXPORT void ctr_roommode_native_choose(int mode,int private){int choice=4|(mode?1:0)|(private?2:0);diagnostic(225,choice);__atomic_store_n(&map_context,0,__ATOMIC_RELEASE);if(leave_callback)__atomic_store_n(&leave_pending,1,__ATOMIC_RELEASE);__atomic_store_n(&native_choice,choice,__ATOMIC_RELEASE);}
CTR_EXPORT void ctr_roommode_native_requested(int mode){if(__atomic_exchange_n(&native_requested,!!mode,__ATOMIC_ACQ_REL)!=!!mode)diagnostic(226,!!mode);if(!mode)__atomic_store_n(&ctr_speed_active,0,__ATOMIC_RELEASE);}
CTR_EXPORT void ctr_roommode_native_map(int private){
    __atomic_store_n(&map_context,private?2:1,__ATOMIC_RELEASE);diagnostic(231,!!private);
    if(!private)__atomic_store_n(&ctr_speed_active,0,__ATOMIC_RELEASE);
    // Consume pending selection/confirmation before original_load_map reads PAKs.
    ctr_roommode_tick();
}
CTR_EXPORT int ctr_roommode_choose(int mode){
    if((mode!=0&&mode!=1)||!ready||!enter())return -1;
    if(view.role==CTR_ROOM_GUEST){leave();return -2;}
    if(mode&&!api.assets_ready()){leave();return -3;}
    view.selected=mode;invalidate();publish=view.role==CTR_ROOM_HOST;leave();return 0;
}
CTR_EXPORT int ctr_roommode_snapshot(CtrRoomView *out){
    if(!out||!enter())return -1;*out=view;out->available=ready&&api.assets_ready();out->active=__atomic_load_n(&ctr_speed_active,__ATOMIC_ACQUIRE);leave();return 0;
}
CTR_EXPORT void ctr_roommode_tick(void){
    if(!ready)return;int private=!!api.private_now(),assets=!!api.assets_ready(),peers=!!api.peer_recent();
    if(leave_callback&&__atomic_exchange_n(&leave_pending,0,__ATOMIC_ACQ_REL))leave_callback();
    if(!enter())return;
    int choice=__atomic_exchange_n(&native_choice,0,__ATOMIC_ACQ_REL);
    if(choice){
        invalidate();native_known=1;native_private=!!(choice&2);view.selected=!!(choice&1)&&native_private;
        view.role=CTR_ROOM_HOST;view.following=0;view.host[0]=0;const char*me=ctr_player_name();
        if(name_ok(me))ctr_memcpy(view.host,me,ctr_strlen(me)+1);else view.role=CTR_ROOM_NONE;publish=1;
    }
    if(private!=last_private){last_private=private;if(view.role!=CTR_ROOM_GUEST&&!native_known){invalidate();publish=view.role==CTR_ROOM_HOST;}}
    view.available=assets;
    int host=native_known&&view.role==CTR_ROOM_HOST;
    int map=__atomic_load_n(&map_context,__ATOMIC_ACQUIRE);
    int eligible=map==2||(map==0&&(private||peers));
    int active=assets&&eligible&&view.role!=CTR_ROOM_NONE&&(view.role==CTR_ROOM_GUEST||private||map==2||(host&&native_private))&&(host?(view.selected&&native_private&&__atomic_load_n(&native_requested,__ATOMIC_ACQUIRE)):view.confirmed);
    view.active=active;__atomic_store_n(&ctr_speed_active,active,__ATOMIC_RELEASE);
    unsigned state=(assets?1U:0)|(peers?2U:0)|(private?4U:0)|(view.role==CTR_ROOM_HOST?8U:0)|(view.role==CTR_ROOM_GUEST?16U:0)|(native_known?32U:0)|(native_private?64U:0)|(__atomic_load_n(&native_requested,__ATOMIC_ACQUIRE)?128U:0)|(view.confirmed?256U:0)|(view.selected?512U:0)|(active?1024U:0)|((unsigned)map<<11);
    if(state!=last_trace_state){last_trace_state=state;diagnostic(227,(int)state);}
    int due=view.role!=CTR_ROOM_NONE&&name_ok(view.host)&&api.time_us()>=next_request&&(view.role==CTR_ROOM_GUEST||publish);
    if(!due){leave();return;}
    int zero=0;if(!__atomic_compare_exchange_n(&busy,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED)){leave();return;}
    task.generation=view.generation;task.role=view.role;task.mode=(host?native_private:private)&&assets&&view.selected;ctr_memcpy(task.host,view.host,sizeof(task.host));
    leave();
    if(api.spawn(worker,0)){
        if(enter()){view.status=-1;next_request=api.time_us()+2000000ULL;leave();}
        __atomic_store_n(&busy,0,__ATOMIC_RELEASE);
    }
}
