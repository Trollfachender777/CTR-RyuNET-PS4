// SPDX-License-Identifier: GPL-2.0-only
// Complete an old module-only update without running the new UI against
// missing assets. Keep the old code active; commit new code only after assets.
#include "native_assets.h"
#include "updater.h"
extern int64_t ctr_syscall(int64_t,...);
extern void ctr_sha256(const uint8_t*,size_t,uint8_t*);
static uint8_t file_buffer[CTR_UPDATER_MAX];
static uint8_t pending_digest[32],fallback_digest[32];
static size_t pending_size;
static int delegated;
static int32_t delegated_result;
static const char pending[]=CTR_UPDATER_TARGET ".pending-assets";
static int same(const uint8_t*a,const uint8_t*b){unsigned n=0;for(unsigned i=0;i<32;i++)n|=a[i]^b[i];return n==0;}
static void *symbol(const char *name,const char *nid){
    int32_t ids[256];uint64_t count=0;if(ctr_syscall(592,ids,(size_t)256,&count)||count>256)return 0;
    for(uint64_t i=0;i<count;i++){void*p=0;if((!ctr_syscall(591,ids[i],name,&p)&&p)||(!ctr_syscall(591,ids[i],nid,&p)&&p))return p;}return 0;
}
static int code_read(const char *path){
    int64_t fd=ctr_syscall(5,path,0x100,0);if(fd<0)return -1;size_t n=0;int good=1;
    while(n<sizeof(file_buffer)){int64_t r=ctr_syscall(3,fd,file_buffer+n,sizeof(file_buffer)-n);if(r<0||(uint64_t)r>sizeof(file_buffer)-n){good=0;break;}if(!r)break;n+=(size_t)r;}
    if(good&&n==sizeof(file_buffer)){uint8_t extra;if(ctr_syscall(3,fd,&extra,(size_t)1)!=0)good=0;}
    if(ctr_syscall(6,fd)<0)good=0;return good&&ctr_update_self_valid(file_buffer,n)?(int)n:-1;
}
static int code_write(const char *path,const uint8_t *data,size_t size){
    int64_t fd=ctr_syscall(5,path,0x701,0755);if(fd<0)return -1;size_t n=0;int good=1;
    while(n<size){int64_t r=ctr_syscall(4,fd,data+n,size-n);if(r<=0||(uint64_t)r>size-n){good=0;break;}n+=(size_t)r;}
    if(good&&ctr_syscall(124,fd,0755)<0)good=0;if(good&&ctr_syscall(95,fd)<0)good=0;if(ctr_syscall(6,fd)<0)good=0;return good?0:-1;
}
static int code_matches(const char *path,const uint8_t expected[32],size_t expected_size){
    int n=code_read(path);if(n<0||(expected_size&&(size_t)n!=expected_size))return 0;uint8_t digest[32];ctr_sha256(file_buffer,(size_t)n,digest);return same(digest,expected);
}
static void notify(const char *message){
    // Exact OpenOrbis OrbisNotificationRequest ABI (message offset 45).
    typedef struct {int32_t fields[11];uint8_t icon;char message[1024],uri[1024],unused[1024];} Notification;
    _Static_assert(sizeof(Notification)==3120,"Orbis notification ABI");
    int32_t(*send)(int32_t,const void*,size_t,int32_t)=(__typeof__(send))symbol("sceKernelSendNotificationRequest","zl7hupSO0C0");
    if(!send)return;Notification n;ctr_memset(&n,0,sizeof(n));n.fields[4]=-1;size_t size=ctr_strlen(message);if(size>=sizeof(n.message))return;ctr_memcpy(n.message,message,size+1);send(0,&n,sizeof(n),0);
}
static void *download(void *unused){
    (void)unused;size_t allocated=(CTR_ASSET_BYTES+0x3fffU)&~0x3fffU;
    int64_t address=ctr_syscall(477,(void*)0,allocated,3,0x1002,-1,(int64_t)0);
    int good=address>0&&(uint64_t)address<0x800000000000ULL;
    if(good){
        uint8_t *data=(uint8_t*)address;size_t length=0;
        good=!ctr_assets_fetch(data,CTR_ASSET_BYTES,&length)&&length==CTR_ASSET_BYTES&&!ctr_assets_store(data,length);
        ctr_syscall(73,data,allocated);
    }
    // A newer concurrent update wins. Never overwrite code which changed while
    // assets were downloading, even if this transfer itself was successful.
    if(good&&code_matches(CTR_UPDATER_TARGET,fallback_digest,0)&&code_matches(pending,pending_digest,pending_size))
        good=ctr_syscall(128,pending,CTR_UPDATER_TARGET)==0;
    else good=0;
    notify(good?(CTR_MODS_EN?"RyuNET update ready. Close CTR normally and reopen it.":"Actualizacion RyuNET preparada. Cierra CTR normalmente y vuelve a abrirlo."):
        (CTR_MODS_EN?"RyuNET update incomplete. Your previous version is preserved. Please try again.":"Actualizacion RyuNET incompleta. Tu version anterior se conserva. Intentalo otra vez."));
    return 0;
}
int ctr_assets_migration(int32_t *result){
    if(!result)return 0;if(delegated){*result=delegated_result;return 1;}
    typedef int32_t(*Load)(const char*,size_t,const void*,uint32_t,const void*,int32_t*);
    Load load=(Load)symbol("sceKernelLoadStartModule","wzvqT4UqKX8");if(!load)return 0;
    typedef int32_t(*Unload)(int32_t,size_t,const void*,uint32_t,const void*,int32_t*);
    Unload unload=(Unload)symbol("sceKernelStopUnloadModule","QKd0qM58Qes");
    typedef int32_t(*Initialize)(void);Initialize initialize=0;const char *fallback=0;
    const char *candidates[]={CTR_UPDATER_TARGET ".previous","/app0/sce_module/ctr_online.prx"};
    for(unsigned i=0;i<2;i++){
        if(code_read(candidates[i])<0)continue;
        int32_t start_result=0;int32_t id=load(candidates[i],0,0,0,0,&start_result);if(id<0||start_result<0)continue;
        void *v=0,*entry=0;
        if(ctr_syscall(591,id,"ctr_updater_version",&v)||!v)ctr_syscall(591,id,"kxzHfCJBfmc",&v);
        if(ctr_syscall(591,id,"ctr_initialize",&entry)||!entry)ctr_syscall(591,id,"OrQ4BxjNqwA",&entry);
        uint32_t version=v?((uint32_t(*)(void))v)():0;
        if(entry&&version>=1001000U&&version<ctr_updater_version()){initialize=(Initialize)entry;fallback=candidates[i];break;}
        if(unload){int32_t stopped=0;unload(id,0,0,0,0,&stopped);}
    }
    if(!initialize)return 0;
    int n=code_read(CTR_UPDATER_TARGET);if(n<0)return 0;pending_size=(size_t)n;
    ctr_sha256(file_buffer,pending_size,pending_digest);
    if(code_write(pending,file_buffer,pending_size)||!code_matches(pending,pending_digest,pending_size))return 0;
    n=code_read(fallback);if(n<0)return 0;ctr_sha256(file_buffer,(size_t)n,fallback_digest);
    const char temporary[]=CTR_UPDATER_TARGET ".restore-assets";
    if(code_write(temporary,file_buffer,(size_t)n)||!code_matches(temporary,fallback_digest,(size_t)n)||ctr_syscall(128,temporary,CTR_UPDATER_TARGET)<0){ctr_syscall(10,temporary);return 0;}
    // Only now initialize old code. No new imports, users or profiles have been
    // initialized or modified by this module before the handoff.
    delegated=1;delegated_result=initialize();*result=delegated_result;
    if(!delegated_result){
        notify(CTR_MODS_EN?"RyuNET is downloading the files for the new update. Your previous version stays active.":"RyuNET esta descargando los archivos de la nueva actualizacion. Tu version anterior sigue activa.");
        if(ctr_assets_download_start(download,0))notify(CTR_MODS_EN?"Update download could not start. Your previous version is preserved.":"No se pudo iniciar la descarga. Tu version anterior se conserva.");
    }return 1;
}
