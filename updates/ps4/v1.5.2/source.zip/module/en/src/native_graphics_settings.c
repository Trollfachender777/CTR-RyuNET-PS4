// SPDX-License-Identifier: GPL-2.0-only
// Native selectors reuse the approved PS4 settings, including friend preservation.
#include "settings.h"
#include "native_menu.h"
static CtrSettings startup,pending;
static int have_startup,dirty,save_failed,last_capped=60;
static const char *enabled(int on){return CTR_MODS_EN?(on?"On":"Off"):(on?"Si":"No");}
void ctr_native_graphics_baseline(void){if(!ctr_settings_snapshot(&startup)){have_startup=1;if(startup.fps)last_capped=startup.fps;}}
static CtrSettings *current(void){if(!dirty&&ctr_settings_snapshot(&pending))return 0;return &pending;}
const char *ctr_native_graphics_row(size_t row,int direction){
    CtrSettings*s=current();if(!s||row>6)return "";
    int change=direction<0?-1:direction>0?1:0;
    if(change){
        if(row==0)ctr_settings_set_resolution(s,(ctr_settings_resolution(s)+change+3)%3);
        else if(row==1){const int values[]={30,60,0};int index=s->fps==30?0:s->fps==60?1:2;s->fps=values[(index+change+3)%3];if(s->fps)last_capped=s->fps;}
        else if(row==2){if(s->fps){last_capped=s->fps;s->fps=0;}else s->fps=last_capped;}
        else if(row==3)s->motion_blur=!s->motion_blur;
        else if(row==4)s->no_shadows=!s->no_shadows;
        else if(row==5)s->performance=!s->performance;
        else s->pro_1080=!s->pro_1080;
        dirty=1;
    }
    if(row==0){int resolution=ctr_settings_resolution(s);return resolution==1?"720p":resolution==2?"480p":CTR_MODS_EN?"Native":"Nativa";}
    if(row==1)return s->fps==30?"30":s->fps==60?"60":CTR_MODS_EN?"Unlimited":"Sin limite";
    if(row==2)return enabled(!s->fps);
    if(row==3)return enabled(s->motion_blur);
    if(row==4)return enabled(!s->no_shadows);
    if(row==5)return enabled(s->performance);
    return enabled(s->pro_1080);
}
int ctr_native_graphics_changed(void){
    CtrSettings*s=current();if(!s||!have_startup)return 0;
    return s->motion_blur!=startup.motion_blur||s->pro_1080!=startup.pro_1080||s->performance!=startup.performance||s->low_quality!=startup.low_quality||s->no_shadows!=startup.no_shadows;
}
void ctr_native_graphics_save(void){
    if(!dirty)return;
    save_failed=ctr_native_graphics_commit(&pending)!=0;
    if(save_failed)ctr_native_menu_notice(CTR_MODS_EN?"The settings could not be saved. Your previous settings are preserved.":"No se pudieron guardar los ajustes. Se conserva la configuracion anterior.");
    dirty=0;
}
void ctr_native_graphics_restart(void){ctr_native_graphics_save();if(!save_failed)ctr_native_menu_notice(CTR_MODS_EN?"Settings saved. Close CTR normally and open it again to apply the pending graphics changes.":"Ajustes guardados. Cierra CTR normalmente y vuelve a abrirlo para aplicar los cambios graficos pendientes.");}
const char *ctr_native_graphics_description(size_t row){
    static const char*en[]={"Choose the internal 3D resolution. Close and reopen CTR to apply.","Cap the frame rate at 30, 60 or leave it unlimited. Applies immediately.","Turn off the FPS cap. Turning it off restores your last chosen 30/60 cap.","Enable or disable motion blur. Close and reopen CTR to apply.","Enable or remove dynamic character shadows. Close and reopen CTR to apply.","Use the approved PS4 performance settings. Close and reopen CTR to apply.","1080p mode for PS4 Pro. Close and reopen CTR to apply.","Save settings, then close CTR normally and open it again to apply graphics changes."};
    static const char*es[]={"Elige la resolucion interna 3D. Cierra y vuelve a abrir CTR para aplicarla.","Limita los FPS a 30, 60 o dejalos sin limite. Se aplica al momento.","Quita el limite de FPS. Al desactivarlo vuelve al ultimo limite de 30/60 elegido.","Activa o desactiva el desenfoque. Cierra y vuelve a abrir CTR para aplicarlo.","Activa o quita las sombras dinamicas de los personajes. Cierra y vuelve a abrir CTR.","Usa los ajustes de rendimiento aprobados para PS4. Cierra y vuelve a abrir CTR.","Modo 1080p para PS4 Pro. Cierra y vuelve a abrir CTR para aplicarlo.","Guarda los ajustes; despues cierra CTR normalmente y vuelve a abrirlo para aplicarlos."};
    return row<8?(CTR_MODS_EN?en[row]:es[row]):"";
}
