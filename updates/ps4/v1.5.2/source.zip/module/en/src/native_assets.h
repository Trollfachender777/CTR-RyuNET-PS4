// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
#define CTR_ASSET_BYTES 7204396U
#define CTR_ASSET_BUNDLED "/app0/archives/update3.pak"
#define CTR_ASSET_DIRECTORY "/data/ryunet/assets/ui-5b4a4062b75966fa"
#define CTR_ASSET_FILE CTR_ASSET_DIRECTORY "/update3.pak"
#define CTR_ASSET_URL "https://raw.githubusercontent.com/Trollfachender777/CTR-RyuNET-PS4/main/updates/ps4/assets/ui-5b4a4062b75966fa.pak"
CTR_EXPORT int ctr_assets_boot_source(void); // 0 missing, 1 bundled, 2 verified external
CTR_EXPORT int ctr_assets_bytes_valid(const uint8_t*,size_t);
const char *ctr_assets_boot_path(void);
int ctr_assets_verify_file(const char*);
int ctr_assets_route_init(uint64_t,const void*);
int ctr_assets_store(const uint8_t*,size_t);
int ctr_assets_migration(int32_t *result);
int ctr_assets_download_start(void *(*entry)(void*),void *arg);
int ctr_assets_fetch(uint8_t*,size_t,size_t*);
