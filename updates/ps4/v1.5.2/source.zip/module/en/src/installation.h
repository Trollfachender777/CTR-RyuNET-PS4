// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
// Keys are generated on the console, never embedded in the package or logged.
typedef struct {
    int (*read)(const char*,void*,size_t); // byte count; -2 absent; -1 I/O error
    int (*write)(const char*,const char*,const void*,size_t,int);
    int (*random)(void*,size_t);
} CtrIdentityIo;
CTR_EXPORT int ctr_identity_parse(uint8_t out[32],const char *text,size_t length);
CTR_EXPORT int ctr_identity_derive(const uint8_t key[32],char out[65]);
CTR_EXPORT int ctr_identity_prepare(const CtrIdentityIo*,int allow_create);
CTR_EXPORT int ctr_identity_activate(const CtrIdentityIo*,int owned);
CTR_EXPORT const char *ctr_identity_header(const char *url);
void ctr_sha256(const uint8_t*,size_t,uint8_t[32]);
