// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
#define CTR_MAX_FRIENDS 32
#define CTR_FPS_UNLIMITED 0
enum {CTR_RES_NATIVE=0,CTR_RES_720P,CTR_RES_480P};
typedef struct {
    int32_t fps, motion_blur, pro_1080, performance, light_effects;
    int32_t low_quality, no_shadows;
    uint32_t count;
    char friends[CTR_MAX_FRIENDS][17];
} CtrSettings;
CTR_EXPORT void ctr_settings_defaults(CtrSettings *s);
CTR_EXPORT int ctr_settings_parse(CtrSettings *s,const char *text,size_t size);
CTR_EXPORT int ctr_settings_format(const CtrSettings *s,char *out,size_t capacity);
CTR_EXPORT int ctr_settings_add(CtrSettings *s,const char *name,const char *self);
CTR_EXPORT int ctr_settings_remove(CtrSettings *s,const char *name);
CTR_EXPORT int ctr_settings_publish(const CtrSettings *s);
CTR_EXPORT int ctr_settings_snapshot(CtrSettings *s);
CTR_EXPORT int ctr_settings_resolution(const CtrSettings *s);
CTR_EXPORT int ctr_settings_set_resolution(CtrSettings *s,int resolution);
CTR_EXPORT int ctr_settings_reset_graphics(CtrSettings *s);
CTR_EXPORT int ctr_friends_json(const char *path,char *out,size_t capacity);
int ctr_name_valid(const char *name);
int ctr_name_equal(const char *a,const char *b);
