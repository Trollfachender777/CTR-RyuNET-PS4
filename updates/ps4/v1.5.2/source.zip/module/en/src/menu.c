// SPDX-License-Identifier: GPL-2.0-only
#include "menu.h"
#include "characters.h"
#include "room_mode.h"
#include "profile.h"
#include "updates.h"
#include "updater.h"
#include "social.h"
#include "season.h"
#include "sessions.h"
#include "runtime_net_ping.h"
extern int ctr_net_ping_view(PingPeer*,int);
enum {MAIN=1,PERFORMANCE,FPS,GRAPHICS,BLUR,RESOLUTION,FRIENDS,LIST=9,ADD,REMOVE,NOTICE,FRIENDS_LIST,ONLINE=15,PROFILE,NAME_EDIT,GRAPHICS_MORE,LIGHT_MODE,MANUAL_GRAPHICS,LIGHT_EFFECTS,QUALITY_SHADOWS,SHADOWS,FPS_CAPPED,RESET_GRAPHICS,SETUP,EXTRAS,UPDATES,SOCIAL_HUB,SERVER_LIST,SOCIAL_PENDING,REQUESTS,REQUEST_ACTION,INVITES,SOCIAL_MORE,NET_INFO,ROOM_EXTRAS,ROOM_MODE,CHARACTERS};
static CtrMenuApi api;
static CtrDialogParam param;
static CtrDialogMessage message;
static CtrDialogButtons choices;
static CtrImeParam ime;
static uint16_t input[17],title[64];
static char body[2048];
static int available,state,dialog,lock,owned_handle=-1,combo_held,cooldown,owns_message_init;
static int ime_owned,ime_last_status;
static int capturing;
static int setup_pending;
static uint32_t resolution_choice;
static int update_shown;
static unsigned friend_choice,request_choice,invite_choice;
static char social_target[17];
static const char *resolution_names[]={"Native","720p","480p"};
static const char *notice;
static void trace(int32_t stage,int32_t result){if(api.trace)api.trace(stage,result);}
static void append(const char *text){size_t a=ctr_strlen(body),b=ctr_strlen(text);if(a+b<sizeof(body))ctr_memcpy(body+a,text,b+1);}
static void utf16(uint16_t *out,size_t cap,const char *text){size_t i=0;while(i+1<cap&&text[i]){out[i]=(uint8_t)text[i];i++;}out[i]=0;}
static void release_message(void){api.message_term();if(!owns_message_init)api.message_init();}
static int open_message(const char *text,const char *first,const char *second){
    int status=api.message_status();if(status!=0&&status!=1)return -1;
    owns_message_init=status==0;int r=0;
    if(owns_message_init){r=api.message_init();if(r<0){trace(61,r);return r;}}
    ctr_memset(&param,0,sizeof(param));ctr_memset(&message,0,sizeof(message));ctr_memset(&choices,0,sizeof(choices));
    body[0]=0;append(text);message.message=body;
    message.buttons=second?9:0;choices.first=first;choices.second=second;message.custom=second?&choices:0;
    param.base.size=sizeof(param.base);param.base.magic=(uint32_t)((uintptr_t)&param.base+0xC0D1A109U);
    param.size=sizeof(param);param.mode=1;param.message=&message;param.user=api.user;
    r=api.message_open(&param);trace(62,r);
    if(r<0){release_message();return r;}dialog=1;return 0;
}
static int open_ime(int mode){
    if(!api.ime_init||!api.ime_status||!api.ime_result||!api.ime_term)return -1;
    if(api.ime_status()!=0)return -1;
    ctr_memset(input,0,sizeof(input));ctr_memset(&ime,0,sizeof(ime));
    utf16(title,64,mode==REMOVE?"RyuNET nickname of the friend to remove":mode==NAME_EDIT?"Your nickname for RyuNET":"PC or PS4 friend's RyuNET nickname");
    if(mode==NAME_EDIT){char saved[17];if(!ctr_profile_snapshot(saved)&&saved[0])utf16(input,17,saved);}
    ime.user=api.user;ime.type=1;ime.max_length=16;ime.buffer=input;ime.title=title;
    __atomic_store_n(&ime_owned,1,__ATOMIC_RELEASE);ime_last_status=-1;
    int r=api.ime_init(&ime,0);trace(60,r);
    if(r<0){__atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);return r;}
    dialog=2;return 0;
}
CTR_EXPORT int ctr_menu_ime_owned(void){return __atomic_load_n(&ime_owned,__ATOMIC_ACQUIRE);}
CTR_EXPORT int ctr_menu_active(void){return __atomic_load_n(&capturing,__ATOMIC_ACQUIRE);}
static int release_ime(void){
    int r=api.ime_term();trace(65,r);
    __atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);dialog=0;return r;
}
static void show(int next){
    if(next==MAIN&&ctr_updater_auto_prompt())next=UPDATES;
    state=next;dialog=0;CtrSettings s;
    if(ctr_settings_snapshot(&s)){state=0;return;}
    const char *text="",*one="",*two=0;char list[1600];
    switch(next){
    case SETUP:text="Welcome to RyuNET\n\nChoose your own nickname to play online (3 to 16 characters). Do not use someone else's name.\n\nThis PS4 will create and save its private identity. Your PSN name is not used.\n\nIf you skip setup, you can play offline and set it up with L3 + R3 -> Online -> My nickname.";one="Choose nickname";two="Not now";break;
    case MAIN:text="RyuNET - PS4 Settings v1.5.2\nOCTR PC base: v0.7.5\n\nL3 + R3 to open. Circle to return to the game.";one="Performance";two="Online and extras";break;
    case EXTRAS:text="Online and extras";one="Online";two="PS4 updates";break;
    case UPDATES:{
        CtrUpdaterResult u;if(ctr_updater_snapshot(&u)){state=0;return;}update_shown=u.state;
        char percent[5];unsigned value=u.percent>100?100:u.percent;int digits=0;
        if(value>=100)percent[digits++]='1';if(value>=10)percent[digits++]=(char)('0'+value/10%10);percent[digits++]=(char)('0'+value%10);percent[digits++]='%';percent[digits]=0;
        const char *status=u.state==CTR_UPDATER_CHECKING?"Checking for PS4 updates...\nPress View result in a few seconds.":
            u.state==CTR_UPDATER_CURRENT?"Your PS4 version is up to date.":
            u.state==CTR_UPDATER_AVAILABLE?"An update is available.\n\nUpdate now?\nOnly the RyuNET module will be downloaded. Close and reopen the game to apply it.":
            u.state==CTR_UPDATER_DOWNLOADING?"Downloading and verifying the update...":
            u.state==CTR_UPDATER_READY?"Update ready.\n\nClose the game normally using PS -> Close Application, then reopen it to apply the update. Do not disconnect the console during the download.":
            u.state==CTR_UPDATER_FAILED?"The update did not finish. Your previous version is preserved. Check again to retry.":
            u.state==CTR_UPDATER_NEEDS_SETUP?"This installation needs the v1.1.0 builder or a one-time updater setup. Afterwards, you can update the module directly from PS4.":
            u.state==CTR_UPDATER_RATE_LIMIT?"GitHub has limited requests. Wait and try again.":
            u.state==CTR_UPDATER_INVALID?"The update is incompatible with this port, or its information is invalid.":
            u.state==CTR_UPDATER_UNAVAILABLE?"The updater is unavailable in this session. Restart and try again.":
            u.state==CTR_UPDATER_NO_RELEASE?"No PS4 update has been published to the channel yet.":
            u.state==CTR_UPDATER_NETWORK?"Could not check. Check your Internet connection and the console date, or try again later.":"Check for updates to the PS4 port.";
        const char *parts[]={"PS4 updates\n\n",status,
            u.version[0]?"\n\nAvailable version: ":"",u.version,
            u.state==CTR_UPDATER_DOWNLOADING?"\nProgress: ":"",u.state==CTR_UPDATER_DOWNLOADING?percent:"",
            "\n\nInstalled version: " CTR_PS4_RELEASE_TAG,
            "\nYour save, identity, nickname, friends and settings are preserved."};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t l=ctr_strlen(parts[i]);if(n+l+1>sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],l);n+=l;}list[n]=0;
        text=list;one=u.state==CTR_UPDATER_AVAILABLE?"Update now":u.state==CTR_UPDATER_CHECKING||u.state==CTR_UPDATER_DOWNLOADING?"View result":u.state==CTR_UPDATER_READY?"OK":"Check for updates";
        two=u.state==CTR_UPDATER_AVAILABLE?"Not now":"Back";break;
    }
    case ONLINE:text="RyuNET Online";one="Friends";two="My nickname";break;
    case PROFILE:{
        char saved[17];if(ctr_profile_snapshot(saved))saved[0]=0;
        const char *parts[]={"My RyuNET nickname\n\nActive: ",ctr_profile_name_valid(ctr_player_name())?ctr_player_name():"Not configured",
            "\nSaved: ",saved[0]?saved:"Not configured",
            "\n\nUse 3 to 16 letters, numbers, hyphens or underscores.\nApplies after restarting the game. A different nickname may be another server profile; your friends must add it. Your local save is preserved."};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t l=ctr_strlen(parts[i]);if(n+l+1>sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],l);n+=l;}list[n]=0;
        text=list;one="Change nickname";two="Characters";break;
    }
    case CHARACTERS:{
        int r=ctr_characters_status();
        text=r==1?"Temporary unlock: enabled\n\nReopen character selection. It resets when the game closes.":r==0?"Temporary character and cosmetic unlock (test)\n\nEnables the game flag for this session only. Reopen selection after enabling. It resets when the game closes. Missing DLC is not added.":"Unlock is not available yet\n\nThe game state did not pass validation. Return to the main menu and retry. The unlock flag was not modified.";
        one=r==1?"Check":"Enable";two="Back";break;
    }
    case PERFORMANCE:text="Performance\n\nChoose the FPS limit or graphics settings.";one="FPS limit";two="Graphics";break;
    case FPS:
        text=s.fps==60?"Current limit: 60 FPS\n\nChoose a 30/60 FPS cap or allow the game to render without this limiter.":s.fps==30?"Current limit: 30 FPS\n\nChoose a 30/60 FPS cap or allow the game to render without this limiter.":"Current limit: unlimited\n\nThis may increase load and power use. Results depend on the game, console and display synchronization.";
        one="30 / 60 FPS";two="Unlimited";break;
    case FPS_CAPPED:
        text="FPS limit\n\n30 and 60 apply a real cap using timed waits. Applies when you return to the game; no restart is required.";
        one="30 FPS";two="60 FPS";break;
    case GRAPHICS:text="Graphics\n\nChoose one internal resolution: Native, 720p or 480p.\nGraphics changes require closing and reopening the game.";one="Internal resolution";two="More options";break;
    case GRAPHICS_MORE:text="More graphics options";one="Effects and shadows";two="Restore graphics";break;
    case MANUAL_GRAPHICS:text="Effects and shadows";one="Motion blur";two="Dynamic shadows";break;
    case SHADOWS:
        text=s.no_shadows?"Dynamic shadows: disabled (saved)\n\nRemoves cascaded and racer shadows using the engine controls. Lighting remains. Shadows painted into textures may remain visible.\n\nRestart required.":"Dynamic shadows: enabled (saved)\n\nYou can remove them to reduce graphics work. This changes the appearance; a specific FPS improvement is not guaranteed.\n\nShadows painted into textures are unchanged. Restart required.";
        one="Remove shadows";two="Restore shadows";break;
    case BLUR:text=s.performance&&!s.low_quality?"Motion blur\n\nThe 720p profile keeps it disabled. Your manual preference applies when Native or 480p is selected.":s.motion_blur?"Motion blur: enabled\n\nRestart the game after saving.":"Motion blur: disabled\n\nRestart the game after saving.";one="Enable";two="Disable";break;
    case RESOLUTION:{
        int current=ctr_settings_resolution(&s);if(current<0||resolution_choice>CTR_RES_480P){state=0;return;}
        const char *saved=api.pro&&s.pro_1080&&current==CTR_RES_NATIVE?"1080p Pro (legacy)":resolution_names[current];
        const char *parts[]={"Internal resolution\n\nSaved: ",saved,"\nSelected: ",resolution_names[resolution_choice],
            "\n\nOptions: Native / 720p / 480p.\nNext cycles through the options; Apply saves your selection.\n",
            resolution_choice==CTR_RES_720P?"720p uses the existing profile without motion blur.\n":"",
            "\nKeeps FPS and shadows. The TV may still show 1080p: that is the HDMI output.\nRestart the game to apply. Circle cancels."};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t length=ctr_strlen(parts[i]);if(n+length+1>sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],length);n+=length;}list[n]=0;
        text=list;one="Apply";two="Next";break;
    }
    case RESET_GRAPHICS:
        text="Restore graphics settings\n\nReturns to Native resolution, motion blur enabled and dynamic shadows enabled.\n\nKeeps the FPS limit, your save, nickname and friends.\nRequires closing and reopening the game.";
        one="Restore";two="Cancel";break;
    case FRIENDS:text="RyuNET Friends - OCTR 0.7.2 protocol\n\nAdd sends a server friend request. The other player must accept. To join a game, use Online -> Friends in CTR.\nView / remove includes requests and invitations.";one="Add friend";two="View / remove";break;
    case FRIENDS_LIST:text="Manage RyuNET friends";one="View list";two="Remove friend";break;
    case LIST:
        list[0]=0;
        if(!s.count){const char *empty="You have not added any friends yet.";ctr_memcpy(list,empty,ctr_strlen(empty)+1);}
        else {size_t n=0;for(uint32_t i=0;i<s.count;i++){size_t l=ctr_strlen(s.friends[i]);ctr_memcpy(list+n,s.friends[i],l);n+=l;list[n++]='\n';}list[n]=0;}
        text=list;one="Server friends";two="Back";break;
    case SOCIAL_HUB:text="Server friends\n\nRefreshes every 8 seconds. Friend requests require acceptance; removing a friend removes the server friendship for both players.\nPrevious local contacts are preserved and send a request when needed.";one="List / invite";two="Requests and extras";break;
    case SERVER_LIST:case REQUESTS:case INVITES:{
        CtrSocialView v;social_target[0]=0;if(ctr_social_snapshot(&v)){state=0;return;}
        if(v.state!=CTR_SOCIAL_READY){text=v.state==CTR_SOCIAL_REFUSED?"The server did not accept the friends query. Enter Online first and try again.":"Fetching server friends. Enter Online first and wait a few seconds.";one="View result";two="Back";break;}
        unsigned total=next==SERVER_LIST?v.count:next==REQUESTS?v.incoming_count:v.invite_count;
        if(!total){text=next==SERVER_LIST?"No accepted friendships on the server yet.":next==REQUESTS?"No pending friend requests.":"No pending invitations.";one="Refresh";two="Back";break;}
        unsigned *choice=next==SERVER_LIST?&friend_choice:next==REQUESTS?&request_choice:&invite_choice;*choice%=total;
        const char *name=next==SERVER_LIST?v.friends[*choice].name:next==REQUESTS?v.incoming[*choice]:v.invites[*choice].from;
        ctr_memcpy(social_target,name,ctr_strlen(name)+1);list[0]=0;
        const char *parts[]={next==SERVER_LIST?"Friend: ":next==REQUESTS?"Friend request from: ":"Your friend invites you to their game: ",name,
            next==SERVER_LIST?(v.friends[*choice].online?"\nOnline":"\nOffline"):"",
            next==INVITES?"\n\nAccept will try to enter their room. It must have free slots and be waiting before the race.":"",
            "\n\nNext cycles through contacts. Circle returns to the game.",v.result[0]?"\nLast response: ":"",v.result};
        size_t n=0;for(size_t i=0;i<sizeof(parts)/sizeof(parts[0]);i++){size_t len=ctr_strlen(parts[i]);if(n+len>=sizeof(list)){state=0;return;}ctr_memcpy(list+n,parts[i],len);n+=len;}list[n]=0;
        text=list;one=next==SERVER_LIST?"Invite":next==REQUESTS?"Accept / decline":"Accept invitation";two="Next";break;
    }
    case REQUEST_ACTION:list[0]=0;const char *prefix="Request from: ";size_t len=ctr_strlen(prefix);ctr_memcpy(list,prefix,len);ctr_memcpy(list+len,social_target,ctr_strlen(social_target)+1);text=list;one="Accept";two="Decline";break;
    case SOCIAL_PENDING:text="Requests and extras";one="Incoming requests";two="Invitations / network";break;
    case SOCIAL_MORE:text="Invitations and network";one="Incoming invitations";two="Room ping";break;
    case NET_INFO:{
        PingPeer peers[PING_MAX_PEERS];int n=ctr_net_ping_view(peers,PING_MAX_PEERS);list[0]=0;
        const char *intro="Player ping (OCTR 0.7.2)\n\n";ctr_memcpy(list,intro,ctr_strlen(intro)+1);size_t at=ctr_strlen(list);
        for(int i=0;i<n;i++){
            const char *name=peers[i].name[0]?peers[i].name:"Player";size_t len=ctr_strlen(name);ctr_memcpy(list+at,name,len);at+=len;list[at++]=' ';list[at]=0;
            if(peers[i].ms>=0){unsigned value=(unsigned)peers[i].ms;char rev[12];unsigned k=0;do{rev[k++]=(char)('0'+value%10);value/=10;}while(value);while(k)list[at++]=rev[--k];ctr_memcpy(list+at," ms\n",5);at+=4;}
            else {const char *status=peers[i].ms==PING_OLDER_PORT?"(ping not supported)\n":"(waiting for reply)\n";len=ctr_strlen(status);ctr_memcpy(list+at,status,len+1);at+=len;}
        }
        if(!n){const char *empty="Enter a room with other players to see their ping.";ctr_memcpy(list+at,empty,ctr_strlen(empty)+1);}text=list;one="Refresh";two="Back";break;
    }
    case ADD:case REMOVE:case NAME_EDIT:if(!open_ime(next))return;notice="Could not open the keyboard. Try again from the main menu.";state=NOTICE;next=NOTICE;/* fall through */
    case NOTICE:text=notice?notice:"Settings saved.";one="OK";break;
    default:state=0;return;
    }
    if(open_message(text,one,two)<0){state=0;trace(61,-1);}
}
static void commit(CtrSettings *s,const char *success){
    if(!api.save||api.save(s)<0){notice="Could not save. Your previous settings are preserved.";show(NOTICE);return;}
    if(ctr_settings_publish(s)<0){notice="File saved. Restart the game to load it.";show(NOTICE);return;}
    notice=success;show(NOTICE);
}
static void selected(int button){
    CtrSettings s;if(ctr_settings_snapshot(&s)){state=0;return;}
    switch(state){
    case SETUP:if(button==1)show(NAME_EDIT);else state=0;return;
    case MAIN:show(button==1?PERFORMANCE:EXTRAS);return;
    case EXTRAS:show(button==1?ONLINE:UPDATES);return;
    case UPDATES:if(button==2){show(EXTRAS);return;}if(update_shown==CTR_UPDATER_AVAILABLE)ctr_updater_install();else if(update_shown!=CTR_UPDATER_CHECKING&&update_shown!=CTR_UPDATER_DOWNLOADING&&update_shown!=CTR_UPDATER_READY)ctr_updater_check();show(UPDATES);return;
    case ONLINE:show(button==1?FRIENDS:PROFILE);return;
    case PROFILE:show(button==1?NAME_EDIT:CHARACTERS);return;
    case CHARACTERS:
        if(button==2){show(PROFILE);return;}
        {int r=ctr_characters_enable();notice=r==1?"Temporary unlock enabled. Reopen character selection. It resets when the game closes.":"Could not enable with validation. Unlock was not applied. Return to the main menu and retry.";show(NOTICE);return;}
    case PERFORMANCE:show(button==1?FPS:GRAPHICS);return;
    case FPS:
        if(button==1){show(FPS_CAPPED);return;}
        s.fps=CTR_FPS_UNLIMITED;commit(&s,"Unlimited saved. Applies when you return to the game.");return;
    case FPS_CAPPED:s.fps=button==1?30:60;commit(&s,"Limit saved. Applies when you return to the game.");return;
    case GRAPHICS:
        if(button==1){int current=ctr_settings_resolution(&s);if(current<0){state=0;return;}resolution_choice=(uint32_t)current;show(RESOLUTION);}
        else show(GRAPHICS_MORE);return;
    case GRAPHICS_MORE:show(button==1?MANUAL_GRAPHICS:RESET_GRAPHICS);return;
    case MANUAL_GRAPHICS:show(button==1?BLUR:SHADOWS);return;
    case SHADOWS:
        s.no_shadows=button==1;
        commit(&s,s.no_shadows?"Dynamic shadows disabled. Close the game normally and reopen it to apply.":"Dynamic shadows restored. Close the game and reopen it to apply.");return;
    case BLUR:s.motion_blur=button==1;commit(&s,"Motion blur saved. Restart the game to apply.");return;
    case RESOLUTION:
        if(button==2){resolution_choice=(resolution_choice+1)%3;show(RESOLUTION);return;}
        if(ctr_settings_set_resolution(&s,(int)resolution_choice)<0){state=0;return;}
        commit(&s,"Resolution saved. Close the game normally and reopen it to apply. Your FPS limit is preserved.");return;
    case RESET_GRAPHICS:
        if(button==2){show(GRAPHICS_MORE);return;}
        if(ctr_settings_reset_graphics(&s)<0){state=0;return;}
        commit(&s,"Graphics restored. Close the game normally and reopen it. FPS, save, nickname and friends are preserved.");return;
    case LIST:show(button==1?SOCIAL_HUB:FRIENDS_LIST);return;
    case SOCIAL_HUB:show(button==1?SERVER_LIST:SOCIAL_PENDING);return;
    case SOCIAL_PENDING:show(button==1?REQUESTS:SOCIAL_MORE);return;
    case SOCIAL_MORE:show(button==1?INVITES:NET_INFO);return;
    case NET_INFO:show(button==1?NET_INFO:SOCIAL_MORE);return;
    case SERVER_LIST:case REQUESTS:case INVITES:{
        int previous=state;
        if(!social_target[0]){show(button==1?state:SOCIAL_HUB);return;}
        if(button==2){if(state==SERVER_LIST)friend_choice++;else if(state==REQUESTS)request_choice++;else invite_choice++;show(previous);return;}
        if(state==REQUESTS){show(REQUEST_ACTION);return;}
        if(state==INVITES){int r=ctr_session_queue(social_target);notice=r?"Could not prepare the invitation. Enter Online first and try again.":"Invitation accepted. Return to the game to enter the room.";}
        else {int r=ctr_social_action("invite",social_target);notice=r?"Could not send. Wait and try again.":"Invitation queued. The server response will appear in the friends list.";}
        show(NOTICE);return;
    }
    case REQUEST_ACTION:{int r=ctr_social_action(button==1?"accept":"decline",social_target);notice=r?"Could not send. Wait and try again.":"Response queued. The list will refresh when the server answers.";show(NOTICE);return;}
    case FRIENDS:show(button==1?ADD:FRIENDS_LIST);return;
    case FRIENDS_LIST:show(button==1?LIST:REMOVE);return;
    default:break;
    }state=0;
}
CTR_EXPORT int ctr_menu_init(const CtrMenuApi *native){
    if(!native||!native->message_init||!native->message_open||!native->message_status||!native->message_update||!native->message_result||!native->message_term||native->user<0)return -1;
    api=*native;state=dialog=combo_held=cooldown=setup_pending=0;owned_handle=-1;
    __atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);__atomic_store_n(&capturing,0,__ATOMIC_RELEASE);available=1;return 0;
}
CTR_EXPORT void ctr_menu_request_setup(void){setup_pending=120;}
CTR_EXPORT int ctr_menu_poll(int32_t handle,uint32_t buttons){
    if(!available)return 0;int zero=0;
    if(!__atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return state!=0;
    int capture=state!=0;int combo=(buttons&6)==6;
    if(owned_handle<0)owned_handle=handle;
    if(handle!=owned_handle)goto done;
    ctr_updater_tick();
    ctr_social_tick();
    ctr_season_tick();
    ctr_roommode_tick();
    if(!state&&setup_pending&&!--setup_pending){
        // Respect dialogs already owned by CTR or the OS; retry later without
        // stealing their input or assuming a particular loading-screen length.
        int status=api.message_status();
        if((status==0||status==1)&&(!api.ime_status||api.ime_status()==0)){show(SETUP);capture=state!=0;}
        if(!state)setup_pending=120;combo_held=combo;goto done;
    }
    if(cooldown>0)cooldown--;
    if(!state){if(combo&&!combo_held&&!cooldown){show(MAIN);capture=state!=0;trace(59,state);}combo_held=combo;goto done;}
    int escape=combo&&!combo_held&&!cooldown;combo_held=combo;
    if(dialog==2&&escape){
        if(api.ime_abort)trace(67,api.ime_abort());
        release_ime();state=0;cooldown=20;goto done;
    }
    if(dialog==1&&api.message_update()==3){
        CtrDialogResult result;ctr_memset(&result,0,sizeof(result));int r=api.message_result(&result);
        release_message();dialog=0;
        if(r<0||result.result!=0||result.button<1||result.button>2)state=0;
        else selected(result.button);
        cooldown=20;
    }else if(dialog==2){
        int status=api.ime_status();
        if(status!=ime_last_status){trace(63,status);ime_last_status=status;}
        if(status==1)goto done;
        if(status!=2){
            // The OS dialog disappeared, or its status call failed. Never keep
            // capturing game input while waiting for a result that cannot arrive.
            if(status!=0&&api.ime_abort)trace(67,api.ime_abort());
            if(status!=0)release_ime();
            else {__atomic_store_n(&ime_owned,0,__ATOMIC_RELEASE);dialog=0;}
            trace(66,status);state=0;cooldown=20;goto done;
        }
        CtrImeResult result;ctr_memset(&result,0,sizeof(result));int r=api.ime_result(&result);trace(64,r);
        int terminated=release_ime();
        if(terminated<0){state=0;cooldown=20;goto done;}
        if(r<0||result.result!=0){state=0;goto done;}
        char name[17];size_t n=0;while(n<16&&input[n]&&input[n]<128){name[n]=(char)input[n];n++;}name[n]=0;
        if(input[n]){notice="Invalid nickname. Use letters, numbers, hyphens or underscores.";show(NOTICE);goto done;}
        CtrSettings s;if(ctr_settings_snapshot(&s)){state=0;goto done;}
        if(state==NAME_EDIT){
            if(!ctr_profile_name_valid(name)){notice="Choose your own nickname with 3 to 16 letters, numbers, hyphens or underscores. Do not use generic names such as Player or RyuNET.";show(NOTICE);goto done;}
            uint32_t i=0;while(i<s.count&&!ctr_name_equal(name,s.friends[i]))i++;
            if(i<s.count){notice="That nickname belongs to a contact in your list. Choose your own nickname.";show(NOTICE);goto done;}
            if(!api.save_name||api.save_name(name)<0){notice="Could not save the nickname. Your previous nickname is preserved.";show(NOTICE);goto done;}
            ctr_profile_publish(name);trace(112,0);
            setup_pending=0;notice="Nickname saved. Close the game normally and reopen it to use it with RyuNET. If the server rejects the name, choose another available name. Do not share your identity files.";show(NOTICE);cooldown=20;goto done;
        }
        r=state==ADD?ctr_settings_add(&s,name,ctr_player_name()):ctr_settings_remove(&s,name);
        if(state==REMOVE&&ctr_social_contact(name))r=0;
        if(r<0){notice=r==-3?"That friend is already in your list.":"Could not change the list. Check the nickname (1 to 16 characters), that it is not your own and that the list has room.";show(NOTICE);}
        else {
            int social_result=ctr_social_action(state==ADD?"request":"remove",name);
            commit(&s,social_result?"Local contact saved. Could not queue the server request; enter Online and try again.":"Request queued. Check Server friends for the response. The other player must accept new friendships.");
        }
        cooldown=20;
    }
done:
    __atomic_store_n(&capturing,state!=0,__ATOMIC_RELEASE);
    __atomic_store_n(&lock,0,__ATOMIC_RELEASE);return capture;
}

void ctr_native_menu_notice(const char*text){int zero=0;if(!available||!text||!__atomic_compare_exchange_n(&lock,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return;if(!state&&!dialog){notice=text;show(NOTICE);__atomic_store_n(&capturing,state!=0,__ATOMIC_RELEASE);}__atomic_store_n(&lock,0,__ATOMIC_RELEASE);}
