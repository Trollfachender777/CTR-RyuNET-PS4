// SPDX-License-Identifier: GPL-2.0-only
// Install only during the existing startup UI initialization, before level load.
// No executable changes occur in the worker or during a race.
#include "season.h"
extern int64_t ctr_syscall(int64_t,...);
extern void ctr_season_hook(void);
uint64_t ctr_season_continue;
typedef struct {uint64_t address;uint32_t size;int32_t protection;} EventSegment;
typedef struct {uint64_t size;char name[256];EventSegment segments[4];uint32_t count;uint8_t fingerprint[20];} EventModule;
static uint64_t installed;
static int permission(const EventModule *m,uint64_t address,size_t size){
    if(m->count>4)return 0;
    for(uint32_t i=0;i<m->count;i++){
        const EventSegment *s=&m->segments[i];
        if(address>=s->address&&address-s->address<=s->size&&size<=s->size-(address-s->address))return s->protection;
    }return 0;
}
int ctr_season_install(uint64_t base,const void *module){
    // Exact supported CUSA13795 1.21 instructions AND the original setMode call.
    static const uint8_t expected[]={0x49,0x8b,0x87,0x30,0x01,0x00,0x00,0x4c,0x89,0xef,0x8b,0x70,0x18,0xe8,0xe3,0x16,0x00,0x00};
    if(!base||base>=0x800000000000ULL-0xfb602d||!module)return -1;
    uint64_t address=base+0xfb601b;
    if(installed)return installed==address?0:-1;
    int prot=permission(module,address,sizeof(expected));if((prot&5)!=5)return -2;
    const uint8_t *window=(const uint8_t*)address;
    for(size_t i=0;i<sizeof(expected);i++)if(window[i]!=expected[i])return -3;
    uint8_t replacement[13]={0x48,0xb8,0,0,0,0,0,0,0,0,0xff,0xe0,0x90};
    uint64_t entry=(uint64_t)ctr_season_hook;ctr_memcpy(replacement+2,&entry,8);
    uint64_t page=address&~0x3fffULL;
    if(ctr_syscall(74,page,(size_t)0x4000,prot|2))return -4;
    for(size_t i=0;i<sizeof(expected);i++)if(window[i]!=expected[i]){
        ctr_syscall(74,page,(size_t)0x4000,prot);return -3;
    }
    ctr_season_continue=address+13;
    __atomic_thread_fence(__ATOMIC_RELEASE);
    ctr_memcpy((void*)address,replacement,sizeof(replacement));
    installed=address;
    return ctr_syscall(74,page,(size_t)0x4000,prot)?-5:0;
}
