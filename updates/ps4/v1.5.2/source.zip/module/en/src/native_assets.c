// SPDX-License-Identifier: GPL-2.0-only
// Only the immutable, hash-pinned native UI archive can be routed externally.
// No mod directory, profile path or writable game-file redirection is enabled.
#include "native_assets.h"
#include "native_asset_hashes.h"
extern int64_t ctr_syscall(int64_t,...);
extern void ctr_sha256(const uint8_t*,size_t,uint8_t*);
typedef struct {uint64_t address;uint32_t size;int32_t protection;} Segment;
typedef struct {uint64_t size;char name[256];Segment segments[4];uint32_t count;uint8_t fingerprint[20];} Module;
static int checked,source,routed;
static uint8_t buffer[65536];
static int same(const uint8_t*a,const uint8_t*b){unsigned different=0;for(unsigned i=0;i<32;i++)different|=a[i]^b[i];return different==0;}
CTR_EXPORT int ctr_assets_bytes_valid(const uint8_t *data,size_t size){
    if(!data||size!=CTR_ASSET_BYTES)return 0;uint8_t digest[32];size_t at=0;unsigned index=0;
    while(at<size){size_t n=size-at;if(n>65536)n=65536;ctr_sha256(data+at,n,digest);if(!same(digest,asset_hashes[index++]))return 0;at+=n;}return 1;
}
int ctr_assets_verify_file(const char *path){
    int64_t fd=ctr_syscall(5,path,0x100,0);if(fd<0)return 0;
    size_t remaining=CTR_ASSET_BYTES;unsigned index=0;int good=1;uint8_t digest[32];
    while(remaining){size_t n=remaining<sizeof(buffer)?remaining:sizeof(buffer),used=0;
        while(used<n){int64_t got=ctr_syscall(3,fd,buffer+used,n-used);if(got<=0||(uint64_t)got>n-used){good=0;break;}used+=(size_t)got;}
        if(!good)break;ctr_sha256(buffer,n,digest);if(!same(digest,asset_hashes[index++])){good=0;break;}remaining-=n;
    }
    if(good){uint8_t extra;good=ctr_syscall(3,fd,&extra,(size_t)1)==0;}
    if(ctr_syscall(6,fd)<0)good=0;return good;
}
CTR_EXPORT int ctr_assets_boot_source(void){
    if(checked)return source;
    if(ctr_assets_verify_file(CTR_ASSET_BUNDLED))source=1;
    else if(ctr_assets_verify_file(CTR_ASSET_FILE))source=2;
    checked=1;return source;
}
const char *ctr_assets_boot_path(void){return ctr_assets_boot_source()==2?CTR_ASSET_FILE:CTR_ASSET_BUNDLED;}
static int(*original_stat)(const char*,void*),(*original_open)(const char*,int,int);
static void*(*original_fopen)(const char*,const char*);
static int exact(const char *path){return routed&&path&&!ctr_strcmp(path,CTR_ASSET_BUNDLED);}
static int redirected_stat(const char *path,void *out){return original_stat(exact(path)?CTR_ASSET_FILE:path,out);}
static int redirected_open(const char *path,int flags,int mode){
    return original_open(exact(path)&&!(flags&(3|8|0x200|0x400))?CTR_ASSET_FILE:path,flags,mode);
}
static void *redirected_fopen(const char *path,const char *mode){
    int read=mode&&(!ctr_strcmp(mode,"r")||!ctr_strcmp(mode,"rb"));return original_fopen(exact(path)&&read?CTR_ASSET_FILE:path,mode);
}
static int permissions(const Module *m,uint64_t at){
    for(unsigned i=0;i<m->count;i++){const Segment*s=&m->segments[i];if(at>=s->address&&at+8>=at&&at+8<=s->address+s->size)return s->protection;}return 0;
}
static void *bound_export(const char *name,const char *nid,uint64_t current,int lazy){
    int32_t ids[256];uint64_t count=0;if(ctr_syscall(592,ids,(size_t)256,&count)||count>256)return 0;
    for(uint64_t i=0;i<count;i++){
        Module m;ctr_memset(&m,0,sizeof(m));m.size=sizeof(m);if(ctr_syscall(593,ids[i],&m)||!m.count||m.count>4)continue;m.name[255]=0;
        const char *leaf=m.name;for(unsigned n=0;m.name[n];n++)if(m.name[n]=='/'||m.name[n]=='\\')leaf=m.name+n+1;
        if(lazy){int libc=!ctr_strcmp(leaf,"libc")||!ctr_strcmp(leaf,"libc.prx")||!ctr_strcmp(leaf,"libc.sprx");
            if(!ctr_strcmp(name,"fopen")?!libc:!ctr_strstr(m.name,"libkernel"))continue;}
        void *p=0;if((ctr_syscall(591,ids[i],name,&p)||!p)&&(ctr_syscall(591,ids[i],nid,&p)||!p))continue;
        int executable=0;for(unsigned n=0;n<m.count;n++)if((m.segments[n].protection&5)==5&&(uint64_t)p>=m.segments[n].address&&(uint64_t)p<m.segments[n].address+m.segments[n].size)executable=1;
        if(executable&&(lazy||(uint64_t)p==current))return p;
    }return 0;
}
int ctr_assets_route_init(uint64_t base,const void *info){
    if(ctr_assets_boot_source()!=2)return 0;if(routed)return 0;if(!base||!info)return -1;const Module*m=info;if(!m->count||m->count>4)return -1;
    static const struct {uint32_t got,lazy;const char *name,*nid;} entries[]={
        {0x2807be8,0x1be90f8,"fopen","xeYO4u7uyJ0"},{0x2808768,0x1bea7f8,"sceKernelStat","eV9wAD2riIA"},{0x2808928,0x1beab78,"sceKernelOpen","1G3lF1Gg1k8"}};
    uint64_t before[3],after[3],pages[2];int prot[2];unsigned page_count=0;
    for(unsigned i=0;i<3;i++){
        uint64_t at=base+entries[i].got;if(!(permissions(m,at)&1))return -2;before[i]=*(uint64_t*)at;
        void *p=bound_export(entries[i].name,entries[i].nid,before[i],before[i]==base+entries[i].lazy);if(!p)return -3;after[i]=(uint64_t)p;
        uint64_t page=at&~0x3fffULL;unsigned n=0;while(n<page_count&&pages[n]!=page)n++;
        if(n==page_count){if(n==2)return -4;pages[n]=page;prot[n]=permissions(m,at);page_count++;}
    }
    original_fopen=(__typeof__(original_fopen))after[0];original_stat=(__typeof__(original_stat))after[1];original_open=(__typeof__(original_open))after[2];
    after[0]=(uint64_t)redirected_fopen;after[1]=(uint64_t)redirected_stat;after[2]=(uint64_t)redirected_open;
    unsigned acquired=0;for(;acquired<page_count;acquired++)if(ctr_syscall(74,pages[acquired],(size_t)0x4000,prot[acquired]|2))break;
    if(acquired!=page_count){for(unsigned n=0;n<acquired;n++)ctr_syscall(74,pages[n],(size_t)0x4000,prot[n]);return -5;}
    int good=1;for(unsigned i=0;i<3;i++)if(*(uint64_t*)(base+entries[i].got)!=before[i])good=0;
    if(good){routed=1;for(unsigned i=0;i<3;i++)__atomic_store_n((uint64_t*)(base+entries[i].got),after[i],__ATOMIC_RELEASE);}
    for(unsigned n=0;n<page_count;n++)ctr_syscall(74,pages[n],(size_t)0x4000,prot[n]);return good?0:-6;
}
int ctr_assets_store(const uint8_t *data,size_t size){
    if(!ctr_assets_bytes_valid(data,size))return -1;
    const char *dirs[]={"/data/ryunet","/data/ryunet/assets",CTR_ASSET_DIRECTORY};
    for(unsigned i=0;i<3;i++){int64_t r=ctr_syscall(136,dirs[i],0755);if(r<0&&r!=-17)return -2;}
    const char *tmp=CTR_ASSET_FILE ".download";int64_t fd=ctr_syscall(5,tmp,0x701,0644);if(fd<0)return -3;size_t used=0;int error=0;
    while(used<size){int64_t n=ctr_syscall(4,fd,data+used,size-used);if(n<=0||(uint64_t)n>size-used){error=-4;break;}used+=(size_t)n;}
    if(!error&&ctr_syscall(95,fd)<0)error=-5;if(ctr_syscall(6,fd)<0)error=-5;
    if(!error&&!ctr_assets_verify_file(tmp))error=-6;
    if(!error&&ctr_syscall(128,tmp,CTR_ASSET_FILE)<0)error=-7;
    if(error)ctr_syscall(10,tmp);return error;
}
