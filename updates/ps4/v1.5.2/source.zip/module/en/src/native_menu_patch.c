// SPDX-License-Identifier: GPL-2.0-only
// Queue all native detours, validate their original bytes and commit together.
#include "native_menu.h"
#include "native_assets.h"
#include "native_modes_compat.h"
#include "room_mode.h"
#include "native_menu_profile.h"
extern int64_t ctr_syscall(int64_t,...);
extern unsigned char ctr_native_menu_code[0xc000];
extern int runtime_graphics_tab_ready;
extern void ctr_sha256(const uint8_t*,size_t,uint8_t*);
extern void(*runtime_online_mode_chosen)(int,int);
static CtrMenuModule game;
static uint64_t base;
static int initializing,installed,failure;
static unsigned allocation,count;
static struct {uint64_t at;size_t size;uint8_t old[64],next[64];} changes[96];
static struct {uint32_t rva;size_t size;uint8_t last[6];} dynamic[]={
 {0xe6675e,1,{1}},{0xf34575,1,{0xed}},
 {0xfff9c2,6,{0x0f,0x85,0xd6,0x06,0,0}},
 {0xffd9c7,6,{0x0f,0x85,0xf2,0x0b,0,0}}
};
static int protection(uint64_t at,size_t size){
    for(unsigned i=0;i<game.count&&i<4;i++){CtrMenuSegment*s=&game.segments[i];if(at>=s->address&&at-s->address<=s->size&&size<=s->size-(at-s->address))return s->protection;}return 0;
}
static int arena(uint64_t at,size_t size){uint64_t first=(uint64_t)ctr_native_menu_code;return at>=first&&at-first<=0xc000&&size<=0xc000-(at-first);}
void *ctr_native_code_allocate(size_t size){if(!initializing||!size||size>4096||allocation>=3){failure=1;return 0;}return ctr_native_menu_code+0x4000*allocation++;}
static int dynamic_write(uint64_t at,const void*data,size_t size){
    for(unsigned i=0;i<4;i++)if(at==base+dynamic[i].rva&&size==dynamic[i].size){
        if(ctr_native_memcmp((void*)at,dynamic[i].last,size))return 0;
        const uint8_t *bytes=data;
        if(i==0&&(bytes[0]!=1&&bytes[0]!=6))return 0;
        if(i==1&&(bytes[0]!=0xed&&bytes[0]!=0xff))return 0;
        if(i>=2){int original=1,nops=1;for(unsigned j=0;j<6;j++){const uint8_t original_bytes[6]={0x0f,0x85,i==2?0xd6:0xf2,i==2?0x06:0x0b,0,0};if(bytes[j]!=original_bytes[j])original=0;if(bytes[j]!=0x90)nops=0;}if(!original&&!nops)return 0;}
        uint64_t page=at&~0x3fffULL;int p=protection(at,size);if((p&5)!=5||ctr_syscall(74,page,(size_t)0x4000,p|2))return 0;
        ctr_memcpy((void*)at,data,size);ctr_memcpy(dynamic[i].last,data,size);
        return ctr_syscall(74,page,(size_t)0x4000,p)==0;
    }
    return 0;
}
int ctr_native_code_write(void*target,const void*data,size_t size){
    uint64_t at=(uint64_t)target;if(!data||!size||size>4096){failure=1;return 0;}
    if(arena(at,size)){if(!initializing){failure=1;return 0;}ctr_memcpy(target,data,size);return 1;}
    if(!initializing)return installed?dynamic_write(at,data,size):0;
    if(count>=96||size>64||!(protection(at,size)&1)){failure=1;return 0;}
    for(unsigned i=0;i<count;i++)if(at<changes[i].at+changes[i].size&&changes[i].at<at+size){failure=1;return 0;}
    changes[count].at=at;changes[count].size=size;ctr_memcpy(changes[count].old,target,size);ctr_memcpy(changes[count].next,data,size);count++;return 1;
}
static int commit(void){
    uint64_t pages[96];int permissions[96];unsigned n=0;
    if(failure||!count)return -1;
    for(unsigned i=0;i<count;i++){
        if(ctr_native_memcmp((void*)changes[i].at,changes[i].old,changes[i].size))return -2;
        for(uint64_t page=changes[i].at&~0x3fffULL;page<=((changes[i].at+changes[i].size-1)&~0x3fffULL);page+=0x4000){unsigned j=0;while(j<n&&pages[j]!=page)j++;if(j==n){if(n==96)return -1;pages[n]=page;permissions[n]=protection(changes[i].at,changes[i].size);n++;}}
    }
    unsigned acquired=0;for(;acquired<n;acquired++)if(ctr_syscall(74,pages[acquired],(size_t)0x4000,permissions[acquired]|2))break;
    if(acquired!=n){for(unsigned i=0;i<acquired;i++)ctr_syscall(74,pages[i],(size_t)0x4000,permissions[i]);return -3;}
    for(unsigned i=0;i<count;i++)ctr_memcpy((void*)changes[i].at,changes[i].next,changes[i].size);
    int result=0;for(unsigned i=0;i<n;i++)if(ctr_syscall(74,pages[i],(size_t)0x4000,permissions[i]))result=-4;
    return result;
}
int ctr_native_menu_assets(void){
    static uint8_t buffer[65536];uint8_t digest[32];uint64_t remaining=native_menu_asset_bytes;
    int64_t fd=ctr_syscall(5,ctr_assets_boot_path(),0,0);if(fd<0)return -1;int result=0;unsigned chunk=0;
    while(remaining){size_t n=remaining<sizeof(buffer)?(size_t)remaining:sizeof(buffer),used=0;
        while(used<n){int64_t got=ctr_syscall(3,fd,buffer+used,n-used);if(got<=0||(uint64_t)got>n-used){result=-2;break;}used+=(size_t)got;}
        if(result)break;ctr_sha256(buffer,n,digest);if(ctr_native_memcmp(digest,native_menu_asset_hashes[chunk++],32)){result=-3;break;}remaining-=n;
    }
    if(!result){uint8_t extra;int64_t n=ctr_syscall(3,fd,&extra,(size_t)1);if(n!=0)result=-4;}
    if(ctr_syscall(6,fd)<0)result=-5;return result;
}
int ctr_native_menu_ready(void){return installed;}
int ctr_native_menu_install(uint64_t start,const void*module,int32_t(*query)(void*,void**,void**,int32_t*),void(*trace)(int32_t,int32_t)){
    if(installed)return start==base?0:-1;
    if(!start||!module)return -1;base=start;game=*(const CtrMenuModule*)module;if(!game.count||game.count>4)return -1;
    if(ctr_native_services_init(query,trace))return -2;
    int assets=ctr_native_menu_assets();if(trace)trace(221,assets);if(assets)return -3;
    for(unsigned i=0;i<sizeof(native_menu_windows)/sizeof(*native_menu_windows);i++){const NativeMenuWindow*w=&native_menu_windows[i];if((protection(base+w->rva,16)&5)!=5||ctr_native_memcmp((void*)(base+w->rva),w->bytes,16))return -4;}
    if((protection(base+native_peer_receiver_rva,sizeof(native_peer_receiver_bytes))&5)!=5||ctr_native_memcmp((void*)(base+native_peer_receiver_rva),native_peer_receiver_bytes,sizeof(native_peer_receiver_bytes)))return -4;
    for(unsigned i=0;i<4;i++)if((protection(base+dynamic[i].rva,dynamic[i].size)&5)!=5||ctr_native_memcmp((void*)(base+dynamic[i].rva),dynamic[i].last,dynamic[i].size))return -4;
    if(ctr_syscall(74,ctr_native_menu_code,(size_t)0xc000,7))return -5;
    count=allocation=failure=0;initializing=1;uint64_t end=0;for(unsigned i=0;i<game.count;i++)if(game.segments[i].address+game.segments[i].size>end)end=game.segments[i].address+game.segments[i].size;
    int ok=runtime_online_mode_start((unsigned char*)base,end-base)&&runtime_itemless_start((unsigned char*)base,end-base)&&!ctr_native_graphics_install((unsigned char*)base,end-base)&&!failure;
    initializing=0;
    if(ctr_syscall(74,ctr_native_menu_code,(size_t)0xc000,5)){runtime_graphics_tab_ready=0;return -6;}
    if(!ok){runtime_graphics_tab_ready=0;return -7;}
    int r=commit();if(r){runtime_graphics_tab_ready=0;return -8;}
    runtime_online_mode_chosen=ctr_native_room_chosen;ctr_roommode_on_leave(runtime_online_mode_leave_cup);installed=1;return 0;
}
