// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
#define CTR_ITEM_COUNT 13
#define CTR_ITEM_TABLES 11
#define CTR_ITEM_WRITES 128
#define CTR_ITEM_BODY_MAX 65536
typedef struct {uint32_t offset,bits;char sha256[65];} CtrItemWrite;
typedef struct {
    uint32_t masks[CTR_ITEM_TABLES];
    float values[CTR_ITEM_TABLES][CTR_ITEM_COUNT];
    uint8_t order[CTR_ITEM_TABLES][CTR_ITEM_COUNT],counts[CTR_ITEM_TABLES];
    uint32_t write_count;
    CtrItemWrite writes[CTR_ITEM_WRITES];
} CtrItemRules;
typedef int (*CtrItemCheck)(uint64_t address,size_t bytes,int write);
CTR_EXPORT int ctr_items_parse(const char *body,size_t size,CtrItemRules *out);
CTR_EXPORT void ctr_items_reset(void);
CTR_EXPORT int ctr_items_accept(const char *body,size_t size);
CTR_EXPORT int ctr_items_pending(void);
CTR_EXPORT uint32_t ctr_items_skipped(void);
CTR_EXPORT int ctr_items_apply(uint64_t object,CtrItemCheck check);
void ctr_items_native_init(uint64_t base,const void *module,
    int32_t(*query)(void*,void**,void**,int32_t*),void(*trace)(int32_t,int32_t));
void ctr_items_native_tick(void);
