// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "settings.h"
#define CTR_SESSION_EVENT_BYTES 180
CTR_EXPORT void ctr_sessions_reset(void);
CTR_EXPORT void ctr_sessions_init(int32_t user,uint64_t(*clock_us)(void),void(*trace)(int32_t,int32_t));
CTR_EXPORT void ctr_sessions_ready(int ready);
CTR_EXPORT int ctr_session_queue(const char *friend_name);
CTR_EXPORT int ctr_session_due(void);
// Returns 1 only when an invitation was written, otherwise leaves output intact.
CTR_EXPORT int ctr_session_event(void *output,size_t capacity);
// Native NP metadata for an explicit local join, not a remote presence query.
CTR_EXPORT int ctr_sessions_json(const char *path,int method,char *out,size_t capacity);
