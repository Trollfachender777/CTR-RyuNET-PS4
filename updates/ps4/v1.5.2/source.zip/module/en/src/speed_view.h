// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "online_core.h"
#define CTR_SPEED_RANGES 128
typedef struct {uint64_t offset;uint32_t bytes;const uint8_t *before,*after;} CtrSpeedRange;
typedef struct {uint64_t source_bytes;uint32_t count;char guest[128];CtrSpeedRange ranges[CTR_SPEED_RANGES];} CtrSpeedView;
CTR_EXPORT int ctr_speed_view_parse(const uint8_t*,size_t,const uint8_t*,size_t,CtrSpeedView*);
// Before bytes are checked for the whole read before any byte is changed.
CTR_EXPORT int ctr_speed_view_apply(const CtrSpeedView*,uint64_t,void*,size_t);
int ctr_speed_native_init(uint64_t,const void*,int32_t(*)(void*,void**,void**,int32_t*),void*(*)(const char*),void(*)(int32_t,int32_t));
int ctr_speed_assets_ready(void);
int ctr_speed_private_now(void);
