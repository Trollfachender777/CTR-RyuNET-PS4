// SPDX-License-Identifier: GPL-2.0-only
// Explicit menu action only. No workers, scans, game calls or code patching.
#include "characters.h"
static CtrCharactersIo io;
static uint64_t image;
static int ready,busy;
typedef struct {uint64_t wrapper,control,object;uint32_t flags;uint8_t enabled;} Snapshot;
static int read_at(uint64_t at,void *out,size_t length){
    if(!io.read||!out||!length||at<0x10000||at>=0x800000000000ULL||length>0x1000||length>0x800000000000ULL-at)return -1;
    return io.read(at,out,length);
}
static int same_bytes(uint64_t rva,const uint8_t *expected,size_t length){
    uint8_t actual[32];if(length>sizeof(actual)||read_at(image+rva,actual,length))return 0;
    for(size_t n=0;n<length;n++)if(actual[n]!=expected[n])return 0;return 1;
}
static int snapshot(Snapshot *s){
    uint64_t wrapper[4];uint8_t control[0x30],object[0x98];
    if(!ready)return -1;
    if(read_at(image+0x2ab1bd0,&s->wrapper,8)||!s->wrapper)return -2;
    if((s->wrapper&7)||read_at(s->wrapper,wrapper,sizeof(wrapper)))return -3;
    if(wrapper[0]!=image+0x25d1da0)return -4;
    s->control=wrapper[2];
    if(!s->control||(s->control&7)||read_at(s->control,control,sizeof(control)))return -5;
    ctr_memcpy(&s->flags,control,4);
    // The original getter has distinct paths for these handle representations.
    // This candidate refuses them instead of guessing a second pointer chain.
    if(s->flags&0x30000000U)return -6;
    ctr_memcpy(&s->object,control+0x28,8);
    if(!s->object||(s->object&7)||read_at(s->object,object,sizeof(object)))return -7;
    uint64_t vtable;ctr_memcpy(&vtable,object,8);
    if(vtable!=image+0x25d1fa8)return -8;
    s->enabled=object[0x81];if(s->enabled>1)return -9;
    return 0;
}
CTR_EXPORT int ctr_characters_init(uint64_t base,const CtrCharactersIo *native){
    static const uint8_t getter[]={0x48,0x8b,0x05,0xd9,0x0e,0x0c,0x02,0x48,0x85,0xc0,0x74,0x01,0xc3};
    static const uint8_t meta[]={0x48,0x8b,0x05,0x19,0x39,0xa1,0x01,0xc3};
    static const uint8_t name[]="CBuildData";
    ready=0;
    if(!native||!native->read||!native->compare_byte||base<0x10000||base>=0x800000000000ULL-0x2ab1bd8)return -1;
    io=*native;image=base;ready=0;
    if(!same_bytes(0x9f0cf0,getter,sizeof(getter))||!same_bytes(0x109e2e0,meta,sizeof(meta))||!same_bytes(0x1ce8d73,name,sizeof(name)))return -2;
    uint64_t first,second;
    if(read_at(base+0x25d1fa8,&first,8)||first!=base+0x109e2e0||read_at(base+0x25d1da0,&second,8)||second!=base+0x109e410)return -3;
    ready=1;return 0;
}
CTR_EXPORT int ctr_characters_status(void){
    int zero=0;if(!__atomic_compare_exchange_n(&busy,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return -10;
    Snapshot s;int result=snapshot(&s);if(!result)result=s.enabled;
    __atomic_store_n(&busy,0,__ATOMIC_RELEASE);return result;
}
CTR_EXPORT int ctr_characters_enable(void){
    int zero=0;if(!__atomic_compare_exchange_n(&busy,&zero,1,0,__ATOMIC_ACQUIRE,__ATOMIC_RELAXED))return -10;
    Snapshot before,after;int result=snapshot(&before);
    if(result)goto done;
    result=snapshot(&after);if(result)goto done;
    if(before.wrapper!=after.wrapper||before.control!=after.control||before.object!=after.object||before.flags!=after.flags||before.enabled!=after.enabled){result=-11;goto done;}
    if(before.enabled){result=1;goto done;}
    // The sole game-data write: one verified boolean, with original value 0.
    result=io.compare_byte(before.object+0x81,0,1)?-12:1;
done:
    if(io.trace)io.trace(190,result);
    __atomic_store_n(&busy,0,__ATOMIC_RELEASE);return result;
}
