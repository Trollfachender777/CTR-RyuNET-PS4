// SPDX-License-Identifier: GPL-2.0-only
// Orbis services for the original game's UI: bounded state, no host environment.
#include "native_menu.h"
#include "native_modes_compat.h"
#include <stdarg.h>
extern int64_t ctr_syscall(int64_t,...);
#include "native_menu_symbols.h"
#include "native_heroes.h"
static int32_t(*query_memory)(void*,void**,void**,int32_t*);
static void*(*thread_self)(void);
static int32_t(*mutex_init)(void**,const void*,const char*),(*mutex_lock)(void**),(*mutex_unlock)(void**);
static int(*format_va)(char*,size_t,const char*,va_list);
static int32_t(*system_parameter)(int32_t,int32_t*);
static int32_t(*system_load_exec)(const char*,const char*[]);
static int32_t(*hero_file_stat)(const char*,void*);
static void(*service_trace)(int32_t,int32_t);
static int quit_requested;
static struct {uint64_t owner;CtrNativeThreadContext state;} contexts[64];
static struct {int used;char text[1024];} strings[32];
int runtime_graphics_tab_ready;
static void *symbol(const char *name,const char *nid){
    int32_t ids[256];uint64_t count=0;if(ctr_syscall(592,ids,(size_t)256,&count)||count>256)return 0;
    for(uint64_t i=0;i<count;i++){void*p=0;if((!ctr_syscall(591,ids[i],name,&p)&&p)||(!ctr_syscall(591,ids[i],nid,&p)&&p))return p;}return 0;
}
int ctr_native_services_init(int32_t(*query)(void*,void**,void**,int32_t*),void(*record)(int32_t,int32_t)){
    query_memory=query;
    service_trace=record;
    thread_self=(__typeof__(thread_self))symbol("scePthreadSelf",native_menu_nids[0]);
    mutex_init=(__typeof__(mutex_init))symbol("scePthreadMutexInit",native_menu_nids[1]);
    mutex_lock=(__typeof__(mutex_lock))symbol("scePthreadMutexLock",native_menu_nids[2]);
    mutex_unlock=(__typeof__(mutex_unlock))symbol("scePthreadMutexUnlock",native_menu_nids[3]);
    format_va=(__typeof__(format_va))symbol("vsnprintf",native_menu_nids[4]);
    system_parameter=(__typeof__(system_parameter))symbol("sceSystemServiceParamGetInt",native_menu_nids[5]);
    system_load_exec=(__typeof__(system_load_exec))symbol("sceSystemServiceLoadExec",native_menu_nids[6]);
    hero_file_stat=(__typeof__(hero_file_stat))symbol("sceKernelStat","eV9wAD2riIA");
    return query_memory&&thread_self&&mutex_init&&mutex_lock&&mutex_unlock&&format_va?0:-1;
}
CtrNativeThreadContext *ctr_native_mode_context(void){
    if(!thread_self)return 0;uint64_t id=(uint64_t)thread_self();if(!id)return 0;
    for(unsigned i=0;i<64;i++)if(__atomic_load_n(&contexts[i].owner,__ATOMIC_ACQUIRE)==id)return &contexts[i].state;
    for(unsigned i=0;i<64;i++){uint64_t zero=0;if(__atomic_compare_exchange_n(&contexts[i].owner,&zero,id,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE))return &contexts[i].state;}return 0;
}
int ctr_native_mutex_create(void **out){if(!out||!mutex_init)return -1;if(*out)return 0;int r=mutex_init(out,0,"RyuNET native UI");return r?r:*out?0:-1;}
void ctr_native_mutex_lock(void **mutex){if(mutex_lock&&mutex&&*mutex)mutex_lock(mutex);}
void ctr_native_mutex_unlock(void **mutex){if(mutex_unlock&&mutex&&*mutex)mutex_unlock(mutex);}
int ctr_native_safe_read(const void *address,void *out,size_t size){
    uint64_t at=(uint64_t)address;if(!query_memory||!out||!at||at>=0x800000000000ULL||size>65536||size>0x800000000000ULL-at)return 0;
    size_t offset=0;while(offset<size){void*first=0,*last=0;int32_t permission=0;uint64_t here=at+offset;
        if(query_memory((void*)here,&first,&last,&permission)||!(permission&1)||(uint64_t)first>here||(uint64_t)last<=here)return 0;
        size_t n=(uint64_t)last-here;if(n>size-offset)n=size-offset;
        ctr_memcpy((char*)out+offset,(void*)here,n);offset+=n;
    }return 1;
}
int ctr_native_memcmp(const void*a,const void*b,size_t n){const uint8_t*x=a,*y=b;for(size_t i=0;i<n;i++)if(x[i]!=y[i])return x[i]<y[i]?-1:1;return 0;}
int ctr_native_strcasecmp(const char*a,const char*b){for(;;a++,b++){unsigned x=(uint8_t)*a,y=(uint8_t)*b;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y||!x)return (int)x-(int)y;}}
const char *ctr_native_strchr(const char*text,int value){for(;;text++){if((uint8_t)*text==(uint8_t)value)return text;if(!*text)return 0;}}
int runtime_file_stat(const char*path,void*out){
    // Only the optional local character archive lookup used by v0.7.5.
    static const char prefix[]="/app0/archives/";
    if(!hero_file_stat||!path||!out||ctr_strncmp(path,prefix,sizeof(prefix)-1))return -1;
    size_t n=0;while(n<128&&path[n])n++;if(n>=128||n<sizeof(prefix)+4||ctr_strcmp(path+n-4,".pak"))return -1;
    for(size_t i=sizeof(prefix)-1;i<n-4;i++)if(!((path[i]>='a'&&path[i]<='z')||(path[i]>='0'&&path[i]<='9')||path[i]=='_'))return -1;
    return hero_file_stat(path,out);
}
int ctr_native_snprintf(char*out,size_t capacity,const char*format,...){
    if(!format_va||!out||!capacity)return -1;va_list args;va_start(args,format);int r=format_va(out,capacity,format,args);va_end(args);out[capacity-1]=0;return r;
}
int ctr_native_log(const char*format,...){(void)format;return 0;}
int ctr_native_flush(void*stream){(void)stream;return 0;}
char *ctr_native_strdup(const char*value){
    if(!value)return 0;size_t n=0;while(n<1024&&value[n])n++;if(n>=1024)return 0;
    for(unsigned i=0;i<32;i++){int zero=0;if(__atomic_compare_exchange_n(&strings[i].used,&zero,1,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE)){ctr_memcpy(strings[i].text,value,n+1);return strings[i].text;}}return 0;
}
void ctr_native_free(void*value){for(unsigned i=0;i<32;i++)if(value==strings[i].text){__atomic_store_n(&strings[i].used,0,__ATOMIC_RELEASE);return;}}
const char*ctr_native_mode_setting(const char*name){
    if(!ctr_strcmp(name,"BB_ONLINE_MODE_HOOK"))return "1277e00";
    if(!ctr_strcmp(name,"BB_KNOWN_HEROES"))return native_known_heroes;
    return 0;
}
int ctr_native_language(void){int32_t language=-1;if(system_parameter&&!system_parameter(1,&language)&&language>=0&&language<32)return language;return CTR_MODS_EN?1:3;}
void ctr_native_quit(void){
    // Raw sys_exit is not an Orbis application-close API and can raise SIGSYS.
    // Ask SystemService to perform the normal shell-managed application exit.
    int zero=0;if(!__atomic_compare_exchange_n(&quit_requested,&zero,1,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE))return;
    int32_t result=system_load_exec?system_load_exec("exit",0):-1;
    if(service_trace)service_trace(222,result);
    if(result<0){
        __atomic_store_n(&quit_requested,0,__ATOMIC_RELEASE);
        ctr_native_menu_notice(CTR_MODS_EN?"The system could not close CTR. Use PS > Close Application.":"El sistema no pudo cerrar CTR. Usa PS > Cerrar aplicacion.");
    }
}
