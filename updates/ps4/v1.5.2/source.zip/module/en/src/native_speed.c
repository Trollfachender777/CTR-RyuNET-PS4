// SPDX-License-Identifier: GPL-2.0-only
// Read-only in-memory Speed views. No writes to game archives or player files.
#include "speed_view.h"
#include "room_mode.h"
extern int64_t ctr_syscall(int64_t,...);
typedef struct {uint64_t address;uint32_t size;int32_t protection;} Segment;
typedef struct {uint64_t size;char name[256];Segment segments[4];uint32_t count;uint8_t fingerprint[20];} Module;
typedef struct {uint32_t device,inode;uint16_t mode,links;uint32_t uid,gid,rdev;uint8_t times[48];int64_t size,blocks;uint32_t blocksize,flags,generation,spare;int64_t birth_seconds,birth_ns;} Stat;
_Static_assert(sizeof(Stat)==120,"Orbis stat layout");
_Static_assert(__builtin_offsetof(Stat,size)==72,"Orbis stat size field");
#include "speed_data.h"
#include "speed_libc_profile.h"
#include "speed_source_profile.h"
extern void ctr_sha256(const uint8_t*,size_t,uint8_t*);
static CtrSpeedView views[4];
static Stat sources[4];
static Module image;
static uint64_t base;
static int ready;
static void(*read_trace)(int32_t,int32_t);
static unsigned seen_read_paths,patch_traces,stat_traces;
static void read_event(unsigned path,int active){unsigned bit=1U<<(path+(active?3:0));if(!(__atomic_fetch_or(&seen_read_paths,bit,__ATOMIC_RELAXED)&bit)&&read_trace)read_trace(228,(int)path|(active?0x100:0));}
static int32_t(*query_memory)(void*,void**,void**,int32_t*);
static int32_t(*file_stat)(const char*,Stat*),(*fd_stat)(int32_t,Stat*),(*file_no)(void*);
static int64_t(*seek_fd)(int32_t,int64_t,int32_t),(*tell_file)(void*);
static size_t(*original_fread)(void*,size_t,size_t,void*);
static int64_t(*original_read)(int32_t,void*,size_t),(*original_pread)(int32_t,void*,size_t,int64_t);
static int region(uint64_t at,size_t bytes){
    for(unsigned i=0;i<image.count&&i<4;i++){Segment *s=&image.segments[i];if(at>=s->address&&at-s->address<=s->size&&bytes<=s->size-(at-s->address))return s->protection;}return 0;
}
static int readable(uint64_t at,size_t bytes){
    if(!at||at>=0x800000000000ULL||bytes>0x800000000000ULL-at)return 0;
    if(region(at,bytes)&1)return 1;void *a=0,*b=0;int32_t p=0;
    return query_memory&&!query_memory((void*)at,&a,&b,&p)&&(p&1)&&(uint64_t)a<=at&&(uint64_t)b>=at+bytes;
}
static uint64_t pointer(uint64_t at){uint64_t p;ctr_memcpy(&p,(void*)at,8);return p;}
static int executable_in(const Module *m,uint64_t at,size_t bytes){
    for(unsigned i=0;i<m->count&&i<4;i++){const Segment *s=&m->segments[i];if((s->protection&5)==5&&at>=s->address&&at-s->address<=s->size&&bytes<=s->size-(at-s->address))return 1;}return 0;
}
static void *export_in(int32_t id,const Module *m,const char *name,const char *nid){
    void *p=0;if(!ctr_syscall(591,id,name,&p)&&p&&executable_in(m,(uint64_t)p,1))return p;
    p=0;return !ctr_syscall(591,id,nid,&p)&&p&&executable_in(m,(uint64_t)p,1)?p:0;
}
static int stream_library(int32_t id,const Module *m,uint64_t bound,int bundled){
    void *symbols[3];symbols[0]=(void*)bound;
    for(unsigned i=1;i<3;i++)if(!(symbols[i]=export_in(id,m,speed_libc_symbols[i].name,speed_libc_symbols[i].nid)))return 0;
    if(bundled)for(unsigned i=0;i<3;i++){
        const SpeedLibcSymbol *s=&speed_libc_symbols[i];uint64_t at=(uint64_t)symbols[i];
        if(at!=m->segments[0].address+s->rva||!executable_in(m,at,sizeof(s->bytes)))return 0;
        for(unsigned j=0;j<sizeof(s->bytes);j++)if(((const uint8_t*)at)[j]!=s->bytes[j])return 0;
    }
    // Commit only after all three exports and instruction windows pass.
    file_no=(__typeof__(file_no))symbols[1];tell_file=(__typeof__(tell_file))symbols[2];return 1;
}
// A symbol can exist in more than one loaded platform module. Accept a bound
// import only when its exact pointer is exported under the expected name/NID
// by a platform library or the verified libc bundled with CTR. Foreign hooks fail.
static int platform_export(const char *name,const char *nid,uint64_t value,int *owner,uint32_t *rva){
    int32_t ids[256];uint64_t count=0;*owner=0;*rva=0;
    if(!value||value>=0x800000000000ULL||ctr_syscall(592,ids,(size_t)256,&count)||count>256)return 0;
    for(uint64_t i=0;i<count;i++){
        Module m;ctr_memset(&m,0,sizeof(m));m.size=sizeof(m);
        if(ctr_syscall(593,ids[i],&m)||!m.count||m.count>4)continue;m.name[255]=0;
        if(!executable_in(&m,value,1))continue;
        const char *leaf=m.name;for(unsigned j=0;m.name[j];j++)if(m.name[j]=='/'||m.name[j]=='\\')leaf=m.name+j+1;
        int bundled=!ctr_strcmp(leaf,"libc")||!ctr_strcmp(leaf,"libc.prx")||!ctr_strcmp(leaf,"libc.sprx");
        int kind=ctr_strstr(m.name,"libSceLibcInternal")?2:ctr_strstr(m.name,"libkernel")?3:bundled?5:!ctr_strcmp(m.name,"eboot.bin")?1:4;
        *owner=kind;uint64_t relative=value-m.segments[0].address;*rva=relative>UINT32_MAX?UINT32_MAX:(uint32_t)relative;
        if(kind!=2&&kind!=3&&kind!=5)continue;
        void *p=export_in(ids[i],&m,name,nid);if((uint64_t)p!=value)continue;
        if(!ctr_strcmp(name,"fread"))return stream_library(ids[i],&m,value,bundled);
        if(!bundled)return 1;
    }return 0;
}
int ctr_speed_assets_ready(void){return __atomic_load_n(&ready,__ATOMIC_ACQUIRE);}
int ctr_speed_private_now(void){
    if(!ctr_speed_assets_ready()||!(region(base+0x2a92868,0x28)&1)||!*(const uint8_t*)(base+0x2a92868))return 0;
    // The upstream selector reads this same network object's game-type field.
    // Battle never inherits a remembered private Speed choice.
    if(!(region(base+0x2acb3d8,8)&1))return 0;
    uint64_t network=pointer(base+0x2acb3d8);if(!readable(network,0x140))return 0;
    uint32_t game_type;ctr_memcpy(&game_type,(void*)(network+0x13c),4);if(game_type>=2)return 0;
    uint32_t id,invalid;ctr_memcpy(&id,(void*)(base+0x2a92888),4);ctr_memcpy(&invalid,(void*)(base+0x2a922d0),4);
    if(id==invalid||!(id&0x8000))return 0;
    uint64_t root=pointer(base+0x2a92880);if(!readable(root,0x30))return 0;
    uint64_t list=pointer(root+0x28),objects=pointer(root+0x20);if(!readable(list,0x28))return 0;
    uint32_t count;ctr_memcpy(&count,(void*)(list+0xc),4);uint32_t index=id&0x7fff;
    if(count>65536||index>=count)return 0;
    uint64_t ids=pointer(list+0x20);if(!readable(ids+index*2,2)||!readable(objects+index*8,8))return 0;
    uint16_t token;ctr_memcpy(&token,(void*)(ids+index*2),2);if(token!=(uint16_t)id)return 0;
    uint64_t object=pointer(objects+index*8);if(!readable(object,0x50)||!readable(pointer(object),8)||!readable(pointer(base+0x2ae3230),8))return 0;
    unsigned char yes=0,no=0;((void(*)(unsigned char*,unsigned char*))(base+0xf50350))(&yes,&no);return yes!=0;
}
static int supported_header(int32_t fd,unsigned index){
    uint8_t header[512],digest[32];size_t used=0;
    // Positional reads preserve the game's FILE/descriptor position. PFS stat
    // and fstat may report different identities for the same mounted PAK.
    while(used<sizeof(header)){
        int64_t n=original_pread(fd,header+used,sizeof(header)-used,(int64_t)used);
        if(n<=0||(uint64_t)n>sizeof(header)-used)return 0;used+=(size_t)n;
    }
    ctr_sha256(header,sizeof(header),digest);
    for(unsigned i=0;i<sizeof(digest);i++)if(digest[i]!=speed_source_headers[index][i])return 0;
    return 1;
}
static int select_view(int32_t fd){
    Stat s;ctr_memset(&s,0,sizeof(s));if(fd<0||fd_stat(fd,&s)||((s.mode&0170000)!=0100000)||s.size<0)return -1;
    for(unsigned i=0;i<4;i++){
        if((uint64_t)s.size!=views[i].source_bytes)continue;
        int identity=s.device==sources[i].device&&s.inode==sources[i].inode;
        int content=!identity&&supported_header(fd,i);
        if(read_trace&&__atomic_fetch_add(&stat_traces,1,__ATOMIC_RELAXED)<8)read_trace(230,(int)i|(identity?0x100:0)|(content?0x200:0));
        if(identity||content)return (int)i;
    }
    return -1;
}
static int apply(int index,int64_t at,void *data,size_t size){
    if(index<0||at<0)return 0;
    int result=ctr_speed_view_apply(&views[index],(uint64_t)at,data,size),overlap=0;
    for(uint32_t i=0;i<views[index].count;i++){const CtrSpeedRange*r=&views[index].ranges[i];if((uint64_t)at<r->offset+r->bytes&&r->offset<(uint64_t)at+size){overlap=1;break;}}
    if(overlap&&read_trace&&__atomic_fetch_add(&patch_traces,1,__ATOMIC_RELAXED)<16)read_trace(229,(index<<16)|(result&0xffff));return result;
}
static size_t read_file(void *data,size_t size,size_t count,void *file){
    int active=ctr_speed_assets_ready()&&__atomic_load_n(&ctr_speed_active,__ATOMIC_ACQUIRE);
    read_event(0,active);
    int index=active?select_view(file_no(file)):-1;int64_t at=index<0?-1:tell_file(file);
    size_t n=original_fread(data,size,count,file);
    if(n&&size&&n<=SIZE_MAX/size&&index>=0&&apply(index,at,data,n*size))return 0;return n;
}
static int64_t read_at(int32_t fd,void *data,size_t size,int64_t at){
    int active=ctr_speed_assets_ready()&&__atomic_load_n(&ctr_speed_active,__ATOMIC_ACQUIRE);read_event(1,active);int index=active?select_view(fd):-1;
    int64_t n=original_pread(fd,data,size,at);if(n>0&&(uint64_t)n<=size&&apply(index,at,data,(size_t)n))return -1;return n;
}
static int64_t read_next(int32_t fd,void *data,size_t size){
    int active=ctr_speed_assets_ready()&&__atomic_load_n(&ctr_speed_active,__ATOMIC_ACQUIRE);read_event(2,active);int index=active?select_view(fd):-1;
    int64_t at=index<0?-1:seek_fd(fd,0,1);int64_t n=original_read(fd,data,size);
    if(n>0&&(uint64_t)n<=size&&apply(index,at,data,(size_t)n))return -1;return n;
}
int ctr_speed_native_init(uint64_t start,const void *module,int32_t(*query)(void*,void**,void**,int32_t*),void*(*resolve)(const char*),void(*trace)(int32_t,int32_t)){
    ready=0;base=0;read_trace=trace;seen_read_paths=patch_traces=stat_traces=0;if(!start||!module||!query||!resolve)return -1;image=*(const Module*)module;query_memory=query;
    static const uint8_t signature[]={0x55,0x48,0x89,0xe5,0x41,0x57,0x41,0x56};
    if((region(start+0xf50350,8)&5)!=5||!(region(start+0x2a922d0,4)&1))return -2;
    for(unsigned i=0;i<8;i++)if(((const uint8_t*)(start+0xf50350))[i]!=signature[i])return -2;
    #define GET(field,name) field=(__typeof__(field))resolve(name);if(!field)return -3
    GET(file_stat,"sceKernelStat");GET(fd_stat,"sceKernelFstat");GET(file_no,"fileno");GET(seek_fd,"sceKernelLseek");GET(tell_file,"ftell");
    GET(original_fread,"fread");GET(original_read,"sceKernelRead");GET(original_pread,"sceKernelPread");
    #undef GET
    for(unsigned i=0;i<4;i++){
        if(ctr_speed_view_parse(speed_data[i].normal,speed_data[i].normal_bytes,speed_data[i].speed,speed_data[i].speed_bytes,&views[i]))return -4;
        ctr_memset(&sources[i],0,sizeof(Stat));
        if(file_stat(views[i].guest,&sources[i])||sources[i].size<0||(uint64_t)sources[i].size!=views[i].source_bytes||((sources[i].mode&0170000)!=0100000))return -5;
    }
    const uint64_t got[]={41975936,41977672,41978568},lazy[]={29268520,29271992,29273784};
    const char *names[]={"fread","sceKernelPread","sceKernelRead"},*nids[]={"lbB+UlZqVG0","+r3rMFwItV4","Cg4srZ6TKbU"};
    uint64_t expected[]={(uint64_t)original_fread,(uint64_t)original_pread,(uint64_t)original_read};
    uint64_t replacement[]={(uint64_t)read_file,(uint64_t)read_at,(uint64_t)read_next},old[3],pages[3];int permissions[3];unsigned page_count=0;
    for(unsigned i=0;i<3;i++){
        uint64_t at=start+got[i];int p=region(at,8);if(!(p&1))return -6;old[i]=__atomic_load_n((uint64_t*)at,__ATOMIC_ACQUIRE);
        if(old[i]!=expected[i]&&old[i]!=start+lazy[i]){
            int owner;uint32_t rva;
            if(!platform_export(names[i],nids[i],old[i],&owner,&rva)){
                if(trace){trace(204,(int)i);trace(205,owner);trace(206,(int32_t)rva);}return -7;
            }
            if(i==0)original_fread=(__typeof__(original_fread))old[i];else if(i==1)original_pread=(__typeof__(original_pread))old[i];else original_read=(__typeof__(original_read))old[i];
            if(trace)trace(207,(int)i);
        }
        uint64_t page=at&~0x3fffULL;unsigned j=0;while(j<page_count&&pages[j]!=page)j++;
        if(j==page_count){pages[j]=page;permissions[j]=p;page_count++;}else if(permissions[j]!=p)return -6;
    }
    unsigned writable=0;for(;writable<page_count;writable++)if(ctr_syscall(74,pages[writable],0x4000,permissions[writable]|2))break;
    if(writable!=page_count){for(unsigned j=0;j<writable;j++)ctr_syscall(74,pages[j],0x4000,permissions[j]);return -8;}
    unsigned installed=0;for(;installed<3;installed++){uint64_t was=old[installed];if(!__atomic_compare_exchange_n((uint64_t*)(start+got[installed]),&was,replacement[installed],0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE))break;}
    if(installed!=3)for(unsigned j=0;j<installed;j++){uint64_t ours=replacement[j];__atomic_compare_exchange_n((uint64_t*)(start+got[j]),&ours,old[j],0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE);}
    for(unsigned j=0;j<page_count;j++){int r=(int)ctr_syscall(74,pages[j],0x4000,permissions[j]);if(trace)trace(203,r);}
    if(installed!=3)return -9;base=start;__atomic_store_n(&ready,1,__ATOMIC_RELEASE);return 0;
}
