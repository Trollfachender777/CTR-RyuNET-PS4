// SPDX-License-Identifier: GPL-2.0-only
#pragma once
#include "settings.h"
#define CTR_SOCIAL_MAX 200
#define CTR_SOCIAL_PENDING 50
#define CTR_SOCIAL_INVITES 16
enum {CTR_SOCIAL_OFF,CTR_SOCIAL_WAITING,CTR_SOCIAL_READY,CTR_SOCIAL_NETWORK,CTR_SOCIAL_REFUSED};
typedef struct {char name[17];int32_t online,players,max;} CtrSocialFriend;
typedef struct {char from[17];uint32_t ago;} CtrSocialInvite;
typedef struct {
    int32_t state,status;uint32_t serial,count,incoming_count,outgoing_count,invite_count;
    CtrSocialFriend friends[CTR_SOCIAL_MAX];
    char incoming[CTR_SOCIAL_PENDING][17],outgoing[CTR_SOCIAL_PENDING][17];
    CtrSocialInvite invites[CTR_SOCIAL_INVITES];char result[24],who[17];
} CtrSocialView;
typedef struct {
    int (*spawn)(void *(*)(void*),void*);
    int (*request)(const char*,const char*,char*,size_t);
    uint64_t (*time_us)(void);
} CtrSocialApi;
CTR_EXPORT int ctr_social_init(const CtrSocialApi*);
CTR_EXPORT void ctr_social_tick(void);
CTR_EXPORT int ctr_social_snapshot(CtrSocialView*);
CTR_EXPORT int ctr_social_action(const char*,const char*);
CTR_EXPORT int ctr_social_parse(const char*,size_t,CtrSocialView*);
CTR_EXPORT int ctr_social_contacts(CtrSettings*);
CTR_EXPORT int ctr_social_contact(const char*);
// Same HMAC-SHA256 wire proof as OCTR v0.6.4 runtime_http.c. Never logs keys.
CTR_EXPORT int ctr_social_proof(const char*,const char*,uint64_t,const char*,char*,size_t);
CTR_EXPORT int64_t ctr_social_http_date(const char*,size_t);

CTR_EXPORT int ctr_social_key_hash(char out[65]);
