"""Actual C room-mode state machine and bounded compressed resource views."""
import ctypes as C,random,struct,unittest
import test_core as core
from test_settings_menu import Menu,defaults
lib=core.lib
Spawn=C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_void_p);Request=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_char_p,C.c_void_p,C.c_size_t)
Clock=C.CFUNCTYPE(C.c_uint64);Flag=C.CFUNCTYPE(C.c_int)
class Api(C.Structure):_fields_=[('spawn',Spawn),('request',Request),('clock',Clock),('private',Flag),('assets',Flag),('peers',Flag)]
class View(C.Structure):_fields_=[(n,C.c_int32) for n in ('role','selected','following','confirmed','available','active','status')]+[('generation',C.c_uint32),('host',C.c_char*17)]
class Range(C.Structure):_fields_=[('offset',C.c_uint64),('bytes',C.c_uint32),('before',C.c_void_p),('after',C.c_void_p)]
class Patches(C.Structure):_fields_=[('source_bytes',C.c_uint64),('count',C.c_uint32),('guest',C.c_char*128),('ranges',Range*128)]
lib.ctr_roommode_init.argtypes=[C.c_void_p];lib.ctr_roommode_joined.argtypes=[C.c_char_p];lib.ctr_roommode_snapshot.argtypes=[C.POINTER(View)]
lib.ctr_roommode_parse.argtypes=[C.c_char_p,C.c_size_t,C.POINTER(C.c_int)]
lib.ctr_speed_view_parse.argtypes=[C.c_void_p,C.c_size_t,C.c_void_p,C.c_size_t,C.POINTER(Patches)]
lib.ctr_speed_view_apply.argtypes=[C.POINTER(Patches),C.c_uint64,C.c_void_p,C.c_size_t]
class Room(unittest.TestCase):
 def setUp(self):
  self.core=core.Api();lib.ctr_core_init(C.byref(self.core),b'FirstPlayer');s=defaults();lib.ctr_settings_publish(C.byref(s))
  self.now=1;self.private=1;self.assets=1;self.peers=1;self.tasks=[];self.calls=[];self.status=200;self.body=b'mode speed\n';self.spawn_result=0
  def spawn(fn,arg):
   if not self.spawn_result:self.tasks.append((fn,arg))
   return self.spawn_result
  def request(method,target,out,cap):
   self.calls.append((method,target));C.memmove(out,self.body+b'\0',min(cap,len(self.body)+1));return self.status
  self.api=Api(Spawn(spawn),Request(request),Clock(lambda:self.now),Flag(lambda:self.private),Flag(lambda:self.assets),Flag(lambda:self.peers))
  self.assertEqual(lib.ctr_roommode_init(C.byref(self.api)),0)
 def tearDown(self):
  while self.tasks:self.finish()
  lib.ctr_roommode_init(None)
 def finish(self):fn,arg=self.tasks.pop(0);C.CFUNCTYPE(C.c_void_p,C.c_void_p)(fn)(arg)
 def view(self):v=View();self.assertEqual(lib.ctr_roommode_snapshot(C.byref(v)),0);return v
 def test_host_publishes_own_identity_and_requires_confirmation_and_private_context(self):
  self.assertEqual(lib.ctr_roommode_choose(1),0);lib.ctr_roommode_hosting();lib.ctr_roommode_tick();self.assertFalse(self.calls);self.assertEqual(self.view().active,0)
  self.finish();self.assertEqual(self.calls,[(b'POST',b'/ryunet/room-mode?name=FirstPlayer&mode=speed&format=text')]);lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  self.peers=0;lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  self.private=0;lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_guest_follows_host_and_never_overrides_the_host_choice(self):
  lib.ctr_roommode_joined(b'cusa13795-session-OtherPlayer');lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick()
  self.assertEqual(self.calls[0],(b'GET',b'/ryunet/room-mode?host=OtherPlayer&format=text'));self.assertEqual(self.view().active,1);self.assertEqual(lib.ctr_roommode_choose(0),-2)
  self.body=b'mode normal';self.now+=2000000;lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_join_discards_a_pending_choice_from_the_previous_local_menu(self):
  lib.ctr_roommode_native_choose(1,1);lib.ctr_roommode_native_requested(1)
  lib.ctr_roommode_joined(b'cusa13795-session-OtherPlayer');lib.ctr_roommode_tick()
  self.assertEqual(self.view().role,2);self.finish();lib.ctr_roommode_tick()
  self.assertEqual(self.calls,[(b'GET',b'/ryunet/room-mode?host=OtherPlayer&format=text')])
  self.assertEqual(self.view().confirmed,1);self.assertEqual(self.view().active,1)
 def test_guest_itemless_does_not_depend_on_seeing_the_hosts_native_selector(self):
  self.private=0;lib.ctr_roommode_joined(b'cusa13795-session-OtherPlayer');lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  self.peers=0;lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_native_host_selection_survives_selector_close_and_public_pick_disables_it(self):
  self.private=0;lib.ctr_roommode_native_choose(1,1);lib.ctr_roommode_native_requested(1);lib.ctr_roommode_tick();self.assertEqual(self.view().active,1);self.finish();self.assertIn(b'mode=speed',self.calls[-1][1])
  lib.ctr_roommode_native_choose(0,0);lib.ctr_roommode_native_requested(0);lib.ctr_roommode_tick();self.assertEqual(self.view().active,0);self.finish();self.assertIn(b'mode=normal',self.calls[-1][1])
 def test_native_private_host_works_without_port_3074_peer_detection(self):
  self.peers=0;lib.ctr_roommode_native_choose(1,1);lib.ctr_roommode_native_requested(1);lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
 def test_confirmed_private_guest_works_without_port_3074_peer_detection(self):
  self.peers=0;lib.ctr_roommode_joined(b'cusa13795-session-OtherPlayer');lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
 def test_private_map_keeps_itemless_during_loading_and_next_public_map_clears_it(self):
  self.peers=0;lib.ctr_roommode_joined(b'cusa13795-session-OtherPlayer');lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  lib.ctr_roommode_native_map(1);self.private=0;self.now+=30000000;lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  lib.ctr_roommode_native_map(0);self.assertEqual(self.view().active,0);self.peers=1;self.private=1;lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_native_map_consumes_pending_host_choice_before_loading_and_obeys_missing_assets(self):
  self.peers=0;self.private=0;lib.ctr_roommode_native_choose(1,1);lib.ctr_roommode_native_requested(1)
  lib.ctr_roommode_native_map(1);self.assertEqual(self.view().active,1)
  self.assets=0;lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
  self.assets=1;lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  lib.ctr_roommode_left();lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_native_cup_leave_callback_runs_on_tick_instead_of_a_service_worker(self):
  events=[];callback=C.CFUNCTYPE(None)(lambda:events.append(1));lib.ctr_roommode_on_leave.argtypes=[C.c_void_p];lib.ctr_roommode_on_leave(callback)
  lib.ctr_roommode_left();self.assertFalse(events);lib.ctr_roommode_tick();self.assertEqual(events,[1]);lib.ctr_roommode_on_leave(None)
 def test_stale_response_cannot_reenable_speed_after_leave_or_host_replacement(self):
  for operation in (lambda:lib.ctr_roommode_left(),lambda:lib.ctr_roommode_joined(b'cusa13795-session-NewHost')):
   lib.ctr_roommode_joined(b'cusa13795-session-OldHost');lib.ctr_roommode_tick();operation();self.finish();self.assertEqual(self.view().confirmed,0)
   self.now+=2000000;lib.ctr_roommode_tick()
   if self.tasks:self.finish()
 def test_public_transition_publishes_normal_and_restores_separate_private_choice(self):
  lib.ctr_roommode_choose(1);lib.ctr_roommode_hosting();lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,1)
  self.private=0;lib.ctr_roommode_tick();self.assertEqual(self.view().active,0);self.finish();self.assertIn(b'mode=normal',self.calls[-1][1]);self.assertEqual(self.view().selected,1)
 def test_bad_or_missing_reply_never_claims_speed_confirmation(self):
  for status,body in ((404,b''),(200,b'mode corrupt'),(503,b'mode speed')):
   lib.ctr_roommode_left();self.status=status;self.body=body;self.now+=2000000;lib.ctr_roommode_joined(b'cusa13795-session-OtherPlayer');lib.ctr_roommode_tick();self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_no_assets_no_public_speed_and_no_synchronous_http(self):
  self.assets=0;self.assertEqual(lib.ctr_roommode_choose(1),-3);lib.ctr_roommode_hosting();lib.ctr_roommode_tick();self.assertFalse(self.calls);self.finish();lib.ctr_roommode_tick();self.assertEqual(self.view().active,0)
 def test_spawn_failure_retries_without_locking_ui(self):
  self.spawn_result=-1;lib.ctr_roommode_hosting();lib.ctr_roommode_tick();self.assertFalse(self.tasks);self.assertEqual(self.view().status,-1)
  self.spawn_result=0;self.now+=2000000;lib.ctr_roommode_tick();self.assertEqual(len(self.tasks),1)
 def test_strict_response_parser_leaves_output_unchanged_on_failure(self):
  for body in (b'',b'mode speed extra',b'mode speed\0',b'xmode speed',b'mode normal!'):
   out=C.c_int(9);self.assertEqual(lib.ctr_roommode_parse(body,len(body),C.byref(out)),-1);self.assertEqual(out.value,9)
  for body,expected in ((b'\r\nmode speed\n',1),(b'mode normal',0)):
   out=C.c_int(9);self.assertEqual(lib.ctr_roommode_parse(body,len(body),C.byref(out)),0);self.assertEqual(out.value,expected)
 def test_menu_has_updates_room_and_no_mods_and_preserves_other_settings(self):
  m=Menu();m.open();m.choose(2);self.assertNotIn('speed',m.shown[-1][0].lower());m.choose(2);self.assertNotIn('speed',m.shown[-1][0].lower());self.assertFalse(m.saved);self.assertFalse(m.errors)

def encoded(size,path,ranges):
 return b'BBPAK001'+struct.pack('<QI',size,len(path))+path+struct.pack('<I',len(ranges))+b''.join(struct.pack('<QI',at,len(data))+data for at,data in ranges)
class Resources(unittest.TestCase):
 def create(self,ranges=None,size=6*1024**3):
  ranges=ranges or [(0x100000004,b'abcdef'),(0x100000020,b'ghi')];self.a=encoded(size,b'/app0/archives/update2.pak',ranges);self.b=encoded(size,b'/app0/archives/update2.pak',[(at,data.upper()) for at,data in ranges]);v=Patches();self.assertEqual(lib.ctr_speed_view_parse(self.a,len(self.a),self.b,len(self.b),C.byref(v)),0);return v
 def test_split_reads_above_4gib_and_guard_bytes(self):
  v=self.create();data=C.create_string_buffer(b'!bcde!');self.assertEqual(lib.ctr_speed_view_apply(C.byref(v),0x100000005,C.byref(data,1),4),0);self.assertEqual(data.raw[:6],b'!BCDE!')
 def test_all_preimages_checked_before_first_write(self):
  v=self.create([(10,b'abc'),(20,b'def')],100);raw=bytearray(30);raw[10:13]=b'abc';raw[20:23]=b'bad';data=C.create_string_buffer(bytes(raw));before=data.raw
  self.assertEqual(lib.ctr_speed_view_apply(C.byref(v),0,data,30),-2);self.assertEqual(data.raw,before)
 def test_invalid_headers_ranges_overlaps_paths_and_truncations_leave_output_unchanged(self):
  self.create();out=Patches();C.memset(C.byref(out),0xa5,C.sizeof(out));before=bytes(out)
  bad=[b'',self.a[:-1],self.a+b'x',encoded(100,b'/app0/archives/../x.pak',[(1,b'x')]),encoded(100,b'/app0/archives/x.pak\0z',[(1,b'x')]),encoded(100,b'/app0/archives/x.pak',[(10,b'abc'),(11,b'x')]),encoded(100,b'/app0/archives/x.pak',[(99,b'abc')])]
  for a in bad:self.assertEqual(lib.ctr_speed_view_parse(a,len(a),self.b,len(self.b),C.byref(out)),-1);self.assertEqual(bytes(out),before)
 def test_bounds_and_overflow_are_rejected(self):
  v=self.create();data=C.create_string_buffer(8)
  for at,n in ((v.source_bytes+1,0),(v.source_bytes-1,2),(2**64-2,5)):
   self.assertEqual(lib.ctr_speed_view_apply(C.byref(v),at,data,n),-1)
  v.ranges[0].offset=2**64-1;self.assertEqual(lib.ctr_speed_view_apply(C.byref(v),0,data,8),-1)
 def test_random_truncations_never_publish_partial_views(self):
  self.create();out=Patches();random.seed(72)
  for _ in range(150):
   a=self.a[:random.randrange(len(self.a))];C.memset(C.byref(out),0xa5,C.sizeof(out));before=bytes(out)
   self.assertEqual(lib.ctr_speed_view_parse(a,len(a),self.b,len(self.b),C.byref(out)),-1);self.assertEqual(bytes(out),before)
if __name__=='__main__':unittest.main(verbosity=2)
