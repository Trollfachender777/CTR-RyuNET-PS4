"""Actual candidate SELF: real post-load table layout and no profile mutations."""
import json,struct,unittest
from test_items import TABLES,BLOB,pc
from test_native_bridge import ModuleMachine,prepare,SCRATCH,UI
from test_native_updates import UpdateMachine

BASE=0x900000000;DATA=0x7200000000;OWNER=DATA+0xf0000
class Tests(unittest.TestCase):
    def invoke(self,m,name,*args):return m.call(m.exports[prepare.nid(name)],*args)
    def fixture(self,permission=3,bad_tag=False,machine=None):
        m=machine or ModuleMachine('ui_items');m.map(DATA,0x100000);m.allowed.append((DATA,DATA+0x100000))
        m.map(SCRATCH,0x4000);m.allowed.append((SCRATCH,SCRATCH+0x4000))
        data=bytearray(TABLES.igz.data)
        for at in TABLES.igz.sites['ROFS']:
            value=struct.unpack_from('<Q',data,at)[0];struct.pack_into('<Q',data,at,DATA+value)
        struct.pack_into('<Q',data,TABLES.data,BASE+0x26bc7a0+(8 if bad_tag else 0))
        m.uc.mem_write(DATA,bytes(data));m.uc.mem_write(BASE+0x2ad9c38,struct.pack('<Q',OWNER))
        m.uc.mem_write(OWNER+0xf8,struct.pack('<Q',DATA+TABLES.data))
        m.query_first=DATA;m.query_last=DATA+0x100000;m.query_permission=permission
        self.assertEqual(m.initialize(),0);return m
    def accept(self,m,rules):
        body=json.dumps({'theme':'halloween','items':rules}).encode();m.uc.mem_write(SCRATCH,body)
        self.assertEqual(self.invoke(m,'ctr_items_accept',SCRATCH,len(body)),0)
    def pad(self,m):
        record=next(r for r in UI['imports'] if r['name']=='scePadReadState')
        hook=struct.unpack('<Q',m.uc.mem_read(BASE+record['got'],8))[0]
        return m.call(hook,7,SCRATCH+0x1000)
    def test_real_self_applies_pc_rules_via_existing_pad_hook_without_user_file_writes(self):
        m=self.fixture();before=dict(m.files);rules={'race':[{'Bomb':77,'Super Engine':50}],'cooldowns':{'Warp Orb':5}}
        self.accept(m,rules);self.assertEqual(self.pad(m),0)
        self.assertEqual(self.invoke(m,'ctr_items_pending'),0)
        actual=bytearray(m.uc.mem_read(DATA,len(TABLES.igz.data)))
        original=bytes(TABLES.igz.data)
        for at in TABLES.igz.sites['ROFS']:actual[at:at+8]=original[at:at+8]
        actual[TABLES.data:TABLES.data+8]=original[TABLES.data:TABLES.data+8]
        expected,_=pc.apply(BLOB,rules)
        self.assertEqual(bytes(actual),bytes(pc.Tables(expected).igz.data))
        self.assertEqual({p:v for p,v in m.files.items() if not p.endswith('ctr_native_port.log')},
                         {p:v for p,v in before.items() if not p.endswith('ctr_native_port.log')})
    def test_no_rules_mean_no_heap_access_or_game_changes(self):
        m=self.fixture();before=bytes(m.uc.mem_read(DATA,0x100000));queries=m.query_count
        self.assertEqual(self.pad(m),0);self.assertEqual(m.query_count,queries)
        self.assertEqual(bytes(m.uc.mem_read(DATA,0x100000)),before)
    def test_downloaded_theme_publishes_item_rules_before_existing_pad_hook_applies_them(self):
        body=b'{"theme":"halloween","items":{"race":[{"Bomb":77}]}}'
        m=self.fixture(machine=UpdateMachine(response=body));at=TABLES.weights(TABLES.sections()['race'][0])['Bomb']
        before=bytes(m.uc.mem_read(DATA+at,4));self.invoke(m,'ctr_season_tick')
        self.assertEqual(bytes(m.uc.mem_read(DATA+at,4)),before);m.finish()
        self.assertEqual(self.invoke(m,'ctr_items_pending'),1);self.assertEqual(self.pad(m),0)
        self.assertEqual(bytes(m.uc.mem_read(DATA+at,4)),struct.pack('<f',77))
    def test_wrong_type_or_readonly_memory_cannot_partially_patch_the_game(self):
        for permission,bad_tag in ((1,False),(3,True)):
            m=self.fixture(permission,bad_tag);self.accept(m,{'race':[{'Bomb':77}]*8})
            before=bytes(m.uc.mem_read(DATA,0x100000));self.assertEqual(self.pad(m),0)
            self.assertEqual(bytes(m.uc.mem_read(DATA,0x100000)),before)
            self.assertEqual(self.invoke(m,'ctr_items_pending'),1)
    def test_exact_supported_game_signatures_are_only_read_not_rewritten(self):
        m=self.fixture();self.accept(m,{'battle':{'Missile':0}})
        sites=[(BASE+0x9b9ec0,13),(BASE+0x117e140,8)]
        before=[bytes(m.uc.mem_read(p,n)) for p,n in sites];self.pad(m)
        self.assertEqual([bytes(m.uc.mem_read(p,n)) for p,n in sites],before)
if __name__=='__main__':unittest.main(verbosity=2)
