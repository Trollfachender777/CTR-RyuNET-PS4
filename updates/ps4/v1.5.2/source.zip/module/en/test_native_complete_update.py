"""Actual PS4 SELF: asset HTTP policy and early migration guard."""
import struct,unittest
from test_native_bridge import ModuleMachine,prepare,SCRATCH
from test_native_updates import UpdateMachine
from test_native_speed import SYMBOLS
class Tests(unittest.TestCase):
    def test_missing_assets_stop_new_hooks_before_user_or_network_initialization(self):
        m=ModuleMachine('ui_updates');before=dict(m.files)
        m.uc.mem_write(m.exports[prepare.nid('ctr_assets_boot_source')],b'\x31\xc0\xc3')
        self.assertEqual(m.initialize()&0xffffffff,(-100)&0xffffffff)
        self.assertEqual({p:v for p,v in m.files.items() if p!='/data/GoldHEN/ctr_native_port.log'},before)
        self.assertIn(b'assets missing',m.files['/data/GoldHEN/ctr_native_port.log'])
        self.assertEqual(m.cache_writes,[]);self.assertEqual(m.ui_writes,[])
    def test_asset_fetch_uses_pinned_https_url_full_tls_verification_and_owned_cleanup(self):
        m=UpdateMachine(response=b'fixture-resource');self.assertEqual(m.initialize(),0);before=dict(m.files)
        out=SCRATCH+0x100000;m.map(out,0x700000);m.allowed.append((out,out+0x700000))
        self.assertEqual(m.call(SYMBOLS['ctr_assets_fetch'],out,7204396,SCRATCH),0)
        self.assertEqual(struct.unpack('<Q',m.uc.mem_read(SCRATCH,8))[0],16)
        url='https://raw.githubusercontent.com/Trollfachender777/CTR-RyuNET-PS4/main/updates/ps4/assets/ui-5b4a4062b75966fa.pak'
        self.assertEqual(m.requested,[url,url]);self.assertEqual(m.policy['sceHttpsEnableOption'],(604,0xbd));self.assertEqual(m.policy['sceHttpSetAutoRedirect'],(604,0));self.assertEqual(len(m.cleanup),6);self.assertEqual(m.files,before)
        self.assertFalse(any('Key' in name or 'Proof' in name or 'Authorization' in name for _,name,_,_ in m.http_headers))
    def test_invalid_capacity_and_failed_http_are_not_accepted_as_resources(self):
        m=UpdateMachine(status=404);self.assertEqual(m.initialize(),0)
        self.assertNotEqual(m.call(SYMBOLS['ctr_assets_fetch'],SCRATCH,1024,SCRATCH+128)&0xffffffff,0);self.assertFalse(m.requested)
        self.assertNotEqual(m.call(SYMBOLS['ctr_assets_fetch'],SCRATCH,7204396,SCRATCH+128)&0xffffffff,0);self.assertEqual(len(m.cleanup),6)
    def test_migration_worker_uses_the_existing_native_detached_thread_abi(self):
        m=UpdateMachine();self.assertEqual(m.initialize(),0)
        self.assertEqual(m.call(SYMBOLS['ctr_assets_download_start'],SYMBOLS['ctr_assets_fetch'],SCRATCH),0)
        self.assertEqual(m.detached,[1]);self.assertEqual(m.tasks,[(SYMBOLS['ctr_assets_fetch'],SCRATCH)]);self.assertFalse(m.requested)
if __name__=='__main__':unittest.main(verbosity=2)
