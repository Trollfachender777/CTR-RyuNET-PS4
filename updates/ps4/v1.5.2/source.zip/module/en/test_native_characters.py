"""Execute the PS4 SELF and real permission/CAS adapter under emulation."""
import unittest,struct
from test_native_bridge import ModuleMachine,SCRATCH,prepare
from unicorn import UC_HOOK_MEM_WRITE
BASE=0x900000000

class Tests(unittest.TestCase):
    def model(self,permission=3):
        m=ModuleMachine('ui_characters');self.assertEqual(m.initialize(),0)
        self.assertIn(b'CTR native stage=000000bd code=00000000',m.files['/data/GoldHEN/ctr_native_port.log'])
        wrapper,control,obj=SCRATCH+0x400,SCRATCH+0x500,SCRATCH+0x600
        m.uc.mem_write(BASE+0x2ab1bd0,struct.pack('<Q',wrapper))
        m.uc.mem_write(wrapper,struct.pack('<QQQQ',BASE+0x25d1da0,0,control,0))
        c=bytearray(48);struct.pack_into('<I',c,0,2);struct.pack_into('<Q',c,40,obj);m.uc.mem_write(control,bytes(c))
        o=bytearray([0x5a]*152);struct.pack_into('<Q',o,0,BASE+0x25d1fa8);o[0x80]=1;o[0x81]=0;m.uc.mem_write(obj,bytes(o))
        m.query_first=SCRATCH;m.query_last=SCRATCH+0x1000;m.query_permission=permission
        m.allowed.append((obj+0x81,obj+0x82))
        writes=[]
        def watch(uc,access,at,size,value,user):
            if SCRATCH<=at<SCRATCH+0x1000:writes.append((at,size,value))
        m.uc.hook_add(UC_HOOK_MEM_WRITE,watch)
        return m,obj,writes
    def call(self,m,name):return m.call(m.exports[prepare.nid(name)])
    def test_actual_self_writes_only_one_byte_after_explicit_action(self):
        m,obj,writes=self.model();before=bytes(m.uc.mem_read(obj,152))
        self.assertEqual(self.call(m,'ctr_characters_status'),0)
        self.assertEqual(writes,[])
        self.assertEqual(self.call(m,'ctr_characters_enable'),1)
        after=bytes(m.uc.mem_read(obj,152))
        self.assertEqual([i for i,(a,b) in enumerate(zip(before,after)) if a!=b],[0x81])
        self.assertEqual(writes,[(obj+0x81,1,1)])
        self.assertEqual(self.call(m,'ctr_characters_status'),1)
        self.assertEqual(self.call(m,'ctr_characters_enable'),1)
        self.assertEqual(len(writes),1)
    def test_readonly_object_is_not_written(self):
        m,obj,writes=self.model(1)
        self.assertEqual(self.call(m,'ctr_characters_enable'),0xfffffff4)
        self.assertEqual(writes,[]);self.assertEqual(m.uc.mem_read(obj+0x81,1),b'\0')
    def test_menu_navigation_only_writes_after_activate(self):
        m,obj,writes=self.model();before={k:v for k,v in m.files.items() if '/users/' in k}
        poll=m.exports[prepare.nid('ctr_menu_poll')]
        def choose(button):
            m.dialog_chosen=button;m.dialog_status=3;m.call(poll,7,0)
        m.call(poll,7,6)
        for button in (2,1,2,2):choose(button)
        self.assertEqual(writes,[])
        choose(2);choose(2)
        self.assertEqual(writes,[])
        choose(1)
        self.assertEqual(writes,[(obj+0x81,1,1)])
        self.assertEqual(before,{k:v for k,v in m.files.items() if '/users/' in k})
    def test_wrong_class_and_unmapped_pointer_refuse_before_write(self):
        for case in ('class','pointer','bounds','permission','query_failure'):
            m,obj,writes=self.model()
            if case=='class':m.uc.mem_write(obj,b'X'*8)
            if case=='pointer':m.uc.mem_write(SCRATCH+0x500+40,struct.pack('<Q',0x7200000000))
            if case=='bounds':m.query_last=obj+0x81
            if case=='permission':m.query_permission=0
            if case=='query_failure':m.query_result=-1
            self.assertGreaterEqual(self.call(m,'ctr_characters_enable'),0x80000000,case)
            self.assertEqual(writes,[],case)
if __name__=='__main__':unittest.main()
