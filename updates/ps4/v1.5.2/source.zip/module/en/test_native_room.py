"""Actual SELF: private mode uses the existing signed, origin-bound HTTP worker."""
import hashlib,hmac,struct,unittest
from test_native_updates import UpdateMachine
from test_native_speed import SYMBOLS
from test_native_bridge import prepare,SCRATCH
class Tests(unittest.TestCase):
 def machine(self):
  m=UpdateMachine(response=b'mode speed\n');m.social_http=True
  prefix='/data/ryunet/users/12345678/'
  m.files[prefix+'profile.ini']=b'version=2\nnickname=OwnPlayer\nidentity=installation\n';m.files[prefix+'identity.key']=bytes(range(32)).hex().encode()
  self.assertEqual(m.initialize(),0)
  # The native reader itself is tested separately with the real game's code.
  for name in ('ctr_speed_assets_ready','ctr_itemless_assets_ready','ctr_speed_private_now','ctr_net_private_lobby_active'):m.uc.mem_write(SYMBOLS[name],b'\xb8\x01\x00\x00\x00\xc3')
  return m
 def invoke(self,m,name,*args):return m.call(m.exports[prepare.nid(name)],*args)
 def test_host_posts_the_current_nickname_with_its_own_key_and_retains_user_files(self):
  m=self.machine();before=dict(m.files);self.assertEqual(self.invoke(m,'ctr_roommode_choose',1),0);self.invoke(m,'ctr_roommode_hosting');self.invoke(m,'ctr_roommode_tick')
  self.assertEqual(len(m.tasks),1);self.assertFalse(m.requested);m.finish()
  target='/ryunet/room-mode?name=OwnPlayer&mode=speed&format=text';self.assertEqual(m.requested,['https://octr.ryu7w7.xyz'+target]*2)
  proof=next(v for _,key,v,_ in m.http_headers if key=='X-RyuNET-Proof');_,ts,nonce,mac=proof.split('.')
  key=hmac.new(bytes(range(32)),b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest().encode();message=(ts+'\n'+nonce+'\nPOST\n'+target).encode()
  self.assertEqual(mac,hmac.new(hashlib.sha256(key).hexdigest().encode(),message,hashlib.sha256).hexdigest())
  self.assertEqual({p:d for p,d in m.files.items() if p not in ('/data/GoldHEN/ctr_native_port.log','/temp0/ctr_native_port.log')},{p:d for p,d in before.items() if p not in ('/data/GoldHEN/ctr_native_port.log','/temp0/ctr_native_port.log')});self.assertTrue(m.files.get('/data/GoldHEN/ctr_native_port.log',b'').startswith(before.get('/data/GoldHEN/ctr_native_port.log',b'')));self.assertFalse(m.fds);self.assertEqual(len(m.cleanup),6)
 def test_guest_gets_mode_without_rewriting_its_name_and_stale_reply_is_ignored(self):
  m=self.machine();m.uc.mem_write(SCRATCH,b'cusa13795-session-OtherPlayer\0');self.invoke(m,'ctr_roommode_joined',SCRATCH);self.invoke(m,'ctr_roommode_tick');self.invoke(m,'ctr_roommode_left');m.finish()
  self.assertEqual(m.requested,['https://octr.ryu7w7.xyz/ryunet/room-mode?host=OtherPlayer&format=text']*2)
  self.invoke(m,'ctr_roommode_snapshot',SCRATCH);self.assertEqual(struct.unpack('<i',m.uc.mem_read(SCRATCH+20,4))[0],0)
if __name__=='__main__':unittest.main(verbosity=2)
