from pathlib import Path
import subprocess,json,os
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'src';BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
LLVM=Path(os.environ.get('CTR_LLVM_BIN',ROOT.parent/'ps4-online/llvm/bin'))
def run(args):
    p=subprocess.run([str(x) for x in args],capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
objects=[]
for name in ['online_core.c', 'mini.c', 'identity_hash.c', 'installation.c', 'settings.c', 'profile.c', 'friends.c', 'sessions.c', 'menu.c', 'characters.c', 'updates.c', 'updater.c', 'frame_limit.c', 'net_tunnel.c', 'runtime_net_tunnel.c', 'runtime_net_ping.c', 'social.c', 'season.c', 'items.c', 'net_transport.c', 'host_stack_probe.S', 'room_mode.c', 'speed_view.c']:
    obj=BUILD/(name.replace('/','_').replace('.','-')+'-host.obj')
    run([LLVM/'clang.exe','--target=x86_64-pc-windows-msvc','-ffreestanding','-fno-builtin','-fno-stack-protector',
         '-DCTR_MODS_EN=1','-DMINIZ_NO_STDIO','-DMINIZ_NO_TIME','-DMINIZ_NO_MALLOC','-DMINIZ_NO_DEFLATE_APIS','-DMINIZ_NO_ZLIB_APIS','-DNDEBUG',
         '-O1',*(['-w'] if ('vendor/' in name) else ['-Wall','-Wextra','-Werror']),'-I'+str(SRC),'-I'+str(SRC/'pcmod/compat'),'-I'+str(SRC/'pcmod'),'-I'+str(SRC/'vendor/compat'),'-c',SRC/name,'-o',obj]);objects.append(obj)
run([LLVM/'lld.exe','-flavor','link','/dll','/noentry','/machine:x64','/out:'+str(BUILD/'ctr_core_test.dll'),*objects])
print(json.dumps({'built':str(BUILD/'ctr_core_test.dll')}))
