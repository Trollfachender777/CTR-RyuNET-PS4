"""Regressions for real relay traffic racing the sender's bookkeeping lock."""
import ctypes as C,socket,struct,unittest
import test_network as fixture
lib,PEER,SERVER,address,wire=fixture.lib,fixture.PEER,fixture.SERVER,fixture.address,fixture.wire
class Tests(unittest.TestCase):
 def setUp(self):self.net=fixture.Tests();self.net.setUp();self.net.bind()
 def offer(self):
  n=self.net;packet=b'RYUPS1'+b'P'*75+b'\1'+socket.inet_aton('81.2.3.4')+struct.pack('>H',4000)+b'\4near'
  n.queue.append((packet,SERVER));self.assertEqual(n.recv()[0],-1)
 def test_relay_envelope_never_enters_game_while_send_owns_state_lock(self):
  self.offer();n=self.net;relay=address('81.2.3.4',4000);n.queue.append((wire(PEER,b'pending',2),relay));seen=[]
  n.on_send=lambda p:seen.append(n.recv()) if p[1].startswith(b'RYUTN1') and not seen else None
  n.send();n.on_send=None
  self.assertEqual(seen[0][0],-1,'A contended receive must defer instead of exposing a raw relay envelope')
  calls=n.recvs;self.assertEqual(n.recv()[1],b'pending');self.assertEqual(n.recvs,calls,'Deferred packet must not consume a second socket read')
 def test_relay_offer_is_deferred_not_lost_during_send(self):
  n=self.net;packet=b'RYUPS1'+b'P'*75+b'\1'+socket.inet_aton('81.2.3.4')+struct.pack('>H',4000)+b'\4near';n.queue.append((packet,SERVER));seen=[]
  n.on_send=lambda p:seen.append(n.recv()[0]) if p[1].startswith(b'RYUTN1') and not seen else None
  n.send();n.on_send=None;self.assertEqual(seen,[-1]);self.assertEqual(n.recv()[0],-1);self.assertEqual(lib.tun_relay_count(),1)
 def test_deferred_relay_packet_preserves_peek_and_is_discarded_on_rebind(self):
  self.offer();n=self.net;relay=address('81.2.3.4',4000);n.queue.append((wire(PEER,b'kept',2),relay));seen=[]
  n.on_send=lambda p:seen.append(n.recv()[0]) if p[1].startswith(b'RYUTN1') and not seen else None
  n.send();n.on_send=None;self.assertEqual(seen,[-1]);calls=n.recvs
  self.assertEqual(n.recv(flags=2)[1],b'kept');self.assertEqual(n.recv(flags=2)[1],b'kept');self.assertEqual(n.recv()[1],b'kept');self.assertEqual(n.recvs,calls)
  n.queue.append((wire(PEER,b'old',2),relay));seen.clear();n.on_send=lambda p:seen.append(n.recv()[0]) if p[1].startswith(b'RYUTN1') and not seen else None
  n.send();n.on_send=None;self.assertEqual(seen,[-1]);lib.ctr_net_close(7);n.bind();n.queue.append((b'new',PEER));self.assertEqual(n.recv()[1],b'new')
if __name__=='__main__':unittest.main(verbosity=2)
