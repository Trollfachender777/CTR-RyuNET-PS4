"""Actual C dialogs: retained updates/profile/graphics and removed mod manager."""
import ctypes as C,unittest
from test_settings_menu import Menu,defaults,lib,core
class Tests(unittest.TestCase):
 def setUp(self):
  self.api=core.Api();lib.ctr_core_init(C.byref(self.api),b'DevelopmentUser1');s=defaults();lib.ctr_settings_publish(C.byref(s))
 def test_updates_remain_accessible_through_room_extras(self):
  m=Menu();m.open();m.choose(2);m.choose(2);m.choose(1);self.assertIn('PS4',m.shown[-1][0]);self.assertFalse(m.errors);self.assertFalse(m.saved)
 def test_mod_backend_api_is_no_longer_linked(self):
  with self.assertRaises(AttributeError):getattr(lib,'ctr_mods_client_bind')
  m=Menu();m.open();m.choose(2);m.choose(2);self.assertNotIn('mod',m.shown[-1][0].lower());self.assertFalse(m.saved)
 def test_character_option_and_graphics_remain_available(self):
  m=Menu();m.open();m.choose(2);m.choose(1);m.choose(2);m.choose(2);self.assertFalse(m.errors);self.assertFalse(m.saved)
  m=Menu();m.open();m.choose(1);m.choose(2);self.assertIn('720p',m.shown[-1][0]);self.assertFalse(m.saved)
if __name__=='__main__':unittest.main(verbosity=2)
