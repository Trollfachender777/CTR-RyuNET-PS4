"""Actual SELF: two fresh consoles with the same local user ID do not share a key."""
import unittest
from test_native_bridge import ModuleMachine,prepare,SCRATCH
PREFIX='/data/ryunet/users/12345678/'
class Tests(unittest.TestCase):
    def create(self,seed,nickname):
        m=ModuleMachine('ui_profile_missing');m.files={};m.random_seed=seed;self.assertEqual(m.initialize(),0)
        poll=m.exports[prepare.nid('ctr_menu_poll')]
        for _ in range(120):m.call(poll,7,0)
        m.dialog_status=3;m.dialog_chosen=1;m.call(poll,7,0)
        m.uc.mem_write(m.ime_buffer,(nickname+'\0').encode('utf-16-le'));m.ime_state=2;m.call(poll,7,0)
        self.assertEqual(m.random_calls,1);return m
    def test_same_user_id_on_independent_consoles_gets_different_entropy_and_keys(self):
        first=self.create(1,'FirstNewPlayer');second=self.create(71,'SecondNewPlayer')
        self.assertNotEqual(first.files[PREFIX+'identity.key'],second.files[PREFIX+'identity.key'])
        self.assertIn(b'FirstNewPlayer',first.files[PREFIX+'profile.ini']);self.assertIn(b'SecondNewPlayer',second.files[PREFIX+'profile.ini'])
        for m in (first,second):self.assertFalse(any(p.endswith('.sav') for p in m.files))
    def test_update_restart_keeps_existing_identity_without_generating_another(self):
        first=self.create(31,'PersonalPlayer');again=ModuleMachine('ui_identity_restart');again.files=dict(first.files)
        before=dict(again.files);self.assertEqual(again.initialize(),0);self.assertEqual(again.random_calls,0)
        for path,data in before.items():
            if not path.endswith('ctr_native_port.log'):self.assertEqual(again.files[path],data)
if __name__=='__main__':unittest.main(verbosity=2)
