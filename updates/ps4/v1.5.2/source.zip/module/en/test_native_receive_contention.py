"""Real SELF UDP receive path: relay datagrams survive a busy bookkeeping gate."""
import socket,struct,unittest
from test_native_bridge import ModuleMachine,prepare,SCRATCH
from test_native_speed import SYMBOLS
def addr(ip,port=3074):return bytes([16,2])+struct.pack('>H',port)+socket.inet_aton(ip)+bytes(8)
class Tests(unittest.TestCase):
 def invoke(self,m,name,*args):return m.call(m.exports[prepare.nid(name)],*args)
 def test_native_relay_packet_is_retained_and_unwrapped_after_gate_is_released(self):
  m=ModuleMachine('ui_network');m.map(SCRATCH,0x4000);m.allowed.append((SCRATCH,SCRATCH+0x4000));self.assertEqual(m.initialize(),0)
  server=addr('165.1.125.122');peer=addr('201.189.26.165',18270);relay=addr('81.2.3.4',4000)
  self.invoke(m,'ctr_net_server',int.from_bytes(server[4:8],'little'));m.uc.mem_write(SCRATCH+0x100,addr('0.0.0.0'));self.assertEqual(self.invoke(m,'ctr_net_bind',7,SCRATCH+0x100,16),0)
  def recv():
   m.uc.mem_write(SCRATCH+0x200,struct.pack('<I',16));return self.invoke(m,'ctr_net_recvfrom',7,SCRATCH+0x1000,2048,0,SCRATCH+0x300,SCRATCH+0x200)&0xffffffff
  offer=b'RYUPS1'+b'P'*75+b'\1'+relay[4:8]+relay[2:4]+b'\4near';m.network_incoming.append((offer,server));self.assertEqual(recv(),0xffffffff)
  gate=SYMBOLS['net_bookkeeping_lock'];m.uc.mem_write(gate,struct.pack('<i',1));m.uc.mem_write(SCRATCH+0x1000,b'Z'*16)
  m.network_incoming.append((b'RYUTN1\2'+peer[4:8]+peer[2:4]+b'answer',relay));self.assertEqual(recv(),0xffffffff);self.assertEqual(bytes(m.uc.mem_read(SCRATCH+0x1000,16)),b'Z'*16)
  m.uc.mem_write(gate,bytes(4));self.assertEqual(recv(),6);self.assertEqual(bytes(m.uc.mem_read(SCRATCH+0x1000,6)),b'answer');self.assertEqual(bytes(m.uc.mem_read(SCRATCH+0x300,16)),peer)
if __name__=='__main__':unittest.main(verbosity=2)
