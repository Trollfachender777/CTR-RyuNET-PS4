"""OCTR 0.6.4 protocol interoperability and PS4-only UI/worker integration."""
import ctypes as C,hashlib,hmac,socket,struct,unittest
from test_core import lib,Api as CoreApi
from test_settings_menu import Settings,defaults,Menu,snapshot
from test_installation import Disk,PRIMARY
from test_network import Tests as NetworkTests,SERVER,PEER,address,wire

class Friend(C.Structure):_fields_=[('name',C.c_char*17),('online',C.c_int32),('players',C.c_int32),('max',C.c_int32)]
class Invite(C.Structure):_fields_=[('name',C.c_char*17),('ago',C.c_uint32)]
class View(C.Structure):
    _fields_=[('state',C.c_int32),('status',C.c_int32),('serial',C.c_uint32),('count',C.c_uint32),('incoming_count',C.c_uint32),('outgoing_count',C.c_uint32),('invite_count',C.c_uint32),('friends',Friend*200),('incoming',(C.c_char*17)*50),('outgoing',(C.c_char*17)*50),('invites',Invite*16),('result',C.c_char*24),('who',C.c_char*17)]
class SocialApi(C.Structure):_fields_=[('spawn',C.c_void_p),('request',C.c_void_p),('clock',C.c_void_p)]
lib.ctr_social_init.argtypes=[C.POINTER(SocialApi)]
lib.ctr_social_parse.argtypes=[C.c_char_p,C.c_size_t,C.POINTER(View)]
lib.ctr_social_snapshot.argtypes=[C.POINTER(View)]
lib.ctr_social_action.argtypes=[C.c_char_p,C.c_char_p]
lib.ctr_social_contacts.argtypes=[C.POINTER(Settings)]
lib.ctr_social_contact.argtypes=[C.c_char_p]
lib.ctr_social_proof.argtypes=[C.c_char_p,C.c_char_p,C.c_uint64,C.c_char_p,C.c_void_p,C.c_size_t]
lib.ctr_social_http_date.argtypes=[C.c_char_p,C.c_size_t];lib.ctr_social_http_date.restype=C.c_int64
def view():
    v=View();assert lib.ctr_social_snapshot(C.byref(v))==0;return v
class Service:
    def __init__(self,body=b'friend 1 1 8 PcFriend\nincoming NewFriend\ninvite 2 PcFriend\n',status=200):
        self.body=body;self.status=status;self.now=1000000;self.tasks=[];self.requests=[]
        def spawn(fn,arg):self.tasks.append((fn,arg));return 0
        def request(method,target,out,cap):
            self.requests.append((method,target));data=self.body if method==b'GET' else b'status sent\n'
            C.memmove(out,data+b'\0',min(len(data)+1,cap));return self.status
        self.callbacks=[C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_void_p)(spawn),C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_char_p,C.c_void_p,C.c_size_t)(request),C.CFUNCTYPE(C.c_uint64)(lambda:self.now)]
        self.api=SocialApi(*(C.cast(f,C.c_void_p).value for f in self.callbacks));assert lib.ctr_social_init(C.byref(self.api))==0
    def finish(self):fn,arg=self.tasks.pop(0);C.CFUNCTYPE(C.c_void_p,C.c_void_p)(fn)(arg)
    def refresh(self):self.now+=8000000;lib.ctr_social_tick();self.finish()
class SocialTests(unittest.TestCase):
    def setUp(self):
        self.core=CoreApi();assert lib.ctr_core_init(C.byref(self.core),b'Ps4Player')==0
        lib.ctr_settings_publish(C.byref(defaults()))
        self.disk=Disk({PRIMARY:bytes(range(32)).hex().encode()});assert lib.ctr_identity_activate(C.byref(self.disk.io),1)==0
    def tearDown(self):lib.ctr_social_init(None);lib.ctr_identity_activate(None,0)
    def test_exact_signed_proof_matches_official_pc_hmac_contract(self):
        target=b'/ryunet/friends/accept?name=Ps4Player&from=PcFriend&format=text';nonce=b'0123456789abcdef0123456789abcdef';seconds=1792800000
        out=C.create_string_buffer(160);self.assertEqual(lib.ctr_social_proof(b'POST',target,seconds,nonce,out,160),1)
        key=hmac.new(bytes(range(32)),b'octr.ryu7w7.xyz',hashlib.sha256).hexdigest().encode()
        expected=hmac.new(hashlib.sha256(key).hexdigest().encode(),str(seconds).encode()+b'\n'+nonce+b'\nPOST\n'+target,hashlib.sha256).hexdigest().encode()
        self.assertEqual(out.value,b'1.'+str(seconds).encode()+b'.'+nonce+b'.'+expected)
        for method,path,n in [(b'GET',b'http://evil/',nonce),(b'GET',b'/x\r\nHeader:x',nonce),(b'CONNECT',target,nonce),(b'GET',target,b'x'*32)]:
            self.assertEqual(lib.ctr_social_proof(method,path,seconds,n,out,160),0)
        lib.ctr_identity_activate(None,0);self.assertEqual(lib.ctr_social_proof(b'POST',target,seconds,nonce,out,160),0)
    def test_server_clock_is_strict_and_does_not_modify_os_clock(self):
        import email.utils,datetime
        date=b'Sat, 24 Oct 2026 12:34:56 GMT'
        expected=int(email.utils.parsedate_to_datetime(date.decode()).timestamp())
        self.assertEqual(lib.ctr_social_http_date(date,len(date)),expected)
        for bad in [b'Sat, 31 Feb 2026 12:34:56 GMT',b'Sat, 24 Oct 2026 25:34:56 GMT',date[:-1],date.replace(b'GMT',b'PST')]:self.assertEqual(lib.ctr_social_http_date(bad,len(bad)),-1)
    def test_server_view_requests_and_invites_are_bounded_and_transactional(self):
        s=Service();lib.ctr_social_tick();self.assertFalse(s.requests);self.assertEqual(len(s.tasks),1);s.finish()
        v=view();self.assertEqual((v.state,v.count,v.incoming_count,v.invite_count),(2,1,1,1));self.assertEqual(v.friends[0].name,b'PcFriend')
        for bad in [b'friend 1 9 8 Bad\n',b'friend 1 1 8 bad/name\n',b'friend 1 1 8 PcFriend\nfriend 1 1 8 pcfriend\n',b'incoming '+b'A'*17,b'invite 3 PcFriend\0bad']:
            out=View();C.memset(C.byref(out),85,C.sizeof(out));before=bytes(out)
            self.assertLess(lib.ctr_social_parse(bad,len(bad),C.byref(out)),0);self.assertEqual(bytes(out),before)
    def test_two_hundred_server_contacts_do_not_overflow_local_32_contact_file(self):
        raw=b''.join(f'friend 0 0 0 Friend{i:03}\n'.encode() for i in range(200));s=Service(raw);s.refresh()
        self.assertEqual(view().count,200);out=defaults();self.assertEqual(lib.ctr_social_contacts(C.byref(out)),1);self.assertEqual(out.count,32)
        self.assertEqual(lib.ctr_social_contact(b'Friend199'),1);self.assertEqual(snapshot().count,0)
    def test_signed_actions_use_same_paths_as_pc_and_never_block_menu_thread(self):
        s=Service();s.refresh()
        for action,arg in [(b'request',b'to'),(b'accept',b'from'),(b'decline',b'from'),(b'remove',b'who'),(b'invite',b'to')]:
            before=len(s.requests);self.assertEqual(lib.ctr_social_action(action,b'PcFriend'),0);self.assertEqual(len(s.requests),before)
            lib.ctr_social_tick();self.assertEqual(len(s.tasks),1);self.assertEqual(len(s.requests),before);s.finish()
            self.assertIn((b'POST',b'/ryunet/friends/'+action+b'?name=Ps4Player&'+arg+b'=PcFriend&format=text'),s.requests)
        self.assertEqual(view().result,b'sent')
        for action,name in [(b'invalid',b'PcFriend'),(b'request',b'bad/name'),(b'remove',b'Ps4Player')]:self.assertLess(lib.ctr_social_action(action,name),0)
    def test_removed_friend_is_removed_from_original_ctr_list_without_pc_file_changes(self):
        s=Service();s.refresh();out=C.create_string_buffer(32768)
        lib.ctr_friends_json(b'/friends',out,len(out));self.assertIn(b'PcFriend',out.value)
        s.body=b'';s.refresh();lib.ctr_friends_json(b'/friends',out,len(out));self.assertNotIn(b'PcFriend',out.value)
    def test_network_or_malformed_response_keeps_last_good_contacts(self):
        s=Service();s.refresh()
        for status,body in [(0,b''),(403,b''),(200,b'friend 2 1 8 Bad')]:
            s.status=status;s.body=body;s.refresh();out=defaults();self.assertEqual(lib.ctr_social_contacts(C.byref(out)),1);self.assertEqual(out.count,1)
    def test_only_one_worker_and_eight_second_refresh_with_no_frame_http(self):
        s=Service()
        for _ in range(100):lib.ctr_social_tick()
        self.assertEqual(len(s.tasks),1);self.assertFalse(s.requests);self.assertLess(lib.ctr_social_init(None),0)
        s.finish()
        for _ in range(100):lib.ctr_social_tick()
        self.assertFalse(s.tasks);self.assertEqual(len(s.requests),1);s.refresh();self.assertEqual(len(s.requests),2)
    def test_l3_r3_incoming_request_can_accept_and_invitation_uses_explicit_consent(self):
        s=Service();s.refresh();clock=C.CFUNCTYPE(C.c_uint64)(lambda:s.now)
        lib.ctr_sessions_init(42,C.cast(clock,C.c_void_p),None);lib.ctr_sessions_ready(1)
        m=Menu();m.open();m.choose(2);m.choose(1);m.choose(1);m.choose(2);m.choose(1);m.choose(1);m.choose(2);m.choose(1)
        self.assertIn('NewFriend',m.shown[-1][0]);m.choose(1);self.assertEqual(m.shown[-1][1:],('Accept','Decline'))
        m.choose(1);self.assertEqual(lib.ctr_session_due(),0);lib.ctr_social_tick();s.finish()
        self.assertIn((b'POST',b'/ryunet/friends/accept?name=Ps4Player&from=NewFriend&format=text'),s.requests)

class RegionalTests(NetworkTests):
    def offer(self,relays):
        packet=b'RYUPS1'+b'P'*75+bytes([len(relays)])
        for ip,port,name in relays:packet+=socket.inet_aton(ip)+struct.pack('>H',port)+bytes([len(name)])+name
        self.queue.append((packet,SERVER));self.assertEqual(self.recv()[0],-1)
    def test_regional_relay_registration_nearest_path_and_old_peer_server_fallback(self):
        self.bind();self.now+=100000;self.offer([('81.2.3.4',4000,b'near')]);self.sent.clear();self.send()
        reg=next(x[1] for x in self.sent if x[1].startswith(b'RYURG1'));self.assertEqual(len(reg),85)
        relay=address('81.2.3.4',4000);self.now+=1000;self.queue.append((b'RYURG1\0'+reg[-4:],relay));self.assertEqual(self.recv()[0],-1)
        self.sent.clear();self.send();destinations=[x[3] for x in self.sent if x[1].startswith(b'RYUTN1')]
        self.assertIn(bytes(SERVER),destinations);self.assertIn(bytes(relay),destinations)
        self.queue.append((wire(PEER,b'answer',2),relay));self.assertEqual(self.recv()[1],b'answer');self.sent.clear();self.send()
        destinations=[x[3] for x in self.sent if x[1].startswith(b'RYUTN1') and x[1][13:]==b'game']
        self.assertEqual(destinations,[bytes(relay)])
        self.now+=17000000;self.sent.clear();self.send();self.assertTrue(any(x[3]==bytes(SERVER) for x in self.sent if x[1].startswith(b'RYUTN1')))
    def test_invalid_or_private_relay_offer_cannot_redirect_game_traffic(self):
        self.bind();self.offer([('127.0.0.1',2121,b'bad')]);self.sent.clear();self.send()
        self.assertFalse(any(x[1].startswith(b'RYURG1') for x in self.sent))
    def test_ping_packet_is_consumed_and_replied_with_same_stamp_before_game_peek(self):
        self.bind();self.send();self.sent.clear();ping=b'RYUPN1\1'+struct.pack('>I',1000)+b'\10PcFriend'
        self.queue.append((wire(PEER,ping,2),SERVER));self.assertEqual(self.recv(flags=2)[0],-1)
        replies=[x[1] for x in self.sent if x[1].startswith(b'RYUPN1')];self.assertEqual(replies[0][6],2);self.assertEqual(replies[0][7:11],struct.pack('>I',1000))
        self.queue.append((b'normal',PEER));self.assertEqual(self.recv()[1],b'normal')
    def test_ping_capability_never_sends_control_to_old_peer(self):
        self.bind();self.send();self.assertFalse(any(x[1].startswith(b'RYUPN1') for x in self.sent))
        self.queue.append((wire(PEER,b'game',2),SERVER));self.recv();self.sent.clear();self.send()
        self.assertTrue(any(x[1].startswith(b'RYUPN1') for x in self.sent))

if __name__=='__main__':unittest.main(verbosity=2)
