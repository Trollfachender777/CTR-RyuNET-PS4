"""Execute the actual PS4 native menu installer against the owned game image."""
from pathlib import Path
import json,re,struct,unittest
from test_native_speed import SpeedMachine,SYMBOLS,BASE,PAIRS
from test_native_bridge import P,prepare,STUB,SCRATCH
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parent
UP=ROOT.parent/'ctr-upstream-v075/source'
class NativeMenusMachine(SpeedMachine):
 def __init__(self,failure=None):
  super().__init__('ui_native_menu');self.instruction_budget=20000000;self.failure=failure;self.native_calls=[];self.self_id=0xabc100;self.exit_calls=[];self.load_exec_calls=[];self.load_exec_result=0
  self.map(SCRATCH,0x40000);self.allowed.append((SCRATCH,SCRATCH+0x40000));self.query_first=SCRATCH;self.query_last=SCRATCH+0x40000;self.query_permission=3
  names=['scePthreadSelf','scePthreadMutexInit','scePthreadMutexLock','scePthreadMutexUnlock','vsnprintf','sceSystemServiceParamGetInt','sceSystemServiceLoadExec']
  self.services={name:STUB+0xf00+16*i for i,name in enumerate(names)};self.ui_symbols.update(self.services)
  elf,_,ph,_,_=prepare.parse_elf(Path(P[0]['elf']).read_bytes())
  c=(UP/'src/runtime_online_mode.c').read_text(encoding='utf-8')+'\n'+(UP/'src/runtime_itemless.c').read_text(encoding='utf-8')
  rvas={int(x,16) for x in re.findall(r'image\s*\+\s*\(?0x([0-9a-f]+)',c)}
  rvas.update(x['rva'] for x in json.loads((ROOT.parent/'ctr-v150-tools/NATIVE_IMAGE_PROFILE.json').read_text())['function_windows'])
  rvas.update((0x10de0c9,0x11345b0+0x3e,0x2af2600))
  filled=set()
  for rva in rvas:
   page=rva&~4095
   if page in filled:continue
   filled.add(page);self.map(BASE+page,4096);segment=next((p for p in ph if p['type'] in (1,0x61000010) and p['vaddr']<=page and page+4096<=p['vaddr']+p['filesz']),None)
   if segment:self.uc.mem_write(BASE+page,bytes(prepare.span(elf,segment['offset']+page-segment['vaddr'],4096)))
   self.allowed.append((BASE+page,BASE+page+4096))
  self.native_pages=filled
  pairs=re.findall(r'memcpy\(&handler, image \+ (0x[0-9a-f]+), sizeof handler\);\s*if \(handler != \(uintptr_t\)\(image \+ \(?(0x[0-9a-f]+)',c)
  assert len(pairs)==9,pairs
  for at,value in pairs:self.uc.mem_write(BASE+int(at,16),struct.pack('<Q',BASE+int(value,16)))
  # Asset archive hash/roundtrip is tested independently; here this boundary
  # selects valid, missing and rejected resources without hashing 7 MB in emulation.
  result=-1 if failure=='asset' else 0
  self.asset_entry=bytes(self.uc.mem_read(SYMBOLS['ctr_native_menu_assets'],6))
  self.uc.mem_write(SYMBOLS['ctr_native_menu_assets'],b'\xb8'+struct.pack('<I',result&0xffffffff)+b'\xc3')
  if failure=='helper':self.uc.mem_write(BASE+0x4708a0,b'X')
  if failure=='peer_receiver_tail':self.uc.mem_write(BASE+0xec03c0+16,b'\x69')
  if failure=='vtable':self.uc.mem_write(BASE+0x2773b40,struct.pack('<Q',BASE+0x1277c71))
  if failure=='service':del self.ui_symbols['scePthreadMutexInit']
  if failure=='exit_service':del self.ui_symbols['sceSystemServiceLoadExec']
  previous=getattr(self,'pc_filesystem',None)
  def syscalls(uc):
   number=uc.reg_read(UC_X86_REG_RDI);a=uc.reg_read(UC_X86_REG_RSI);b=uc.reg_read(UC_X86_REG_RDX);mode=uc.reg_read(UC_X86_REG_R10)
   if number==1:self.exit_calls.append(a);uc.reg_write(UC_X86_REG_RAX,0);return True
   if number==74 and failure=='permission' and a==(BASE+0x1277e00)&~0x3fff and mode&2:
    flags=uc.reg_read(UC_X86_REG_EFLAGS);uc.reg_write(UC_X86_REG_EFLAGS,flags|1);uc.reg_write(UC_X86_REG_RAX,13);return True
   return bool(previous and previous(uc))
  self.pc_filesystem=syscalls
  def code(uc,address,size,user):
   name=next((n for n,at in self.services.items() if at==address),None)
   if not name:return
   a,b,c=[uc.reg_read(r) for r in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX)];result=0
   if name=='scePthreadSelf':result=self.self_id
   elif name=='scePthreadMutexInit':uc.mem_write(a,struct.pack('<Q',SCRATCH+0x35000))
   elif name=='sceSystemServiceParamGetInt':uc.mem_write(b,struct.pack('<i',3))
   elif name=='sceSystemServiceLoadExec':
    self.load_exec_calls.append((bytes(uc.mem_read(a,5)),b));result=self.load_exec_result
   elif name=='vsnprintf':
    def text(at):return bytes(uc.mem_read(at,128)).split(b'\0')[0]
    if text(c)!=b'/app0/archives/%s.pak':raise AssertionError('Unexpected formatting during menu installation')
    va=uc.reg_read(UC_X86_REG_RCX);gp=struct.unpack('<I',uc.mem_read(va,4))[0];saved=struct.unpack('<Q',uc.mem_read(va+16,8))[0]
    value=struct.unpack('<Q',uc.mem_read(saved+gp,8))[0];rendered=b'/app0/archives/'+text(value)+b'.pak'
    uc.mem_write(a,rendered[:b-1]+b'\0');result=len(rendered)
   self.native_calls.append(name);uc.reg_write(UC_X86_REG_RAX,result&0xffffffffffffffff)
  self.uc.hook_add(UC_HOOK_CODE,code,begin=STUB,end=STUB+4095)
 def snapshot_game(self):return {p:bytes(self.uc.mem_read(BASE+p,4096)) for p in self.native_pages}
 def ready(self):return self.call(SYMBOLS['ctr_native_menu_ready'])
 def pointer(self,address,*args):self.call(address,*args);return self.uc.reg_read(UC_X86_REG_RAX)
 def intercept(self,callbacks):
  def code(uc,address,size,user):
   if address not in callbacks:return
   args=[uc.reg_read(r) for r in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8,UC_X86_REG_R9)]
   result=callbacks[address](*args);stack=uc.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',uc.mem_read(stack,8))[0]
   uc.reg_write(UC_X86_REG_RAX,(result or 0)&0xffffffffffffffff);uc.reg_write(UC_X86_REG_RSP,stack+8);uc.reg_write(UC_X86_REG_RIP,ret)
  self.uc.hook_add(UC_HOOK_CODE,code)

class Tests(unittest.TestCase):
 def test_native_quit_uses_system_service_exit_and_never_raw_sys_exit(self):
  m=NativeMenusMachine();m.initialize();self.assertEqual(m.ready(),1)
  m.call(SYMBOLS['ctr_native_quit']);self.assertEqual(m.load_exec_calls,[(b'exit\0',0)]);self.assertFalse(m.exit_calls)
  # A successful asynchronous close is queued only once, even on repeated input.
  m.call(SYMBOLS['ctr_native_quit']);self.assertEqual(len(m.load_exec_calls),1);self.assertFalse(m.exit_calls)
 def test_native_quit_missing_or_rejected_service_keeps_game_alive_and_can_retry(self):
  for missing in (False,True):
   m=NativeMenusMachine('exit_service' if missing else None);m.initialize();self.assertEqual(m.ready(),1)
   m.load_exec_result=-2145353727
   m.call(SYMBOLS['ctr_native_quit']);self.assertFalse(m.exit_calls)
   self.assertEqual(len(m.load_exec_calls),0 if missing else 1)
   m.call(SYMBOLS['ctr_native_quit']);self.assertFalse(m.exit_calls)
   self.assertEqual(len(m.load_exec_calls),0 if missing else 2)
 def test_real_self_installs_all_native_modes_and_graphics_together(self):
  m=NativeMenusMachine();self.assertEqual(m.initialize(),0);self.assertEqual(m.ready(),1)
  for rva,opcode in ((0x1277e00,b'\xff\x25'),(0xec03c0,b'\xff\x25'),(0xe916b0,b'\xff\x25'),(0xe92e90,b'\xff\x25'),(0x1109200,b'\x48\xb8'),(0x1276c70,b'\x48\xb8')):self.assertEqual(bytes(m.uc.mem_read(BASE+rva,2)),opcode)
  self.assertFalse(m.exit_calls);self.assertFalse(m.fds)
 def test_native_mode_selection_maps_itemless_to_race_and_battle_to_battle(self):
  m=NativeMenusMachine();m.initialize();context=m.pointer(SYMBOLS['ctr_native_mode_context']);m.uc.mem_write(context,struct.pack('<i',1));seen=[];private=[1]
  def state(a,b,*rest):m.uc.mem_write(a,bytes([private[0]]));m.uc.mem_write(b,bytes([1-private[0]]))
  m.intercept({BASE+0xf50350:state})
  # The choice trampoline replays the real displaced prologue before this
  # original continuation. Restore that frame after recording its arguments.
  def original(uc,address,size,user):
   if address!=BASE+0x1277e11:return
   seen.append(uc.reg_read(UC_X86_REG_RSI));stack=uc.reg_read(UC_X86_REG_RSP)
   for reg,off in ((UC_X86_REG_RBX,8),(UC_X86_REG_R14,16),(UC_X86_REG_R15,24),(UC_X86_REG_RBP,32)):uc.reg_write(reg,struct.unpack('<Q',uc.mem_read(stack+off,8))[0])
   ret=struct.unpack('<Q',uc.mem_read(stack+40,8))[0];uc.reg_write(UC_X86_REG_RSP,stack+48);uc.reg_write(UC_X86_REG_RIP,ret)
  m.uc.hook_add(UC_HOOK_CODE,original)
  for mode,expected in ((0,0),(1,1),(2,0)):
   m.call(SYMBOLS['select_mode'],SCRATCH,mode);self.assertEqual(m.call(SYMBOLS['runtime_online_mode_private_speed']),expected)
  self.assertEqual(seen,[0,0,1]);private[0]=0;m.call(SYMBOLS['select_mode'],SCRATCH,1);self.assertEqual(seen[-1],0)
 def test_opening_native_selector_does_not_turn_a_guest_into_host(self):
  m=NativeMenusMachine();m.initialize()
  m.map(BASE+0x2a92868,0x28)
  owner=SCRATCH+0x1000;options=SCRATCH+0x2000;available=SCRATCH+0x3000;items=SCRATCH+0x3100
  event=SCRATCH+0x4000;vtable=SCRATCH+0x4100;network=SCRATCH+0x5000;get_type=SCRATCH+0x32000;host=SCRATCH+0x6000;snapshot=SCRATCH+0x7000
  def u64(at,value):m.uc.mem_write(at,struct.pack('<Q',value))
  u64(owner+0x1a8,options);m.uc.mem_write(options+12,struct.pack('<i',3));u64(owner+0x1b0,available);u64(available+0x20,items)
  u64(event,vtable);u64(vtable,get_type);u64(BASE+0x2a21ee8,0xabc123);u64(BASE+0x2acb3d8,network)
  def state(a,b,*rest):m.uc.mem_write(a,b'\x01');m.uc.mem_write(b,b'\0')
  m.intercept({BASE+0xf50350:state,get_type:lambda *args:0xabc123,BASE+0x125d570:lambda *args:0})
  m.uc.mem_write(host,b'cusa13795-session-PcHarness\0');m.call(SYMBOLS['ctr_roommode_joined'],host)
  m.call(SYMBOLS['ctr_roommode_snapshot'],snapshot);before=bytes(m.uc.mem_read(snapshot,49));self.assertEqual(struct.unpack_from('<i',before)[0],2)
  m.call(SYMBOLS['selector_event'],owner,event,0);m.call(SYMBOLS['ctr_roommode_tick'])
  m.call(SYMBOLS['ctr_roommode_snapshot'],snapshot);after=bytes(m.uc.mem_read(snapshot,49))
  self.assertEqual(struct.unpack_from('<i',after)[0],2)
  self.assertEqual(after[28:49],before[28:49]) # generation and host identity are retained
 def test_native_map_applies_itemless_before_real_archive_reads_without_peer_probe_and_public_restores_boxes(self):
  m=NativeMenusMachine();m.initialize();private=[1]
  # The legacy UI handle can be unavailable while the native map loads.
  m.map(BASE+0x2a92868,0x28)
  m.stat_identity_mismatch=True
  def state(a,b,*rest):m.uc.mem_write(a,bytes([private[0]]));m.uc.mem_write(b,bytes([1-private[0]]))
  m.intercept({BASE+0xf50350:state})
  _,at,normal,fast=PAIRS[0];m.index=0;m.offset=at;m.payload=normal
  buffer=SCRATCH+0x10000;spy=SCRATCH+0x30000;track=SCRATCH+0x1000;m.uc.mem_write(track,b'octane/test/private_track\0')
  # The native map continuation immediately reads the real compressed resource
  # through the actual SELF pread hook. No pad tick or fake peer is inserted.
  code=b'\x48\x83\xec\x08'
  for opcode,value in ((b'\x48\xbf',31),(b'\x48\xbe',buffer),(b'\x48\xba',len(normal)),(b'\x48\xb9',at),(b'\x48\xb8',m.hook(1))):code+=opcode+struct.pack('<Q',value)
  code+=b'\xff\xd0\x48\x83\xc4\x08\xc3';m.uc.mem_write(spy,code);m.uc.mem_write(SYMBOLS['original_load_map'],struct.pack('<Q',spy))
  m.call(SYMBOLS['ctr_roommode_native_choose'],1,1);m.call(SYMBOLS['ctr_roommode_native_requested'],1)
  m.call(SYMBOLS['load_private_map'],track,0);self.assertEqual(bytes(m.uc.mem_read(buffer,len(normal))),fast)
  self.assertEqual(struct.unpack('<i',m.uc.mem_read(SYMBOLS['ctr_speed_active'],4))[0],1)
  private[0]=0;m.call(SYMBOLS['load_private_map'],track,0);self.assertEqual(bytes(m.uc.mem_read(buffer,len(normal))),normal)
  self.assertEqual(struct.unpack('<i',m.uc.mem_read(SYMBOLS['ctr_speed_active'],4))[0],0)
 def test_cup_host_order_uses_native_9_6_3_1_points_without_double_awards(self):
  m=NativeMenusMachine();m.initialize();pool=SCRATCH+0x1000;table=SCRATCH+0x2000;items=SCRATCH+0x3000;system=SCRATCH+0x4000;awards=SCRATCH+0x5000;points=SCRATCH+0x6000;event=SCRATCH+0x7000
  def u64(at,value):m.uc.mem_write(at,struct.pack('<Q',value))
  def i32(at,value):m.uc.mem_write(at,struct.pack('<i',value))
  u64(BASE+0x2ad4b70,pool);u64(pool+0x10,table);i32(table+12,8);u64(table+0x20,items)
  u64(BASE+0x2ad9c38,system);u64(system+0x180,awards);i32(awards+12,4);u64(awards+0x20,points);m.uc.mem_write(points,struct.pack('<4i',9,6,3,1))
  racers=[SCRATCH+0x10000+i*0x400 for i in range(8)]
  for i,racer in enumerate(racers):u64(items+8*i,racer);i32(racer+0x164,i)
  i32(SYMBOLS['private_cup_race_active'],1);totals=[0]*8
  for order in ([0,1,2,3,4,5,6,7],[7,6,5,4,3,2,1,0],[1,0,3,2,5,4,7,6],[6,7,4,5,2,3,0,1]):
   m.uc.mem_write(event+0x20,struct.pack('<8i',*order));self.assertEqual(m.call(SYMBOLS['apply_cup_results'],event),1)
   for rank,identity in enumerate(order):totals[identity]+=[9,6,3,1,0,0,0,0][rank]
   self.assertEqual([struct.unpack('<i',m.uc.mem_read(r+0xb8,4))[0] for r in racers],totals)
   before=[bytes(m.uc.mem_read(r,0x200)) for r in racers];self.assertEqual(m.call(SYMBOLS['apply_cup_results'],event),1);self.assertEqual([bytes(m.uc.mem_read(r,0x200)) for r in racers],before)
   # Feed the next race the previous native racer identities/totals. The helper
   # that snapshots them is inlined into the engine's level-load callback.
   saved=b''.join(struct.pack('<Qiiii',0,i,0,totals[i],order.index(i)+1) for i in range(8));m.uc.mem_write(SYMBOLS['cup_totals'],saved);i32(SYMBOLS['cup_total_count'],8)
  before=[bytes(m.uc.mem_read(r,0x200)) for r in racers];m.uc.mem_write(event+0x20,struct.pack('<8i',*[0]*8));self.assertEqual(m.call(SYMBOLS['apply_cup_results'],event),0);self.assertEqual([bytes(m.uc.mem_read(r,0x200)) for r in racers],before)
 def test_itemless_contacts_preserve_boost_but_keep_wall_impacts_and_native_response(self):
  m=NativeMenusMachine();m.initialize();self_obj=SCRATCH+0x1000;owner=SCRATCH+0x2000;other=SCRATCH+0x2100;wall=SCRATCH+0x2200;context=SCRATCH+0x3000;world=SCRATCH+0x4000;bodies=SCRATCH+0x5000;collision=SCRATCH+0x6000;boost=SCRATCH+0x7000;response=[];removed=[]
  def u64(at,value):m.uc.mem_write(at,struct.pack('<Q',value))
  u64(self_obj+0x18,owner);u64(boost+0x18,owner);u64(context,world);u64(world+0x20,bodies);m.uc.mem_write(collision+12,struct.pack('<i',1));m.uc.mem_write(bodies+0x90+0x42,b'\x04');u64(bodies+0x90+0x88,other);u64(BASE+0x2ad4b70,SCRATCH+0x8000)
  stop=SCRATCH+0x30000;respond=SCRATCH+0x30100;m.uc.mem_write(stop,b'\xc3')
  u64(SYMBOLS['native_contact'],respond);u64(SYMBOLS['native_stop'],stop)
  m.intercept({BASE+0xfd4230:lambda manager,entity,*rest:SCRATCH+0x9000 if entity in (owner,other) else 0,stop:lambda *args:removed.append(1)})
  def during_response(uc,address,size,user):
   if address==respond:response.append(1)
  m.uc.hook_add(UC_HOOK_CODE,during_response)
  # The mocked engine response calls the real nested StopBoost hook.
  m.uc.mem_write(respond,b'\x48\x83\xec\x08\x48\xbf'+struct.pack('<Q',boost)+b'\x48\xb8'+struct.pack('<Q',SYMBOLS['stop_boost'])+b'\xff\xd0\x48\x83\xc4\x08\xc3')
  def active(on):m.uc.mem_write(SYMBOLS['ctr_speed_active'],struct.pack('<i',on))
  active(1);m.call(SYMBOLS['contact'],self_obj,context,collision);self.assertEqual(len(removed),0)
  active(0);m.call(SYMBOLS['contact'],self_obj,context,collision);self.assertEqual(len(removed),1)
  active(1);u64(bodies+0x90+0x88,wall);m.call(SYMBOLS['contact'],self_obj,context,collision);self.assertEqual(len(removed),2)
  u64(bodies+0x90+0x88,other);m.uc.mem_write(bodies+0x90+0x42,b'\0');m.call(SYMBOLS['contact'],self_obj,context,collision);self.assertEqual(len(removed),3)
  self.assertEqual(len(response),4);m.call(SYMBOLS['stop_boost'],boost);self.assertEqual(len(removed),4)
 def test_v075_peer_customization_keeps_available_racers_and_falls_back_for_missing_mods(self):
  m=NativeMenusMachine();m.initialize();self.assertEqual(m.ready(),1)
  message=SCRATCH+0x1000;name=SCRATCH+0x8000;replacement=SCRATCH+0x9000;outfit=SCRATCH+0xa000;original=SCRATCH+0x31000
  m.uc.mem_write(replacement,b'DriverCrash\0');m.uc.mem_write(outfit,b'CustomOutfit\0');m.uc.mem_write(message+0x20,struct.pack('<I',8))
  available=[False];forwarded=[];interned=[];released=[];stat_calls=[]
  def text(at):return bytes(m.uc.mem_read(at,128)).split(b'\0')[0]
  def stat(path,out,*rest):stat_calls.append(text(path));return 0 if available[0] and text(path)==b'/app0/archives/driversonic.pak' else -1
  def intern(pool,value,*rest):interned.append(text(value));return replacement
  m.uc.mem_write(SYMBOLS['original_peer_customization'],struct.pack('<Q',original))
  m.intercept({original:lambda owner,msg,*rest:forwarded.append((owner,msg)),BASE+0x1574080:intern,BASE+0x1518e30:lambda pool,value,*rest:released.append(value),m.file_symbols['sceKernelStat']:stat})
  for hero,local_present,fallback in ((b'DriverCrash',False,False),(b'dRiVeRLiz',False,False),(b'DriverSonic',False,True),(b'DriverSonic',True,False)):
   available[0]=local_present;m.uc.mem_write(name,hero+b'\0');m.uc.mem_write(message+0x88,struct.pack('<Q',name));m.uc.mem_write(message+0x90,struct.pack('<Q',outfit))
   m.call(SYMBOLS['peer_customization'],SCRATCH,message)
   self.assertEqual(struct.unpack('<Q',m.uc.mem_read(message+0x88,8))[0],replacement if fallback else name)
   self.assertEqual(struct.unpack('<Q',m.uc.mem_read(message+0x90,8))[0],0 if fallback else outfit)
  self.assertEqual(len(forwarded),4);self.assertEqual(interned,[b'DriverCrash']);self.assertEqual(released,[name-16])
  self.assertEqual(stat_calls,[b'/app0/archives/driversonic.pak']*2);self.assertFalse(m.exit_calls)
 def test_v075_short_customization_message_is_forwarded_without_reading_a_hero(self):
  m=NativeMenusMachine();m.initialize();message=SCRATCH+0x1000;original=SCRATCH+0x31000;forwarded=[]
  m.uc.mem_write(SYMBOLS['original_peer_customization'],struct.pack('<Q',original));m.intercept({original:lambda owner,msg,*rest:forwarded.append(msg)})
  m.uc.mem_write(message+0x20,struct.pack('<I',7));m.uc.mem_write(message+0x88,struct.pack('<Q',1));before=bytes(m.uc.mem_read(message,0xc0))
  m.call(SYMBOLS['peer_customization'],SCRATCH,message);m.call(SYMBOLS['peer_customization'],SCRATCH,0)
  self.assertEqual(forwarded,[message,0]);self.assertEqual(bytes(m.uc.mem_read(message,0xc0)),before)
 def test_v075_character_lookup_rejects_path_components_and_never_writes_player_files(self):
  m=NativeMenusMachine();m.initialize();before=dict(m.files);calls=[]
  m.intercept({m.file_symbols['sceKernelStat']:lambda path,out,*rest:calls.append(path) or 0})
  for text in (b'/data/ryunet/profile.ini',b'/app0/archives/../identity.key.pak',b'/app0/archives/sub/driver.pak',b'/app0/archives/driver.pak/extra'):
   m.uc.mem_write(SCRATCH,text+b'\0');self.assertNotEqual(m.call(SYMBOLS['runtime_file_stat'],SCRATCH,SCRATCH+0x1000)&0xffffffff,0)
  self.assertFalse(calls);self.assertEqual(m.files,before)
 def test_bad_asset_helpers_vtable_or_page_permissions_never_install_partial_detours(self):
  for failure in ('asset','helper','vtable','permission','service','peer_receiver_tail'):
   m=NativeMenusMachine(failure);before=m.snapshot_game();self.assertEqual(m.initialize(),0);self.assertEqual(m.ready(),0,failure)
   # Existing, independently approved graphics/season hooks still install; new
   # native mode, CUP, contact and Graphics entry points must remain original.
   for rva,size in ((0x1277e00,17),(0xe916b0,20),(0xe92e90,17),(0x1109200,12),(0x1276c70,12),(0x2773b40,8),(0xec03c0,17)):
    page=rva&~4095;self.assertEqual(bytes(m.uc.mem_read(BASE+rva,size)),before[page][rva-page:rva-page+size],failure)
 def test_physics_and_ui_contexts_are_isolated_between_threads_and_bounded(self):
  m=NativeMenusMachine();m.initialize();self.assertEqual(m.ready(),1);a=m.pointer(SYMBOLS['ctr_native_mode_context']);m.uc.mem_write(a,b'\x07\x00\x00\x00')
  m.self_id=0xabc200;b=m.pointer(SYMBOLS['ctr_native_mode_context']);self.assertNotEqual(a,b);self.assertEqual(bytes(m.uc.mem_read(b,4)),bytes(4))
  m.self_id=0xabc100;self.assertEqual(m.pointer(SYMBOLS['ctr_native_mode_context']),a)
  for i in range(62):m.self_id=0x1000+i;self.assertNotEqual(m.pointer(SYMBOLS['ctr_native_mode_context']),0)
  m.self_id=0x999900;self.assertEqual(m.pointer(SYMBOLS['ctr_native_mode_context']),0)
 def test_save_changes_preserve_nickname_key_contacts_and_original_30_60_caps(self):
  m=NativeMenusMachine();path='/data/ryunet/users/12345678/settings.ini';m.files[path]=b'version=1\nfps=30\nfriends=First,Middle,Last\n';m.initialize();before={p:d for p,d in m.files.items() if not p.endswith(('ctr_native_port.log','settings.ini','settings.ini.tmp'))}
  row=SYMBOLS['ctr_native_graphics_row'];save=SYMBOLS['ctr_native_graphics_save']
  for cap in (30,60):
   m.call(row,2,1);m.call(save);self.assertIn(b'fps=0\n',m.files[path]);m.call(row,2,1);m.call(save);self.assertIn(('fps=%d\n'%cap).encode(),m.files[path])
   if cap==30:m.call(row,1,1);m.call(save)
  self.assertIn(b'friends=First,Middle,Last\n',m.files[path]);self.assertEqual({p:d for p,d in m.files.items() if not p.endswith(('ctr_native_port.log','settings.ini','settings.ini.tmp'))},before)
  self.assertFalse(m.exit_calls);self.assertFalse(m.fds)
if __name__=='__main__':unittest.main(verbosity=2)
