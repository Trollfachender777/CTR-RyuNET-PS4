"""Actual SELF: secure-first RyuNET requests and bounded, origin-safe fallback."""
import socket,struct,unittest
from test_native_updates import UpdateMachine
from test_native_bridge import prepare,STUB,SCRATCH
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import UC_X86_REG_RAX,UC_X86_REG_RSI
class Tests(unittest.TestCase):
    def invoke(self,m,name,*args):return m.call(m.exports[prepare.nid(name)],*args)
    def fixture(self,mode,ip=None):
        m=UpdateMachine(response=b'{"theme":"halloween","items":{}}');m.social_http=True
        self.assertEqual(m.initialize(),0)
        if ip:self.invoke(m,'ctr_net_server',struct.unpack('<I',socket.inet_aton(ip))[0])
        def hook(uc,address,size,user):
            url=m.requested[-1] if m.requested else ''
            if address==m.ui_symbols['sceHttpSendRequest']:
                m.offset=0
                if url.startswith('https://'):
                    if mode=='tls_failure':uc.reg_write(UC_X86_REG_RAX,0xffffffff)
                    elif mode in ('intercept','private'):m.response=b'<html>ISP warning</html>'
                elif url.startswith('http://octr.'):
                    if mode in ('intercept','private'):m.response=b'gateway'
                else:m.response=b'{"theme":"golden","items":{}}'
            if address==m.ui_symbols['sceHttpGetStatusCode'] and url.startswith('http://octr.') and mode in ('intercept','private'):
                uc.mem_write(uc.reg_read(UC_X86_REG_RSI),struct.pack('<i',302))
        m.uc.hook_add(UC_HOOK_CODE,hook,begin=STUB,end=STUB+4095)
        return m
    def run_request(self,m):self.invoke(m,'ctr_season_tick');self.assertEqual(len(m.tasks),1);m.finish()
    def test_valid_https_never_downgrades_or_changes_tls_policy(self):
        m=self.fixture('valid');before=dict(m.files);self.run_request(m)
        self.assertEqual(m.requested,['https://octr.ryu7w7.xyz/ryunet/theme']*2)
        self.assertEqual(self.invoke(m,'ctr_season_current'),1)
        self.assertEqual({p:v for p,v in m.files.items() if not p.endswith('ctr_native_port.log')},
                         {p:v for p,v in before.items() if not p.endswith('ctr_native_port.log')})
        self.assertEqual(m.policy['sceHttpsEnableOption'],(604,0xbd));self.assertEqual(m.policy['sceHttpSetAutoRedirect'],(604,0))
    def test_tls_failure_uses_the_existing_http_endpoint_and_cleans_both_attempts(self):
        m=self.fixture('tls_failure');self.run_request(m)
        self.assertEqual(m.requested,['https://octr.ryu7w7.xyz/ryunet/theme']*2+['http://octr.ryu7w7.xyz:8080/ryunet/theme']*2)
        self.assertEqual(self.invoke(m,'ctr_season_current'),1);self.assertEqual(len(m.cleanup),12)
    def test_intercepted_name_uses_only_the_existing_public_server_address(self):
        m=self.fixture('intercept','81.2.3.4');self.run_request(m)
        self.assertEqual(m.requested[-2:],['http://81.2.3.4:8080/ryunet/theme']*2)
        self.assertEqual(self.invoke(m,'ctr_season_current'),2);self.assertEqual(len(m.cleanup),18)
    def test_private_or_loopback_dns_result_never_receives_the_fallback_request(self):
        for ip in ('127.0.0.1','192.168.50.20','10.0.0.1'):
            m=self.fixture('private',ip);self.run_request(m)
            self.assertFalse(any('http://'+ip+':' in u for u in m.requested));self.assertEqual(self.invoke(m,'ctr_season_current'),0xffffffff)
if __name__=='__main__':unittest.main(verbosity=2)
