"""Execute the real SELF read hooks, Orbis stat ABI and supported game code."""
from pathlib import Path
import json,struct,subprocess,unittest
from test_native_bridge import ModuleMachine,prepare,STUB,SCRATCH,ROOT,SELF_BASE
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
BASE=0x900000000
INFO=json.loads((ROOT.parent/'ctr-v140-tools/SPEED_INPLACE.json').read_text())
PAIRS=[]
for pair in INFO['pairs']:
 raw=(ROOT.parent/'ctr-v140-tools/build/speed-inplace'/pair['normal']['file']).read_bytes();n=struct.unpack_from('<I',raw,16)[0];p=24+n;at,size=struct.unpack_from('<QI',raw,p);before=raw[p+12:p+12+size]
 fast=(ROOT.parent/'ctr-v140-tools/build/speed-inplace'/pair['speed']['file']).read_bytes()[p+12:p+12+size]
 PAIRS.append((pair,at,before,fast))
def symbols():
 output=subprocess.check_output([str(ROOT.parent/'ps4-online/llvm/bin/llvm-objdump.exe'),'-t',str(ROOT/'build/ctr_online.elf')],text=True)
 return {a[-1]:SELF_BASE+int(a[0],16) for line in output.splitlines() if len(a:=line.split())>=5 and all(c in '0123456789abcdefABCDEF' for c in a[0])}
SYMBOLS=symbols()
GOT=[41975936,41977672,41978568];LAZY=[29268520,29271992,29273784]
HEADERS=[]
for row in INFO['pairs']:
 with (ROOT.parents[1]/'outputs/Crash_Online/CTR-NitroFueled-PC-portable/CUSA13795-1.21/archives'/Path(row['guest']).name).open('rb') as f:HEADERS.append(f.read(512))
class SpeedMachine(ModuleMachine):
 def __init__(self,case='ui_speed'):
  super().__init__(case);self.instruction_budget=10000000
  self.map(SCRATCH,0x20000);self.allowed.append((SCRATCH,SCRATCH+0x20000));self.offset=0;self.payload=b'';self.index=0;self.fd=31;self.stat_bad=False;self.original_calls=[];self.stat_identity_mismatch=False;self.header_override=None;self.header_chunk=512;self.header_error=False;self.header_reads=[]
  names=['sceKernelStat','sceKernelFstat','fileno','sceKernelLseek','ftell','fread','sceKernelPread','sceKernelRead']
  self.file_symbols={name:STUB+0xe00+i*16 for i,name in enumerate(names)};self.ui_symbols.update(self.file_symbols)
  for got,lazy in zip(GOT,LAZY):self.map(BASE+got,8);self.uc.mem_write(BASE+got,struct.pack('<Q',BASE+lazy));self.allowed.append((BASE+got,BASE+got+8))
  def text(at):
   raw=bytes(self.uc.mem_read(at,128));return raw.split(b'\0')[0].decode()
  def stat(out,index,descriptor=False):
   data=bytearray(120);struct.pack_into('<IIHH',data,0,17,index+1,0o100644,1);struct.pack_into('<q',data,72,INFO['pairs'][index]['source_bytes']+(1 if self.stat_bad else 0));
   if descriptor and self.stat_identity_mismatch:struct.pack_into('<II',data,0,99,0)
   self.uc.mem_write(out,bytes(data))
  def code(uc,address,size,user):
   name=next((name for name,at in self.file_symbols.items() if at==address),None)
   if not name:return
   a,b,c,d=[uc.reg_read(r) for r in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX)];result=0
   if name=='sceKernelStat':
    found=next((i for i,p in enumerate(INFO['pairs']) if p['guest']==text(a)),None)
    if found is None:result=-1
    else:stat(b,found)
   elif name=='sceKernelFstat':
    if a!=self.fd:result=-1
    else:stat(b,self.index,True)
   elif name=='fileno':result=self.fd
   elif name in ('ftell','sceKernelLseek'):result=self.offset
   else:
    self.original_calls.append(name)
    if name=='sceKernelPread' and a==self.fd and d<512 and c+d==512:
     header=HEADERS[self.index] if self.header_override is None else self.header_override
     self.header_reads.append((d,c));result=-1 if self.header_error else max(0,min(c,len(header)-d,self.header_chunk))
     if result>0:uc.mem_write(b,header[d:d+result])
     uc.reg_write(UC_X86_REG_RAX,result&0xffffffffffffffff);return
    if name=='fread':count=min(c,len(self.payload)//b) if b else 0;amount=count*b;out=a;result=count
    else:out=b;amount=min(c,len(self.payload));result=amount
    if amount:uc.mem_write(out,self.payload[:amount])
   uc.reg_write(UC_X86_REG_RAX,result&0xffffffffffffffff)
  self.uc.hook_add(UC_HOOK_CODE,code,begin=STUB,end=STUB+4095)
 def bundled_libc(self,name='libc',failure=None):
  libc=0x7400000000
  raw=(ROOT.parent/'crash-ryunet-vnext/build/portable-readback-20261020-014120/libc.prx').read_bytes()
  elf,_,ph,_,_=prepare.parse_self(raw);dp=next(p for p in ph if p['type']==2)
  tags=dict(prepare.unpack('<QQ',elf,p) for p in range(dp['offset'],dp['offset']+dp['filesz'],16))
  dyn=next(p for p in ph if p['type']==0x61000000);blob=prepare.span(elf,dyn['offset'],dyn['filesz'])
  strings=prepare.span(blob,tags[0x61000035],tags[0x61000037]);syms=prepare.span(blob,tags[0x61000039],tags[0x6100003f]);exports={}
  for p in range(0,len(syms),24):
   n,_,_,section,value,_=prepare.unpack('<IBBHQQ',syms,p);nid=strings[n:strings.index(0,n)].decode().split('#')[0]
   for expected in ('fread','fileno','ftell'):
    if section and nid==prepare.nid(expected):
     seg=next(s for s in ph if s['type']==1 and s['flags']&1 and s['vaddr']<=value and value+32<=s['vaddr']+s['filesz'])
     data=bytes(prepare.span(elf,seg['offset']+value-seg['vaddr'],32));at=libc+value;self.map(at,32);self.uc.mem_write(at,data)
     exports[expected]=at;exports[nid]=at
  assert exports['fread']-libc==0x3d7d0
  if failure in ('fread','fileno','ftell'):self.uc.mem_write(exports[failure],b'\xcc')
  self.uc.mem_write(BASE+GOT[0],struct.pack('<Q',exports['fread']));self.libc_calls=[];self.global_file_helpers=[]
  def text(at):return bytes(self.uc.mem_read(at,128)).split(b'\0')[0].decode()
  def handled(uc):
   number=uc.reg_read(UC_X86_REG_RDI);a=uc.reg_read(UC_X86_REG_RSI);b=uc.reg_read(UC_X86_REG_RDX);c=uc.reg_read(UC_X86_REG_R10);result=0;yes=False
   if number==592:uc.mem_write(a,struct.pack('<iii',0,1,2));uc.mem_write(c,struct.pack('<Q',3));yes=True
   elif number==593 and a==2:
    info=struct.pack('<Q256s',352,name.encode())+struct.pack('<QIi',libc,0x60000,5)+bytes(48)+struct.pack('<I20s',1,b'\0'*20);uc.mem_write(b,info);yes=True
   elif number==591 and a==2:
    key=text(b);address=exports.get(key)
    if failure=='missing' and key in ('ftell',prepare.nid('ftell')):address=None
    if failure=='foreign_helper' and key in ('fileno',prepare.nid('fileno')):address=self.file_symbols['fileno']
    if address:uc.mem_write(c,struct.pack('<Q',address))
    else:result=-1
    yes=True
   if yes:
    flags=uc.reg_read(UC_X86_REG_EFLAGS);uc.reg_write(UC_X86_REG_EFLAGS,(flags|1) if result<0 else flags&~1);uc.reg_write(UC_X86_REG_RAX,abs(result));return True
   return False
  self.pc_filesystem=handled
  def code(uc,address,size,user):
   symbol=next((s for s in ('fread','fileno','ftell') if exports[s]==address),None)
   if not symbol:return
   self.libc_calls.append(symbol)
   if symbol=='fileno':result=self.fd
   elif symbol=='ftell':result=self.offset
   else:
    out,element,count=[uc.reg_read(r) for r in (UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX)];result=min(count,len(self.payload)//element) if element else 0
    if result:uc.mem_write(out,self.payload[:result*element])
   stack=uc.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',uc.mem_read(stack,8))[0]
   uc.reg_write(UC_X86_REG_RAX,result);uc.reg_write(UC_X86_REG_RSP,stack+8);uc.reg_write(UC_X86_REG_RIP,ret)
  self.uc.hook_add(UC_HOOK_CODE,code,begin=libc,end=libc+0x60000)
  def global_helpers(uc,address,size,user):
   if address in (self.file_symbols['fileno'],self.file_symbols['ftell']):self.global_file_helpers.append(address)
  self.uc.hook_add(UC_HOOK_CODE,global_helpers,begin=STUB,end=STUB+4095)
 def active(self,on=True):self.uc.mem_write(SYMBOLS['ctr_speed_active'],struct.pack('<i',int(on)))
 def hook(self,index):return struct.unpack('<Q',self.uc.mem_read(BASE+GOT[index],8))[0]
class Tests(unittest.TestCase):
 def machine(self):m=SpeedMachine();self.assertEqual(m.initialize(),0);self.assertEqual(m.call(SYMBOLS['ctr_speed_assets_ready']),1);return m
 def test_three_native_hooks_apply_only_when_enabled_and_original_size_is_retained(self):
  m=self.machine();before_files=dict(m.files)
  for i,(pair,at,normal,fast) in enumerate(PAIRS):
   m.index=i;m.offset=at;m.payload=normal
   m.active(False);self.assertEqual(m.call(m.hook(1),31,SCRATCH,len(normal),at),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),normal)
   m.active();self.assertEqual(m.call(m.hook(1),31,SCRATCH,len(normal),at),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
   self.assertEqual(m.call(m.hook(2),31,SCRATCH,len(normal)),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
   self.assertEqual(m.call(m.hook(0),SCRATCH,1,len(normal),SCRATCH+0x19000),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
  self.assertEqual({p:d for p,d in m.files.items() if p not in ('/data/GoldHEN/ctr_native_port.log','/temp0/ctr_native_port.log')},{p:d for p,d in before_files.items() if p not in ('/data/GoldHEN/ctr_native_port.log','/temp0/ctr_native_port.log')});self.assertTrue(m.files.get('/data/GoldHEN/ctr_native_port.log',b'').startswith(before_files.get('/data/GoldHEN/ctr_native_port.log',b'')))
 def test_pfs_inode_aliases_use_supported_header_for_all_archives_and_read_apis(self):
  m=self.machine();m.stat_identity_mismatch=True;m.active()
  for i,(_,at,normal,fast) in enumerate(PAIRS):
   m.index=i;m.offset=at;m.payload=normal
   self.assertEqual(m.call(m.hook(1),31,SCRATCH,len(normal),at),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
   self.assertEqual(m.call(m.hook(2),31,SCRATCH,len(normal)),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
   self.assertEqual(m.call(m.hook(0),SCRATCH,1,len(normal),SCRATCH+0x19000),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
   self.assertEqual(m.offset,at)
  self.assertTrue(m.header_reads)
 def test_wrong_header_short_header_and_header_io_failure_keep_same_size_file_unchanged(self):
  m=self.machine();m.stat_identity_mismatch=True;m.active();_,at,normal,_=PAIRS[3];m.index=3;m.offset=at;m.payload=normal
  for header,error in ((bytes([HEADERS[3][0]^1])+HEADERS[3][1:],False),(HEADERS[3][:100],False),(HEADERS[3],True)):
   m.header_override=header;m.header_error=error;self.assertEqual(m.call(m.hook(1),31,SCRATCH,len(normal),at),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),normal)
 def test_header_short_reads_are_completed_positionally_without_moving_the_game_stream(self):
  m=self.machine();m.stat_identity_mismatch=True;m.header_chunk=64;m.active();_,at,normal,fast=PAIRS[3];m.index=3;m.offset=at;m.payload=normal
  self.assertEqual(m.call(m.hook(0),SCRATCH,1,len(normal),SCRATCH+0x19000),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
  self.assertEqual(m.header_reads,[(i,512-i) for i in range(0,512,64)]);self.assertEqual(m.offset,at)
 def test_ctr_bundled_libc_export_is_accepted_with_its_own_file_helpers(self):
  for name in ('libc','libc.prx','/app0/sce_module/libc.prx'):
   m=SpeedMachine();m.bundled_libc(name);self.assertEqual(m.initialize(),0);self.assertEqual(m.call(SYMBOLS['ctr_speed_assets_ready']),1)
   _,at,normal,fast=PAIRS[0];m.offset=at;m.payload=normal;m.active()
   self.assertEqual(m.call(m.hook(0),SCRATCH,1,len(normal),SCRATCH+0x19000),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
   self.assertEqual(m.libc_calls,['fileno','ftell','fread']);self.assertEqual(m.global_file_helpers,[])
 def test_ctr_libc_preimages_missing_export_and_cross_library_helpers_fail_closed(self):
  for failure in ('fread','fileno','ftell','missing','foreign_helper'):
   m=SpeedMachine();m.bundled_libc(failure=failure);before=[m.hook(i) for i in range(3)]
   self.assertEqual(m.initialize(),0);self.assertEqual(m.call(SYMBOLS['ctr_speed_assets_ready']),0);self.assertEqual([m.hook(i) for i in range(3)],before)
 def test_unrelated_library_cannot_claim_ctr_file_exports(self):
  m=SpeedMachine();m.bundled_libc(name='third_party.prx');before=[m.hook(i) for i in range(3)]
  self.assertEqual(m.initialize(),0);self.assertEqual(m.call(SYMBOLS['ctr_speed_assets_ready']),0);self.assertEqual([m.hook(i) for i in range(3)],before)
 def test_split_pread_fread_elements_and_wrong_file_are_safe(self):
  m=self.machine();_,at,normal,fast=PAIRS[3];m.index=3;m.active();m.offset=at+1;m.payload=normal[1:9]
  self.assertEqual(m.call(m.hook(0),SCRATCH,4,2,SCRATCH+0x19000),2);self.assertEqual(bytes(m.uc.mem_read(SCRATCH,8)),fast[1:9])
  m.stat_bad=True;self.assertEqual(m.call(m.hook(1),31,SCRATCH,8,m.offset),8);self.assertEqual(bytes(m.uc.mem_read(SCRATCH,8)),normal[1:9])
 def test_preimage_mismatch_reports_failure_without_any_partial_speed_writes(self):
  m=self.machine();_,at,normal,_=PAIRS[0];m.payload=b'X'+normal[1:];m.offset=at;m.active()
  self.assertEqual(m.call(m.hook(1),31,SCRATCH,len(normal),at)&0xffffffff,0xffffffff);self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),m.payload)
 def test_foreign_hook_or_bad_source_size_does_not_change_any_read_slot(self):
  for failure in ('foreign','size'):
   m=SpeedMachine()
   if failure=='foreign':m.uc.mem_write(BASE+GOT[1],struct.pack('<Q',STUB+0xc00))
   else:m.stat_bad=True
   before=[m.hook(i) for i in range(3)];self.assertEqual(m.initialize(),0);self.assertEqual(m.call(SYMBOLS['ctr_speed_assets_ready']),0);self.assertEqual([m.hook(i) for i in range(3)],before)
 def test_bound_platform_export_is_accepted_even_if_global_lookup_returns_another_copy(self):
  m=SpeedMachine();alternate=STUB+0xd80;m.uc.mem_write(BASE+GOT[2],struct.pack('<Q',alternate))
  def text(at):return bytes(m.uc.mem_read(at,128)).split(b'\0')[0].decode()
  def handled(uc):
   number=uc.reg_read(UC_X86_REG_RDI);a=uc.reg_read(UC_X86_REG_RSI);b=uc.reg_read(UC_X86_REG_RDX);c=uc.reg_read(UC_X86_REG_R10);result=0;yes=False
   if number==592:uc.mem_write(a,struct.pack('<iii',0,1,2));uc.mem_write(c,struct.pack('<Q',3));yes=True
   elif number==593 and a==2:
    info=struct.pack('<Q256s',352,b'libkernel.sprx')+struct.pack('<QIi',STUB+0xd00,0x100,5)+bytes(48)+struct.pack('<I20s',1,b'\0'*20);uc.mem_write(b,info);yes=True
   elif number==591 and a==2:
    if text(b) in ('sceKernelRead',prepare.nid('sceKernelRead')):uc.mem_write(c,struct.pack('<Q',alternate))
    else:result=-1
    yes=True
   if yes:
    flags=uc.reg_read(UC_X86_REG_EFLAGS);uc.reg_write(UC_X86_REG_EFLAGS,(flags|1) if result<0 else flags&~1);uc.reg_write(UC_X86_REG_RAX,abs(result));return True
   return False
  m.pc_filesystem=handled
  def alias(uc,address,size,user):
   if address==alternate:
    n=min(len(m.payload),uc.reg_read(UC_X86_REG_RDX));uc.mem_write(uc.reg_read(UC_X86_REG_RSI),m.payload[:n]);uc.reg_write(UC_X86_REG_RAX,n)
  m.uc.hook_add(UC_HOOK_CODE,alias,begin=STUB,end=STUB+4095)
  self.assertEqual(m.initialize(),0);self.assertEqual(m.call(SYMBOLS['ctr_speed_assets_ready']),1)
  _,at,normal,fast=PAIRS[0];m.offset=at;m.payload=normal;m.active();self.assertEqual(m.call(m.hook(2),31,SCRATCH,len(normal)),len(normal));self.assertEqual(bytes(m.uc.mem_read(SCRATCH,len(normal))),fast)
 def test_private_reader_never_initializes_engine_state_before_it_is_ready(self):
  m=self.machine();m.map(BASE+0x2a92868,0x30);self.assertEqual(m.call(SYMBOLS['ctr_speed_private_now']),0)
 def test_guarded_private_reader_executes_the_original_supported_game_function(self):
  from test_native_bridge import P
  m=self.machine();raw=Path(P[0]['elf']).read_bytes();_,_,ph,_,_=prepare.parse_elf(raw)
  rva=0xf50350;n=0x130;s=next(x for x in ph if x['type']==1 and x['vaddr']<=rva and rva+n<=x['vaddr']+x['filesz']);off=s['offset']+rva-s['vaddr']
  m.map(BASE+rva,n);m.uc.mem_write(BASE+rva,raw[off:off+n])
  root=SCRATCH+0x500;slots=SCRATCH+0x600;ids=SCRATCH+0x700;objects=SCRATCH+0x800;obj=SCRATCH+0x900;kind=SCRATCH+0xa00;vtable=SCRATCH+0xb00
  for at,size in ((0x2a92868,0x30),(0x2a922d0,4),(0x2ae3230,8),(0x2acb3d8,8)):m.map(BASE+at,size)
  m.uc.mem_write(BASE+0x2a92868,b'\x01');m.uc.mem_write(BASE+0x2a92880,struct.pack('<QI',root,0x8000));m.uc.mem_write(BASE+0x2a922d0,struct.pack('<I',0xffffffff));m.uc.mem_write(BASE+0x2ae3230,struct.pack('<Q',kind))
  m.uc.mem_write(root+0x20,struct.pack('<QQ',objects,slots));m.uc.mem_write(slots+0xc,struct.pack('<I',1));m.uc.mem_write(slots+0x20,struct.pack('<Q',ids));m.uc.mem_write(ids,struct.pack('<H',0x8000));m.uc.mem_write(objects,struct.pack('<Q',obj));m.uc.mem_write(obj,struct.pack('<Q',vtable));m.uc.mem_write(obj+0x44,b'\x01')
  m.uc.mem_write(BASE+0x2acb3d8,struct.pack('<Q',SCRATCH+0xc00));m.uc.mem_write(SCRATCH+0xd3c,struct.pack('<I',1))
  m.map(BASE+0x3dbf90,16);m.uc.mem_write(BASE+0x3dbf90,b'\x48\xb8'+struct.pack('<Q',obj)+b'\xc3')
  self.assertEqual(m.call(SYMBOLS['ctr_speed_private_now']),1)
  m.uc.mem_write(SCRATCH+0xd3c,struct.pack('<I',2));self.assertEqual(m.call(SYMBOLS['ctr_speed_private_now']),0)
  m.uc.mem_write(SCRATCH+0xd3c,struct.pack('<I',1))
  m.uc.mem_write(obj+0x44,b'\x00');self.assertEqual(m.call(SYMBOLS['ctr_speed_private_now']),0)
  m.uc.mem_write(ids,b'\x01\x80');self.assertEqual(m.call(SYMBOLS['ctr_speed_private_now']),0)
 def test_speed_season_override_preserves_registers_and_flags(self):
  from test_native_season import SITE,STACK
  m=self.machine();m.active();outer=SCRATCH+0x16000;config=SCRATCH+0x17000;m.uc.mem_write(outer+0x130,struct.pack('<Q',config));m.uc.mem_write(config+0x18,struct.pack('<I',2))
  m.uc.reg_write(UC_X86_REG_R15,outer);m.uc.reg_write(UC_X86_REG_R13,SCRATCH+0x18000);m.uc.reg_write(UC_X86_REG_EFLAGS,0x246);m.uc.reg_write(UC_X86_REG_RSP,STACK+0x1f000)
  m.uc.emu_start(SITE,SITE+13,count=100);self.assertEqual(m.uc.reg_read(UC_X86_REG_RSI),0);self.assertEqual(m.uc.reg_read(UC_X86_REG_EFLAGS),0x246)
if __name__=='__main__':unittest.main(verbosity=2)
