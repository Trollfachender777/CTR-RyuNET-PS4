"""Differential tests against pinned OCTR v0.6.5 on the owner's real IGZ layout."""
from pathlib import Path
import ctypes as C, importlib.util, json, os, random, struct, sys, unittest
from test_core import lib,ROOT

WORK=ROOT.parent
sys.path.insert(0,str(WORK/'ctr-v130-tools/upstream-v0.6.5/scripts'))
spec=importlib.util.spec_from_file_location('pinned_item_rules',WORK/'ctr-v130-tools/upstream-v0.6.5/scripts/item_rules.py')
pc=importlib.util.module_from_spec(spec);spec.loader.exec_module(pc)
SOURCE=Path(os.environ.get('CTR_TEST_SYSTEMDATA',WORK/'ctr-liz-pop-dark/donor-private/update2/loosedata/systemData.igz'))
BLOB=SOURCE.read_bytes();TABLES=pc.Tables(BLOB)
class Write(C.Structure):_fields_=[('offset',C.c_uint32),('bits',C.c_uint32),('sha256',C.c_char*65)]
class Rules(C.Structure):_fields_=[('masks',C.c_uint32*11),('values',(C.c_float*13)*11),('order',(C.c_uint8*13)*11),('counts',C.c_uint8*11),('count',C.c_uint32),('writes',Write*128)]
Check=C.CFUNCTYPE(C.c_int,C.c_uint64,C.c_size_t,C.c_int)
lib.ctr_items_parse.argtypes=[C.c_char_p,C.c_size_t,C.POINTER(Rules)]
lib.ctr_items_accept.argtypes=[C.c_char_p,C.c_size_t]
lib.ctr_items_apply.argtypes=[C.c_uint64,Check]

class Fixture:
    def __init__(self,deny=None):
        self.original=bytes(TABLES.igz.data);self.memory=C.create_string_buffer(self.original,len(self.original));self.base=C.addressof(self.memory)
        for at in TABLES.igz.sites['ROFS']:
            value=struct.unpack_from('<Q',self.original,at)[0]
            C.memmove(self.base+at,struct.pack('<Q',self.base+value),8)
        def check(address,size,write):
            if not self.base<=address<=self.base+len(self.original)-size:return 0
            if deny is not None and write and address<=self.base+deny<address+size:return 0
            return 1
        self.check=Check(check);self.object=self.base+TABLES.data
    def original_coordinates(self):
        out=bytearray(self.memory.raw)
        for at in TABLES.igz.sites['ROFS']:out[at:at+8]=self.original[at:at+8]
        return bytes(out)

class Tests(unittest.TestCase):
    def setUp(self):lib.ctr_items_reset()
    def accept(self,rules):
        body=json.dumps({'theme':'halloween','items':rules}).encode()
        self.assertEqual(lib.ctr_items_accept(body,len(body)),0)
    def same_as_pc(self,rules):
        fixture=Fixture();self.accept(rules)
        self.assertGreaterEqual(lib.ctr_items_apply(fixture.object,fixture.check),0)
        expected,_=pc.apply(BLOB,rules)
        self.assertEqual(fixture.original_coordinates(),bytes(pc.Tables(expected).igz.data))
        self.assertEqual(lib.ctr_items_pending(),0)
    def test_defaults_and_absent_rules_do_not_touch_a_byte(self):
        for rules in ({},None):
            lib.ctr_items_reset();fixture=Fixture();before=fixture.memory.raw;self.accept(rules)
            self.assertEqual(lib.ctr_items_pending(),0);self.assertEqual(lib.ctr_items_apply(0,fixture.check),0)
            self.assertEqual(fixture.memory.raw,before)
    def test_official_pc_examples_match_byte_for_byte_in_real_relocated_game_data(self):
        original=pc.read_rules(BLOB)
        turbo={name:(100 if name=='Turbo Boost' else 0) for name in original['race'][0]}
        cases=[{'race':[turbo]*8,'cooldowns':{'Warp Orb':5},'bacon':{'Bomb':0,'Nothing':3}},
               {'race':[{'Super Engine':50,'Invisibility':0}]+[{}]*7},
               {'battle':{'Bomb':311,'Missile':0}},
               {'race':[{'Bomb':'1.25'}],'cooldowns':{"N'Tropy Clock":20}}]
        for rules in cases:
            lib.ctr_items_reset();self.same_as_pc(rules)
    def test_one_hundred_random_rule_sets_match_official_pc_exactly(self):
        rng=random.Random(65300);names=list(TABLES.keys)
        for _ in range(100):
            rules={'race':[{n:rng.choice([0,1,5,50,1.5,0.3333]) for n in rng.sample(names,6)} for _ in range(rng.randrange(1,9))],
                   'battle':{n:rng.randrange(1000) for n in rng.sample(names,6)},
                   'bacon':{n:rng.randrange(1000) for n in rng.sample(names,6)},'cooldowns':{'Warp Orb':rng.randrange(121)}}
            lib.ctr_items_reset();self.same_as_pc(rules)
    def test_raw_scalar_write_is_pinned_to_exact_source_and_matches_pc(self):
        at=TABLES.weights(TABLES.sections()['race'][0])['Bomb']
        self.same_as_pc({'writes':[{'sha256':pc.read_rules(BLOB)['sha256'],'offset':at,'f32':77},
                                   {'sha256':'0'*64,'offset':at,'f32':12}]})
    def test_raw_pointer_or_metadata_write_cannot_corrupt_the_loaded_game(self):
        for offset in [TABLES.data,TABLES.data+24,TABLES.sections()['race'][0]+0x20]:
            lib.ctr_items_reset();fixture=Fixture();before=fixture.memory.raw
            self.accept({'writes':[{'sha256':pc.read_rules(BLOB)['sha256'],'offset':offset,'u32':0}]})
            self.assertGreaterEqual(lib.ctr_items_apply(fixture.object,fixture.check),0)
            self.assertEqual(lib.ctr_items_skipped(),1)
            self.assertEqual(fixture.memory.raw,before)
    def test_denied_or_inconsistent_memory_never_partially_changes_other_tables(self):
        slot=TABLES.weights(TABLES.sections()['race'][7])['Bomb']
        for fixture in (Fixture(deny=slot),Fixture()):
            lib.ctr_items_reset()
            if fixture.check(fixture.base+slot,4,1):C.memmove(fixture.object+24,struct.pack('<Q',0x1234),8)
            before=fixture.memory.raw;self.accept({'race':[{'Bomb':15}]*8})
            self.assertLess(lib.ctr_items_apply(fixture.object,fixture.check),0);self.assertEqual(fixture.memory.raw,before)
    def test_bad_json_or_out_of_range_weights_do_not_publish_or_modify_output(self):
        bad=[b'{"items":{"race":[{"Bomb":-1}]}}',b'{"items":{"race":[{"Bomb":1e30}]}}',
             b'{"items":{"race":[{"Bomb":"nan"}]}}',b'{"items":{"race":[{"Bomb":1,"Bomb":2}]}}',
             b'{"items":{},"items":{}}',b'{"items":{"race":'+json.dumps([{}]*9).encode()+b'}}',
             b'{"items":{"race":[{"Bomb":01}]}}',b'{}\0',b'{"items":{}}junk',b'x'*65536]
        for body in bad:
            out=Rules();C.memset(C.byref(out),0x55,C.sizeof(out));before=bytes(out)
            self.assertLess(lib.ctr_items_parse(body,len(body),C.byref(out)),0)
            self.assertEqual(bytes(out),before);self.assertLess(lib.ctr_items_accept(body,len(body)),0)
            self.assertEqual(lib.ctr_items_pending(),0)
    def test_first_good_server_snapshot_is_frozen_for_this_run(self):
        self.accept({'race':[{'Bomb':77}]});body=b'{"items":{"race":[{"Bomb":88}]}}'
        self.assertEqual(lib.ctr_items_accept(body,len(body)),0)
        fixture=Fixture();self.assertGreater(lib.ctr_items_apply(fixture.object,fixture.check),0)
        at=TABLES.weights(TABLES.sections()['race'][0])['Bomb']
        self.assertEqual(struct.unpack_from('<f',fixture.memory.raw,at)[0],77)
        before=fixture.memory.raw;self.assertEqual(lib.ctr_items_apply(0,fixture.check),0);self.assertEqual(before,fixture.memory.raw)

if __name__=='__main__':unittest.main(verbosity=2)
