"""Exercise compiled code with real image bytes and hostile pointer graphs."""
from pathlib import Path
import ctypes as C
import struct
import sys
import unittest
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT.parents[1]/'outputs/Crash_Online/CTR-NitroFueled-PC-portable/scripts'))
import prepare
raw=(ROOT.parent/'ctr-character-unlock/installed-eboot.ftp-view.elf').read_bytes()
image,_,segments,_,_=prepare.parse_elf(raw)
def actual(rva,length):
    for s in segments:
        if s['type']==1 and s['vaddr']<=rva and rva+length<=s['vaddr']+s['filesz']:
            at=s['offset']+rva-s['vaddr'];return bytes(image[at:at+length])
    raise AssertionError(hex(rva))
READ=C.CFUNCTYPE(C.c_int,C.c_uint64,C.c_void_p,C.c_size_t)
WRITE=C.CFUNCTYPE(C.c_int,C.c_uint64,C.c_uint8,C.c_uint8)
TRACE=C.CFUNCTYPE(None,C.c_int32,C.c_int32)
class IO(C.Structure):_fields_=[('read',READ),('write',WRITE),('trace',TRACE)]
lib=C.CDLL(str(ROOT/'build/ctr_core_test.dll'))
lib.ctr_characters_init.argtypes=[C.c_uint64,C.POINTER(IO)]

class Graph:
    def __init__(self,base=0x2000000000):
        self.base=base;self.wrapper=0x5000000000;self.control=self.wrapper+0x1000;self.object=self.wrapper+0x2000
        self.mem={};self.writes=[];self.denied=False;self.root_reads=0;self.flip_root=False;self.flip_flags=False;self.control_reads=0
        for rva,n in ((0x9f0cf0,13),(0x109e2e0,8),(0x1ce8d73,11)):
            self.mem[base+rva]=bytearray(actual(rva,n))
        for rva,value in ((0x25d1fa8,base+0x109e2e0),(0x25d1da0,base+0x109e410),(0x2ab1bd0,self.wrapper)):
            self.mem[base+rva]=bytearray(struct.pack('<Q',value))
        w=bytearray(32);struct.pack_into('<Q',w,0,base+0x25d1da0);struct.pack_into('<Q',w,16,self.control);self.mem[self.wrapper]=w
        c=bytearray(48);struct.pack_into('<I',c,0,2);struct.pack_into('<Q',c,40,self.object);self.mem[self.control]=c
        o=bytearray([0x5a]*152);struct.pack_into('<Q',o,0,base+0x25d1fa8);o[0x80]=1;o[0x81]=0;self.mem[self.object]=o
        self.reader=READ(self.read);self.writer=WRITE(self.write);self.tracer=TRACE(lambda a,b:None);self.io=IO(self.reader,self.writer,self.tracer)
    def read(self,at,out,n):
        if at==self.base+0x2ab1bd0:
            self.root_reads+=1
            if self.flip_root and self.root_reads==2:self.mem[at][:]=struct.pack('<Q',self.wrapper+8)
        if at==self.control:
            self.control_reads+=1
            if self.flip_flags and self.control_reads==2:struct.pack_into('<I',self.mem[at],0,3)
        for start,data in self.mem.items():
            if start<=at and at+n<=start+len(data):C.memmove(out,bytes(data[at-start:at-start+n]),n);return 0
        return -1
    def write(self,at,old,new):
        if self.denied:return -1
        if at!=self.object+0x81 or self.mem[self.object][0x81]!=old:return -1
        self.writes.append((at,old,new));self.mem[self.object][0x81]=new;return 0
    def init(self):return lib.ctr_characters_init(self.base,C.byref(self.io))

class Checks(unittest.TestCase):
    def test_valid_flag_only_at_two_bases(self):
        for base in (0x2000000000,0x3000000000):
            g=Graph(base);self.assertEqual(g.init(),0)
            before={k:bytes(v) for k,v in g.mem.items()}
            self.assertEqual(lib.ctr_characters_status(),0)
            self.assertEqual(lib.ctr_characters_enable(),1)
            self.assertEqual(lib.ctr_characters_status(),1)
            changes=[at+i for at,data in g.mem.items() for i,v in enumerate(data) if v!=before[at][i]]
            self.assertEqual(changes,[g.object+0x81]);self.assertEqual(len(g.writes),1)
            self.assertEqual(lib.ctr_characters_enable(),1);self.assertEqual(len(g.writes),1)
            self.assertEqual(g.mem[g.object][0x80],1)
    def test_image_guards(self):
        for rva in (0x9f0cf0,0x109e2e0,0x1ce8d73,0x25d1fa8,0x25d1da0):
            g=Graph();g.mem[g.base+rva][0]^=1
            self.assertLess(g.init(),0);self.assertLess(lib.ctr_characters_enable(),0);self.assertEqual(g.writes,[])
    def test_invalid_graph(self):
        for case in ('no_wrapper','unaligned_wrapper','wrapper_type','no_control','control_type','no_object','object_type','truncated_object','bad_bool'):
            g=Graph();self.assertEqual(g.init(),0)
            if case=='no_wrapper':g.mem[g.base+0x2ab1bd0][:]=bytes(8)
            if case=='unaligned_wrapper':g.mem[g.base+0x2ab1bd0][:]=struct.pack('<Q',g.wrapper+1)
            if case=='wrapper_type':g.mem[g.wrapper][0]^=1
            if case=='no_control':g.mem[g.wrapper][16:24]=bytes(8)
            if case=='control_type':struct.pack_into('<I',g.mem[g.control],0,0x30000000)
            if case=='no_object':g.mem[g.control][40:48]=bytes(8)
            if case=='object_type':g.mem[g.object][0]^=1
            if case=='truncated_object':g.mem[g.object]=g.mem[g.object][:0x82]
            if case=='bad_bool':g.mem[g.object][0x81]=255
            before={k:bytes(v) for k,v in g.mem.items()}
            self.assertLess(lib.ctr_characters_enable(),0,case);self.assertEqual(g.writes,[],case)
            self.assertEqual(before,{k:bytes(v) for k,v in g.mem.items()},case)
    def test_changed_roots_or_control_do_not_write(self):
        for attr in ('flip_root','flip_flags'):
            g=Graph();self.assertEqual(g.init(),0);setattr(g,attr,True)
            self.assertLess(lib.ctr_characters_enable(),0);self.assertEqual(g.writes,[])
    def test_denied_write(self):
        g=Graph();g.init();g.denied=True
        self.assertEqual(lib.ctr_characters_enable(),-12);self.assertEqual(g.writes,[])
        self.assertEqual(g.mem[g.object][0x81],0)
    def test_failed_reinitialization_is_disabled(self):
        g=Graph();self.assertEqual(g.init(),0)
        self.assertEqual(lib.ctr_characters_init(0,None),-1)
        self.assertLess(lib.ctr_characters_enable(),0);self.assertEqual(g.writes,[])
if __name__=='__main__':unittest.main()
