"""Production asset/migration code, with only PS4 platform calls substituted."""
from pathlib import Path
import ctypes as C,hashlib,struct,unittest
ROOT=Path(__file__).resolve().parent
LANG='es'
ASSET=(ROOT.parent/'ctr-v150-tools/build/native-assets-v074/update3.pak').read_bytes()
BUNDLED='/app0/archives/update3.pak'
DIRECTORY='/data/ryunet/assets/ui-5b4a4062b75966fa'
RESOURCE=DIRECTORY+'/update3.pak'
TARGET='/data/ryunet/'+LANG+'/ctr_online.prx'
SHIPPED='/app0/sce_module/ctr_online.prx'
DLL=C.CDLL(str(ROOT/'build/asset_test.dll'))
System=C.CFUNCTYPE(C.c_int64,C.c_int64,*([C.c_uint64]*6))
Fetch=C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_size_t,C.POINTER(C.c_size_t))
Load=C.CFUNCTYPE(C.c_int32,C.c_char_p,C.c_size_t,C.c_void_p,C.c_uint32,C.c_void_p,C.POINTER(C.c_int32))
Unload=C.CFUNCTYPE(C.c_int32,C.c_int32,C.c_size_t,C.c_void_p,C.c_uint32,C.c_void_p,C.POINTER(C.c_int32))
Initialize=C.CFUNCTYPE(C.c_int32)
Version=C.CFUNCTYPE(C.c_uint32)
Notify=C.CFUNCTYPE(C.c_int32,C.c_int32,C.c_void_p,C.c_size_t,C.c_int32)
class Segment(C.Structure):_fields_=[('address',C.c_uint64),('size',C.c_uint32),('protection',C.c_int32)]
class Module(C.Structure):_fields_=[('size',C.c_uint64),('name',C.c_char*256),('segments',Segment*4),('count',C.c_uint32),('fingerprint',C.c_uint8*20)]
DLL.test_reset.argtypes=[System,C.c_void_p,C.c_int]
DLL.test_verify.argtypes=[C.c_char_p]
DLL.test_store.argtypes=[C.c_void_p,C.c_size_t]
DLL.test_migration.argtypes=[C.POINTER(C.c_int32)]
DLL.test_route.argtypes=[C.c_uint64,C.c_void_p]
DLL.ctr_assets_bytes_valid.argtypes=[C.c_void_p,C.c_size_t]
DLL.ctr_update_self_valid.argtypes=[C.c_void_p,C.c_size_t]
def small_self(marker):
    out=bytearray(4096);out[:4]=bytes.fromhex('4f153d1d');struct.pack_into('<H',out,24,1)
    struct.pack_into('<QQQQ',out,32,0x800,1024,256,256)
    base=64;out[base:base+7]=b'\x7fELF\x02\x01\x01';struct.pack_into('<H',out,base+18,62)
    struct.pack_into('<Q',out,base+32,64);struct.pack_into('<HH',out,base+54,56,1)
    struct.pack_into('<Q',out,base+64+32,256);out[-1]=marker;return bytes(out)

class Platform:
    def __init__(self,fault=None):
        self.fault=fault;self.files={TARGET:small_self(99),TARGET+'.previous':small_self(42),SHIPPED:small_self(12),'/data/ryunet/users/example/profile.ini':b'PRIVATE-KEEP', '/data/ryunet/users/example/identity.key':b'PRIVATE-KEY'}
        self.initial_users={p:v for p,v in self.files.items() if '/users/' in p}
        self.fd={};self.nextfd=8;self.calls=[];self.notifications=[];self.errors=[];self.refs=[];self.initialized=0;self.loaded={};self.versions={TARGET+'.previous':1002001,SHIPPED:1001000}
        self.read_cap=16381;self.write_cap=17321;self.read_override=None;self.symbol_override={};self.module_info={}
        def load(path,*args):
            path=path.decode();self.calls.append(('load',path));args[-1][0]=0
            if self.fault=='load':return -1
            handle=50+len(self.loaded);self.loaded[handle]=path;return handle
        def unload(handle,*args):self.calls.append(('unload',handle));return 0
        def initialize():
            self.initialized+=1
            if self.files.get(TARGET)!=small_self(42 if self.loaded and TARGET+'.previous' in self.loaded.values() else 12):self.errors.append('fallback not restored before initialization')
            self.assert_users();return -1 if self.fault=='initialize' else 0
        def notify(_kind,request,size,_flags):
            if size!=3120:self.errors.append('notification ABI')
            self.notifications.append(C.string_at(request+45).decode());return 0
        self.symbols={'sceKernelLoadStartModule':Load(load),'sceKernelStopUnloadModule':Unload(unload),'sceKernelSendNotificationRequest':Notify(notify)}
        self.initialize=Initialize(initialize)
        def fetch(out,cap,length):
            self.calls.append(('fetch',cap))
            data=ASSET
            if self.fault=='network':return -1
            if self.fault=='truncated':data=data[:-1]
            if self.fault=='corrupt':data=data[:1000]+b'FAIL'+data[1004:]
            C.memmove(out,data,len(data));length[0]=len(data);return 0
        self.fetch=Fetch(fetch)
        def system(*args):
            try:return self.system(*args)
            except BaseException as error:self.errors.append(repr(error));return -999
        self.callback=System(system)
        DLL.test_reset(self.callback,C.cast(self.fetch,C.c_void_p),-1 if fault=='spawn' else 0)
    def assert_users(self):
        if {p:v for p,v in self.files.items() if '/users/' in p}!=self.initial_users:self.errors.append('user data changed')
    def system(self,n,a,b,c,d,e,f):
        if n==5:
            path=C.string_at(a).decode();self.calls.append(('open',path,b))
            if path.endswith('.download') and self.fault=='disk':return -28
            if b&1:
                if self.fault=='pending' and path.endswith('.pending-assets'):return -28
                self.files[path]=b''
            elif path not in self.files:return -2
            self.nextfd+=1;self.fd[self.nextfd]=[path,0,b];return self.nextfd
        if n==3:
            path,at,mode=self.fd[a];data=self.files[path]
            if self.read_override and self.read_override(path,at):return -5
            chunk=data[at:at+min(c,self.read_cap)];self.fd[a][1]+=len(chunk);C.memmove(b,chunk,len(chunk));return len(chunk)
        if n==4:
            path,at,mode=self.fd[a];size=min(c,self.write_cap);chunk=C.string_at(b,size)
            if self.fault=='readback' and path.endswith('.download') and not at:chunk=b'FAIL'+chunk[4:]
            self.files[path]=self.files[path][:at]+chunk;self.fd[a][1]+=size;return size
        if n==6:self.fd.pop(a);return 0
        if n==95:return -5 if self.fault=='fsync' else 0
        if n==124:return -5 if self.fault=='chmod' else 0
        if n==10:self.files.pop(C.string_at(a).decode(),None);return 0
        if n==128:
            old,new=C.string_at(a).decode(),C.string_at(b).decode();self.calls.append(('rename',old,new))
            if self.fault=='rename' or (self.fault=='commit' and old.endswith('.pending-assets')):return -5
            self.files[new]=self.files.pop(old);return 0
        if n==136:return -17
        if n==477:
            if self.fault=='mmap':return -12
            self.memory=C.create_string_buffer(b);return C.addressof(self.memory)
        if n==73:self.calls.append(('munmap',b));return 0
        if n==74:
            self.calls.append(('protect',a,c));return -5 if self.fault=='protect' else 0
        if n==592:
            ids=list(self.module_info) if self.module_info else [1]
            for index,value in enumerate(ids):C.c_int32.from_address(a+4*index).value=value
            C.c_uint64.from_address(c).value=len(ids);return 0
        if n==593:
            if a not in self.module_info:return -1
            C.memmove(b,C.byref(self.module_info[a]),C.sizeof(Module));return 0
        if n==591:
            name=C.string_at(b).decode();value=self.symbol_override.get((a,name))
            if value is None:
                if a in self.loaded and name=='ctr_updater_version':
                    value=Version(lambda:self.versions.get(self.loaded[a],0));self.refs.append(value)
                elif a in self.loaded and name=='ctr_initialize':value=self.initialize
                elif a==1:value=self.symbols.get(name)
            if value is None:C.c_void_p.from_address(c).value=0;return -1
            C.c_void_p.from_address(c).value=value if isinstance(value,int) else C.cast(value,C.c_void_p).value;return 0
        raise AssertionError((n,a,b,c))
    def migrate(self):
        result=C.c_int32(-999);r=DLL.test_migration(C.byref(result));return r,result.value
    def healthy(self,case):
        self.assert_users();case.assertFalse(self.fd);case.assertEqual(self.errors,[])

class Tests(unittest.TestCase):
    def test_real_chunk_hashes_accept_exact_asset_and_reject_changes_including_last_chunk(self):
        self.assertEqual(hashlib.sha256(ASSET).hexdigest(),'5b4a4062b75966fa0ed1b9485dd3c01b76f9af12454312dc1a02da971780b8ed')
        self.assertEqual(DLL.ctr_assets_bytes_valid(ASSET,len(ASSET)),1)
        for data in (ASSET[:-1],ASSET+b'X',b'FAIL'+ASSET[4:],ASSET[:-1]+bytes([ASSET[-1]^1])):
            self.assertEqual(DLL.ctr_assets_bytes_valid(data,len(data)),0)
    def test_file_verification_handles_short_reads_truncation_extra_data_and_io_failure(self):
        for data,expected in ((ASSET,1),(ASSET[:-1],0),(ASSET+b'X',0),(ASSET[:-1]+b'X',0)):
            p=Platform();p.files[RESOURCE]=data;self.assertEqual(DLL.test_verify(RESOURCE.encode()),expected);p.healthy(self)
        p=Platform();p.files[RESOURCE]=ASSET;p.read_override=lambda path,at:at>65536
        self.assertEqual(DLL.test_verify(RESOURCE.encode()),0);p.healthy(self)
    def test_store_commits_only_complete_verified_resource(self):
        p=Platform();self.assertEqual(DLL.test_store(ASSET,len(ASSET)),0);self.assertEqual(p.files[RESOURCE],ASSET);self.assertNotIn(RESOURCE+'.download',p.files);p.healthy(self)
        for fault in ('disk','fsync','readback','rename'):
            p=Platform(fault);p.files[RESOURCE]=b'existing'
            self.assertLess(DLL.test_store(ASSET,len(ASSET)),0);self.assertEqual(p.files[RESOURCE],b'existing');self.assertNotIn(RESOURCE+'.download',p.files);p.healthy(self)
    def test_boot_uses_bundled_before_external_and_checks_both(self):
        p=Platform();p.files[BUNDLED]=ASSET;p.files[RESOURCE]=ASSET;self.assertEqual(DLL.ctr_assets_boot_source(),1)
        p=Platform();p.files[BUNDLED]=b'bad';p.files[RESOURCE]=ASSET;self.assertEqual(DLL.ctr_assets_boot_source(),2)
        p=Platform();self.assertEqual(DLL.ctr_assets_boot_source(),0);p.healthy(self)
    def test_migration_restores_old_version_before_initialization_and_defers_download(self):
        p=Platform();self.assertEqual(p.migrate(),(1,0));self.assertEqual(p.files[TARGET],small_self(42));self.assertEqual(p.files[TARGET+'.pending-assets'],small_self(99));self.assertNotIn(RESOURCE,p.files);self.assertFalse(any(c[0]=='fetch' for c in p.calls));self.assertEqual(p.initialized,1)
        self.assertEqual(DLL.test_worker(),0);self.assertEqual(p.files[TARGET],small_self(99));self.assertEqual(p.files[RESOURCE],ASSET);self.assertNotIn(TARGET+'.pending-assets',p.files);self.assertEqual(p.files[TARGET+'.previous'],small_self(42));self.assertTrue(any('preparada' in text or 'ready' in text for text in p.notifications));p.healthy(self)
    def test_network_memory_disk_and_commit_errors_keep_old_working_version(self):
        for fault in ('network','truncated','corrupt','disk','fsync','readback','commit','mmap'):
            with self.subTest(fault=fault):
                p=Platform(fault)
                # fsync/readback are injected after safe restoration, at download.
                p.fault=None;self.assertEqual(p.migrate(),(1,0));p.fault=fault
                self.assertEqual(DLL.test_worker(),0);self.assertEqual(p.files[TARGET],small_self(42));p.healthy(self)
    def test_preparation_failure_never_runs_new_or_old_initializer(self):
        for fault in ('load','pending','fsync','chmod','rename'):
            p=Platform(fault);self.assertEqual(p.migrate()[0],0);self.assertEqual(p.initialized,0);self.assertEqual(p.files[TARGET],small_self(99));p.healthy(self)
    def test_fallback_requires_older_version_and_can_use_bundled_code(self):
        for version in (0,1005002,1005003):
            p=Platform();p.versions[TARGET+'.previous']=version;p.files.pop(SHIPPED)
            self.assertEqual(p.migrate()[0],0);self.assertEqual(p.initialized,0);self.assertTrue(any(c[0]=='unload' for c in p.calls));p.healthy(self)
        p=Platform();p.files.pop(TARGET+'.previous');self.assertEqual(p.migrate(),(1,0));self.assertEqual(p.files[TARGET],small_self(12));p.healthy(self)
    def test_concurrent_newer_module_and_tampered_pending_code_are_never_replaced(self):
        for path in (TARGET,TARGET+'.pending-assets'):
            p=Platform();self.assertEqual(p.migrate(),(1,0));p.files[path]=small_self(77);DLL.test_worker()
            self.assertEqual(p.files[path],small_self(77));self.assertNotEqual(p.files[TARGET],small_self(99));p.healthy(self)
    def test_failed_spawn_keeps_restored_version_and_repeated_initialize_is_idempotent(self):
        p=Platform('spawn');self.assertEqual(p.migrate(),(1,0));self.assertEqual(p.files[TARGET],small_self(42));self.assertEqual(p.migrate(),(1,0));self.assertEqual(p.initialized,1);p.healthy(self)
    def route_fixture(self,fault=None):
        p=Platform(fault);p.files[RESOURCE]=ASSET
        memory=C.create_string_buffer(0x280c000);p.refs.append(memory);base=C.addressof(memory)
        info=Module();info.size=C.sizeof(info);info.name=b'eboot.bin';info.count=1;info.segments[0]=Segment(base,len(memory),3)
        imports=[(0x2807be8,0x1be90f8,'fopen',1),(0x2808768,0x1bea7f8,'sceKernelStat',2),(0x2808928,0x1beab78,'sceKernelOpen',2)]
        calls=[]
        fopen=C.CFUNCTYPE(C.c_void_p,C.c_char_p,C.c_char_p)(lambda path,mode:(calls.append(('fopen',path.decode(),mode.decode())),1234)[1])
        stat=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_void_p)(lambda path,out:(calls.append(('stat',path.decode())),0)[1])
        open_=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_int,C.c_int)(lambda path,flags,mode:(calls.append(('open',path.decode(),flags)),8)[1])
        p.refs.extend((fopen,stat,open_))
        for (got,lazy,name,owner),fn in zip(imports,(fopen,stat,open_)):
            C.c_uint64.from_address(base+got).value=base+lazy;pointer=C.cast(fn,C.c_void_p).value
            p.symbol_override[(owner,name)]=fn
            if owner not in p.module_info:
                m=Module();m.size=C.sizeof(m);m.name=b'libc.prx' if owner==1 else b'libkernel.sprx';m.count=1;p.module_info[owner]=m
            m=p.module_info[owner];i=m.count-1;m.segments[i]=Segment(pointer,1,5);m.count+=1
        # Avoid a trailing empty segment; kernel has two exported functions.
        for m in p.module_info.values():m.count-=1
        return p,base,info,imports,calls
    def test_game_import_route_is_read_only_and_exact_path_only(self):
        p,base,info,imports,calls=self.route_fixture();self.assertEqual(DLL.test_route(base,C.byref(info)),0)
        ptrs=[C.c_uint64.from_address(base+row[0]).value for row in imports]
        fopen=C.CFUNCTYPE(C.c_void_p,C.c_char_p,C.c_char_p)(ptrs[0]);stat=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_void_p)(ptrs[1]);open_=C.CFUNCTYPE(C.c_int,C.c_char_p,C.c_int,C.c_int)(ptrs[2])
        fopen(BUNDLED.encode(),b'rb');fopen(BUNDLED.encode(),b'wb');fopen(b'/app0/archives/update2.pak',b'rb');stat(BUNDLED.encode(),None);open_(BUNDLED.encode(),0,0);open_(BUNDLED.encode(),1,0)
        self.assertEqual(calls,[('fopen',RESOURCE,'rb'),('fopen',BUNDLED,'wb'),('fopen','/app0/archives/update2.pak','rb'),('stat',RESOURCE),('open',RESOURCE,0),('open',BUNDLED,1)]);p.healthy(self)
    def test_route_rejects_foreign_import_or_failed_protection_before_any_hook(self):
        for fault in ('foreign','protect'):
            p,base,info,imports,calls=self.route_fixture(fault)
            if fault=='foreign':C.c_uint64.from_address(base+imports[1][0]).value=1234
            before=[C.c_uint64.from_address(base+r[0]).value for r in imports]
            self.assertLess(DLL.test_route(base,C.byref(info)),0)
            self.assertEqual([C.c_uint64.from_address(base+r[0]).value for r in imports],before);self.assertEqual(calls,[]);p.healthy(self)
if __name__=='__main__':unittest.main(verbosity=2)
