from pathlib import Path
import subprocess,os,json,hashlib
ROOT=Path(__file__).resolve().parent
TOOLS=ROOT.parent/'ps4-online'
LLVM=Path(os.environ.get('CTR_LLVM_BIN',TOOLS/'llvm/bin'));OO=Path(os.environ.get('OO_PS4_TOOLCHAIN',TOOLS/'openorbis'));BUILD=ROOT/'build';SRC=ROOT/'src'
BUILD.mkdir(exist_ok=True)
def run(args):
    env=os.environ.copy();env['OO_PS4_TOOLCHAIN']=str(OO)
    p=subprocess.run([str(x) for x in args],capture_output=True,text=True,env=env,cwd=ROOT)
    if p.stdout:print(p.stdout)
    if p.stderr:print(p.stderr)
    if p.returncode:raise SystemExit(p.returncode)
objects=[]
for name in ['online_core.c', 'identity_hash.c', 'installation.c', 'mini.c', 'settings.c', 'profile.c', 'friends.c', 'sessions.c', 'menu.c', 'characters.c', 'updates.c', 'updater.c', 'native_updates.c', 'native_assets.c', 'native_asset_migration.c', 'frame_limit.c', 'net_tunnel.c', 'runtime_net_tunnel.c', 'runtime_net_ping.c', 'social.c', 'season.c', 'items.c', 'native_items.c', 'native_season.c', 'season_hook.S', 'net_transport.c', 'native_network.c', 'frame_hooks.S', 'native_ui.c', 'native_bridge.c', 'native_syscall.S', 'room_mode.c', 'speed_view.c', 'native_speed.c', 'native_online_mode.c', 'native_itemless.c', 'native_menu_services.c', 'native_menu_patch.c', 'native_graphics_settings.c', 'native_room_bridge.c', 'native_menu_code.S']:
    obj=BUILD/(name.replace('/','_').replace('.','-')+'.o')
    run([LLVM/'clang.exe','--target=x86_64-pc-freebsd12-elf','-ffreestanding','-fno-builtin','-fno-stack-protector','-fPIC','-fvisibility=hidden','-DCTR_MODS_EN=0','-I'+str(SRC/'pcmod/compat'),'-I'+str(SRC/'pcmod'),'-I'+str(SRC/'vendor/compat'),'-DMINIZ_NO_STDIO','-DMINIZ_NO_TIME','-DMINIZ_NO_MALLOC','-DMINIZ_NO_DEFLATE_APIS','-DMINIZ_NO_ZLIB_APIS','-DNDEBUG','-Oz',*(['-w'] if ('vendor/' in name) else ['-Wall','-Wextra','-Werror']),'-I'+str(SRC),'-c',SRC/name,'-o',obj]);objects.append(obj)
cpp=BUILD/'native_graphics-cpp.o'
run([LLVM/'clang.exe','-x','c++','--target=x86_64-pc-freebsd12-elf','-std=c++20','-ffreestanding','-fno-builtin','-fno-stack-protector','-fPIC','-fvisibility=hidden','-fno-exceptions','-fno-rtti','-nostdinc++','-DCTR_MODS_EN=0','-Oz','-Wall','-Wextra','-Werror','-I'+str(SRC),'-c',SRC/'native_graphics.cpp','-o',cpp]);objects.append(cpp)
crt=BUILD/'native-crt.o'
run([LLVM/'clang.exe','--target=x86_64-pc-freebsd12-elf','-ffreestanding','-fno-builtin','-fno-stack-protector','-fPIC','-isystem',OO/'include','-c',TOOLS/'sdk-source/GoldHEN_Plugins_SDK-main/crt/crtprx.c','-o',crt]);objects.append(crt)
elf=BUILD/'ctr_online.elf'
run([LLVM/'ld.lld.exe','-m','elf_x86_64','-pie','--script',OO/'link.x','-e','_init','--eh-frame-hdr',*objects,'-o',elf])
prx=BUILD/'ctr_online.prx'
run([OO/'bin/windows/create-fself.exe','-in=build/ctr_online.elf','-out=build/ctr_online.oelf','--lib=build/ctr_online.prx','--paid','0x3800000000000011'])
from ps4_transport import require_self
require_self(prx.read_bytes())
print(json.dumps({'file':str(prx),'bytes':prx.stat().st_size,'sha256':hashlib.file_digest(prx.open('rb'),'sha256').hexdigest(),'status':'native module compiled; console validation pending'},indent=2))
