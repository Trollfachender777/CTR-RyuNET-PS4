# SPDX-License-Identifier: LGPL-3.0-or-later
"""Bind an approved RyuNET update to its user's exact base; never edit inputs.

PKG serialization and deterministic public-key header encoding follow
LibOrbisPkg (LGPL-3.0). No game data or private identity is required by this tool.
"""
import argparse
from ftplib import FTP, Error as FtpError
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import struct
import sys
import tempfile
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
CONTENT_ID = b'IV9999-RYUN00001_00-CRASHRYUNET00001'
APPROVED = {'becb5a7624cc0b596c98528e0a2d7520f4115346be03d122c80ae1c6f9ad2614': 'v1.5.2 ES', '957128e6b98adbd6cca588316cbd0cc79d3c84672be33b163356b2d52c7266eb': 'v1.5.2 EN'}

def digest(data):
    return hashlib.sha256(data).digest()

def check(condition, message):
    if not condition:
        raise ValueError(message)

def u32(data, at):
    return struct.unpack_from('>I', data, at)[0]

def u64(data, at):
    return struct.unpack_from('>Q', data, at)[0]

def entry(data, meta):
    return data[meta[4]:meta[4]+meta[5]]

def metadata(path, allow_prefix=False):
    with Path(path).open('rb') as stream:
        header = stream.read(0x1100)
        check(header[:4] == b'\x7fCNT', 'Not a PS4 PKG / No es un PKG PS4')
        size = u64(header, 0x410)
        check(0x1100 <= size <= 8*1024*1024, 'Unsupported package metadata layout')
        check(header[0x40:0x70].rstrip(b'\0') == CONTENT_ID, 'Select the RyuNET BASE PKG, not original CTR CUSA13795')
        check(digest(header[:0xfe0]) == header[0xfe0:0x1000], 'Damaged package header')
        check(Path(path).stat().st_size == u64(header, 0x430) or
              (allow_prefix and Path(path).stat().st_size == size), 'Incomplete PKG / PKG incompleto')
        stream.seek(0)
        data = bytearray(stream.read(size))
    check(len(data) == size, 'Incomplete metadata')
    body, count, table = u64(data, 0x20), u32(data, 0x10), u32(data, 0x18)
    check(0 < count < 4096 and table + count*32 <= size, 'Invalid entry table')
    check(body <= size and u64(data,0x28) == size-body, 'Unsupported body layout')
    check(digest(data[body:]) == data[0x160:0x180], 'Damaged package metadata')
    metas = [struct.unpack_from('>6I', data, table+i*32) for i in range(count)]
    check(len({m[0] for m in metas}) == count, 'Duplicate metadata entry')
    check(all(0 <= m[4] <= size and m[5] <= size-m[4] for m in metas), 'Metadata outside package prefix')
    by_id = {m[0]:m for m in metas}
    for key in (1,0x10,0x20,0x80,0x100,0x1000):
        check(key in by_id, 'Missing required entry')
    check(metas[0][0] == 1 and by_id[1][5] >= 32*count, 'Unsupported digest table')
    hashes = entry(data,by_id[1])
    for i,m in enumerate(metas[1:],1):
        check(digest(entry(data,m)) == hashes[i*32:(i+1)*32], 'Entry checksum mismatch')
    g = entry(data,by_id[0x80])
    check(g[:2] == b'\xd2V' and len(g) in (0x180,0x1c0), 'Unsupported general digests')
    check(not by_id[0x80][2]&0x80000000, 'Encrypted general digests unsupported')
    sf = entry(data,by_id[0x1000])
    check(sf[:4] == b'\0PSF', 'Invalid SFO')
    _,_,keys,values,n = struct.unpack_from('<5I',sf)
    fields = {}
    for i in range(n):
        ko,fmt,length,capacity,vo = struct.unpack_from('<HHIII',sf,20+i*16)
        name = sf[keys+ko:sf.index(0,keys+ko)].decode('ascii')
        fields[name] = sf[values+vo:values+vo+length].rstrip(b'\0')
    check(fields.get('TITLE_ID') == b'RYUN00001', 'Wrong title ID')
    return data, metas, by_id, fields

def signature(header_hash):
    modulus = bytes.fromhex((ROOT/'public_header_modulus.txt').read_text().strip())
    check(len(modulus)==256, 'Invalid public header key')
    seed = digest(digest(modulus+header_hash))
    # CPython's integer seed uses the same MT19937 init_by_array sequence.
    words = struct.unpack('>8I',seed)
    rng = random.Random(int.from_bytes(struct.pack('<8I',*words),'little'))
    padding = bytearray()
    while len(padding)<221:
        block = digest(struct.pack('>12I',*(rng.getrandbits(32) for _ in range(12))))
        padding.extend(b for b in block if b)
    encoded = b'\0\2'+padding[:221]+b'\0'+header_hash
    return pow(int.from_bytes(encoded,'big'),65537,int.from_bytes(modulus,'big')).to_bytes(256,'big')

def base_metadata(source):
    if not source.startswith('ftp://'):
        return metadata(Path(source))
    url=urlsplit(source)
    check(url.hostname is not None and url.username is None and url.password is None and
          url.path in ('','/') and not url.query and not url.fragment,
          'Use ftp://IP:2121 without a username or file path')
    ftp=FTP(timeout=8)
    try:
        ftp.connect(url.hostname,url.port or 2121)
        ftp.login('anonymous','anonymous')
        ftp.voidcmd('TYPE I')
        stream=ftp.transfercmd('RETR /user/app/RYUN00001/app.pkg')
        try:
            data=bytearray()
            target=0x1100
            while len(data)<target:
                part=stream.recv(min(262144,target-len(data)))
                check(bool(part),'Incomplete FTP metadata')
                data.extend(part)
                if len(data)==0x1100:
                    check(data[:4]==b'\x7fCNT','The installed base is not a PKG')
                    target=u64(data,0x410)
                    check(0x1100<target<=8*1024*1024,'Unsupported installed base metadata')
        finally:stream.close()
    finally:ftp.close()
    with tempfile.TemporaryDirectory(prefix='ryunet-origin-') as tmp:
        path=Path(tmp)/'base.metadata'
        path.write_bytes(data)
        return metadata(path,allow_prefix=True)

def repair_prefix(patch, metas, by_id, base_general):
    out = bytearray(patch)
    gmeta = by_id[0x80]
    general = bytearray(entry(out,gmeta))
    check(len(general)==0x1c0 and general[:4]==b'\xd2V\1\1', 'Use an approved current RyuNET update PKG')
    check(u32(general,28)&0x1400==0x1400, 'Missing origin slots')
    general[0x140:0x160] = base_general[0x20:0x40]
    general[0x180:0x1a0] = base_general[0x40:0x60]
    out[gmeta[4]:gmeta[4]+gmeta[5]] = general
    dmeta = by_id[1]
    for i,m in enumerate(metas[1:],1):
        at = dmeta[4]+i*32
        out[at:at+32] = digest(entry(out,m))
    out[0x140:0x160] = digest(entry(out,dmeta))
    for at,ids in ((0x100,(0x10,0x20,0x80,0x100,1)),(0x120,(0x10,0x20,0x80,0x100))):
        pieces=[]
        for key in ids:
            b=entry(out,by_id[key])
            if at==0x120 and key==0x100:
                b=b[:struct.unpack_from('>H',out,0x14)[0]*32]
            pieces.append(b)
        out[at:at+32]=digest(b''.join(pieces))
    out[0x160:0x180] = digest(out[u64(out,0x20):])
    out[0xfe0:0x1000] = digest(out[:0xfe0])
    out[0x1000:0x1100] = signature(digest(out[:0x1000]))
    return out

def bind(base_path, update_path, output_path):
    base_source=str(base_path)
    base_path,update_path,output_path=map(Path,(base_path,update_path,output_path))
    remote=base_source.startswith('ftp://')
    check(remote or base_path.resolve()!=update_path.resolve(), 'Base and update must be different files')
    check(not output_path.exists(), 'Output already exists; originals are preserved')
    check(output_path.resolve() not in (base_path.resolve(),update_path.resolve()), 'Do not overwrite an input')
    # The update is small; the multi-GB base is read only up to its metadata end.
    h=hashlib.sha256()
    with update_path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    label=APPROVED.get(h.hexdigest())
    check(label is not None, 'Unknown update: use an approved RyuNET v1.5.2 PKG')
    base,_,bm,bfields=base_metadata(base_source)
    patch,metas,pm,pfields=metadata(update_path)
    check(bfields.get('CATEGORY')==b'gd', 'The base must be the original RyuNET application PKG, not another patch')
    check(pfields.get('CATEGORY')==b'gp', 'Select an update PKG')
    for key in ('APP_TYPE','ATTRIBUTE','ATTRIBUTE2','SAVEDATA_DIRECTORY','SAVEDATA_BLOCKS','SAVEDATA_MAX_SIZE','SAVEDATA_LIST_PARAM','VERSION'):
        check(bfields.get(key)==pfields.get(key), 'Incompatible base settings: '+key)
    check(bfields.get('APP_VER',b'') < pfields.get('APP_VER',b''), 'Base version must precede this update')
    bg=entry(base,bm[0x80])
    check(u32(bg,28)&6==6 and any(bg[0x20:0x40]) and any(bg[0x40:0x60]), 'Invalid base digests')
    fixed=repair_prefix(patch,metas,pm,bg)
    output_path.parent.mkdir(parents=True,exist_ok=True)
    temporary=output_path.with_name(output_path.name+'.partial')
    check(not temporary.exists(), 'A partial output already exists')
    try:
        with temporary.open('xb') as dst, update_path.open('rb') as src:
            dst.write(fixed)
            src.seek(len(patch))
            shutil.copyfileobj(src,dst,1024*1024)
            dst.flush();os.fsync(dst.fileno())
        verified,_,vm,_=metadata(temporary)
        check(verified==fixed, 'Output verification failed')
        vg=entry(verified,vm[0x80])
        check(vg[0x140:0x160]==bg[0x20:0x40] and vg[0x180:0x1a0]==bg[0x40:0x60], 'Origin verification failed')
        # Payload must remain identical, byte for byte.
        with temporary.open('rb') as f,update_path.open('rb') as original:
            f.seek(len(fixed));original.seek(len(patch))
            while True:
                a,b=f.read(1024*1024),original.read(1024*1024)
                check(a==b,'Payload changed')
                if not a:break
        check(not output_path.exists(), 'Output appeared during work')
        temporary.rename(output_path)
    except Exception:
        if temporary.exists():temporary.unlink()
        raise
    return {'update':label,'output':str(output_path),'base_read_only':True,
        'original_update_read_only':True,'game_payload_unchanged':True,
        'origin_content_digest':bg[0x20:0x40].hex(),'origin_game_digest':bg[0x40:0x60].hex(),
        'console_install_test_pending':True}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base');p.add_argument('--update');p.add_argument('--output')
    a=p.parse_args()
    base=a.base or input('RyuNET BASE PKG or ftp://IP:2121 / PKG BASE o ftp://IP:2121: ').strip().strip('"')
    update=a.update or input('Update PKG / PKG actualizacion: ').strip().strip('"')
    output=a.output or str(ROOT/'Output'/(Path(Path(update).name.removesuffix('.template')).stem+'_Matched.pkg'))
    result=bind(base,update,output)
    Path(output+'.verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,struct.error,KeyError,EOFError,FtpError) as e:
        print('ERROR: '+str(e),file=sys.stderr);sys.exit(1)
