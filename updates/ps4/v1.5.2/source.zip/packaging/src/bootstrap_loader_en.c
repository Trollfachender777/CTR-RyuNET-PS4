// SPDX-License-Identifier: GPL-2.0-only
#include <stdint.h>
#include <stddef.h>
extern int64_t ctr_syscall(int64_t,...);
static void loader_trace(int32_t stage,int32_t code){
    char line[]="CTR loader stage=00000000 code=00000000\n";
    const char hex[]="0123456789abcdef";
    for(int i=0;i<8;i++){line[17+i]=hex[((uint32_t)stage>>((7-i)*4))&15];line[31+i]=hex[((uint32_t)code>>((7-i)*4))&15];}
    int64_t fd=ctr_syscall(5,"/data/GoldHEN/ctr_native_port.log",0x209,0666);
    if(fd<0)fd=ctr_syscall(5,"/temp0/ctr_native_port.log",0x209,0666);
    if(fd>=0){ctr_syscall(4,fd,line,sizeof(line)-1);ctr_syscall(6,fd);}
}
// Use Sony's complete module loader, including its relocation/init handling.
// This function runs outside that loader before and after every loader call.
int ctr_load_port_module(void){
    loader_trace(50,0);
    int32_t handles[256];uint64_t count=0;
    if(ctr_syscall(592,handles,(size_t)256,&count)!=0 || count>256){loader_trace(51,-1);return -1;}
    typedef int32_t(*LoadModule)(const char*,size_t,const void*,uint32_t,const void*,int32_t*);
    LoadModule load=0;
    for(uint64_t i=0;i<count;i++){
        void *symbol=0;
        if(ctr_syscall(591,handles[i],"sceKernelLoadStartModule",&symbol)==0 && symbol){load=(LoadModule)symbol;break;}
    }
    if(!load){loader_trace(52,-2);return -2;}
    int32_t result=0;
    int32_t module=load("/data/ryunet/en/ctr_online.prx",0,0,0,0,&result);
    loader_trace(56,module);
    // A rebuilt PKG must never be overridden by an older downloaded module.
    // Reject it before ctr_initialize can touch game imports, then unload it
    // before loading the bundled module with the same library identity.
    if(module>=0){
        void *version=0;int compatible=ctr_syscall(591,module,"ctr_updater_version",&version)==0&&version&&((uint32_t(*)(void))version)()>=1005002U;
        if(!compatible){
            void *stop=0;
            for(uint64_t i=0;i<count;i++)if(!ctr_syscall(591,handles[i],"sceKernelStopUnloadModule",&stop)&&stop)break;
            if(!stop){loader_trace(57,-4);return -4;}
            typedef int32_t(*StopModule)(int32_t,size_t,const void*,uint32_t,const void*,int32_t*);
            int32_t stopped=((StopModule)stop)(module,0,0,0,0,&result);
            if(stopped<0){loader_trace(57,stopped);return stopped;}module=-1;
        }
    }
    if(module<0)module=load("/app0/sce_module/ctr_online.prx",0,0,0,0,&result);
    loader_trace(53,module);
    if(module<0)return module;
    void *entry=0;
    if(ctr_syscall(591,module,"ctr_initialize",&entry)!=0 || !entry){loader_trace(54,-3);return -3;}
    int32_t status=((int32_t(*)(void))entry)();loader_trace(55,status);return status;
}
