"""Run candidate regression suites sequentially to bound CPU/RAM use."""
from pathlib import Path
import argparse,json,os,re,subprocess,sys
def main():
    parser=argparse.ArgumentParser();parser.add_argument('language',choices=('es','en'));parser.add_argument('--only',nargs='*');args=parser.parse_args()
    root=Path(__file__).resolve().parent.parent/f'ctr-v152-{args.language}'
    scripts=[root/('test_'+name+'.py') for name in args.only] if args.only else sorted(root.glob('test_*.py'))
    log=root/'build/checks';log.mkdir(exist_ok=True)
    previous=json.loads((log/'RESULTS.json').read_text())['suites'] if (log/'RESULTS.json').exists() and args.only else []
    results=[x for x in previous if x['suite'] not in {p.stem for p in scripts}]
    env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    for script in scripts:
        p=subprocess.run([sys.executable,'-B',str(script)],cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
        text=p.stdout+p.stderr;(log/(script.stem+'.log')).write_text(text,encoding='utf-8')
        match=re.findall(r'Ran (\d+) tests?',text)
        row={'suite':script.stem,'exit_code':p.returncode,'tests':int(match[-1]) if match else None};results.append(row)
        print(json.dumps(row),flush=True)
        if p.returncode:print(text[-5000:],flush=True)
        (log/'RESULTS.json').write_text(json.dumps({'language':args.language,'all_passed':all(x['exit_code']==0 for x in results),'suites':results},indent=2),encoding='utf-8')
    raise SystemExit(not all(x['exit_code']==0 for x in results))
if __name__=='__main__':main()

