"""Stage v1.5.2 separately; never replace the last working public packages."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent
OLD=WORK/'ctr-game-update-v151';NEW=WORK/'ctr-game-update-v152'
OUT=WORK.parent/'outputs/CTR_RyuNET_v1.5.2_Candidate'
def main():
    if NEW.exists():raise RuntimeError('Staging already exists')
    hashes={lang:hashlib.sha256((WORK/f'ctr-v152-{lang}/build/ctr_online.prx').read_bytes()).hexdigest() for lang in ('es','en')}
    (NEW/'build').mkdir(parents=True)
    for name in ('src','templates','pkg-engine-source'):shutil.copytree(OLD/name,NEW/name)
    shutil.copytree(OLD/'build/base',NEW/'build/base')
    for name in ('installed-base.metadata','installed-base-metadata.json','external-module-plan.json'):shutil.copy2(OLD/'build'/name,NEW/'build'/name)
    (NEW/'build-r3').mkdir()
    shutil.copy2(OLD/'build-r3/LibOrbisPkg.GameUpdateV150.dll',NEW/'build-r3/LibOrbisPkg.GameUpdateV150.dll')
    payload=OUT/'updates/ps4/v1.5.2';payload.mkdir(parents=True)
    for lang in ('es','en'):shutil.copy2(WORK/f'ctr-v152-{lang}/build/ctr_online.prx',payload/f'ctr_online_{lang}.prx')
    for name in ('prepare_patch.py','stage_r3.py','make_en_r3.py','test_bootstrap.py','verify_package.ps1','inspect_origin_digest.py'):
        text=(OLD/name).read_text().replace('v1.5.1','v1.5.2').replace('01.51','01.52')
        text=text.replace("'>=1005001U'","'>=1005002U'")
        text=text.replace("1005000 if scenario=='external_older' else 1005001","1005001 if scenario=='external_older' else 1005002")
        text=text.replace('79beafff5679736f4ed018296fde016c48e140bb77d085ce84363be5ff4d915f',hashes['es'])
        text=text.replace('86f7c19b46004aca9fda2e7e9b09584cc761abbc18129d087a6ffdd7251d27c5',hashes['en'])
        (NEW/name).write_text(text)
    for name in ('build_manual.ps1','audit_manual.py'):
        text=(WORK/'ctr-v150-tools'/name).read_text().replace('ctr-game-update-v151','ctr-game-update-v152').replace('v1.5.1','v1.5.2').replace('01.51','01.52').replace('readback-v151-v075','readback-v152-v075').replace('ctr-v150-','ctr-v152-')
        (ROOT/name).write_text(text)
    for name in ('NATIVE_ASSETS.json','RESOURCE_VERIFICATION.json','NATIVE_ASSET_VERIFIER_TESTS.json'):shutil.copy2(WORK/'ctr-v150-tools'/name,ROOT/name)
    (ROOT/'MODULES.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'staging':str(NEW),'version':'v1.5.2','profiles_copied':False,'minimum_external_version':1005002}))
if __name__=='__main__':main()
