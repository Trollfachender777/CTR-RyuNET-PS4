param([ValidateSet('es','en')][string]$Language='es')
$ErrorActionPreference='Stop'
$taskRoot=Join-Path $PSScriptRoot '../ctr-game-update-v152'
$folder=if($Language -eq 'en'){'build-r3-en'}else{'build-r3'}
$proof=if($Language -eq 'en'){'build-r3-en/bootstrap-test-result.json'}else{'build/bootstrap-test-result.json'}
if(-not(Get-Content -LiteralPath (Join-Path $taskRoot $proof) -Raw|ConvertFrom-Json).successful){throw 'Verified native bootstrap required'}
$sources=(Get-ChildItem -LiteralPath (Join-Path $taskRoot 'pkg-engine-source') -Recurse -Filter '*.cs').FullName
$assembly=Join-Path $taskRoot 'build-r3/LibOrbisPkg.GameUpdateV150.dll'
if(-not(Test-Path -LiteralPath $assembly)){Add-Type -Path $sources -OutputAssembly $assembly -CompilerOptions '/define:CORE','/unsafe','/optimize' -IgnoreWarnings}
[Reflection.Assembly]::LoadFrom($assembly)|Out-Null
$projectFile=Join-Path $taskRoot ($folder+'/update.gp4')
$stream=[IO.File]::OpenRead($projectFile)
try{$project=[LibOrbisPkg.GP4.Gp4Project]::ReadFrom($stream)}finally{$stream.Dispose()}
$dir=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($projectFile))
foreach($issue in [LibOrbisPkg.GP4.Gp4Validator]::ValidateProject($project,$dir)){if($issue.Type.ToString() -eq 'Fatal'){throw $issue.Message}}
$props=[LibOrbisPkg.PKG.PkgProperties]::FromGp4($project,$dir)
$expected=Get-Content -LiteralPath (Join-Path $taskRoot 'build/installed-base-metadata.json') -Raw|ConvertFrom-Json
if([Convert]::ToHexString($props.OriginContentDigest).ToLowerInvariant() -ne $expected.origin_content_digest){throw 'Base content binding mismatch'}
if([Convert]::ToHexString($props.OriginGameDigest).ToLowerInvariant() -ne $expected.origin_game_digest){throw 'Base image binding mismatch'}
$output=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../outputs/CTR_RyuNET_v1.5.2_Candidate/Manual_PKG'))
New-Item -ItemType Directory -Path $output -Force|Out-Null
$file=Join-Path $output ('CTR_Nitro-Fueled_Online_RyuNET_v1.5.2_Update_'+$Language.ToUpperInvariant()+'.pkg')
if(Test-Path -LiteralPath $file){throw 'Refusing to replace an existing PKG'}
$pkg=[LibOrbisPkg.PKG.PkgBuilder]::new($props).Write($file)
@{file=$file;bytes=$pkg.Header.package_size;sha256=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant();title_id='RYUN00001';app_version='01.52';ryunet_version='v1.5.2';upstream='v0.7.5';language=$Language;origin_content_digest=$expected.origin_content_digest;origin_game_digest=$expected.origin_game_digest;hardware_test_pending=$true}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $taskRoot ($folder+'/pkg-result.json'))
Write-Output ('Created private candidate: '+$file)
