"""Independent PKG integrity, extraction, base binding and identity exclusion."""
from pathlib import Path
import hashlib,json,re,struct,subprocess,sys
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent;R=WORK/'ctr-game-update-v152'
PW=Path('C:/Users/Trollface/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
FORBIDDEN=[] # Local owner markers are intentionally not distributed.
ALLOWED={'archives/update3.pak','eboot.bin','sce_module/ctr_online.prx','sce_module/ryunet-updater.txt','sce_sys/icon0.png','sce_sys/keystone','sce_sys/nptitle.dat','sce_sys/param.sfo','sce_sys/app/playgo-chunk.dat','sce_sys/app/playgo-chunk.sha','sce_sys/app/playgo-manifest.xml','sce_sys/changeinfo/changeinfo.xml'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def digests(path):
 with path.open('rb') as f:
  header=f.read(0x1100);count=struct.unpack_from('>I',header,0x10)[0];pos=struct.unpack_from('>I',header,0x18)[0];f.seek(pos);table=f.read(32*count)
  for i in range(count):
   kind,_,_,_,offset,n=struct.unpack_from('>6I',table,32*i)
   if kind==0x80:f.seek(offset);return header,f.read(n)
 raise ValueError('Missing general digests')
def bind(header,g,bh,bg):
 assert header[0x40:0x70]==bh[0x40:0x70],'title mismatch'
 assert struct.unpack_from('>H',g,2)[0]==0x101,'wrong digest layout'
 assert struct.unpack_from('>I',g,28)[0]&0x1400==0x1400,'missing base binding'
 assert g[0x140:0x160]==bg[0x20:0x40],'different base content'
 assert g[0x180:0x1a0]==bg[0x40:0x60],'different base image'
def sfo(raw):
 _,_,keys,values,count=struct.unpack_from('<5I',raw);out={}
 for i in range(count):
  ko,fmt,n,cap,vo=struct.unpack_from('<HHIII',raw,20+i*16);key=raw[keys+ko:raw.index(0,keys+ko)].decode();out[key]=(fmt,raw[values+vo:values+vo+n])
 return out
base=R/'build/installed-base.metadata';bh,bg=digests(base)
proof=json.loads((R/'build/installed-base-metadata.json').read_text());assert sha(bh)==proof['header_sha256']
native_assets=json.loads((ROOT/'NATIVE_ASSETS.json').read_text());assert native_assets['successful']
script=(R/'verify_package.ps1').read_text();checks={}
for lang in ('es','en'):
 folder='build-r3-en' if lang=='en' else 'build-r3';B=R/folder;info=json.loads((B/'pkg-result.json').read_text(encoding='utf-8-sig'))
 code=script[:script.index('$inputFile =')].replace('CtrGamePatchAudit','CtrGamePatchAudit'+lang.upper())
 assembly=R/'build-r3/LibOrbisPkg.GameUpdateV150.dll'
 code=code.replace("$assembly = if ($env:CTR_PKG_ENGINE)","$assembly = if ($env:CTR_PKG_ENGINE)")
 code=code.replace("$workspaceRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))","$workspaceRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))\n$env:CTR_PKG_ENGINE='"+assembly.as_posix()+"'")
 code+="$inputFile='"+info['file'].replace('\\','/')+"'\n[CtrGamePatchAudit"+lang.upper()+"]::Run($inputFile,(Join-Path $PSScriptRoot '"+folder+"/readback-v152-v075'))\n"
 target=R/f'verify_{lang}.ps1';target.write_text(code)
 p=subprocess.run([str(PW),'-NoProfile','-File',str(target)],capture_output=True,text=True,encoding='utf-8',errors='replace');(B/'readback-validation.log').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 file=Path(info['file']);raw=file.read_bytes();assert sha(raw)==info['sha256'];h,g=digests(file);bind(h,g,bh,bg)
 negative=[]
 for label,at in (('missing-binding',28),('wrong-origin',0x140),('wrong-layout',2)):
  altered=bytearray(g)
  if label=='missing-binding':struct.pack_into('>I',altered,28,0)
  else:altered[at]^=1
  try:bind(h,altered,bh,bg)
  except AssertionError:negative.append(label)
  else:raise AssertionError('A broken base binding passed')
 staging=json.loads((B/'staging.json').read_text());actual={x.relative_to(B/'readback-v152-v075').as_posix() for x in (B/'readback-v152-v075').rglob('*') if x.is_file()};assert actual==ALLOWED==set(staging['files'])
 for name in sorted(actual):
  data=(B/'readback-v152-v075'/name).read_bytes();assert not any(marker.lower() in data.lower() for marker in FORBIDDEN),name
  if name!='sce_sys/param.sfo':assert sha(data)==staging['files'][name]['sha256'],name
 installed=sfo((B/'readback-v152-v075/sce_sys/param.sfo').read_bytes());assert installed['TITLE_ID'][1].rstrip(b'\0')==b'RYUN00001' and installed['CATEGORY'][1].rstrip(b'\0')==b'gp' and installed['APP_VER'][1].rstrip(b'\0')==b'01.52'
 assert not any('ACCOUNT' in key or 'USER' in key or 'PSN' in key for key in installed)
 module=(B/'readback-v152-v075/sce_module/ctr_online.prx').read_bytes();assert module==(WORK/f'ctr-v152-{lang}/build/ctr_online.prx').read_bytes();assert len(module)<1024*1024
 assets=(B/'readback-v152-v075/archives/update3.pak').read_bytes();assert len(assets)==native_assets['bytes'] and sha(assets)==native_assets['sha256']
 assert (B/'readback-v152-v075/sce_module/ryunet-updater.txt').read_bytes()==f'RYUNET-PS4-UPDATER-ABI1:{lang}\n'.encode()
 match=re.search(r'Package checks passed: (\d+); platform-key-only checks: (\d+)',p.stdout);assert match
 checks[lang]={'pkg':info,'integrity_checks_passed':int(match[1]),'platform_key_only_checks':int(match[2]),'readback_files':sorted(actual),'base_binding_negative_checks':negative,'personal_data_files_included':False,'owner_markers_found':False,'source_module_matches':True,'native_assets_match':True,'native_assets_sha256':sha(assets)}
report={'successful':True,'languages':checks,'console_files_written':False,'published':False,'hardware_test_pending':True}
(ROOT/'PKG_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'successful':True,'languages':list(checks),'payload_files_per_language':len(ALLOWED),'personal_data_included':False,'hardware_test_pending':True},indent=2))
