// Test-only platform boundary. The production files are included unchanged.
#include <stdarg.h>
#include "online_core.h"
typedef int64_t (*System)(int64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);
static System system_call;
static int (*fetch_call)(uint8_t*,size_t,size_t*);
static void *(*worker)(void*);
static void *worker_arg;
static int spawn_result;
int64_t ctr_syscall(int64_t number,...){
    va_list a;va_start(a,number);uint64_t v[6]={0};
    switch(number){
        case 3: case 4:v[0]=va_arg(a,int64_t);v[1]=(uint64_t)va_arg(a,void*);v[2]=va_arg(a,size_t);break;
        case 5:v[0]=(uint64_t)va_arg(a,const char*);v[1]=va_arg(a,int);v[2]=va_arg(a,int);break;
        case 6:v[0]=va_arg(a,int64_t);break;
        case 10:v[0]=(uint64_t)va_arg(a,const char*);break;
        case 73:v[0]=(uint64_t)va_arg(a,void*);v[1]=va_arg(a,size_t);break;
        case 74:v[0]=va_arg(a,uint64_t);v[1]=va_arg(a,size_t);v[2]=va_arg(a,int);break;
        case 95:v[0]=va_arg(a,int64_t);break;
        case 124:v[0]=va_arg(a,int64_t);v[1]=va_arg(a,int);break;
        case 128:v[0]=(uint64_t)va_arg(a,const char*);v[1]=(uint64_t)va_arg(a,const char*);break;
        case 136:v[0]=(uint64_t)va_arg(a,const char*);v[1]=va_arg(a,int);break;
        case 477:v[0]=(uint64_t)va_arg(a,void*);v[1]=va_arg(a,size_t);v[2]=va_arg(a,int);v[3]=va_arg(a,int);v[4]=va_arg(a,int);v[5]=va_arg(a,int64_t);break;
        case 591:v[0]=va_arg(a,int);v[1]=(uint64_t)va_arg(a,const char*);v[2]=(uint64_t)va_arg(a,void*);break;
        case 592:v[0]=(uint64_t)va_arg(a,void*);v[1]=va_arg(a,size_t);v[2]=(uint64_t)va_arg(a,void*);break;
        case 593:v[0]=va_arg(a,int);v[1]=(uint64_t)va_arg(a,void*);break;
        default:va_end(a);return -999;
    }
    va_end(a);return system_call?system_call(number,v[0],v[1],v[2],v[3],v[4],v[5]):-999;
}
int ctr_assets_download_start(void *(*entry)(void*),void *arg){worker=entry;worker_arg=arg;return spawn_result;}
int ctr_assets_fetch(uint8_t*out,size_t cap,size_t*length){return fetch_call?fetch_call(out,cap,length):-1;}
#define same asset_same
#include "native_assets.c"
#undef same
#include "native_asset_migration.c"
CTR_EXPORT void test_reset(System s,void *fetcher,int spawn){
    system_call=s;fetch_call=(__typeof__(fetch_call))fetcher;worker=0;worker_arg=0;spawn_result=spawn;
    checked=source=routed=delegated=0;delegated_result=0;pending_size=0;
}
CTR_EXPORT int test_verify(const char*path){return ctr_assets_verify_file(path);}
CTR_EXPORT int test_store(const uint8_t*data,size_t size){return ctr_assets_store(data,size);}
CTR_EXPORT int test_migration(int32_t*result){return ctr_assets_migration(result);}
CTR_EXPORT int test_worker(void){if(!worker)return -1;worker(worker_arg);worker=0;return 0;}
CTR_EXPORT int test_route(uint64_t base,const void *info){return ctr_assets_route_init(base,info);}
