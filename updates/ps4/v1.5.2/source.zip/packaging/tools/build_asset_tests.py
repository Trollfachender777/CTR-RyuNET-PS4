from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
module=root.parent/f'ctr-v152-{sys.argv[1]}'
llvm=root.parent/'ps4-online/llvm/bin'
target=module/'build/asset_test.obj'
subprocess.run([str(llvm/'clang.exe'),'--target=x86_64-pc-windows-msvc','-ffreestanding','-fno-builtin','-fno-stack-protector','-O1','-Wall','-Wextra','-Werror',f'-DCTR_MODS_EN={int(sys.argv[1]=="en")}',f'-I{module/"src"}','-c',str(root/'asset_test_shim.c'),'-o',str(target)],check=True)
objects=list((module/'build').glob('*-host.obj'))
subprocess.run([str(llvm/'lld.exe'),'-flavor','link','/dll','/noentry','/machine:x64',f'/out:{module/"build/asset_test.dll"}',*map(str,objects),str(target)],check=True)
print('Built asset platform tests:',sys.argv[1])
